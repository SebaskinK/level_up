# 连续 RGB-D 直出 3DGS：跨帧去冗余调研

**更新**：2026-09-16
**范围**：仅 RGB-D 连续图像流（不依赖 IMU / LiDAR / 多相机外参 rig）。目标是从连续帧直出 3D 高斯，并避免同一表面被反复建成新基元。
**定位**：调研文档，不选定方案。单帧解析构造已定稿于 `SINGLE FRAME/scripts/h_pipeline_final.py`；本文件只回答「第二帧起怎么并进一张图」。
**实验 J 铺垫**（同目录 `exp_j_gt_skip5.py`）：用 TUM `groundtruth.txt` 把第 n 帧 3DGS 刚体变换到第 n+5 帧，ray-disc / EWA 均可复用。说明「单帧盘 + 位姿」在相邻乃至跨 5 帧（约 0.16 s、平移 6–8 cm、转角 4–6°）几何上是通的。缺的是**关联与去冗余**，不是单帧构造。

---

## 0. 问题与约束

### 0.1 要什么

输入：RGB-D 相机的连续流 \(\{(I_t, D_t)\}_{t=0}^{T}\)，已知内参，深度与彩色已对齐（或可 associate）。

输出（直出，不强制一次出齐）：

1. 一组可渲染的 3D 高斯 / surfel（位置、法线/朝向、尺度、颜色、不透明度）。
2. 每帧相机位姿 \(T_t \in SE(3)\)（世界系）。位姿可以是算法自产，也可以暂时用外部轨迹做对照（实验 J 用的是 TUM GT）。
3. **跨帧不爆炸**：同一静止表面被反复看到时，不应每帧再铺一层盘。RTG-SLAM 在 4838 帧酒店场景上给出过量级：有剔除 675,818 个高斯 vs 无剔除 1,073,366 个；同场景 RTG ~98 万 vs SplaTAM 715 万（约 7.3×）。

单帧侧已经解决的（见 `SINGLE FRAME/scripts/RESEARCH.md`）：曲率定尺 \(r=\sqrt{2\varepsilon/|k|}\)、贪心椭圆占领、纹理掩模 + S2 回填、解析零优化。跨帧要解决的是**同一盘在时间上的身份**，不是再发明一套半径公式。

### 0.2 传感器约束（硬）

- **只有 RGB-D**。不假设 IMU、轮速、LiDAR、多目外参、运动捕捉。
- 输出是**连续图像流**，不是事先拍好、可乱序的照片集。算法必须能在流上运行；离线批处理可以当作对照，但不能当作唯一解。
- 深度有量化、空洞、飞点（TUM/Kinect：\(\Delta z \approx 0.0029 z^2\)，2 m 处约 11.6 mm）。关联判据必须能在这种噪声下工作。
- 场景是静止的。

### 0.3 两类合法路线（不做限制）

文献里跨帧 3DGS 只有两种骨架，都符合「仅 RGB-D」：

| | **A. 大一统 / 批处理** | **B. 增量 / 迭代** |
| --- | --- | --- |
| 何时出高斯 | 先攒齐（或分段攒齐）位姿与点，再一次性或分段拟合高斯 | 第 1 帧建成图，第 2 帧起只补新观测 |
| 典型前身 | COLMAP/SfM → 3DGS；TSDF 融完再提取 | KinectFusion / ElasticFusion；GS-SLAM 家族 |
| 去冗余发生在 | 融合体素 / 全局点云阶段，高斯诞生时已经是「一张图」 | 每帧的「要不要新建」门：投影关联、体素占用、silhouette、误差图 |
| 流式 | 弱（要等、或滑动窗口假装批） | 强（录完即可、可边扫边看） |
| 与本项目单帧解析构造 | 把每帧解析盘当「带属性的点」，再做一次全局融合/抽样 | 把第 n 帧解析盘投影到模型上，命中则更新、不命中才 `build_hybrid` |

两条路不是对立宗教。很多系统是 **B 的前端 + A 的回环/全局再优化**（RTG-SLAM、GSFusion 的 post-scan global opt）。本项目也可以：增量保不爆炸，必要时再做一次全局整理。

在 A/B 之上还有一档**时间粒度**：不必每帧都做同等份量的事，也可以按**关键帧**做一次局部整理。这不是第三条建图哲学，是增量路线里很常见的调度——SLAM 和视频编码都用。

### 0.4 关键帧局部优化（SLAM 与视频编码同构）

**SLAM 侧**：前端每帧只跟踪；建图、局部 BA、加路标，集中在关键帧。ORB-SLAM 的 local mapping 线程、ElasticFusion 的关键帧变形、GSFusion「关键帧 m 次迭代 / 非关键帧 n 次 + 随机回放旧关键帧」、RTG 的优化时间窗，都是「普通帧便宜、关键帧才动结构」。

**视频编码侧**：GOP 里 I 帧全量编码，P/B 帧只编相对关键帧（或已重建帧）的残差；码率控制也以 GOP/关键帧为单元做局部率失真，而不是每一帧独立闭式。思想是：**时间上相邻的观测高度相关，不必每帧重解一次，隔一段把窗口内的冗余收一次。**

映射到本项目（仍是调研，不定方案）：

| 帧类型 | 便宜动作（每帧） | 关键帧才做的局部动作 |
| --- | --- | --- |
| 普通帧 | 投影关联、置信 +1、颜色/法线加权；不命中才少量新建 | 无，或极浅更新 |
| 关键帧 | 同上 | 对**当前可见子集**做一次局部整理：再贪心覆盖、合并过近盘、时序平均法线/曲率、可选局部光度/几何拟合 |

关键帧怎么选，文献里现成：视差/运动超过阈值、新建基元数超过阈值（GSFusion 用「本帧新建数 > 50」）、固定间隔（视频 GOP）。静止场景下，运动阈值和「新建数」几乎是同一件事——相机扫到新表面才值得开一次局部优化。

和 A/B 的关系：这是 **B 的调度**，窗口可以短到数帧（像 P 帧），也可以在回环处放大成局部 A。它不强迫打开 Kerbl 式 densify，也不强迫每关键帧 50 次梯度；局部整理可以仍是解析的（合并、再占领、加权平均）。

---

## 1. 先把「位姿」从「建图」拆开

连续 RGB-D 直出 3DGS 其实是两个问题叠在一起：

1. **\(T_t\) 从哪来**（仅 RGB-D）。
2. **高斯集合怎么随 \(T_t\) 长**（去冗余）。

实验 J 用 GT 把 (2) 单独测通了。下面先列 (1) 的现成选项，再集中写 (2)。

### 1.1 仅 RGB-D 的位姿来源

| 家族 | 做法 | 传感器 | 流式 | 备注 |
| --- | --- | --- | --- | --- |
| **Frame-to-model ICP** | 当前深度对齐已有模型（TSDF 或 surfel 渲染深度） | RGB-D | 是 | KinectFusion、ElasticFusion、RTG-SLAM 前端。纹理弱、几何强时稳；纯平面会漂 |
| **光度 + 深度可微跟踪** | 渲染当前图，对位姿反传 \(L_\text{color}+\lambda L_\text{depth}\) | RGB-D | 是 | SplaTAM、MonoGS、GS-SLAM。依赖可微渲染；大运动（实验 J 那种 6–8 cm）容易丢 |
| **特征 RGB-D VO** | FAST/ORB + 描述子 + RANSAC，深度给 3D，再 ICP 精修 | RGB-D | 是 | Henry 2012 RGB-D Mapping；ORB-SLAM2 RGB-D 模式。回环能力强 |
| **场景流 / RGB-D 里程计** | 稠密光流 + 深度，估计刚体 \(\Delta T\) | RGB-D | 是 | 本仓库 986 默认 DIS 残差 + 刚体扩内点；自产轨迹，**建图不用 GT**。`valid` / `expanded` 接 985 身份 |
| **批 SfM** | COLMAP 等，全序列一起 | 主要用 RGB，深度可作尺度 | 否 | 「大一统」标准入口。手持近桌、运动模糊、弱纹理键盘区会不稳；且违反「流上直出」除非当离线对照 |

**对约束的含义**：不需要 IMU。ICP / 特征 / 场景流 / 可微跟踪都能只吃 RGB-D。建图位姿用 986 自产，不用 GT。帧间对应直接用同一管线的稠密流，不必另喂一条轨迹再算一遍光流。

---

## 2. 大一统路线：先一张几何，再出高斯

思想：跨帧冗余在**几何融合**里消掉，高斯只从融合结果采样一次。

### 2.1 经典体积融合（零或几乎零外观优化）

**KinectFusion**（Newcombe et al., 2011）把每帧深度积分进 TSDF 体素，加权平均。同一表面被多次看到，只是同一个体素的权重 +1，不会长出第二层。位姿用 frame-to-model ICP。产物是网格，不是 3DGS。

**Voxel hashing / Voxblox / Supereight2**：可扩展的 TSDF，仍然是「体素身份 = 表面身份」。

对 3DGS 的用法有两种：

- 融完提取 mesh / 点，再在面上撒高斯（离线 3DGS 的深度版）。
- **边融边在新体素上长高斯**——这就是 GSFusion（下一节增量里也会出现，因为它是混合体）。

优点：去冗余几乎免费，几何一致。缺点：外观是体素里的平均色，照片级差；分辨率被体素边长锁死（GSFusion 用 1 cm）。本项目单帧盘的半径是曲率闭式，比固定体素细；若走这条路，等于放弃「先判后建」的尺度，改成「体素格子」。

### 2.2 经典 surfel 融合（最接近本项目的零优化前身）

**Point-based Fusion**（Keller et al., 3DV 2013）与 **ElasticFusion**（Whelan et al., RSS 2015）：

- 每个 surfel：位置、法线、半径、颜色、**置信计数**、时间戳。
- 半径由深度与焦距闭式给出，类似本项目 footprint，没有曲率。
- ElasticFusion 还做非刚性变形（world 坐标可弹）处理环路；本项目当前场景可先当刚体。

这几乎就是 `SINGLE FRAME/scripts/OPEN_ITEMS.md` A1 里已经写过、尚未实现的机制。差别只是：他们的半径更粗、没有曲率各向异性、没有纹理掩模混合；本项目可以把「新建」换成对未覆盖像素调用 `build_hybrid`。

**像素级融合怎么做**（不是两张 RGB 对像素相加，而是当前帧每个深度像素去认模型里的哪块盘）：

1. **把已有盘画到这一帧**（所以每像素 \(O(1)\)）。用当前位姿把模型 splat 成和输入一样大的图：深度、**index**（该像素打到哪块 surfel）、法线/颜色。每个像素查 index 就知道对应哪块盘，不必在 3D 里做最近邻。
2. **这个像素能不能认那块盘**（三条门）。像素反投影得点 \(p\)、法线 \(n\)，对应盘 \(s\)：沿法线距离 \(|(p-s.\mathrm{pos})\cdot s.\mathrm{normal}|\)；法线夹角 \(n\cdot s.\mathrm{normal}\)；半径与 footprint 相容。三条都过 → 命中。
3. **命中：像素融进盘**（解析，不反传）。置信 \(w\) 加权平均位置/法线/颜色，\(w\leftarrow w+1\)（有上限）；半径有时按更近、更正对的观测收紧。同一块墙很多像素打到同一块盘 = 这块盘被多次平均。
4. **未命中：该像素变成新盘**。用反投影 + footprint 半径新建；长期看不见或 \(w\) 一直低则扔。

和本项目的对应：第 1 步已有 ray-disc（hit + index + 深度）；缺的是第 2–4 步用 index 去更新全局 \(\mathcal{S}\)，而不是每帧再 `build_hybrid` 一套新盘。RTG 三类像素是同一套 index 图上的门，后面多了可微迭代，融合本身不是迭代。

- **谁在何时：** 没有可微优化。每帧所有命中像素解析地更新对应盘；置信 \(w\) 当「被更新次数」。长期低置信 / 看不见则删。位姿 frame-to-model ICP，不与盘绑在一个反传环。RTG 的稳定/不稳定是这套的高斯版。本项目跨帧要抄的就是这一层。

### 2.3 离线 3DGS 批处理

**3D Gaussian Splatting**（Kerbl et al., 2023）：COLMAP 点云初始化，然后数万次光度迭代、梯度 densify/prune。去冗余靠优化过程中的 clone/split/prune，不是几何身份。需要多视角、已知（或 SfM）位姿、离线分钟级。

- **谁在何时：** 基线调度——位姿冻结（SfM 已给），**全部高斯**打数万步光度；densify/prune 按视角空间梯度启发式长/删，没有稳定冻结。后来所有在线方法都是在改这一条。

深度监督 / 曲率优化的变体（GeoSplat 2025、Depth-Supervised Curvature-Optimized 3DGS 2025）仍然是「先优化再纠偏」，与本项目单帧零优化相反，见单帧 `RESEARCH.md` §2。

**对约束**：能出高质量新视角，但（1）不是流式直出；（2）冗余控制不可解释（N 由梯度启发式长出来）；（3）本项目已经能解析出盘，再丢进这个优化器等于把闭式尺度当初始化——可以做对照，不是主线。

**事后合并 — NanoGS**（Xiong, Liu, Zhou, Chen, Fan, Feng；USC ICT / TAMU，arXiv:2603.16103v3，2026）

问题：3DGS 动辄百万 splat，压缩方法大多还要 GPU + 训练图再优化。NanoGS 是 **training-free compaction**：只拿已经训好的高斯 PLY，不要图像、不要位姿、不要 CUDA 训练，CPU 上把 N 压下去，参数化仍是标准 3DGS，渲法不用改。

做法拆成可替换的三截（他们强调框架比算子新）：

1. **候选拓扑**：对当前 splat 中心建稀疏 kNN 图，只考虑邻居对，复杂度 \(O(kN)\) 而不是全对。
2. **代价**：\(\mathcal{C}(i,j)=\mathcal{D}_\mathrm{geo}+\mathcal{D}_\mathrm{app}\)。几何项是「两个高斯的混合 \(\tilde p_{ij}=\pi\mathcal N_i+(1-\pi)\mathcal N_j\)」对「矩匹配得到的单高斯 \(q_m\)」的 KL / I-散度；再加外观差。
3. **合并算子（MPMM）**：质量守恒矩匹配，一对变一个（质量加权均值/协方差，偏向前一个更大的；不透明度按概率并；外观加权平均）。

调度：先按 \(\alpha\) 丢掉几乎看不见的；然后反复——建 kNN → 给边打分 → **贪心选互不相交的低代价边**（可并行塌）→ 更新集合，直到达到保留比 \(\rho\)。

**闭式 vs 蒙特卡洛（必须说清的坑）：**
两个**单个**未归一高斯 \(p_i=m_i\mathcal N_i\)、\(p_j=m_j\mathcal N_j\) 的 I-散度有闭式（附录式 13–14）：

\[
D(p_i\|p_j)=m_i\Big(\log\frac{m_i}{m_j}+\mathrm{KL}(\mathcal N_i\|\mathcal N_j)\Big)-m_i+m_j
\]

\[
\mathrm{KL}(\mathcal N_i\|\mathcal N_j)=\tfrac12\Big(\mathrm{tr}(\Sigma_j^{-1}\Sigma_i)+(\mu_j-\mu_i)^\top\Sigma_j^{-1}(\mu_j-\mu_i)-3+\log\frac{\det\Sigma_j}{\det\Sigma_i}\Big)
\]

这是高斯混合约化文献里的标准式。但 NanoGS **真正打分的是混合对单高斯**（式 15）。\(\log(\pi\mathcal N_i+(1-\pi)\mathcal N_j)\) 没有闭式，实现里用从混合里抽样的蒙特卡洛（式 16–17，固定少量样本、候选对共用随机数）。所以 **NanoGS 不是全解析**。若本项目要纯解析合并，只能拿上面「单高斯对」闭式当代理——近似，平坦区过近盘可能够用。

效果（21 场景：NeRF-Synthetic / Mip-NeRF 360 / Tanks&Temples / Deep Blending）：相对对比方法，\(\rho=0.1\)（留 10%）平均 **+2.40 dB**，\(\rho=0.01\) +4.84 dB，\(\rho=0.001\) **+5.46 dB**。极端压缩时优势更大。不改表示，可再叠一层 bit 压缩。

- **谁在何时：** 部署后、无图像监督、不反传。对本项目：可挂在 P1/P4「过近盘合并」当可选算子，**不是跨帧身份**（不认新像素、不替代 ElasticFusion）。单帧曲率贪心已经在构造时压过 N，NanoGS 是事后再压已经存在的 \(\mathcal{S}\)。

**GMR 家族：合并算子 = 矩匹配，分歧只在「选哪一对」（2026-09-16 补检索）**

仓库此前只记了 NanoGS 一条。补一轮检索后结论：**合并算子**与**相似性判据**在文献里是两条分开的
线，而且最干净、最权威的答案不在 3DGS 圈，在更老的高斯混合约简（GMR，多目标跟踪）文献里。

**合并算子本身 = 矩匹配，所有路线共用。** 对两个带权高斯 \((w_i,\mu_i,\Sigma_i)\)、
\((w_j,\mu_j,\Sigma_j)\)：

\[
w_{ij}=w_i+w_j,\qquad
\mu_{ij}=\frac{w_i\mu_i+w_j\mu_j}{w_{ij}},
\]

\[
\Sigma_{ij}=\frac{w_i\big(\Sigma_i+(\mu_i-\mu_{ij})(\mu_i-\mu_{ij})^\top\big)+w_j\big(\Sigma_j+(\mu_j-\mu_{ij})(\mu_j-\mu_{ij})^\top\big)}{w_{ij}}
\]

保零阶、一阶、二阶矩，完全闭式、O(1)。NanoGS 的 MPMM 就是它（外观加权平均、α 按概率并）；
Runnalls / Salmond / Williams 全都用它——分歧只在「选哪一对」，不在「怎么并」。对本项目特别顺：
盘已有 `axis1/axis2/normal` + `scale[r1,r2,thin]`，\(\Sigma=R\,\mathrm{diag}(r_1^2,r_2^2,(0.1r_1)^2)R^\top\)
直接可写，并完后对 \(\Sigma_{ij}\) 再特征分解回 axis/scale/quat，零迭代；置信 \(w\)（P1 里本来就要记）
正好当权重。

同一算子的退化版是 Keller 2013 / ElasticFusion 的 surfel 融合——只并均值不并协方差：
位置/法线/颜色按 \(w\) 加权平均、\(w\leftarrow w+w'\)，半径取更近/更正对那个观测。这正是
`OPEN_ITEMS.md` §1.1 已拍板的「命中加权」，只是现在**冻结半径**、没在盘-盘之间用它。

**相似性判据（选哪一对）才是真正有货的部分，Runnalls 2007 给的是闭式上界：**

\[
B(i,j)=\tfrac12\Big[(w_i+w_j)\log\det\Sigma_{ij}-w_i\log\det\Sigma_i-w_j\log\det\Sigma_j\Big]
\]

这是「并掉这一对后、混合相对合并前的 KL 散度上界」，闭式、只要三个 \(\log\det\)。Runnalls 的贡献
正是指出 Salmond / Williams 的判据在某些情形有反常行为，而 KL 才是该看的量。同族另外三个：

- **Salmond**（类内距增量）：\(\tfrac{w_iw_j}{w_i+w_j}(\mu_i-\mu_j)^\top\Sigma^{-1}(\mu_i-\mu_j)\)，闭式。
- **Williams ISD**（积分平方差）：对高斯混合**完全闭式**（这点常被忽略——ISD 不像 KL 那样对混合无闭式）。
- **NanoGS 混合-对-单高斯 I-散度**：\(\log(\pi\mathcal N_i+(1-\pi)\mathcal N_j)\) 无闭式，蒙特卡洛。

上一条（NanoGS）已记「不是全解析、只能拿单高斯对闭式当代理」。**Runnalls \(B(i,j)\) 就是那个代理的
正规版本**，而且比记下的那个 \(D(p_i\|p_j)\) 更对——后者**有向**（i 逼近 j），\(B(i,j)\) **对称**、直接量
「并掉这一对损失多少信息」。

**一个从公式推的性质（非论文说法，需自行验证）：\(B(i,j)\) 接矢高预算 \(\varepsilon\)。** 合并协方差里的
展布项 \((\mu_i-\mu_{ij})(\mu_i-\mu_{ij})^\top\) 在薄盘上有很好的行为：

- 两盘**共面并排** → 展布落在切平面内，\(r_1\) 或 \(r_2\) 变大、薄轴不变 → \(\det\) 温和增长 → 代价小。
- 两盘**沿法线错开** → 展布落在薄轴上（原本只有 \(0.1r_1\)）→ \(\det\) 暴涨 → 代价极大。

即 \(B(i,j)\) 自动变成「合并后盘必须鼓多厚」的惩罚，与单帧 `RESEARCH.md` §3.3 的矢高预算 \(\varepsilon\)
是**同一个物理量**：阈值可直接定成「允许薄轴从 \(0.1r\) 涨到多少」，而不是拍一个无量纲分数。

**两个补充形态（不是成对塌边）：**

- **Surfel Set Simplification**（OFP, IEEE Access 2016）：局部邻域塌缩，一次把一个 surfel 及其邻域整团
  换成少数几个新 surfel，按几何+纹理复杂度排优先级。比成对合并更适合「一片细带全是小盘」的形态。
- **Compact FF-3DGS**（arXiv:2608.10712, 2026）：saliency 引导自适应超像素把每像素高斯聚成变尺寸簇，
  学习式 encoder 压成 latent、跨视角 match+merge、LOD decoder 解出，做到 1/20 基元数。**关键对照**：
  它把「纯矩匹配」当 baseline 测出 **PSNR 13.29 vs 它的 17.09**——成对矩匹配在大压缩比下明显掉质量。
- **CVT-GS**（2026）：optimization-free post-hoc，Centroidal Voronoi Tessellation 简化、输出标准 3DGS，
  免优化、与零优化路线兼容，值得查原文。

另登记未展开：**Wasserstein-Distance-Based GMR**（IEEE SPL）、**EGG-Fusion**（SIGGRAPH Asia 2025）。

**超像素播种 — Superpixel-guided Sampling for Compact 3DGS**（Kim, Jeong, Park, Han；Korea University，ACM VRST 2024，DOI:10.1145/3641825.3687719）

输入是 **RGB-D + 已知位姿** 的序列（不是纯 RGB 的 COLMAP 点云）。先选关键帧；对每张关键帧 RGB 做 **SLIC 超像素**；把每个超像素中心用深度反投影到 3D，**一个超像素初始化一个高斯**，再交给标准 3DGS 优化。边界跟着颜色/纹理走，不是图像网格的 stride。

对实验 A/B 的点：A 证明均匀降采样（s2/s4/s8）覆盖掉、精度按 \(r\tan\theta\) 赔；B 里颜色纹理会迫使细分。超像素把颜色相近的像素先聚成一团，墙壁上的条纹不会像规则网格那样无谓碎开；纹理密的地方超像素自然更碎，高斯也更密。粒度仍由 SLIC 的网格密度/紧致度旋钮决定，不是曲率。

- **谁在何时：** **只改初始化播种**，后面仍是 Kerbl 式数万步 + densify（有优化、要多视角光度）。对本项目：单帧已用曲率 \(r=\sqrt{2\varepsilon/|k|}\) + 纹理掩模定尺，不必再接 SLIC 当前端；跨帧认盘（§2.2 每个像素去认旧盘）也不靠超像素。应记成「彩色点云按视觉团块抽稀」——你印象里的那种降采样文献在这里，不在像素融合那一节。

### 2.4 Feed-forward 网络直出

DepthSplat、FreeSplat / FreeSplat++、SurfelSplat / SurfaceSplat、ViewSplat、AA-Splat 等：训练一次，稀疏视图进、高斯出，免逐场景优化。

- **谁在何时：** 创新是把优化从「每个房间」挪到「网络训练一次」。部署时不对新场景的高斯做迭代。连续流上每帧前馈仍会重复预测同一表面，去冗余还是要另做。

**对约束**：免的是「这个房间再训 30 分钟」，不是「免网络」。需要大规模训练数据；尺度/朝向由网络回归，与曲率闭式冲突；连续流上每帧都前馈会把同一表面预测无数次，**去冗余仍要另做融合**。与「解析、无网络、测量直出」路线相反，作边界文献即可。

---

## 3. 增量路线：有了第一帧，再决定第二帧加什么

这是与「连续图像流直出」最贴的一簇。按**用什么当「已经有了」的判据**分组。

### 3.1 渲染覆盖 / 误差门（3DGS-SLAM 主流）

共同骨架：跟踪（估 \(T_t\)）→ 用当前模型渲染 → 看哪些像素「没被解释」→ 只在那些像素上播种新高斯 → 再优化一小步。

下列方法凡在「谁在何时被优化」上有创新点的，单独标出（第 4 层：离线全图 / 在线子集 / 稳定冻结 / 位姿是否与高斯绑在一个可微环）。基元与渲染差异不在此重复。

**SplaTAM**（Keetha et al., CVPR 2024）

- 输入：单目 RGB-D，无先验位姿。
- 跟踪：可微渲染，光度 + 深度。
- 稠密化：渲染深度与 silhouette，做 mask——地图已经密的地方不加。新高斯从当前深度反投影。
- 高斯各向同性。N 很大（酒店场景 ~715 万量级的对照来自 RTG 论文）。
- 速度慢（ScanNet++ 上 GSFusion 对照：0.19 fps）。

启发：本项目实验 J 已经在做「渲染当前模型看覆盖」。缺的是把 hit/误差图当成**新建门**，而不是只当评测。

**GS-SLAM**（Yan et al., CVPR 2024）

- 自适应扩展：用透明度决定加/删。
- 跟踪用从粗到细选出的可靠高斯。
- 仍是梯度 densify 家族，N 控制弱于几何门。
- **谁在何时：** 跟踪不拿全部高斯反传位姿，先按粗到细筛一子集再优化 \(T_t\)（运行时「哪些基元进跟踪损失」是创新点）。建图仍每帧/关键帧对地图高斯做梯度更新。

**Gaussian-SLAM**（Yugay et al., 2023/24）

- 场景切成 **submap**，各自优化，不必常驻全部高斯 → 可扩展。
- 播种策略针对「新探索区域」，强调可控、非梯度 clone。
- 跟踪：frame-to-model 光度 + 几何。
- **谁在何时：** 创新是空间调度——只优化当前 submap，旧块卸出内存、不参与本帧反传。不是「稳定冻结」，是「分块活跃集」。对本项目：房间级再考虑；桌面暂不必。

**MonoGS / Gaussian Splatting SLAM**（Matsuki et al., CVPR 2024）

- 高斯表示同时服务跟踪、建图、渲染。
- 在深度附近按方差放置高斯，几何校验后剪枝。
- 可 RGB-D 也可偏单目。报道过 Replica 上较快的高斯 SLAM 之一。

**共同问题（相对本项目）**：他们的「加一个高斯」是反投影一个像素 + 后续优化把尺度学出来。本项目「加一个」是跑一段曲率贪心，半径已经对。所以增量时不应逐像素播种，而应 **对未关联像素跑 `build_hybrid`，或对未关联连通域跑局部贪心**。否则又退回「先密后减」。

### 3.2 显式三类像素 + 稳定/不稳定（最接近已有设计稿）

**RTG-SLAM**（Peng et al., SIGGRAPH 2024）——单帧 `RESEARCH.md` 与 `OPEN_ITEMS` A1 已点名。补全与跨帧相关的机制：

- **仅 RGB-D**（Azure Kinect 实物演示）。前端 frame-to-model ICP，后端 ORB 路标图优化。不需要 IMU。
- 高斯强制二分：不透明（α≈0.99）拟合表面+主色，近透明（α≈0.1）拟合残差色。深度按 **不透明盘的射线–平面交** 读出（和本项目 ray-disc 同族），因此一块平面一个不透明高斯就够，不必叠很多半透明球。
- 每帧只对三类有效深度像素考虑新建：
  1. 新观测（模型没盖住）
  2. 颜色误差大
  3. 深度误差大
- 新观测 / 深度误差 → 采样约 5% 像素，初始化**不透明**高斯（尺度由到最近三邻的间距闭式，第三轴 0.1×，与本项目 `THIN_AXIS_RATIO=0.1` 同构）。
- 仅颜色误差且对应不透明高斯已稳定 → 加一个**透明**残差高斯，避免把旧几何拧坏。
- **稳定 / 不稳定**：置信计数超过阈值则稳定，不再优化；只渲染、只反传不稳定高斯覆盖的像素。
- 长期错误 → 剔除。酒店 4838 帧：有剔除 675,818 vs 无剔除 1,073,366。
- 每关键窗约 50 次迭代（不是本项目的零优化）。α 永不优化。
- **谁在何时（本篇主创新）：** 位姿不进高斯可微环（ICP 外挂 + ORB 后端）。高斯按置信分成稳定/不稳定——稳定者冻结、不反传；每窗只优化不稳定子集，且只渲染它们盖住的像素（tile 不足 50% 直接丢）。新建用三类像素门而非 Kerbl 梯度 densify。α 创建时钉死、永不优化。

**对本项目**：A1 的三条关联（法线距、夹角、半径相容）+ 三类像素新建，几乎是从这里抄的几何门。差别是本项目可以把「采样 5% 像素初始化」换成「对未覆盖像素做曲率贪心」，半径用已有闭式，**不必 50 次迭代**。透明残差高斯对应单帧 A3「补残差色」——外观要再抬时才需要，几何去冗余不依赖它。第 4 层里可借的是「稳定冻结 + 位姿外挂」，不是 Adam 窗。

GPS-SLAM（Peng et al., CVM 2025，RTG 同组）见下一小节：几何整段交给 SDF，高斯退回残差色，对本项目可抄的管线很少。

### 3.2.1 GPS-SLAM：150 fps 不该拿来压 3DGS

同一组作者把 RTG 里最贵的「用高斯拟合几何」拆走。运行时是 **Gaussian-plus-SDF 混合体**，不是单一 PLY，也不是纯 3DGS。

- **谁在何时：** 几何（SDF）每帧融合+ICP，**不对高斯反传深度/法线**。高斯只在 SDF 底色差大的地方插入，短光度迭代（自称比 RTG 少约 75%）；α 可学。位姿外挂 ICP。他们强调不同于 GS-ICP「跟踪 100 fps、建图跟不上」——声称每帧 SDF 与高斯都更新完。第 4 层创新是「几何永不进高斯优化器」，不是新的稳定/不稳定。对本项目可抄的很少（无残差高斯、不走格子）。

- SDF（InfiniTAM 式 hash 格子）：几何 + 格子平均底色；融合约 0.1 ms/帧，抽出表面是零交叉 raycast（亚毫秒到几毫秒）。
- 一层 3D 高斯贴在 SDF 表面附近，只补残差色（数量约少 50%，迭代约少 75%）。渲染：先 SDF raycast 出深度和底色，再 order-independent 叠高斯。

实物 Azure 报 **150+ fps**（Replica 250+），对照他们自己的 RTG ~17 fps（其中高斯优化约 38 ms/帧）。实现是：ICP（SDF）→ 体积融合 → 只在 SDF 渲出色差大的地方插少量高斯做短光度迭代；无排序光栅 + 按高斯反传。采集端笔记本无线传图，桌面机算。

**几何速度精度应锁死 SDF 基线，不该和 3DGS 对打。** 引言自己承认经典 SDF（KinectFusion 一族）本来就是 **几百 fps**，短板是颜色糊、有洞，所以才叠高斯。跟踪/几何表里也会点 BundleFusion、ElasticFusion、ORB-SLAM2。外观才拿 SplaTAM / RTG 比 PSNR。把混合系统的帧率拿去压纯高斯 SLAM，宣传上成立，方法学上是把产出形态搅在一起比：赢的是「格子记账 vs 高斯扛墙」，不是「SDF 表面比解析盘更好」。

**体积融合就是 TSDF。** 空间切成格子，每格存截断有符号距离（表面前正、穿过为负）和颜色/权重。新帧沿视线把测量写进格子，与已有值加权平均——同一块墙多次看到只是权重 +1，不长第二层。抽出表面：沿格子找零交叉。盘是一张皮上的椭圆；SDF 是空间距离场，表面是等值面。GPS 用 SDF 当墙，高斯往墙上贴残差色。

**为什么那么多方法体素化：** 不是因为不会从一帧深度解析出表面。一帧皮已经能直出；难点是第二帧深度抖、量化格子换、法线偏，两张皮直接焊会叠层/留缝。体素用「世界系这个格子」当跨帧身份，不用认盘，所以 KinectFusion 能几百 fps。这是跨帧记账的懒办法，不是「表面必须从体积长出来」。盘路线的身份是 surfel，贵在投影关联（ElasticFusion）。

**融合和抽表面都很快。** 加权本身几乎可忽略（~0.1 ms/帧）。零交叉 raycast 通常亚毫秒到几毫秒，和融合在同一套 CUDA 管线里。GPS 每帧融合 + raycast + ICP 还能 150 fps，说明「积进去 + 抽出皮」加在一起也远小于 10 ms。时间便宜，几何分辨率贵：1 cm 零交叉没有 \(r=\sqrt{2\varepsilon/|k|}\) 细。

**和 GS-ICP 的差别（他们自己划的）：** GS-ICP 跟踪可以报 100 fps，但建图跟不上、扫完优化还没收敛，他们不承认那是真正实时重建。GPS 声称每帧 SDF 都融完、高斯也在线更完，所以敢报 150 fps。

**他们承认的限制：** 只有前端 ICP，大场景会漂（想靠 Loopy-SLAM 一类全局位姿）；渲染依赖 SDF 深度，SDF 几何错了外观一起坏。

**「别让高斯扛墙」** = 别用可微高斯去表示「墙在哪」。RTG 不透明高斯既当表面又当颜色；GPS 墙交给 SDF；本项目墙是解析盘。不是禁止用盘，是禁止再走 RTG 那种用高斯拟合几何。GPS 的高斯就是透明盘那种外观层——我们没有残差高斯、也不走格子，作为可抄管线参考价值很小。有用的是对照：同组自己把「高斯扛墙」拆掉了。

**公平对比该拆开：**

| 比什么 | 该对谁 | GPS 实际怎么报 |
| --- | --- | --- |
| 几何速度 | InfiniTAM / KinectFusion | 承认体素已经很快，150 fps 的大头在这 |
| 几何精度 | 同一套 SDF / 网格 | 有一部分，不是对 3DGS 的主表 |
| 外观 | 3DGS-SLAM | **主对比**（PSNR vs SplaTAM/RTG） |

把混合系统帧率拿去压纯高斯 SLAM，宣传上成立，方法学上不成立。解析盘不该跟这篇的 150 fps 对打。跨帧焊盘仍是 ElasticFusion，不是 SDF 上再恢复高斯。

**交付是偷懒的。** 运行时两套都要：SDF 才能 raycast 深度，高斯才能补色。使用方要网格得自己从 SDF 抽，要标准 3DGS 得自己消化「高斯不扛墙」。耗时和格式都扔给下游。本项目一套盘更干净（缺的是 C2 导出文件，不是故意留两套图）。

对本项目：**可抄的管线很少。** 几何别交给要迭代的高斯——这句话用解析盘已经做完。不引进 SDF。

### 3.3 体素占用门 + 图像四叉树（几何去重最干净）

**GSFusion**（Wei & Leutenegger, RA-L 2024）

- 输入 RGB-D；论文主实验用 **GT 位姿**（ScanNet++ / Replica），实物无人机用 OKVIS2（带 IMU）——**位姿不是它的贡献**，建图是。
- 深度积分进 octree TSDF（Supereight2）。RGB 按对比度做 **quadtree**：一块对比度够低就不再切。
- 叶心反投影到 3D，查最近体素：**体素权重 = 1（刚分配）才允许在此长一个高斯**；权重 > 1 说明来过，禁止再长。每个体素最多一个高斯。
- 新高斯：各向同性，尺度 = 该 quad 反投影到角点的长度，α=0.5，颜色=像素。之后仍做光度迭代（关键帧 m 次、非关键帧 n 次，随机回放旧关键帧防遗忘）；扫完还可全局再优化 10 次。
- ScanNet++：6.14 fps，模型 29 MB，对照 SplaTAM 0.19 fps / 206 MB、RTG 1.29 fps / 112 MB。

**对本项目**：

- 「体素来过就不建」是最便宜的跨帧身份，比渲染误差门更硬、更不依赖外观。
- 和曲率定尺的冲突：体素边长（1 cm）会盖过 \(r=\sqrt{2\varepsilon/|k|}\)。若用，应让体素只当**占用栅格**（hash 查询「这里有没有盘」），半径仍由单帧闭式决定，而不是 `S=diag(d,d,d)`。
- Quadtree 按对比度切，和本项目纹理掩模同源（平坦低对比 → 大单元；边缘 → 小单元）。本项目已经用曲率+掩模在单帧做了这件事，跨帧不必再切一棵树，除非想要「和 TSDF 共用一套空间索引」。
- 他们仍优化。本项目可以只借占用门，不借光度迭代。
- **谁在何时：** 创新是按关键帧分预算——关键帧 \(m\) 次光度、非关键帧 \(n\) 次，并把省下的步数随机回放旧关键帧防遗忘；扫完还可全局再优化。位姿主实验用 GT（不进可微环）。谁被创建由体素权重门决定，不是梯度 densify。

### 3.4 把高斯绑在像素 / 视图上（用表示本身防爆）

**VTGaussian-SLAM**（Hu & Han, ICML 2025）：view-tied 高斯，绑在深度像素上，**不学位置、旋转、多维方差**。省存储，可扩到大场景。跟踪和建图策略跟着这套简化表示改。

后续 **SGAD-SLAM**（2026）允许绑在射线上的高斯沿射线微移。

**对本项目**：单帧盘已经有 3D 位置和两个切向轴，绑回像素等于退化成「每像素一个 splats」。这能去冗余（每像素身份唯一），但会毁掉曲率压缩（桌面从 33k 盘变回数十万 splats）。只在「要可微跟踪、且接受密表示」时有意义。

### 3.5 几何感知的在线 densify（2026 对 3DGS-SLAM 启发式的批评）

**Geometry-Aware Online Mapping for 3DGS SLAM**（Luu et al., arXiv:2608.14902, 2026）指出：Kerbl 的 clone/split 在线时会不可控膨胀，且新 clone 的光度贡献被稀释导致 opacity 漂移；在线每关键帧只有几百次迭代，梯度 densify 来不及。主张几何感知的主动补洞，而不是等梯度。

这从反面支持本项目：**不要把跨帧去冗余交给 3DGS 的 densify**。用投影关联 / 体素占用 / 三类误差门，主动决定加不加。

- **谁在何时：** 本身不是新调度器，而是指出 Kerbl 那套「谁该被 clone」在线时失效——每关键帧只有几百步，梯度 densify 来不及、还会 opacity 漂移。创新在批评第 4 层套用离线启发式。

### 3.6 动态物体

Gassidy（Wen et al., 2024）、若干「光流提示 + 3DGS」动态 SLAM：把动的东西从建图里抠掉，否则同一位置会叠一层「人走过」。

当前 `fr1/desk` 以静景为主，可后置。连续流产品若会扫到人，需要「不关联动态像素」的掩模，986 的 `rigid_delta` 正好是这类分数。

---

## 4. 去冗余机制对照（只看「第二帧怎么不加重复盘」）

| 机制 | 代表 | 身份判据 | 是否优化 | 仅 RGB-D | 与本项目单帧盘 |
| --- | --- | --- | --- | --- | --- |
| TSDF 体素加权 | KinectFusion, GPS-SLAM 几何 | 同一体素 | 几何零优化 | 是 | 半径被格子取代，除非体素只当占用 |
| Surfel 投影关联 | ElasticFusion, Keller | 法线距 + 夹角 + 半径 | 零优化更新 | 是 | **直接可接 `build_hybrid` 的未命中像素** |
| 体素占用 + quadtree | GSFusion | 体素权重=1 才新建 | 仍光度迭代 | 建图是；位姿论文用 GT | 占用可借，尺度勿借 |
| Silhouette / 渲染空洞 | SplaTAM | 渲染没盖住 | 可微优化 | 是 | 实验 J 的 hit 图就是雏形 |
| 三类误差像素 | RTG-SLAM | 新观测 / 色差 / 深差 | 每帧 ~50 iter，只优化不稳定 | 是 | A1 设计稿；新建应改贪心而非 5% 像素 |
| 稳定/不稳定老化 | RTG, ElasticFusion | 置信计数 | 稳定者冻结 | 是 | 时序平均法线/曲率的入口 |
| 梯度 densify/prune | Kerbl, 多数 3DGS-SLAM | 位置梯度 | 必须优化 | 是（若有深度） | 与「先判后建」相反，不建议当主门 |
| Submap | Gaussian-SLAM | 空间分块 | 分块优化 | 是 | 房间级再考虑 |
| View-tied | VTGaussian-SLAM | 像素身份 | 参数极少 | 是 | 放弃曲率压缩 |
| 网络前馈 + 后融合 | DepthSplat 等 | 无内建身份 | 免逐场景、靠网络 | 通常多视图 RGB | 路线不合 |
| COLMAP 全局点再拟合 | 原版 3DGS | 点云已融合 | 离线优化 | RGB 为主 | 合法对照，非流式 |

没有一篇做到：**RGB-D 流 + 单帧曲率闭式盘 + 跨帧投影关联 + 完全零优化更新**。最近的空位仍是把本项目单帧构造接到 ElasticFusion/RTG 那类关联门上，并且**更新时不要打开 Kerbl 式 densify**。

---

## 5. 和本项目现状的接口

已经有的：

- 单帧 `build_hybrid`：~0.7 s/帧，N≈3.14 万，RMSE 4.01 mm，PSNR 26.19 dB（ray-disc）；EWA 可选 34.4 dB。
  （2026-09-16 位，含 aniso claim、曲率 floor×√2、quadric 核符号修正、min_gain 去重、
  `r_k1<floor` 救援；详见 `OPEN_ITEMS.md` §0.5 / §0.6 / §0.7 / §0.8。）
- 位姿：TUM GT（实验 J）、986 `trajectory.txt`（场景流，未接）。
- 刚体变换：`mu/normal/axis1/axis2` 乘 \(R^\top\) 再加 \(t\)，quat 重算（`exp_novelview.py` / `exp_j_gt_skip5.py`）。
- 读出：ray-disc 最近命中（默认）；EWA 椭圆加权（可选）。跨帧深度评测应沿用 ray-disc，避免 alpha 搅进几何门。

还没有的：

- 全局高斯集合 \(\mathcal{S}\)。
- 第 n 帧像素→盘表 + 场景流 warp 的身份（主通道）；ray-disc 仅冲突/新建兜底。
- 「命中 → 位置加权、种子写颜色、冻法线/半径、置信 +1；不命中且有深度 → 局部 `build_hybrid`」。
- 老化剔除。
- （位姿：用 986，不再列「自产」为缺口。）

### 5.1 可并行的研究原型（都不锁死）

**原型 P1 — 场景流身份增量（2026-09-14 拍板；ray-disc 降为兜底）**

1. \(t=0\)：`build_hybrid` → \(\mathcal{S}\)，并记下像素→盘。
2. \(t\ge 1\)：986 流把帧 n 的像素送到帧 n+1；默认归属仍是原盘。\(T_t\) 用 986 自产位姿把 \(\mathcal{S}\) 变到当前相机（世界系需要，认盘主通道不靠全图求交）。
3. 冲突门：点面距 / \(|X_1.z-z_{\mathrm{pred}}|\)（\(3\sigma(z)\)）。不做命中分支的法线夹角、半径相容。
4. 过门：位置加权；**FB 种子写颜色，刚体扩点不写颜色**；法线/半径冻结；置信 +1。
5. 流未打到且 `depth_valid`：剩余掩模 `build_hybrid` 新建（半径相容只在这里防叠层）。没深度不补。
6. 置信低且长期不见：删。

验证 N 是否不再随帧线性涨。这就是实验 C。

并列演进「先整帧 `build_hybrid` 再焊」（`OPEN_ITEMS.md` §3.7 第一条）本轮不走。P1 取「对齐后只拿差更新旧盘」。

**原型 P2 — 占用栅格增量（GSFusion 门，尺度仍闭式）**

世界系 hash：每个格子最多挂一个盘。新盘中心落入已占格子则弃。格子边长取 footprint 或 \(\varepsilon\) 量级，不要 1 cm 一刀切。比 P1 更粗、更快，斜面/薄结构会误杀。

**原型 P3 — 批融合对照（大一统）**

把 10–40 帧解析盘全部变到世界系，体素/半径下采样或 surfel 融合一次，再渲染新视角。用于回答「增量 P1 离全局融合还差多少」。不是产品路径，但是实验对照。

**原型 P4 — 关键帧窗口局部整理（§0.4）**

P1 的每帧关联照做；另设关键帧（固定间隔、或本帧新建数/运动超阈）。关键帧上只对当前可见盘做一次局部整理（合并过近、再贪心、时序平均），普通帧不跑。对应视频 GOP：I 帧整理、P 帧只残差式关联。可与 P1/P2 叠加，不是替代。文献里「关键帧干什么」并不统一，见 P6。

**原型 P5 — RTG-SLAM 可借鉴层（去掉 render-to-fit）**

当「在线 surfel 融合的高斯版说明书」，不当训练配方。不借：50 次 Adam、改版 CUDA 光栅化器、透明残差盘、SH 视方向、tile_mask 工程。透明盘不是解析的，单帧无定义，先不管（`OPEN_ITEMS.md` §3.5）。

可借（跨帧还没做的门和调度）：

1. **三类像素门** — 新观测 / 深差大 → 补不透明几何；只有色差 → 不要动已经稳的几何。本项目没有透明盘，色差大可以先不当「必须新建」，避免在已有表面上再铺一层。
2. **稳定 / 不稳定 + 置信** — 对得上就 +1，过阈冻结，长期对不上就删（Keller / ElasticFusion 同源）。时序平均法线用这个计数当权重。直接进 P1 第 4、6 步。
3. **新建用几何初值，不用梯度 densify** — 他们 5% 像素反投影；本项目应对未覆盖区域跑 `build_hybrid`。精神一样：主动补洞，不要 Kerbl clone。
4. **跟踪外挂、建图内生** — 前端 ICP、后端 ORB，高斯优化不负责位姿。本项目更彻底：位姿先 GT/986，建图只做关联。说明 3DGS 不必和位姿绑在一个可微环里。

**原型 P6 — 关键帧在文献里实际干什么（调度对照，不锁死判据）**

没有统一配方。第 4 层方法里，关键帧有的决定「这帧进不进优化窗」，有的决定「这帧多迭代几次」，有的几乎不用关键帧：

| 方法 | 怎么选 | 选上了干什么 |
| --- | --- | --- |
| Kerbl 3DGS | 无 SLAM 关键帧 | 位姿冻死，全部高斯打数万步 |
| ElasticFusion | 运动够大才留（环路用） | **每帧**都认盘、加权更新；关键帧主要用于变形/回环，不是「这帧才优化」 |
| RTG | 相对上一关键帧转角或平移过阈；第 0 帧进列表但不走 global | 普通帧也可 local_optimize；关键帧才 global。另设时间窗（Replica 6 / Azure 8 / TUM 4），每窗 ~50 iter，只打不稳定高斯 |
| GSFusion | **本帧新建数 > 阈**（默认 50），不是纯运动 | 关键帧 \(m\) 次、非关键帧 \(n\) 次，省下的步数随机回放旧关键帧；扫完可全局再优化 |
| GPS | 30° 或 0.3 m | SDF **每帧都融**；关键帧管高斯外观层别过拟合 |
| Gaussian-SLAM | 更像 submap | 只优化当前块，旧块卸内存 |

可记三句：（1）几何融合派（EF、KinectFusion、GPS 的 SDF）每帧都记账，关键帧是回环/外观；（2）可微高斯派（RTG、GSFusion）关键帧 = 优化预算；（3）选帧判据两类：相对运动，或信息增益（新建数，和「未覆盖才建」更像）。

本项目认盘更近 ElasticFusion：每帧像素融进旧盘，不必先搞一套关键帧迭代器。关键帧若要，留给 P4「隔一段再整理」，不是第一步。

不建议一上来做：可微跟踪、50 次/帧光度、Kerbl densify、feed-forward 网络、view-tied 逐像素高斯。
渲染与监督是 render-to-fit 的一体两面，解析路线无法当设计输入（最多当读出/事后打分）。

### 5.2 已知风险（沿用 A1）

- 986 相对漂移会进流身份，几十帧后同一点可能被当成新点 → **几何门失败必须丢对应**（流为主，不是改回投影做主）。`rigid_delta` 当质量/分块线索，不当位移。
- GT 位姿（实验 J）仍有时间戳最近邻误差（中位 ~1.7 ms，最大 ~13 ms），桌面近、6 cm 级运动下可忽略。
- 大运动（skip-5）hit 从 0.80 掉到 0.70，未覆盖区域会触发大量新建——这是正确行为，但要用置信/半径相容防止在已有桌面上叠一层。
- TUM 量化是跨帧平均的地板：帧间不相关的量化格子可以被平均掉，相关的（同一视角来回扫）平均不动。上界应在 Replica/合成上测。

---

## 6. 文献地图（按任务，不按年代堆）

**几何融合、零外观优化**  
KinectFusion 2011；Keller point-based fusion 2013；ElasticFusion 2015；BundleFusion 2017；Voxblox / Supereight2。

**RGB-D 3DGS SLAM（增量、有优化）**  
SplaTAM CVPR 2024；GS-SLAM CVPR 2024；Gaussian-SLAM 2023/24；MonoGS CVPR 2024；RTG-SLAM SIGGRAPH 2024；GPS-SLAM CVM 2025；GSFusion RA-L 2024；VTGaussian-SLAM ICML 2025；Geometry-Aware Online Mapping 2026。

**批 3DGS / 网络前馈 / 事后压缩**  
Kerbl 3DGS 2023；GeoSplat 2025；DepthSplat；FreeSplat++；SurfelSplat 2025；NanoGS 2026（训练无关合并）；Superpixel-guided 3DGS，VRST 2024（SLIC 播种）；本项目单帧解析构造（对照：「几何是构造本身」）。

**高斯混合约简（GMR，合并算子与判据的老家）**  
矩匹配算子：Runnalls 2007（KL 上界 \(B(i,j)\)，闭式）；Salmond 1990；Williams 2003（ISD，闭式）；NanoGS 2026 的 MPMM = 同一算子、判据走 MC。surfel 退化版：Keller 2013 / ElasticFusion 2015（只并均值不并协方差）。邻域塌缩：Surfel Set Simplification，OFP，IEEE Access 2016。免优化后处理：CVT-GS 2026（Centroidal Voronoi）。学习式合并：Compact FF-3DGS 2026（baseline 纯矩匹配 PSNR 13.29 vs 其 17.09）。另：Wasserstein-Distance-Based GMR，IEEE SPL；EGG-Fusion，SIGGRAPH Asia 2025。详见 §2.3「GMR 家族」。

**位姿（仅视觉/RGB-D）**  
Henry RGB-D Mapping；ORB-SLAM2 RGB-D；ICP frame-to-model；SplaTAM/MonoGS 可微跟踪；本仓库 986 场景流。

单帧相关工作（AdaSplats、SplatMesh、2D-SuGaR、曲率定尺等）见 `SINGLE FRAME/scripts/RESEARCH.md` §2，此处不重复。

---

## 7. 暂时的结论（调研，不是方案）

1. **传感器约束不构成瓶颈**。连续 RGB-D 直出 3DGS 已有完整文献族，IMU 不是前置条件。
2. **大一统和增量都合法**。大一统把冗余消在 TSDF/点云里，再采样高斯；增量把冗余消在「这一像素要不要新建」的门上。流式产品更自然走增量；大一统适合当精度上界对照。二者之间还有关键帧调度（§0.4）：普通帧只关联，关键帧才做一次局部整理——SLAM 的 local mapping 与视频 GOP 是同一思想。
3. **去冗余的有效门都是几何身份，不是梯度**。体素占用、surfel 投影关联、渲染空洞、三类误差，比 Kerbl densify 更可控。2026 年仍有论文在批评在线套用离线 densify。
4. **和本项目缺口对齐得最近的是 ElasticFusion 关联 ∪ RTG 三类像素/稳定态**，但新建应调用已有曲率贪心，而不是 5% 像素反投影 + 50 次迭代。
5. **GSFusion 的占用查询**是实现成本最低的防爆，注意只借「来过就不建」，不借各向同性体素尺度。
6. **第一步不必自产位姿**。实验 J 已证明 GT 刚体变换可用；用 GT 或 986 轨迹先把 P1/P2 的 N–时间曲线跑出来，再回头接 VO。

下一步若开始做，建议先 P1 的最小闭环：10 帧 GT 位姿、只实现关联+不命中才新建、画出 N(t) 和 hit，不写优化器。

---

## 参考文献

[1] Newcombe, R. A., et al. (2011). *KinectFusion: Real-time dense surface mapping and tracking*. ISMAR.

[2] Keller, M., et al. (2013). *Real-time 3D reconstruction in dynamic scenes using point-based fusion*. 3DV.

[3] Whelan, T., et al. (2015). *ElasticFusion: Dense SLAM without a pose graph*. RSS.

[4] Dai, A., et al. (2017). *BundleFusion: Real-time globally consistent 3D reconstruction using on-the-fly surface reintegration*. TOG.

[5] Kerbl, B., et al. (2023). *3D Gaussian Splatting for Real-Time Radiance Field Rendering*. TOG.

[6] Keetha, N., et al. (2024). *SplaTAM: Splat, Track & Map 3D Gaussians for Dense RGB-D SLAM*. CVPR. arXiv:2312.02126

[7] Yan, C., et al. (2024). *GS-SLAM: Dense Visual SLAM with 3D Gaussian Splatting*. CVPR. arXiv:2311.11700

[8] Yugay, V., Li, Y., Gevers, T., & Oswald, M. R. (2024). *Gaussian-SLAM: Photo-realistic Dense SLAM with Gaussian Splatting*. arXiv:2312.10070

[9] Matsuki, H., Murai, R., Kelly, P. H. J., & Davison, A. J. (2024). *Gaussian Splatting SLAM*. CVPR.

[10] Peng, Z., et al. (2024). *RTG-SLAM: Real-time 3D Reconstruction at Scale Using Gaussian Splatting*. SIGGRAPH. arXiv:2404.19706

[11] Peng, Z., Zhou, K., & Shao, T. (2025). *Gaussian-Plus-SDF SLAM*. Computational Visual Media. arXiv:2509.11574

[12] Wei, J., & Leutenegger, S. (2024). *GSFusion: Online RGB-D Mapping Where Gaussian Splatting Meets TSDF Fusion*. IEEE RA-L. arXiv:2408.12677

[13] Hu, P., & Han, Z. (2025). *VTGaussian-SLAM: RGBD SLAM for Large Scale Scenes with Splatting View-Tied 3D Gaussians*. ICML. PMLR 267.

[14] Luu, T., Tran, Q., Phan, H., & Dang, T. (2026). *Geometry-Aware Online Mapping for 3D Gaussian Splatting SLAM*. arXiv:2608.14902

[15] Henry, P., Krainin, M., Herbst, E., Ren, X., & Fox, D. (2012). *RGB-D mapping: Using Kinect-style depth cameras for dense 3D modeling of indoor environments*. IJRR.

[16] Mur-Artal, R., & Tardós, J. D. (2017). *ORB-SLAM2: An open-source SLAM system for monocular, stereo, and RGB-D cameras*. IEEE TRO.

[17] Sturm, J., et al. (2012). *A benchmark for the evaluation of RGB-D SLAM systems*. IROS. (TUM RGB-D)

[18] Vespa, E., et al. (2018). *Efficient octree-based volumetric SLAM supporting signed-distance and occupancy mapping*. RA-L. (Supereight2)

[19] Xu, H., et al. (2025). *DepthSplat: Connecting Gaussian splatting and depth*. CVPR.

[20] Wang, Y., Huang, T., Chen, H., & Lee, G. H. (2026). *FreeSplat++: Generalizable 3D Gaussian Splatting for Efficient Indoor Scene Reconstruction*. TPAMI.

[21] Xiong, B., Liu, R., Zhou, T., Chen, M., Fan, Z., & Feng, A. (2026). *NanoGS: Training-Free Gaussian Splat Simplification*. arXiv:2603.16103

[22] Kim, M. G., Jeong, S. W., Park, S., & Han, J. H. (2024). *Superpixel-guided Sampling for Compact 3D Gaussian Splatting*. ACM VRST. DOI:10.1145/3641825.3687719

过程留档：单帧定稿与相关工作见 `SINGLE FRAME/scripts/RESEARCH.md`；跨帧待办见同目录 `OPEN_ITEMS.md`；实验 J 脚本本目录 `exp_j_gt_skip5.py` / `exp_j_gt_skip5_ewa.py`，输出在 `SEQUENTIAL FRAMES/output_J/`。
