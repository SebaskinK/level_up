"""Draw every newly-added disc: centre + its projected ellipse on the target frame.

The incremental build returns concat(g_curvature, g_S2), and concat drops
axis1/axis2 (S2 footprint discs are isotropic). ~94% of leftover discs are
isotropic (scale0 == scale1), and for those the in-plane axis orientation is
irrelevant. For the few anisotropic ones we reconstruct the tangent basis from
the normal (the true principal direction is lost in the concat, but the SIZE is
preserved). Each disc's projected ellipse is the perspective image of the 3D
disc boundary { mu + a*e1*cos t + b*e2*sin t } with a=scale0, b=scale1 --
matching rasterize_discs' hard-footprint semantics (not the EWA sigma).
"""

import sys
from pathlib import Path

import cv2
import numpy as np

SEQ = Path(__file__).resolve().parent
SINGLE = SEQ.parent.parent / "SINGLE FRAME" / "scripts"
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SINGLE))
sys.path.insert(0, str(SFLOW))

import h_pipeline_final as H  # noqa: E402
import incremental_hybrid as INC  # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402
from scene_flow import compute_scene_flow  # noqa: E402
from se3 import se3_exp  # noqa: E402
from tum_io import undistort_maps as tu_um, FR1_INTRINSICS as tu_K  # noqa: E402

OUT = SEQ.parent.parent / "SEQUENTIAL FRAMES" / "output_T_floor3" / "vis"
N_STEPS = 40
SCALE = 4
THETA = np.linspace(0.0, 2.0 * np.pi, N_STEPS, endpoint=False)


def tangent_basis(n):
    """Orthonormal in-plane axes (e1, e2) for unit normals n (N, 3)."""
    n = n / np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-9)
    ref = np.zeros_like(n, dtype=np.float32)
    ref[:, 2] = 1.0
    parallel = np.abs(n[:, 2]) > 0.9
    ref[parallel, 2] = 0.0
    ref[parallel, 0] = 1.0
    e1 = np.cross(ref, n)
    e1 /= np.maximum(np.linalg.norm(e1, axis=1, keepdims=True), 1e-12)
    e2 = np.cross(n, e1)
    return e1, e2


def project_ellipse(g, K):
    """Per-disc projected ellipse outline (list of (u, v) float arrays)."""
    fx, fy, cx, cy = K[0, 0], K[1, 1], K[0, 2], K[1, 2]
    mu = g.mu.astype(np.float64)
    e1, e2 = tangent_basis(g.normal)
    a = g.scale[:, 0].astype(np.float64)
    b = g.scale[:, 1].astype(np.float64)
    outlines = []
    for i in range(len(g)):
        xyz = (mu[i][None, :]
               + (a[i] * np.cos(THETA))[:, None] * e1[i][None, :]
               + (b[i] * np.sin(THETA))[:, None] * e2[i][None, :])
        z = np.maximum(xyz[:, 2], 1e-6)
        u = fx * xyz[:, 0] / z + cx
        v = fy * xyz[:, 1] / z + cy
        outlines.append(np.stack([u, v], axis=1))
    return outlines


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    pairs = SF.associate(SF.DATA, max_dt=0.02)[:4]
    h, w = 480, 640
    map1, map2, K = tu_um((h, w), tu_K)

    bgr0, z0, _ = SF.load_pair(pairs, 0, map1, map2)
    g0, _, _ = H.build_hybrid(bgr0, z0, K, SF.TEX_Q)
    model = SF.Model(
        g=g0, w=np.ones(len(g0), np.float32), age=np.zeros(len(g0), np.int32),
        owner=SF.owner_from_raster(g0, K, (h, w)), birth=np.zeros(len(g0), np.int32),
        cnt=np.ones(len(g0), np.float32),
    )
    prev_sf, prev_dt = None, 1.0
    bgr_a, z_a = bgr0, z0

    for i in range(3):
        bgr_b, z_b, _ = SF.load_pair(pairs, i + 1, map1, map2)
        dt = pairs[i + 1].t_rgb - pairs[i].t_rgb
        sf = compute_scene_flow(bgr_a, bgr_b, z_a, z_b, K,
                                prev=prev_sf, dt=dt, prev_dt=prev_dt)
        owner_w = SF.warp_owner(model.owner, sf.u, sf.v, sf.valid)
        owner_w = SF._fill_owner_backward(owner_w, model.owner, sf)
        leftover = (z_b > SF.Z_MIN) & (z_b < SF.Z_MAX) & (owner_w < 0)
        g_new = INC.build_hybrid_region(bgr_b, z_b, K, SF.TEX_Q, leftover)
        rec = SF.fuse_frame(model, sf, z_a, z_b, bgr_b, K, 8, 2.0, i)
        assert len(g_new) == rec["n_new"], (len(g_new), rec["n_new"])

        vis = bgr_b.astype(np.float32) * 0.55
        vis = vis.astype(np.float32)
        vis = np.clip(vis, 0, 255).astype(np.uint8)
        # upscale 4x (nearest) so the small ellipses are legible; draw AFTER scaling
        vis_big = cv2.resize(vis, (w * SCALE, h * SCALE),
                             interpolation=cv2.INTER_NEAREST)

        outlines = project_ellipse(g_new, K)
        n_drawn = 0
        # ellipse outlines scaled up, drawn on the upscaled image
        for out in outlines:
            pts = (np.rint(out * SCALE).astype(np.int32))
            pts = np.clip(pts, 0, [w * SCALE - 1, h * SCALE - 1])
            cv2.polylines(vis_big, [pts], True, (0, 0, 255), 1, cv2.LINE_AA)
            n_drawn += 1
        # centres: small filled disc (distinct colour), no cross
        for (u, v) in zip(g_new.pixel[:, 0], g_new.pixel[:, 1]):
            cu, cv_ = int(round(u * SCALE)), int(round(v * SCALE))
            cv2.circle(vis_big, (cu, cv_), 3, (0, 255, 0), -1, cv2.LINE_AA)

        # legend
        bar = np.full((34, w * SCALE, 3), 25, np.uint8)
        cv2.putText(bar, f"frame {i}->{i+1}: new discs = {len(g_new)}  "
                         f"(green dot = centre, red outline = projected disc, 4x)",
                    (8, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (220, 220, 220), 1, cv2.LINE_AA)
        img = np.vstack([vis_big, bar])
        p = OUT / f"newdisc_ellipse_{i:04d}.png"
        cv2.imwrite(str(p), img)
        print(f"wrote {p}  discs={n_drawn}")

        prev_sf, prev_dt = sf, dt
        bgr_a, z_a = bgr_b, z_b


if __name__ == "__main__":
    main()