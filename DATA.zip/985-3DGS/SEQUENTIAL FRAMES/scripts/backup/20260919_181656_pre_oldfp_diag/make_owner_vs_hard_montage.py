"""Side-by-side: frame-0 owner classification map (left) vs hard ray render (right).

Crops the per-image caption bars, pastes the two 640x480 frames next to each
other, adds one wrapped caption and a 1.5x upscale for readability.

Run:  python scripts/make_owner_vs_hard_montage.py
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import cv2
import numpy as np

SEQ = Path(__file__).resolve().parent
sys.path.insert(0, str(SEQ))

RUN = SEQ.parent / "output_f0_80frame_relinkorder"

# same palette as diag_left_oldnew_color (BGR)
PAL = {"green": (60, 200, 60), "yellow": (0, 200, 255),
       "blue": (60, 60, 255), "magenta": (200, 0, 200)}


def caption_bar_legend(img: np.ndarray, lines: list[tuple[str | None, str]],
                       size: int = 18) -> np.ndarray:
    """Caption bar where each entry is drawn after a small colour swatch."""
    sw, pad, txt_x = 14, 8, 34
    h_bar = size * len(lines) + 14
    bar = np.full((h_bar, img.shape[1], 3), 20, np.uint8)
    for i, (swatch, text) in enumerate(lines):
        y = 16 + size * i
        if swatch is not None:
            cv2.rectangle(bar, (pad, y - 12), (pad + sw, y), PAL[swatch], -1)
        cv2.putText(bar, text, (txt_x if swatch else pad, y),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.42, (230, 230, 230), 1, cv2.LINE_AA)
    return np.vstack([img, bar])


def frame_only(path: Path, h: int = 480) -> np.ndarray:
    im = cv2.imread(str(path))
    if im is None:
        raise FileNotFoundError(path)
    return im[:h]


def main() -> None:
    global RUN
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", default=str(RUN.name))
    args = ap.parse_args()
    RUN = SEQ.parent / args.run

    left = frame_only(RUN / "diag_owner_class_f0_full.png")
    right = frame_only(RUN / "f0_hard.png")
    mont = np.hstack([left, right])

    # Legend pixel counts are counted off the classification map itself; the summary
    # numbers come from the JSON the classifying script wrote for this same run.
    st = json.loads((RUN / "diag_owner_class_f0_stats.json").read_text())
    cnt = {k: int(np.all(left == np.array(c, np.uint8), axis=2).sum())
           for k, c in PAL.items()}
    legend = [
        ("green", f"old disc (born f0), colour unchanged  ({cnt['green']} px)"),
        ("yellow", f"old disc (born f0), colour drifted >0.04  ({cnt['yellow']} px)"),
        ("blue", f"born f1-80, ON f0 surface (|dz|/z<0.05)  ({cnt['blue']} px)"),
        ("magenta", f"born f1-80, OFF f0 surface  ({cnt['magenta']} px)"),
    ]
    head = (f"LEFT: frame-0 owner classification of the {st['frames'] - 1}-frame "
            f"model (run={st['run']}) -- legend:")
    tail = [
        (None, "RIGHT: frame-0 HARD RAY render of the same model: front-most "
               "ray-disc hit, every disc painted with its FINAL colour."),
        (None, f"N={st['n_discs']}, coverage={st['coverage']:.3f}.  "
               f"depth-consistency with f0: all {st['depth_consistency_all']:.1f}%, "
               f"old {st['depth_consistency_old']:.1f}%, "
               f"new {st['depth_consistency_new']:.1f}%."),
        (None, f"colour err vs the f0 image, left band x<128: "
               f"old {st['colour_err_left_old_e3']:.0f}e-3, "
               f"new {st['colour_err_left_new_e3']:.0f}e-3.  "
               f"born-f0 discs {st['birth_f0']} / f1-10 {st['birth_f1_10']} / "
               f"f11-80 {st['birth_f11_80']}."),
    ]
    out = caption_bar_legend(mont, [(None, head)] + legend + tail)
    out = cv2.resize(out, None, fx=1.5, fy=1.5, interpolation=cv2.INTER_NEAREST)
    dst = RUN / "owner_vs_hard_f0.png"
    cv2.imwrite(str(dst), out)
    print(f"shapes left={left.shape} right={right.shape} montage={out.shape}")
    print("saved ->", dst)

    # the classification map on its own, same swatch legend
    solo = caption_bar_legend(left, [(None, f"frame-0 owner classification, "
                                            f"{st['frames'] - 1}-frame model "
                                            f"(run={st['run']}) -- legend:")]
                              + legend + tail[1:])
    solo = cv2.resize(solo, None, fx=1.5, fy=1.5, interpolation=cv2.INTER_NEAREST)
    dst2 = RUN / "diag_owner_class_f0_legend.png"
    cv2.imwrite(str(dst2), solo)
    print("saved ->", dst2)


if __name__ == "__main__":
    main()