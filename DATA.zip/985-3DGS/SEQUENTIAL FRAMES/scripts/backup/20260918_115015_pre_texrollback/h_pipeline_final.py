"""Finalized single-file H pipeline (curvature + S2 fallback + texture mask).

Self-contained extraction of the current pipeline, previously spread across
`gaussian_build.py`, `curvature.py`, `exp_e_curvature_sample.py`,
`exp_h_texture_mask.py`, `exp_g_aniso_real.py`, `exp_h_s2.py`, plus the io /
metric helpers from `rgbd_io.py` and `metrics.py`. No local imports. Only the
ACTIVE code path is kept -- every alternative/replaceable implementation and the
once-off 9x9-normal experiment driver have been removed as dead code.

Rename map (new name = old name):

    compute_scene_geometry        = compute_curvature_geometry
    surface_normals               = normals_from_depth
    select_curvature_seeds        = curvature_mask
    emit_footprint_discs          = build_gaussians            (S2 uniform)
    emit_curvature_discs          = build_gaussians_curvature
    build_hybrid                  = build_s2_fallback
    concatenate_gaussians         = concat

Self-check (frame 0, fr1/desk):  .venv/bin/python h_pipeline_final.py
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parent

# ---------------------------------------------------------------------------
# constants / config
# ---------------------------------------------------------------------------

OPAQUE_ALPHA = 0.99
THIN_AXIS_RATIO = 0.1

# The S2 fallback samples on a stride-2 grid, so each S2 disc is the sole owner
# of exactly one 2x2 cell. That analytic 4 px is the yardstick a curvature disc
# has to beat to be worth emitting -- see coverage_sample_aniso's `min_gain`.
S2_STRIDE = 2
S2_CELL_PX = S2_STRIDE * S2_STRIDE

FR1_INTRINSICS = dict(
    fx=517.306408, fy=516.469215, cx=318.643040, cy=255.313989,
    k1=0.262383, k2=-0.953104, p1=-0.005358, p2=0.002628, k3=1.163314,
)
DEPTH_SCALE = 5000.0

# 原名: CFG (exp_g_aniso_real.py), aliased as GEO_CFG by the H scripts.
GEO_CFG = dict(eps=0.001, gauss_sigma=3.0, r_max=0.05, disc_rel=0.02,
               shrink=1.0, overlap=0.6, z_min=0.4, z_max=4.0)

_QUAD_CACHE: dict[int, dict[str, np.ndarray]] = {}


# ---------------------------------------------------------------------------
# data structures
# ---------------------------------------------------------------------------

@dataclass
class Gaussians:
    mu: np.ndarray            # (N, 3) centres, camera frame
    normal: np.ndarray        # (N, 3) unit normals = shortest axis
    scale: np.ndarray         # (N, 3) [r1, r2, thin]
    quat: np.ndarray          # (N, 4) wxyz, shortest axis aligned to normal
    color: np.ndarray         # (N, 3) linear RGB in [0, 1]
    alpha: np.ndarray         # (N,)
    pixel: np.ndarray         # (N, 2) source pixel (u, v)
    axis1: np.ndarray | None = None   # (N, 3) in-plane axis for scale[:, 0]
    axis2: np.ndarray | None = None   # (N, 3) in-plane axis for scale[:, 1]

    def __len__(self) -> int:
        return self.mu.shape[0]


@dataclass
class CurvatureGeometry:
    """Per-pixel geometric quantities shared by seed selection and emission.

    Both select_curvature_seeds (spacing) and emit_curvature_discs (emission)
    need the same smoothed depth, normal, and principal curvatures. Computed once
    in compute_scene_geometry and passed around, so the claim radius and the
    emitted radius come from the same numbers.
    """
    z_grad: np.ndarray
    normal: np.ndarray        # (H, W, 3) unit normals, camera-facing
    n_ok: np.ndarray
    k1: np.ndarray
    k2: np.ndarray
    t1: np.ndarray            # (H, W, 3) principal tangent (thinnest direction)
    c_ok: np.ndarray
    dir_img: np.ndarray       # (H, W, 2) principal direction in image space
    r_k1: np.ndarray          # sqrt(2 eps / |k1|), short (thin) axis radius
    r_k2: np.ndarray          # long axis radius
    r_fp: np.ndarray          # surfel footprint radius
    r_edge: np.ndarray        # radius cap (edge_distance_limit; depth_jump_mask: void NOT a seam)
    disc_mask: np.ndarray     # disc-emission seam mask (depth_discontinuity_mask: void IS a seam)
    valid_depth: np.ndarray


@dataclass
class Frame:
    t_rgb: float
    t_depth: float
    rgb_path: Path
    depth_path: Path


# ---------------------------------------------------------------------------
# io (originally in rgbd_io.py)
# ---------------------------------------------------------------------------

def camera_matrix(intr: dict) -> np.ndarray:
    return np.array(
        [[intr["fx"], 0.0, intr["cx"]],
         [0.0, intr["fy"], intr["cy"]],
         [0.0, 0.0, 1.0]]
    )


def _read_index(path: Path) -> list[tuple[float, str]]:
    out = []
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        ts, rel = line.split()
        out.append((float(ts), rel))
    return out


def associate(data_dir: Path, max_dt: float = 0.02) -> list[Frame]:
    rgb = _read_index(data_dir / "rgb.txt")
    depth = _read_index(data_dir / "depth.txt")
    d_ts = np.array([t for t, _ in depth])
    used = set()
    pairs = []
    for t, rel in rgb:
        j = int(np.argmin(np.abs(d_ts - t)))
        if j in used or abs(d_ts[j] - t) > max_dt:
            continue
        used.add(j)
        pairs.append(Frame(t, float(d_ts[j]), data_dir / rel, data_dir / depth[j][1]))
    return pairs


def load_rgb(path: Path) -> np.ndarray:
    img = cv2.imread(str(path), cv2.IMREAD_COLOR)
    if img is None:
        raise FileNotFoundError(path)
    return img


def load_depth(path: Path) -> np.ndarray:
    raw = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)
    if raw is None:
        raise FileNotFoundError(path)
    return raw.astype(np.float32) / DEPTH_SCALE


def undistort_maps(shape: tuple[int, int], intr: dict):
    h, w = shape
    K = camera_matrix(intr)
    dist = np.array([intr["k1"], intr["k2"], intr["p1"], intr["p2"], intr["k3"]])
    K_new, _ = cv2.getOptimalNewCameraMatrix(K, dist, (w, h), 0.0, (w, h))
    map1, map2 = cv2.initUndistortRectifyMap(K, dist, None, K_new, (w, h), cv2.CV_32FC1)
    return map1, map2, K_new


def remap_rgb(img: np.ndarray, map1, map2) -> np.ndarray:
    return cv2.remap(img, map1, map2, cv2.INTER_LINEAR)


def remap_depth(z: np.ndarray, map1, map2) -> np.ndarray:
    return cv2.remap(z, map1, map2, cv2.INTER_NEAREST)


# ---------------------------------------------------------------------------
# depth prefiltering
# ---------------------------------------------------------------------------

def depth_valid(z: np.ndarray) -> np.ndarray:
    """Measured depth: z > 0. Single source of truth for "valid reading"."""
    return z > 0


def masked_gauss_fast(z, sigma, valid=None, floor=0.05):
    """Normalized-convolution Gaussian with a half-res-pyramid wide-kernel fallback.

    Blurring z*m and m separately divides them out, so the result is the
    Gaussian-weighted mean over VALID neighbours only -- a void (z=0) is never
    averaged in. The wide-kernel fallback fills the few pixels whose local
    support is entirely invalid; it runs on a half-res pyramid (INTER_AREA down
    + fixed-sigma small kernel + INTER_LINEAR up) so each level approximates the
    next doubled-sigma low-pass at a fraction of the cost, and only touches z=0
    pixels -- bit-identical to the full-res version on every raw-valid pixel.
    """
    if valid is None:
        valid = depth_valid(z)
    m = valid.astype(np.float32)
    zm = (z * m).astype(np.float32)
    num = cv2.GaussianBlur(zm, (0, 0), sigma)
    den = cv2.GaussianBlur(m, (0, 0), sigma)
    out = num / np.maximum(den, 1e-9)
    bad = den < floor
    if bad.any():
        shape = (z.shape[1], z.shape[0])
        zc, mc = zm, m
        for _ in range(5):
            lw, lh = zc.shape[1] // 2, zc.shape[0] // 2
            zc = cv2.resize(zc, (lw, lh), interpolation=cv2.INTER_AREA)
            mc = cv2.resize(mc, (lw, lh), interpolation=cv2.INTER_AREA)
            n2 = cv2.GaussianBlur(zc, (0, 0), sigma)
            d2 = cv2.GaussianBlur(mc, (0, 0), sigma)
            n2 = cv2.resize(n2, shape, interpolation=cv2.INTER_LINEAR)
            d2 = cv2.resize(d2, shape, interpolation=cv2.INTER_LINEAR)
            ok = d2 >= floor
            fill = bad & ok
            if fill.any():
                out[fill] = (n2 / np.maximum(d2, 1e-9))[fill]
            bad &= ~ok
            if not bad.any():
                break
        if bad.any():
            out[bad] = float(np.median(z[m > 0])) if m.any() else 0.0
    return out.astype(np.float32)


def prefilter_depth(z, mode="none", size=5, valid=None):
    """Suppress depth quantization before differentiating.

    TUM is disparity-quantized (dz ~ 0.0029 z^2), a staircase that wrecks the
    normals. 'gauss' is the only scale-space-consistent choice (d(G*z)=(dG)*z),
    keeping the normal and the curvature on the same smoothed surface.
    """
    if mode == "none":
        return z
    if mode == "box":
        return cv2.blur(z, (size, size))
    if mode == "bilateral":
        return cv2.bilateralFilter(z, size, 0.02, size)
    if mode == "gauss":
        return masked_gauss_fast(z, float(size), valid=valid)
    raise ValueError(f"unknown prefilter mode: {mode}")


# ---------------------------------------------------------------------------
# normals (3x3 Sobel / 9x9 quadric share one cross-product helper)
# ---------------------------------------------------------------------------

def _normal_from_gradients(z: np.ndarray, K: np.ndarray, zu, zv):
    """Unit normal via cross(dP/du, dP/dv).

    原名: the body of normals_from_depth (3x3 Sobel). NOTE: do not reuse this
    for the 9x9 quadric normal in principal_curvatures -- the dPdu/dPdv stack
    order differs there, and the ~1e-5 float reassociation flips 3 primitives in
    the greedy largest-first tie (N 33735 vs 33732). That one keeps its own
    inline np.cross(Pu, Pv).
    """
    h, w = z.shape
    fx, fy, cx, cy = K[0, 0], K[1, 1], K[0, 2], K[1, 2]
    xs, ys = np.meshgrid(np.arange(w, dtype=np.float32),
                         np.arange(h, dtype=np.float32))
    dPdu = np.stack([(z + (xs - cx) * zu) / fx, (ys - cy) * zu / fy, zu], axis=-1)
    dPdv = np.stack([(xs - cx) * zv / fx, (z + (ys - cy) * zv) / fy, zv], axis=-1)
    n = np.cross(dPdu, dPdv)
    norm = np.linalg.norm(n, axis=-1)
    valid = norm > 1e-12
    n = n / np.where(valid, norm, 1.0)[..., None]
    flip = n[..., 2] > 0
    n[flip] *= -1.0
    return n.astype(np.float32), valid


def surface_normals(z: np.ndarray, K: np.ndarray):
    """Analytic surface normal from 3x3 Sobel depth gradients.

    原名: normals_from_depth. O(1) per pixel: two Sobel passes + one cross
    product. The normal and the curvature are deliberately computed at DIFFERENT
    scales (3x3 vs 9x9 quadric) -- a 9x9 normal was tried and rejected (no
    accuracy gain). That experiment predates the 2026-09-16 quadric linear-kernel
    sign fix, so the "it also surfaces a sign bug" caveat no longer applies;
    the rejection stands on the accuracy numbers alone (OPEN_ITEMS.md H-定稿).
    """
    zu = cv2.Sobel(z, cv2.CV_32F, 1, 0, ksize=3) / 8.0
    zv = cv2.Sobel(z, cv2.CV_32F, 0, 1, ksize=3) / 8.0
    return _normal_from_gradients(z, K, zu, zv)


# ---------------------------------------------------------------------------
# curvature (originally in curvature.py)
# ---------------------------------------------------------------------------

def quadric_kernels(win: int) -> dict[str, np.ndarray]:
    """Least-squares quadric-fit derivative correlation kernels (win x win).

    `P[i].reshape(win, win)` is ALREADY laid out for correlation (row = v + r,
    col = u + r), which is what cv2.filter2D applies -- so it must NOT be
    flipped again. An extra [::-1, ::-1] was present until 2026-09-16; it maps
    (u, v) -> (-u, -v), which leaves the even-order kernels (zuu/zvv/zuv)
    untouched but NEGATES the odd-order ones (zu/zv). Verified on an analytic
    tilted plane: the flipped kernels returned zu = -9.75e-4 where both the
    truth and 3x3 Sobel give +9.75e-4 (ratio exactly -1.0000).

    The sign does NOT cancel inside principal_curvatures: zu/zv appear alone in
    Puu/Puv/Pvv and in the internal cross(Pu, Pv), so the shape operator and its
    eigenvectors were both biased. Synthetic cylinder R=0.2 (truth |k1| = 5.0):
    |k1| 5.85 -> 5.02, and the principal direction t1 went from a median 9.7 deg
    (p90 29 deg) error to 0.07 deg (p90 0.36 deg). See scripts/h_quadric_sign.py.
    """
    cached = _QUAD_CACHE.get(win)
    if cached is not None:
        return cached
    r = win // 2
    us, vs = np.meshgrid(np.arange(-r, r + 1, dtype=np.float64),
                         np.arange(-r, r + 1, dtype=np.float64))
    u, v = us.ravel(), vs.ravel()
    A = np.stack([u * u, u * v, v * v, u, v, np.ones_like(u)], axis=1)
    P = np.linalg.pinv(A)

    def k(i: int, scale: float) -> np.ndarray:
        return (scale * P[i].reshape(win, win)).astype(np.float32)

    out = {
        "zuu": k(0, 2.0), "zuv": k(1, 1.0), "zvv": k(2, 2.0),
        "zu": k(3, 1.0), "zv": k(4, 1.0),
    }
    _QUAD_CACHE[win] = out
    return out


def _derivatives(z: np.ndarray, win: int):
    """First/second image-space depth derivatives via an explicit win x win
    quadric fit (least-squares), read off as correlation kernels."""
    K = quadric_kernels(win)
    return tuple(
        cv2.filter2D(z, cv2.CV_32F, K[name], borderType=cv2.BORDER_REPLICATE)
        for name in ("zu", "zv", "zuu", "zvv", "zuv")
    )


def principal_curvatures(z: np.ndarray, K: np.ndarray, win: int = 9):
    """Principal curvatures + image-space directions from first/second forms.

    Returns (k1, k2, dir1, valid) with |k1| >= |k2|, in 1/m.
    """
    h, w = z.shape
    fx, fy, cx, cy = K[0, 0], K[1, 1], K[0, 2], K[1, 2]
    us, vs = np.meshgrid(np.arange(w, dtype=np.float32),
                         np.arange(h, dtype=np.float32))
    a = (us - cx) / fx
    b = (vs - cy) / fy

    zu, zv, zuu, zvv, zuv = _derivatives(z, win)

    Pu = np.stack([zu * a + z / fx, zu * b, zu], axis=-1)
    Pv = np.stack([zv * a, zv * b + z / fy, zv], axis=-1)
    Puu = np.stack([zuu * a + 2.0 * zu / fx, zuu * b, zuu], axis=-1)
    Pvv = np.stack([zvv * a, zvv * b + 2.0 * zv / fy, zvv], axis=-1)
    Puv = np.stack([zuv * a + zv / fx, zuv * b + zu / fy, zuv], axis=-1)

    # 原名: principal_curvatures 内联的 np.cross(Pu, Pv)（quadric 梯度）。不能复用
    # _normal_from_gradients —— 那里的 dPdu/dPdv 表达式顺序不同，会造成 ~1e-5 的浮点
    # 重结合，把 k1/k2 的贪心 largest-first 平局翻掉 3 个基元（N 33735→33732）。
    nvec = np.cross(Pu, Pv)
    nlen = np.linalg.norm(nvec, axis=-1)
    ok = nlen > 1e-12
    n = nvec / np.where(ok, nlen, 1.0)[..., None]
    flip = n[..., 2] > 0
    n[flip] *= -1.0

    E = np.einsum("ijk,ijk->ij", Pu, Pu)
    F = np.einsum("ijk,ijk->ij", Pu, Pv)
    G = np.einsum("ijk,ijk->ij", Pv, Pv)
    L = np.einsum("ijk,ijk->ij", Puu, n)
    M = np.einsum("ijk,ijk->ij", Puv, n)
    N = np.einsum("ijk,ijk->ij", Pvv, n)

    det_I = E * G - F * F
    ok &= np.abs(det_I) > 1e-20
    inv = np.where(ok, 1.0 / np.where(ok, det_I, 1.0), 0.0)

    s11 = (G * L - F * M) * inv
    s12 = (G * M - F * N) * inv
    s21 = (E * M - F * L) * inv
    s22 = (E * N - F * M) * inv

    tr = s11 + s22
    det = s11 * s22 - s12 * s21
    disc = np.maximum(0.25 * tr * tr - det, 0.0)
    root = np.sqrt(disc)
    ka = 0.5 * tr + root
    kb = 0.5 * tr - root

    swap = np.abs(kb) > np.abs(ka)
    k1 = np.where(swap, kb, ka)
    k2 = np.where(swap, ka, kb)

    d1 = np.stack([s12, k1 - s11], axis=-1)
    d2 = np.stack([k1 - s22, s21], axis=-1)
    use1 = np.linalg.norm(d1, axis=-1) >= np.linalg.norm(d2, axis=-1)
    dirs = np.where(use1[..., None], d1, d2)
    dl = np.linalg.norm(dirs, axis=-1)
    degenerate = dl < 1e-12
    dirs = dirs / np.where(degenerate, 1.0, dl)[..., None]
    dirs[degenerate] = np.array([1.0, 0.0], dtype=np.float32)

    ok &= np.isfinite(k1) & np.isfinite(k2)
    return (k1.astype(np.float32), k2.astype(np.float32),
            dirs.astype(np.float32), ok)


def curvature_radii(k1: np.ndarray, k2: np.ndarray, eps: float):
    """Radii whose sagitta stays within eps: r = sqrt(2 eps / |k|)."""
    r1 = np.sqrt(2.0 * eps / np.maximum(np.abs(k1), 1e-9))
    r2 = np.sqrt(2.0 * eps / np.maximum(np.abs(k2), 1e-9))
    return r1.astype(np.float32), r2.astype(np.float32)


def scale_space_curvature(z: np.ndarray, K: np.ndarray, win: int = 9):
    """Curvature on the caller-smoothed depth (win x win quadric stencil).

    Returns (k1, k2, t1, valid, dirs_img).
    """
    k1, k2, dirs_img, valid = principal_curvatures(z, K, win=win)

    h, w = z.shape
    fx, fy, cx, cy = K[0, 0], K[1, 1], K[0, 2], K[1, 2]
    us, vs = np.meshgrid(np.arange(w, dtype=np.float32),
                         np.arange(h, dtype=np.float32))
    zu = cv2.Sobel(z, cv2.CV_32F, 1, 0, ksize=3) / 8.0
    zv = cv2.Sobel(z, cv2.CV_32F, 0, 1, ksize=3) / 8.0
    a = (us - cx) / fx
    b = (vs - cy) / fy
    Pu = np.stack([a * zu + z / fx, b * zu, zu], axis=-1)
    Pv = np.stack([a * zv, b * zv + z / fy, zv], axis=-1)

    du = dirs_img[..., 0]
    dv = dirs_img[..., 1]
    t1 = Pu * du[..., None] + Pv * dv[..., None]
    t1 = t1 / np.maximum(np.linalg.norm(t1, axis=-1, keepdims=True), 1e-12)
    return k1, k2, t1, valid, dirs_img


# ---------------------------------------------------------------------------
# depth discontinuities and radius limits
# ---------------------------------------------------------------------------

def depth_discontinuity_mask(z, rel_thresh=0.02, valid=None):
    """True where a VALID surface ends (big depth step or into a void).

    This is ``disc_mask``: it decides which pixels may emit a disc. A pixel
    next to a void (FOV border / sensor hole) IS a seam here, because in this
    single view the visible surface really does end there and needs a disc to
    cap it.
    """
    if valid is None:
        valid = depth_valid(z)
    step = np.full(z.shape, -1.0, dtype=np.float32)
    for dy, dx in ((0, 1), (0, -1), (1, 0), (-1, 0)):
        shifted = np.roll(np.roll(z, dy, axis=0), dx, axis=1)
        nbr = np.where(np.roll(np.roll(valid, dy, axis=0), dx, axis=1), shifted, 0.0)
        step = np.maximum(step, np.abs(z - nbr))
    edge = step > rel_thresh * np.maximum(z, 1e-6)
    return edge & valid


def surfel_radius(z: np.ndarray, nz: np.ndarray, K: np.ndarray) -> np.ndarray:
    """ElasticFusion surfel footprint: min(2r, r/|n_z|), r = sqrt(2) z / f."""
    mean_focal = 0.5 * (K[0, 0] + K[1, 1])
    r = np.sqrt(2.0) * z / mean_focal
    return np.minimum(2.0 * r, r / np.maximum(np.abs(nz), 1e-6))


def depth_jump_mask(z, rel_thresh=0.02, valid=None):
    """Valid-valid depth step mask (void adjacency is NOT a discontinuity).

    This is NOT a drop-in replacement for `depth_discontinuity_mask`; it answers
    a different question. A valid pixel next to INVALID depth (FOV border,
    sensor hole) is a place where the surface may keep going, so it must NOT
    count as a seam -- only a large step between two VALID pixels marks a real
    geometric edge. Off-image neighbours are treated as void (padded), so the
    FOV border reads as "no info" instead of the np.roll wraparound the
    single-frame mask uses.

    Used ONLY for radius capping (`edge_distance_limit` / `r_edge`). Disc
    EMISSION still uses `depth_discontinuity_mask` (void IS a seam). The two
    are intentionally opposite: emission caps the surface at the visible
    boundary, while radius capping must not let missing data truncate a disc
    that the next frame will observe.
    """
    if valid is None:
        valid = depth_valid(z)
    h, w = z.shape
    zp = np.zeros((h + 2, w + 2), dtype=np.float32)
    vp = np.zeros((h + 2, w + 2), dtype=bool)
    zp[1:-1, 1:-1] = z
    vp[1:-1, 1:-1] = valid
    step = np.zeros(z.shape, dtype=np.float32)
    for dy, dx in ((0, 1), (0, -1), (1, 0), (-1, 0)):
        zb = zp[1 + dy: 1 + dy + h, 1 + dx: 1 + dx + w]
        vb = vp[1 + dy: 1 + dy + h, 1 + dx: 1 + dx + w]
        both = valid & vb
        step = np.maximum(step, np.where(both, np.abs(z - zb), 0.0))
    return (step > rel_thresh * np.maximum(z, 1e-6)) & valid


def edge_distance_limit(z, K, disc_rel=0.02, valid=None):
    """Largest radius keeping a disc clear of a real geometric seam.

    Uses `depth_jump_mask`, NOT `disc_mask` (`depth_discontinuity_mask`). The
    two are intentionally different: for radius capping, adjacency to invalid
    depth (FOV truncation / sensor hole) is NOT a seam, so the surface may keep
    going past the border and the disc is not truncated there -- the next frame
    observes past the border. Only a large step between two valid pixels
    shrinks the radius. Disc emission, by contrast, treats void as a seam
    (`depth_discontinuity_mask`) so the visible surface gets capped in this
    view.
    """
    edge = depth_jump_mask(z, disc_rel, valid=valid)
    free = (~edge).astype(np.uint8)
    dist_px = cv2.distanceTransform(free, cv2.DIST_L2, 3)
    return (dist_px * z / (0.5 * (K[0, 0] + K[1, 1]))).astype(np.float32)


def tex_boundary_limit(z, K, tex_mask, tol_px=0.0):
    """Largest radius keeping a disc within tol_px of the texture mask edge.

    Counterpart to edge_distance_limit across the COLOUR boundary (where depth is
    flat, so no depth edge fires). tol_px>0 lets the disc poke tol_px into the
    mask (the mask is dilated by the variance window, win/2 ~ 4.5 px).
    """
    free = (~tex_mask).astype(np.uint8)
    dist_px = cv2.distanceTransform(free, cv2.DIST_L2, 3)
    mean_focal = 0.5 * (K[0, 0] + K[1, 1])
    return (np.maximum(dist_px + tol_px, 0.0) * z / mean_focal).astype(np.float32)


# ---------------------------------------------------------------------------
# geometry assembly (single source of truth)
# ---------------------------------------------------------------------------

def compute_scene_geometry(z, K, eps, gauss_sigma, disc_rel,
                           valid_depth=None):
    """Compute the shared geometric quantities once for seed + emission.

    原名: compute_curvature_geometry. The normal is 3x3 Sobel; the curvature is
    9x9 quadric (its own internal cross-product normal is computed for the shape
    operator and discarded, exactly as in the original curvature.py).
    """
    if valid_depth is None:
        valid_depth = depth_valid(z)
    z_grad = prefilter_depth(z, "gauss", gauss_sigma, valid=valid_depth)
    normal, n_ok = surface_normals(z_grad, K)
    k1, k2, t1, c_ok, dir_img = scale_space_curvature(z_grad, K)
    r_k1, r_k2 = curvature_radii(k1, k2, eps)
    r_fp = surfel_radius(z, normal[..., 2], K)
    r_edge = edge_distance_limit(z, K, disc_rel, valid=valid_depth)
    disc_mask = depth_discontinuity_mask(z, disc_rel, valid=valid_depth)
    return CurvatureGeometry(
        z_grad=z_grad, normal=normal, n_ok=n_ok,
        k1=k1, k2=k2, t1=t1, c_ok=c_ok, dir_img=dir_img,
        r_k1=r_k1, r_k2=r_k2, r_fp=r_fp, r_edge=r_edge,
        disc_mask=disc_mask, valid_depth=valid_depth,
    )


# ---------------------------------------------------------------------------
# greedy coverage sampling
# ---------------------------------------------------------------------------

def tangent_frame(t1, n):
    """Emitter's tangent frame: t1 projected onto the plane, plus n x a1."""
    a1 = t1 - np.einsum("ij,ij->i", t1, n)[:, None] * n
    a1n = np.linalg.norm(a1, axis=1, keepdims=True)
    degenerate = (a1n < 1e-9).ravel()
    a1 = a1 / np.maximum(a1n, 1e-12)
    if degenerate.any():
        fb = np.tile(np.array([1.0, 0.0, 0.0], np.float32), (degenerate.sum(), 1))
        fb = fb - np.einsum("ij,ij->i", fb, n[degenerate])[:, None] * n[degenerate]
        a1[degenerate] = fb / np.maximum(
            np.linalg.norm(fb, axis=1, keepdims=True), 1e-12)
    return a1, np.cross(n, a1)


def project_tangent(vec, X, K):
    """Perspective Jacobian applied to 3D tangent vectors -> image offsets."""
    fx, fy = K[0, 0], K[1, 1]
    zc = np.maximum(X[:, 2], 1e-6)
    du = fx * (vec[:, 0] / zc - X[:, 0] * vec[:, 2] / zc ** 2)
    dv = fy * (vec[:, 1] / zc - X[:, 1] * vec[:, 2] / zc ** 2)
    return np.stack([du, dv], axis=1)


def coverage_sample_aniso(ys, xs, e1, e2, shape, min_gain=S2_CELL_PX):
    """Greedy largest-footprint-first claim of the true projected disc ellipse.

    `e1`/`e2` are the image-space semi-axis vectors of the claim footprint (the
    emitted 3D ellipse scaled by `overlap`, pushed through the perspective
    Jacobian). A pixel offset d is claimed iff ||M^-1 d|| <= 1 for M = [e1 e2],
    so the claim is exactly the region the emitted disc covers -- an isotropic
    r_k1 claim under-reserves, since the emitter always extends out to r_k2.

    `min_gain` is how many pixels the ellipse must be FIRST to claim before the
    seed is worth emitting. Testing only `claimed[y, x]` (the old behaviour,
    min_gain=1) accepts a seed whose footprint is already fully covered as long
    as its own centre slipped through a 1 px gap, which is what let the coverage
    multiplicity in grazing regions reach 33 while stride-2 S2 caps out at 13.

    The threshold is DERIVED, not tuned: an S2 disc sits on a stride-2 grid and
    is the sole owner of exactly one 2x2 cell, so it earns S2_CELL_PX = 4 px.
    `gain` is the same quantity for a curvature disc, so min_gain=4 states "a
    curvature disc must earn at least what the uniform fallback earns" -- below
    that the primitive is worse value than just letting S2 cover the area.

    A disc is only asked for as many pixels as its footprint actually contains
    candidates: the edge_fallback_fp discs live in bands a couple of pixels wide
    along a depth discontinuity and cannot physically reach 4, so a flat
    threshold silently undid the black-edge fix (77.9% of the seeds it dropped
    were that population, and 82.6% of the holes it opened sat within 3 px of a
    discontinuity).
    """
    h, w = shape
    det = e1[:, 0] * e2[:, 1] - e2[:, 0] * e1[:, 1]
    order = np.argsort(-np.abs(det))
    ys, xs, e1, e2, det = ys[order], xs[order], e1[order], e2[order], det[order]

    bx = np.maximum(np.ceil(np.hypot(e1[:, 0], e2[:, 0])).astype(np.int64), 0)
    by = np.maximum(np.ceil(np.hypot(e1[:, 1], e2[:, 1])).astype(np.int64), 0)

    YY, XX = np.meshgrid(np.arange(h), np.arange(w), indexing="ij")
    candidate = np.zeros((h, w), dtype=bool)
    candidate[ys, xs] = True
    claimed = np.zeros((h, w), dtype=bool)
    keep = np.zeros(ys.size, dtype=bool)
    for i in range(ys.size):
        y, x = ys[i], xs[i]
        if claimed[y, x]:
            continue
        if abs(det[i]) < 1e-12:
            keep[i] = True
            claimed[y, x] = True
            continue
        y0, y1 = max(y - by[i], 0), min(y + by[i] + 1, h)
        x0, x1 = max(x - bx[i], 0), min(x + bx[i] + 1, w)
        if x0 >= x1 or y0 >= y1:
            continue
        px = XX[y0:y1, x0:x1] - x
        py = YY[y0:y1, x0:x1] - y
        c0 = (e2[i, 1] * px - e2[i, 0] * py) / det[i]
        c1 = (-e1[i, 1] * px + e1[i, 0] * py) / det[i]
        ellipse = c0 * c0 + c1 * c1 <= 1.0
        sub = claimed[y0:y1, x0:x1]
        available = np.count_nonzero(ellipse & candidate[y0:y1, x0:x1])
        if np.count_nonzero(ellipse & ~sub) < min(min_gain, available):
            continue
        keep[i] = True
        sub |= ellipse
        claimed[y, x] = True

    out = np.zeros(shape, dtype=bool)
    out[ys[keep], xs[keep]] = True
    return out


def claim_footprint(z, K, ys, xs, r1, r2, overlap, geo):
    """Image-space semi-axis vectors of the claim footprint at the given seeds."""
    n = geo.normal[ys, xs].astype(np.float64)
    n = n / np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-12)
    a1, a2 = tangent_frame(geo.t1[ys, xs].astype(np.float64), n)
    X = backproject(z, K)[ys, xs].astype(np.float64)
    return (project_tangent(a1 * (overlap * r1)[:, None], X, K),
            project_tangent(a2 * (overlap * r2)[:, None], X, K))


def select_curvature_seeds(z, K, eps, gauss_sigma, z_min, z_max, disc_rel,
                           overlap, r_max, edge_fallback_fp=True,
                           texture_mask=None, r_cap=None, geo=None,
                           floor_scale=np.sqrt(2.0), min_gain=S2_CELL_PX):
    """Coverage sampling whose claim matches the emitted anisotropic disc.

    原名: curvature_mask.

    Radii are clipped to [footprint, min(r_max, edge_limit, r_cap)]; texture
    pixels stay at footprint (no curvature enlargement). The claim is the
    projection of the same 3D ellipse the emitter builds (semi-axes r_k1 x r_k2
    in the principal-curvature frame), scaled by `overlap`. `min_gain` is passed
    through to the greedy; see coverage_sample_aniso.
    """
    if geo is None:
        geo = compute_scene_geometry(z, K, eps, gauss_sigma, disc_rel)

    lim = np.minimum(r_max, geo.r_edge)
    if r_cap is not None:
        # The claim MUST use the same shrunk radius the emitter applies, or it
        # claims space the emitted disc no longer covers -> a seam.
        lim = np.minimum(lim, r_cap)
    floor = geo.r_fp * floor_scale
    consistent = (geo.r_k1 >= floor) & (lim >= floor)
    if edge_fallback_fp:
        # Both contradiction cases (lim < floor, r_k1 < floor) are re-emitted at
        # the floor rather than dropped; the clip below already produces that
        # radius. Dropping r_k1 < floor was justified by a 54 deg normal error
        # measured before the quadric sign fix; re-measured after it, those
        # pixels deviate 7.2 deg from their 9x9 consensus normal (frame-wide
        # baseline 2.9 deg) and 99.5% have same-group neighbours, so they are
        # coherent shallow surface, not noise spikes. Dropping them accounted
        # for 37.9% of the frame-0 hole budget.
        keep_edge = consistent | (lim < floor) | (geo.r_k1 < floor)
    else:
        keep_edge = consistent

    valid = (
        geo.n_ok & geo.c_ok & keep_edge & geo.valid_depth
        & (z > z_min) & (z < z_max)
        & ~geo.disc_mask
    )
    ys, xs = np.where(valid)
    if ys.size == 0:
        return valid

    hi = np.maximum(lim, floor)
    r1 = np.clip(geo.r_k1[ys, xs], floor[ys, xs], hi[ys, xs]).astype(np.float64)
    r2 = np.clip(geo.r_k2[ys, xs], floor[ys, xs], hi[ys, xs]).astype(np.float64)
    if texture_mask is not None:
        tex = texture_mask[ys, xs]
        r1 = np.where(tex, floor[ys, xs], r1)
        r2 = np.where(tex, floor[ys, xs], r2)

    e1, e2 = claim_footprint(z, K, ys, xs, r1, r2, overlap, geo)
    return coverage_sample_aniso(ys, xs, e1, e2, valid.shape, min_gain=min_gain)


def _curv_radii_clip(geo, ys, xs, r_cap, floor_scale):
    """Clip radius for curvature discs at (ys,xs) -- same rule as select_curvature_seeds.

    r_i = clip(r_k_i, floor, min(r_max, r_edge, r_cap)); texture forcing is NOT
    applied here (curvature owner only runs on the already tex-masked keep mask).
    """
    lim = np.minimum(GEO_CFG["r_max"], geo.r_edge)
    if r_cap is not None:
        lim = np.minimum(lim, r_cap)
    floor = geo.r_fp * float(floor_scale)
    hi = np.maximum(lim, floor)
    r1 = np.clip(geo.r_k1[ys, xs], floor[ys, xs], hi[ys, xs]).astype(np.float64)
    r2 = np.clip(geo.r_k2[ys, xs], floor[ys, xs], hi[ys, xs]).astype(np.float64)
    return r1, r2


def claim_owner(ys, xs, e1, e2, shape):
    """Per-pixel disc owner taken as a side product of the claim ellipse.

    Each disc owns the pixels inside its own elliptical footprint (image-space
    semi-axis vectors `e1`/`e2`, already at the full-footprint scale), resolved
    largest-footprint-first. The owner id is the disc index in emission order =
    row-major rank of (ys, xs) -- the same order `emit_curvature_discs` yields.
    Returns an int32 (H, W) map with -1 where unowned. No ray-disc anywhere.
    """
    h, w = shape
    owner = np.full((h, w), -1, dtype=np.int32)
    n = ys.size
    if n == 0:
        return owner
    lin = ys.astype(np.int64) * w + xs.astype(np.int64)
    disc_id = np.empty(n, dtype=np.int32)
    disc_id[np.argsort(lin, kind="stable")] = np.arange(n, dtype=np.int32)

    det = e1[:, 0] * e2[:, 1] - e2[:, 0] * e1[:, 1]
    order = np.argsort(-np.abs(det), kind="stable")

    YY, XX = np.meshgrid(np.arange(h), np.arange(w), indexing="ij")
    for i in order:
        y, x = ys[i], xs[i]
        if abs(det[i]) < 1e-12:
            if owner[y, x] < 0:
                owner[y, x] = disc_id[i]
            continue
        bx = max(int(np.ceil(np.hypot(e1[i, 0], e2[i, 0]))), 0)
        by = max(int(np.ceil(np.hypot(e1[i, 1], e2[i, 1]))), 0)
        y0, y1 = max(y - by, 0), min(y + by + 1, h)
        x0, x1 = max(x - bx, 0), min(x + bx + 1, w)
        if x0 >= x1 or y0 >= y1:
            continue
        px = XX[y0:y1, x0:x1] - x
        py = YY[y0:y1, x0:x1] - y
        c0 = (e2[i, 1] * px - e2[i, 0] * py) / det[i]
        c1 = (-e1[i, 1] * px + e1[i, 0] * py) / det[i]
        ellipse = c0 * c0 + c1 * c1 <= 1.0
        sub = owner[y0:y1, x0:x1]
        sub[ellipse & (sub < 0)] = disc_id[i]
    return owner


def curvature_owner(z, K, geo, keep_geo, r_cap, floor_scale):
    """Claim-based owner for the curvature discs selected by `keep_geo`.

    `keep_geo` is the FINAL curvature keep mask (already tex-masked by the
    caller); ids are 0..N_curv-1 in emission order. The footprint is the full
    anisotropic claim ellipse (overlap 1.0 = the emitted disc).
    """
    ys, xs = np.where(keep_geo)
    if ys.size == 0:
        return np.full(keep_geo.shape, -1, dtype=np.int32)
    r1, r2 = _curv_radii_clip(geo, ys, xs, r_cap, floor_scale)
    e1, e2 = claim_footprint(z, K, ys, xs, r1, r2, 1.0, geo)
    return claim_owner(ys, xs, e1, e2, keep_geo.shape)


def s2_owner(z, geo, mask, shape, offset=0):
    """Analytic owner for stride-2 (S2) discs: each grid point owns one 2x2 cell.

    `mask` is the same mask handed to `emit_footprint_discs` (tex_mask for frame 0,
    tex & region for the region build). Ids are `offset + j`, j = S2 emission
    (row-major stride-2 grid) order, so the caller offsets by N_curv.
    """
    valid = (
        geo.n_ok & geo.valid_depth
        & (z > GEO_CFG["z_min"]) & (z < GEO_CFG["z_max"])
        & ~geo.disc_mask & mask
    )
    keep = np.zeros_like(valid)
    keep[::S2_STRIDE, ::S2_STRIDE] = True
    valid &= keep
    ys, xs = np.where(valid)
    owner = np.full(shape, -1, dtype=np.int32)
    for j, (y, x) in enumerate(zip(ys, xs)):
        owner[y:min(y + S2_STRIDE, shape[0]), x:min(x + S2_STRIDE, shape[1])] = offset + j
    return owner


def owner_from_claim(z, K, geo, keep_geo, tex_mask, r_cap, floor_scale):
    """Compose a full pixel->disc owner map from the claim (no rasterization).

    Curvature discs own their full anisotropic claim ellipse (ids 0..N_curv-1);
    S2 discs own analytic 2x2 cells (ids N_curv..). `keep_geo` must already be
    tex-masked (`keep_geo & ~tex_mask`), which is exactly what `build_hybrid` and
    `build_hybrid_region` emit.
    """
    owner = curvature_owner(z, K, geo, keep_geo, r_cap, floor_scale)
    n_curv = int(keep_geo.sum())
    s2 = s2_owner(z, geo, tex_mask, keep_geo.shape, offset=n_curv)
    return np.where(s2 >= 0, s2, owner)


# ---------------------------------------------------------------------------
# emission
# ---------------------------------------------------------------------------

def backproject(z: np.ndarray, K: np.ndarray) -> np.ndarray:
    h, w = z.shape
    fx, fy, cx, cy = K[0, 0], K[1, 1], K[0, 2], K[1, 2]
    xs, ys = np.meshgrid(np.arange(w, dtype=np.float32),
                         np.arange(h, dtype=np.float32))
    return np.stack([(xs - cx) * z / fx, (ys - cy) * z / fy, z], axis=-1)


def _tangent_basis(n: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Orthonormal in-plane frame (t1, t2) for normals `n`, t2 = n x t1.

    Ref axis is +z (flipped to +x near the poles) for conditioning. This is the
    exact frame `_quat_from_normal` rotates +x/+y from, so the quaternion's
    columns and `axis1`/`axis2` stay consistent.
    """
    ref = np.tile(np.array([0.0, 0.0, 1.0], dtype=np.float32), (n.shape[0], 1))
    parallel = np.abs(n[:, 2]) > 0.9
    ref[parallel] = np.array([1.0, 0.0, 0.0], dtype=np.float32)
    t1 = np.cross(ref, n)
    t1 /= np.maximum(np.linalg.norm(t1, axis=1, keepdims=True), 1e-12)
    t2 = np.cross(n, t1)
    return t1, t2


def _quat_from_frame(t1: np.ndarray, t2: np.ndarray, n: np.ndarray) -> np.ndarray:
    """wxyz quaternion of the orthonormal frame R = [t1 | t2 | n]."""
    R = np.stack([t1, t2, n], axis=-1)
    tr = R[:, 0, 0] + R[:, 1, 1] + R[:, 2, 2]
    q = np.zeros((n.shape[0], 4), dtype=np.float32)
    m0 = tr > 0
    s = np.sqrt(np.maximum(tr[m0] + 1.0, 1e-12)) * 2.0
    q[m0, 0] = 0.25 * s
    q[m0, 1] = (R[m0, 2, 1] - R[m0, 1, 2]) / s
    q[m0, 2] = (R[m0, 0, 2] - R[m0, 2, 0]) / s
    q[m0, 3] = (R[m0, 1, 0] - R[m0, 0, 1]) / s
    rest = ~m0
    if rest.any():
        Rr = R[rest]
        d = np.stack([Rr[:, 0, 0], Rr[:, 1, 1], Rr[:, 2, 2]], axis=1)
        k = np.argmax(d, axis=1)
        qr = np.zeros((Rr.shape[0], 4), dtype=np.float32)
        for axis in range(3):
            sel = k == axis
            if not sel.any():
                continue
            a, b, c = axis, (axis + 1) % 3, (axis + 2) % 3
            Rs = Rr[sel]
            s = np.sqrt(np.maximum(1.0 + Rs[:, a, a] - Rs[:, b, b] - Rs[:, c, c], 1e-12)) * 2.0
            qr[sel, 0] = (Rs[:, c, b] - Rs[:, b, c]) / s
            qr[sel, 1 + a] = 0.25 * s
            qr[sel, 1 + b] = (Rs[:, b, a] + Rs[:, a, b]) / s
            qr[sel, 1 + c] = (Rs[:, c, a] + Rs[:, a, c]) / s
        q[rest] = qr
    return q / np.maximum(np.linalg.norm(q, axis=1, keepdims=True), 1e-12)


def _quat_from_normal(n: np.ndarray) -> np.ndarray:
    """Rotation taking +z onto the normal, as a wxyz quaternion."""
    t1, t2 = _tangent_basis(n)
    return _quat_from_frame(t1, t2, n)


def emit_footprint_discs(bgr, z, K, z_min=0.4, z_max=4.0, disc_rel=0.02,
                         stride=1, mask=None, prefilter="none",
                         prefilter_size=5, valid_depth=None, radius_scale=1.0,
                         geo=None):
    """One isotropic footprint disc per selected pixel (S2 uniform build).

    原名: build_gaussians. Pass geo to reuse the shared smoothed depth/normal/
    discontinuity mask (correct only at the same gauss_sigma).
    """
    if geo is not None:
        valid_depth = geo.valid_depth
        z_grad, normal, n_ok = geo.z_grad, geo.normal, geo.n_ok
        disc_mask = geo.disc_mask
    else:
        if valid_depth is None:
            valid_depth = depth_valid(z)
        z_grad = prefilter_depth(z, prefilter, prefilter_size, valid=valid_depth)
        normal, n_ok = surface_normals(z_grad, K)
        disc_mask = depth_discontinuity_mask(z, disc_rel, valid=valid_depth)
    r = surfel_radius(z, normal[..., 2], K) * radius_scale
    valid = n_ok & valid_depth & (z > z_min) & (z < z_max) & ~disc_mask
    if mask is not None:
        valid &= mask
    if stride > 1:
        keep = np.zeros_like(valid)
        keep[::stride, ::stride] = True
        valid &= keep
    ys, xs = np.where(valid)
    n = normal[ys, xs]
    rad = r[ys, xs].astype(np.float32)
    scale = np.stack([rad, rad, THIN_AXIS_RATIO * rad], axis=1)
    color = bgr[ys, xs][:, ::-1].astype(np.float32) / 255.0
    a1, a2 = _tangent_basis(n)
    # Default S2 centre convention: the disc sits on the pixel centre
    # (x+0.5, y+0.5), not on the integer 2x2-cell corner. The corner placement
    # left every disc half a pixel off its owner cell; that sub-pixel bias
    # accumulated across incremental frames into visible distortion of flat,
    # axis-aligned surfaces (keyboard). Radius and the 2x2 owner map stay
    # unchanged -- only the centre is the corrected default.
    zc = z[ys, xs]
    fx, fy, ccx, ccy = K[0, 0], K[1, 1], K[0, 2], K[1, 2]
    mu = np.stack([
        (xs + 0.5 - ccx) * zc / fx,
        (ys + 0.5 - ccy) * zc / fy,
        zc,
    ], axis=1).astype(np.float32)
    return Gaussians(
        mu=mu, normal=n, scale=scale,
        quat=_quat_from_frame(a1, a2, n), color=color,
        alpha=np.full(ys.shape[0], OPAQUE_ALPHA, dtype=np.float32),
        pixel=np.stack([xs, ys], axis=1).astype(np.int32),
        axis1=a1.astype(np.float32), axis2=a2.astype(np.float32),
    )


def _normal_from_disc_inliers_fast(z_grad, K, ys, xs, center_n, normal_full,
                                   r_px_a, r_px_b, dirs_img, normal_tol_deg=30.0):
    """Disc normal via angle-gate + unit-normal sum.

    原名: _normal_from_disc_inliers_fast (the active path; the lstsq baseline
    _normal_from_disc_inliers was removed as replaced dead code). Inliers are
    pixels inside the disc ellipse whose per-pixel normal agrees with the disc
    centre normal within normal_tol_deg; the disc normal is the unit-sum of
    those inlier normals (~ least-squares direction, no per-disc SVD).
    """
    cos_tol = float(np.cos(np.deg2rad(normal_tol_deg)))
    h, w = z_grad.shape[:2]
    YY, XX = np.meshgrid(np.arange(h), np.arange(w), indexing="ij")
    n_out = np.zeros((ys.size, 3), dtype=np.float32)
    for i in range(ys.size):
        yc, xc = ys[i], xs[i]
        n0 = center_n[i]
        du, dv = dirs_img[i]
        dl = max(float(np.hypot(du, dv)), 1e-9)
        du, dv = du / dl, dv / dl
        pu, pv = -dv, du
        ra = max(float(r_px_a[i]), 1.0)
        rb = max(float(r_px_b[i]), 1.0)
        bbox = int(np.ceil(max(ra, rb))) + 1
        y0, y1 = max(yc - bbox, 0), min(yc + bbox + 1, h)
        x0, x1 = max(xc - bbox, 0), min(xc + bbox + 1, w)
        if x0 >= x1 or y0 >= y1:
            continue
        zz = z_grad[y0:y1, x0:x1]
        px = XX[y0:y1, x0:x1] - xc
        py = YY[y0:y1, x0:x1] - yc
        ca = px * du + py * dv
        cb = px * pu + py * pv
        nn = normal_full[y0:y1, x0:x1]
        dot = nn[..., 0] * n0[0] + nn[..., 1] * n0[1] + nn[..., 2] * n0[2]
        m = ((ca / ra) ** 2 + (cb / rb) ** 2 <= 1.0) & (zz > 1e-6) & (dot > cos_tol)
        if m.sum() < 8:
            continue
        acc = nn[m].sum(axis=0)
        ln = float(np.linalg.norm(acc))
        if ln < 1e-12:
            continue
        nv = acc / ln
        n_out[i] = nv if nv[2] < 0 else -nv
    return n_out


def emit_curvature_discs(bgr, z, K, eps=0.001, gauss_sigma=3.0, r_max=0.05,
                         shrink=1.0, z_min=0.4, z_max=4.0, disc_rel=0.02,
                         stride=1, mask=None, valid_depth=None, r_cap=None,
                         geo=None, floor_scale=np.sqrt(2.0)):
    """Anisotropic discs sized by principal curvature.

    原名: build_gaussians_curvature. Disc normal is the angle-gated unit-sum of
    the disc's own inliers (_normal_from_disc_inliers_fast; the lstsq 'perpixel'
    path was removed). r_i = clip(sqrt(2 eps / |k_i|), footprint,
    min(r_max, edge, r_cap)), then shrunk by shrink. Pass geo to reuse the
    shared fields.
    """
    if geo is not None:
        valid_depth = geo.valid_depth
        z_grad = geo.z_grad
        n_ok = geo.n_ok
        k1, k2, t1, c_ok, dir_img = geo.k1, geo.k2, geo.t1, geo.c_ok, geo.dir_img
        r_k1, r_k2, r_fp, r_edge = geo.r_k1, geo.r_k2, geo.r_fp, geo.r_edge
        disc_mask = geo.disc_mask
        normal = geo.normal
    else:
        if valid_depth is None:
            valid_depth = depth_valid(z)
        z_grad = prefilter_depth(z, "gauss", gauss_sigma, valid=valid_depth)
        normal, n_ok = surface_normals(z_grad, K)
        k1, k2, t1, c_ok, dir_img = scale_space_curvature(z_grad, K)
        r_k1, r_k2 = curvature_radii(k1, k2, eps)
        r_fp = surfel_radius(z, normal[..., 2], K)
        r_edge = edge_distance_limit(z, K, disc_rel, valid=valid_depth)
        disc_mask = depth_discontinuity_mask(z, disc_rel, valid=valid_depth)
    X = backproject(z, K)
    valid = n_ok & c_ok & valid_depth & (z > z_min) & (z < z_max) & ~disc_mask
    if mask is not None:
        valid &= mask
    if stride > 1:
        keep = np.zeros_like(valid)
        keep[::stride, ::stride] = True
        valid &= keep
    ys, xs = np.where(valid)
    n = normal[ys, xs]
    fp = (r_fp[ys, xs] * floor_scale).astype(np.float32)
    lim = np.minimum(r_max, r_edge[ys, xs])
    if r_cap is not None:
        lim = np.minimum(lim, r_cap[ys, xs])
    r1 = np.clip(r_k1[ys, xs], fp, np.maximum(lim, fp)).astype(np.float32)
    r2 = np.clip(r_k2[ys, xs], fp, np.maximum(lim, fp)).astype(np.float32)
    r1 = (r1 * shrink).astype(np.float32)
    r2 = (r2 * shrink).astype(np.float32)

    f_mean = 0.5 * (K[0, 0] + K[1, 1])
    zc = z[ys, xs]
    ra_px = (r1 * shrink) * f_mean / np.maximum(zc, 1e-6)
    rb_px = (r2 * shrink) * f_mean / np.maximum(zc, 1e-6)
    n_fit = _normal_from_disc_inliers_fast(
        z_grad, K, ys, xs, n.astype(np.float64), normal, ra_px, rb_px,
        dir_img[ys, xs],
    )
    ok_fit = np.linalg.norm(n_fit, axis=1) > 0.5
    n = np.where(ok_fit[:, None], n_fit, n).astype(np.float32)
    n = n / np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-12)

    a1 = t1[ys, xs]
    a1 = a1 - np.einsum("ij,ij->i", a1, n)[:, None] * n
    a1n = np.linalg.norm(a1, axis=1, keepdims=True)
    degenerate = (a1n < 1e-9).ravel()
    a1 = a1 / np.maximum(a1n, 1e-12)
    if degenerate.any():
        fb = np.tile(np.array([1.0, 0.0, 0.0], np.float32), (degenerate.sum(), 1))
        fb = fb - np.einsum("ij,ij->i", fb, n[degenerate])[:, None] * n[degenerate]
        a1[degenerate] = fb / np.maximum(
            np.linalg.norm(fb, axis=1, keepdims=True), 1e-12)
    a2 = np.cross(n, a1)

    scale = np.stack([r1, r2, THIN_AXIS_RATIO * np.minimum(r1, r2)], axis=1)
    return Gaussians(
        mu=X[ys, xs].astype(np.float32), normal=n, scale=scale,
        quat=_quat_from_normal(n),
        color=bgr[ys, xs][:, ::-1].astype(np.float32) / 255.0,
        alpha=np.full(ys.shape[0], OPAQUE_ALPHA, dtype=np.float32),
        pixel=np.stack([xs, ys], axis=1).astype(np.int32),
        axis1=a1.astype(np.float32), axis2=a2.astype(np.float32),
    )


# ---------------------------------------------------------------------------
# texture mask (originally in exp_h_texture_mask.py)
# ---------------------------------------------------------------------------

def texture_variance(rgb: np.ndarray, win: int = 9) -> np.ndarray:
    """Per-pixel RGB variance over a win x win box, mean over channels.

    Box support matches the curvature quadric's explicit support, so texture and
    geometry see the same neighbourhood. Var = E[c^2] - E[c]^2 (two box blurs).
    """
    mu = cv2.blur(rgb, (win, win))
    mu2 = cv2.blur(rgb * rgb, (win, win))
    return (mu2 - mu * mu).mean(axis=-1)


TEX_VAR_THR = 4e-4  # fixed texture-variance threshold ([0,1]^2 RGB), dataset-specific hyperparameter


def texture_mask(rgb: np.ndarray, quantile: float = 0.6, win: int = 9,
                 floor: float = 1e-9, thr: float | None = None) -> np.ndarray:
    """Binary texture mask: per-pixel win x win box variance > `thr`.

    The threshold is the fixed hyperparameter `TEX_VAR_THR`, not a per-image
    variance quantile. Recomputing a quantile per frame lets the threshold drift
    with camera motion and flips the same physical surface between S2 and
    curvature from frame to frame. `thr` overrides the constant; `quantile` /
    `floor` are kept for call-site compatibility.
    """
    var = texture_variance(rgb, win)
    if thr is None:
        thr = TEX_VAR_THR
    return var > thr


def concatenate_gaussians(parts: list) -> Gaussians:
    """Concatenate primitive sets. 原名: concat."""
    if len(parts) == 1:
        return parts[0]
    return Gaussians(
        mu=np.concatenate([p.mu for p in parts], axis=0).astype(np.float32),
        normal=np.concatenate([p.normal for p in parts], axis=0).astype(np.float32),
        scale=np.concatenate([p.scale for p in parts], axis=0).astype(np.float32),
        quat=np.concatenate([p.quat for p in parts], axis=0).astype(np.float32),
        color=np.concatenate([p.color for p in parts], axis=0).astype(np.float32),
        alpha=np.concatenate([p.alpha for p in parts], axis=0).astype(np.float32),
        pixel=np.concatenate([p.pixel for p in parts], axis=0).astype(np.int32),
        axis1=(np.concatenate([p.axis1 for p in parts if p.axis1 is not None], axis=0)
               if all(p.axis1 is not None for p in parts) else None),
        axis2=(np.concatenate([p.axis2 for p in parts if p.axis2 is not None], axis=0)
               if all(p.axis2 is not None for p in parts) else None),
    )


def _build_hybrid_parts(dbgr, z, K, texture_quantile, radius_scale,
                        tex_boundary_tol_px, curvature_floor_scale, edge_fallback):
    """Build hybrid discs + the intermediate masks/geometry needed for ownership.

    Returns (gaussians, keep_geo, tex_mask, geo, r_cap); `keep_geo` is already
    tex-masked. Split out so `build_hybrid` and `build_hybrid_with_owner` share
    one emission path.
    """
    rgb = dbgr[..., ::-1].astype(np.float32) / 255.0
    tex_mask = texture_mask(rgb, texture_quantile)
    r_cap = None
    if tex_boundary_tol_px > 0:
        r_cap = tex_boundary_limit(z, K, tex_mask, tol_px=tex_boundary_tol_px)
    geo = compute_scene_geometry(
        z, K, GEO_CFG["eps"], GEO_CFG["gauss_sigma"], GEO_CFG["disc_rel"],
    )
    keep_geo = select_curvature_seeds(
        z, K, GEO_CFG["eps"], GEO_CFG["gauss_sigma"], GEO_CFG["z_min"],
        GEO_CFG["z_max"], GEO_CFG["disc_rel"], GEO_CFG["overlap"], GEO_CFG["r_max"],
        edge_fallback_fp=edge_fallback, r_cap=r_cap, geo=geo,
        floor_scale=curvature_floor_scale,
    )
    keep_geo = keep_geo & ~tex_mask
    parts = []
    if keep_geo.any():
        parts.append(emit_curvature_discs(
            dbgr, z, K, eps=GEO_CFG["eps"], gauss_sigma=GEO_CFG["gauss_sigma"],
            r_max=GEO_CFG["r_max"], shrink=GEO_CFG["shrink"],
            z_min=GEO_CFG["z_min"], z_max=GEO_CFG["z_max"],
            disc_rel=GEO_CFG["disc_rel"], mask=keep_geo, r_cap=r_cap, geo=geo,
            floor_scale=curvature_floor_scale,
        ))
    if tex_mask.any():
        parts.append(emit_footprint_discs(
            dbgr, z, K, z_min=GEO_CFG["z_min"], z_max=GEO_CFG["z_max"],
            disc_rel=GEO_CFG["disc_rel"], stride=2, mask=tex_mask,
            radius_scale=radius_scale, geo=geo,
        ))
    return concatenate_gaussians(parts), keep_geo, tex_mask, geo, r_cap


def build_hybrid(dbgr, z, K, texture_quantile: float,
                 radius_scale: float = np.sqrt(2.0),
                 tex_boundary_tol_px: float = 4.5,
                 curvature_floor_scale: float = np.sqrt(2.0),
                 edge_fallback: bool = True):
    """Texture mask -> S2 (stride 2) inside, curvature outside.

    原名: build_s2_fallback. Texture pixels are covered by a stride-2 footprint
    build; non-texture pixels by the curvature pipeline whose radius is clamped
    by tex_boundary_limit so a large flat disc cannot poke past the colour
    boundary. Overlaps resolve via the ray-disc nearest-hit test.

    `edge_fallback=False` disables the black-edge fill (the `lim<floor` /
    `r_k1<floor` edge re-emission) -- edge-band pixels are dropped instead of
    re-emitted at the footprint floor, leaving a black edge to be filled by a
    later observation.

    Returns (gaussians, keep_geo, tex_mask).
    """
    g, keep_geo, tex_mask, _, _ = _build_hybrid_parts(
        dbgr, z, K, texture_quantile, radius_scale, tex_boundary_tol_px,
        curvature_floor_scale, edge_fallback,
    )
    return g, keep_geo, tex_mask


def build_hybrid_with_owner(dbgr, z, K, texture_quantile: float,
                            radius_scale: float = np.sqrt(2.0),
                            tex_boundary_tol_px: float = 4.5,
                            curvature_floor_scale: float = np.sqrt(2.0),
                            edge_fallback: bool = True):
    """`build_hybrid` + a claim-based pixel->disc owner map (no rasterization).

    owner id is the disc index in `g`. Curvature discs own their full anisotropic
    claim ellipse; S2 discs own analytic 2x2 cells. Returns
    (gaussians, keep_geo, tex_mask, owner).
    """
    g, keep_geo, tex_mask, geo, r_cap = _build_hybrid_parts(
        dbgr, z, K, texture_quantile, radius_scale, tex_boundary_tol_px,
        curvature_floor_scale, edge_fallback,
    )
    owner = owner_from_claim(z, K, geo, keep_geo, tex_mask, r_cap,
                             curvature_floor_scale)
    return g, keep_geo, tex_mask, owner


# ---------------------------------------------------------------------------
# evaluation (originally in metrics.py)
# ---------------------------------------------------------------------------

def rasterize_discs(g: Gaussians, K, shape, window=None, sigma_extent=1.0):
    """Front-most ray-disc intersection per pixel.

    Returns (depth, index, normal): depth is inf where nothing was hit.
    """
    h, w = shape
    fx, fy, cx, cy = K[0, 0], K[1, 1], K[0, 2], K[1, 2]
    zc = g.mu[:, 2]
    u0 = fx * g.mu[:, 0] / zc + cx
    v0 = fy * g.mu[:, 1] / zc + cy
    r_a = g.scale[:, 0] * sigma_extent
    r_b = g.scale[:, 1] * sigma_extent
    anisotropic = g.axis1 is not None and g.axis2 is not None
    radius = np.maximum(r_a, r_b)
    if window is None:
        proj_px = 0.5 * (fx + fy) * radius / np.maximum(zc, 1e-6)
        window = int(np.ceil(np.percentile(proj_px, 99.5))) + 1
        window = max(2, min(window, 64))
    depth = np.full(h * w, np.inf, dtype=np.float32)
    index = np.full(h * w, -1, dtype=np.int64)
    n = g.normal
    n_dot_mu = np.einsum("ij,ij->i", n, g.mu)
    ub = np.round(u0).astype(np.int64)
    vb = np.round(v0).astype(np.int64)
    for dv in range(-window, window + 1):
        for du in range(-window, window + 1):
            u = ub + du
            v = vb + dv
            ok = (u >= 0) & (u < w) & (v >= 0) & (v < h)
            if not ok.any():
                continue
            idx = np.nonzero(ok)[0]
            uu = u[idx].astype(np.float32)
            vv = v[idx].astype(np.float32)
            d = np.stack([(uu - cx) / fx, (vv - cy) / fy, np.ones_like(uu)], axis=1)
            denom = np.einsum("ij,ij->i", n[idx], d)
            live = np.abs(denom) > 1e-9
            if not live.any():
                continue
            idx = idx[live]
            d = d[live]
            t = n_dot_mu[idx] / denom[live]
            front = t > 0
            if not front.any():
                continue
            idx = idx[front]
            P = d[front] * t[front][:, None]
            off = P - g.mu[idx]
            if anisotropic:
                pa = np.einsum("ij,ij->i", off, g.axis1[idx]) / np.maximum(r_a[idx], 1e-9)
                pb = np.einsum("ij,ij->i", off, g.axis2[idx]) / np.maximum(r_b[idx], 1e-9)
                inside = (pa * pa + pb * pb) <= 1.0
            else:
                inside = np.linalg.norm(off, axis=1) <= r_a[idx]
            if not inside.any():
                continue
            idx = idx[inside]
            pz = P[inside, 2].astype(np.float32)
            flat = (v[idx] * w + u[idx]).astype(np.int64)
            np.minimum.at(depth, flat, pz)
            won = depth[flat] == pz
            index[flat[won]] = idx[won]
    depth = depth.reshape(h, w)
    index = index.reshape(h, w)
    normal = np.zeros((h, w, 3), dtype=np.float32)
    hit = index >= 0
    normal[hit] = g.normal[index[hit]]
    return depth, index, normal


def evaluate(g: Gaussians, z_ref, bgr_ref, normal_ref, eval_mask, K) -> dict:
    h, w = z_ref.shape
    depth, index, normal = rasterize_discs(g, K, (h, w))
    hit = np.isfinite(depth) & eval_mask
    coverage = float(hit.sum() / max(eval_mask.sum(), 1))
    err = depth[hit] - z_ref[hit]
    rmse = float(np.sqrt(np.mean(err ** 2)))
    mae = float(np.mean(np.abs(err)))
    med = float(np.median(np.abs(err)))
    p95 = float(np.percentile(np.abs(err), 95))
    cos = np.clip(np.einsum("ij,ij->i", normal[hit], normal_ref[hit]), -1.0, 1.0)
    ang = np.degrees(np.arccos(np.abs(cos)))
    area_ang = _normal_area_error(g, normal_ref, index, hit)
    rgb_ref = bgr_ref[..., ::-1].astype(np.float32) / 255.0
    col_err = g.color[index[hit]] - rgb_ref[hit]
    col_rmse = float(np.sqrt(np.mean(col_err ** 2)))
    area = _surface_area(g)
    out = {
        "n_gaussians": len(g),
        "coverage": coverage,
        "hole_frac": 1.0 - coverage,
        "depth_rmse_mm": rmse * 1000.0,
        "depth_mae_mm": mae * 1000.0,
        "depth_med_mm": med * 1000.0,
        "depth_p95_mm": p95 * 1000.0,
        "normal_med_deg": float(np.median(ang)),
        "normal_mean_deg": float(np.mean(ang)),
        "normal_p95_deg": float(np.percentile(ang, 95)),
        "color_psnr_db": float(-20.0 * np.log10(max(col_rmse, 1e-12))),
        "surface_area_m2": area,
        "gauss_per_m2": float(len(g) / max(area, 1e-9)),
        "radius_med_mm": float(np.median(g.scale[:, 0]) * 1000.0),
    }
    out.update(area_ang)
    return out


def _normal_area_error(g, normal_ref, index, hit) -> dict:
    idx = index[hit]
    if idx.size == 0:
        return {"normal_area_med_deg": float("nan"),
                "normal_area_mean_deg": float("nan"),
                "normal_area_p95_deg": float("nan")}
    nref = normal_ref[hit]
    n_g = len(g)
    acc = np.zeros((n_g, 3), dtype=np.float64)
    sgn = np.sign(np.einsum("ij,ij->i", nref, g.normal[idx]))
    sgn[sgn == 0] = 1.0
    for c in range(3):
        acc[:, c] = np.bincount(idx, weights=nref[:, c] * sgn, minlength=n_g)
    cnt = np.bincount(idx, minlength=n_g)
    live = cnt > 0
    mean_n = acc[live] / cnt[live][:, None]
    ln = np.linalg.norm(mean_n, axis=1)
    ok = ln > 1e-9
    mean_n = mean_n[ok] / ln[ok][:, None]
    cos = np.clip(np.einsum("ij,ij->i", mean_n, g.normal[live][ok]), -1.0, 1.0)
    ang = np.degrees(np.arccos(np.abs(cos)))
    return {"normal_area_med_deg": float(np.median(ang)),
            "normal_area_mean_deg": float(np.mean(ang)),
            "normal_area_p95_deg": float(np.percentile(ang, 95))}


def _surface_area(g) -> float:
    return float(np.sum(np.pi * g.scale[:, 0] * g.scale[:, 1]) / 2.0)


# ---------------------------------------------------------------------------
# reference setup + render (originally eval_setup in exp_g_aniso_real.py)
# ---------------------------------------------------------------------------

def eval_setup(z, K):
    """Independent-ish eval reference normal + mask. NOTE: uses the same 3x3
    Sobel normal as the pipeline -- NOT independent; see de-dup report."""
    zd = depth_valid(z)
    z_grad = prefilter_depth(z, "gauss", int(GEO_CFG["gauss_sigma"]), valid=zd)
    normal_ref, n_ok = surface_normals(z_grad, K)
    eval_mask = (
        n_ok & zd & (z > GEO_CFG["z_min"]) & (z < GEO_CFG["z_max"])
        & ~depth_discontinuity_mask(z, GEO_CFG["disc_rel"], valid=zd)
    )
    return normal_ref, eval_mask


# ---------------------------------------------------------------------------
# self-check (frame 0, fr1/desk)
# ---------------------------------------------------------------------------

def _selfcheck(frame_idx: int = 0) -> None:
    data_dir = ROOT.parent.parent.parent / "986-SceneFlow" / "rgbd_dataset_freiburg1_desk"
    pairs = associate(data_dir)
    fr = pairs[frame_idx]
    map1, map2, K = undistort_maps((480, 640), FR1_INTRINSICS)
    bgr = remap_rgb(load_rgb(fr.rgb_path), map1, map2)
    z = remap_depth(load_depth(fr.depth_path), map1, map2)
    z[z < GEO_CFG["z_min"]] = 0.0
    z[z > GEO_CFG["z_max"]] = 0.0

    normal_ref, eval_mask = eval_setup(z, K)
    g, keep_geo, tex_mask = build_hybrid(bgr, z, K, 0.6)
    m = evaluate(g, z, bgr, normal_ref, eval_mask, K)
    print(f"frame {frame_idx}: N={m['n_gaussians']} RMSE={m['depth_rmse_mm']:.2f} mm "
          f"PSNR={m['color_psnr_db']:.2f} dB hole={m['hole_frac']:.4f} "
          f"normal_med={m['normal_med_deg']:.2f} deg area_med={m['normal_area_med_deg']:.2f} deg")


if __name__ == "__main__":
    import time
    t0 = time.perf_counter()
    _selfcheck()
    print(f"elapsed {time.perf_counter() - t0:.1f} s")