"""Overlay the ray-coverage holes on the frame-0 GT image (right-half zoom)."""
from __future__ import annotations

import sys
from pathlib import Path

import cv2
import numpy as np

SEQ = Path(__file__).resolve().parent
SINGLE = SEQ.parent.parent / "SINGLE FRAME" / "scripts"
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SFLOW))
sys.path.insert(0, str(SINGLE))
sys.path.insert(0, str(SEQ))

import sequential_fusion_flowonly as SF  # noqa: E402

OUT = SEQ.parent / "output_discmask_align"
DEPTH_NPY = OUT / "f0_depth_hard.npy"


def main() -> None:
    pairs = SF.associate(SF.DATA, max_dt=0.02)[: 11]
    sample = SF.load_rgb(pairs[0].rgb_path)
    h, w = sample.shape[:2]
    map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)
    bgr0, z0, _ = SF.load_pair(pairs, 0, map1, map2)

    depth_h = np.load(DEPTH_NPY)
    valid = (z0 > SF.Z_MIN) & (z0 < SF.Z_MAX)
    hole = (depth_h == 0) & valid

    vis = bgr0.copy()
    # mark every hole pixel in bright magenta, plus a small cross
    hy, hx = np.nonzero(hole)
    vis[hy, hx] = (255, 0, 255)

    # right-half crop + 2x zoom for review
    x0, x1 = w // 2, w
    crop = vis[:, x0:x1]
    zoom = cv2.resize(crop, None, fx=2.0, fy=2.0, interpolation=cv2.INTER_NEAREST)
    bar = np.full((34, zoom.shape[1], 3), 20, np.uint8)
    cv2.putText(bar, f"frame0 right-half, ray holes(magenta)={hy.size} ({100.0*hy.size/valid.sum():.3f}% valid)",
                (8, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (230, 230, 230), 1, cv2.LINE_AA)
    img = np.vstack([zoom, bar])
    cv2.imwrite(str(OUT / "f0_holes_right.png"), img)
    print(f"wrote {OUT / 'f0_holes_right.png'}  holes={hy.size}")


if __name__ == "__main__":
    main()