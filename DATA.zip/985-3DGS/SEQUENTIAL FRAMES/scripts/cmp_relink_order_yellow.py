"""Side-by-side ablation: relink order (relink-first vs flow-first) on the f0 owner map.

Re-rasterises each run's `model_f0.npz`, classifies frame-0 hard-render pixels by
disc birth frame and colour drift (identical rule to diag_left_oldnew_color.py),
and prints the yellow (old disc, colour drifted) budget of each, plus a montage.

Run:
  python scripts/cmp_relink_order_yellow.py \
      --a output_f0_80frame_olddraw --b output_f0_80frame_flowfirst
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import cv2
import numpy as np

SEQ = Path(__file__).resolve().parent
sys.path.insert(0, str(SEQ))

import h_pipeline_final as H          # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402

DRIFT_EPS = 0.04
DEPTH_TOL = 0.05
PAL = {1: (60, 200, 60), 2: (0, 200, 255), 3: (60, 60, 255), 4: (200, 0, 200)}


def tangent_basis(n: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    ref = np.zeros_like(n)
    ref[:, 2] = 1.0
    ref[np.abs(n[:, 2]) > 0.9] = np.array([1.0, 0.0, 0.0])
    a1 = np.cross(n, ref)
    a1 /= np.maximum(np.linalg.norm(a1, axis=1, keepdims=True), 1e-9)
    a2 = np.cross(n, a1)
    a2 /= np.maximum(np.linalg.norm(a2, axis=1, keepdims=True), 1e-9)
    return a1, a2


def classify(run: Path, z0: np.ndarray, gt: np.ndarray, hw: tuple[int, int]):
    h, w = hw
    d = np.load(run / "model_f0.npz")
    mu, normal, scale = d["mu"], d["normal"], d["scale"]
    color, birth, birth_color = d["color"], d["birth"], d["birth_color"]
    a1, a2 = tangent_basis(normal)
    g = H.Gaussians(mu=mu, normal=normal, scale=scale, quat=np.zeros((len(mu), 4)),
                    color=color, alpha=np.ones(len(mu)), pixel=np.zeros((len(mu), 2)),
                    axis1=a1, axis2=a2)
    pairs = SF.associate(SF.DATA, max_dt=0.02)
    _, _, K = SF.undistort_maps(hw, SF.FR1_INTRINSICS)
    depth, index, _ = H.rasterize_discs(g, K, hw)
    hit = index >= 0
    own = index[hit]
    dc = np.linalg.norm(color - birth_color, axis=1)
    b_px = np.full(hw, -1, np.int32)
    b_px[hit] = birth[own]
    dz = np.where(hit, np.abs(depth - z0) / np.maximum(z0, 1e-6), np.inf)
    on_surf = dz < DEPTH_TOL
    cls = np.zeros(hw, np.uint8)
    dcp = np.zeros(hw)
    dcp[hit] = dc[own]
    oldm = hit & (b_px == 0)
    cls[oldm & (dcp <= DRIFT_EPS)] = 1
    cls[oldm & (dcp > DRIFT_EPS)] = 2
    newm = hit & (b_px >= 1)
    cls[newm & on_surf] = 3
    cls[newm & ~on_surf] = 4
    err = np.zeros(hw)
    err[hit] = np.linalg.norm(color[own] - gt[hit], axis=1)
    return dict(cls=cls, dcp=dcp, err=err, hit=hit, dc=dc, birth=birth,
                n=len(mu), depth=depth, az=z0, loss=float(err[hit].mean()))


def report(tag: str, r: dict) -> None:
    h, w = r["cls"].shape
    selL = np.zeros((h, w), bool)
    selL[:, :128] = True
    print(f"\n== {tag} ==  N={r['n']}  coverage={r['hit'].mean():.4f}  "
          f"mean colour err vs f0 (hard hit)={1000 * r['loss']:.1f}e-3")
    for k, nm in {1: "GREEN old unchanged", 2: "YELLOW old drifted",
                  3: "BLUE new on-surf", 4: "MAGENTA new off-surf"}.items():
        m = r["cls"] == k
        ml = m & selL
        print(f"  {nm:22s} px={int(m.sum()):7d} (left={int(ml.sum()):7d})  "
              f"{100 * m.sum() / max(int(r['hit'].sum()), 1):5.1f}%")
    old = r["birth"] == 0
    print(f"  old discs: {int(old.sum())}  drifted(>{DRIFT_EPS}): "
          f"{int((old & (r['dc'] > DRIFT_EPS)).sum())}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--a", default="output_f0_80frame_olddraw",
                    help="default: relink-first (current)")
    ap.add_argument("--b", default="output_f0_80frame_flowfirst",
                    help="ablation: flow-first (legacy order)")
    ap.add_argument("--frames", type=int, default=81)
    args = ap.parse_args()
    run_a = SEQ.parent / args.a
    run_b = SEQ.parent / args.b

    pairs = SF.associate(SF.DATA, max_dt=0.02)[: args.frames]
    sample = SF.load_rgb(pairs[0].rgb_path)
    hw = sample.shape[:2]
    map1, map2, K = SF.undistort_maps(hw, SF.FR1_INTRINSICS)
    bgr0, z0, _ = SF.load_pair(pairs, 0, map1, map2)
    gt = bgr0[..., ::-1].astype(np.float32) / 255.0

    ra = classify(run_a, z0, gt, hw)
    rb = classify(run_b, z0, gt, hw)
    report(f"A relink-first (current)  {args.a}", ra)
    report(f"B flow-first  (legacy)   {args.b}", rb)

    # ---- montage: A map | B map | A-B diff of the "old drifted" mask ----
    def vis(r, label):
        img = (gt * 0.30 * 255).astype(np.uint8)
        for k, c in PAL.items():
            img[r["cls"] == k] = c
        bar = np.full((30, img.shape[1], 3), 20, np.uint8)
        cv2.putText(bar, label, (8, 21), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                    (230, 230, 230), 1, cv2.LINE_AA)
        return np.vstack([img, bar])

    ya = (ra["cls"] == 2)
    yb = (rb["cls"] == 2)
    diff = (gt * 0.30 * 255).astype(np.uint8)
    diff[ya & ~yb] = (80, 220, 80)      # yellow only in A (relink-first)
    diff[yb & ~ya] = (0, 140, 255)      # yellow only in B (flow-first)
    diff[ya & yb] = (90, 90, 90)
    dbar = np.full((30, diff.shape[1], 3), 20, np.uint8)
    cv2.putText(dbar, "yellow-only-in-A=GREEN | yellow-only-in-B=ORANGE | both=GREY",
                (8, 21), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (230, 230, 230), 1, cv2.LINE_AA)
    diff = np.vstack([diff, dbar])

    mont = np.vstack([
        vis(ra, f"A relink-first (current default)  {args.a}"),
        vis(rb, f"B flow-first (legacy order)  {args.b}"),
        diff,
    ])
    out = SEQ.parent / "output_f0_80frame_flowfirst" / "cmp_relink_order_yellow.png"
    cv2.imwrite(str(out), mont)
    crop = np.hstack([
        vis(ra, "A relink-first")[:, :200], vis(rb, "B flow-first")[:, :200],
        diff[:, :200],
    ])
    cv2.imwrite(str(out.with_name("cmp_relink_order_yellow_left.png")),
                cv2.resize(crop, None, fx=2.0, fy=2.0, interpolation=cv2.INTER_NEAREST))
    print(f"\nsaved -> {out}\n         {out.with_name('cmp_relink_order_yellow_left.png')}")


if __name__ == "__main__":
    main()