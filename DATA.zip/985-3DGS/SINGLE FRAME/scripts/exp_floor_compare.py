"""Side-by-side: curvature floor = r_fp (old) vs r_fp*sqrt(2) (new, == S2 floor).

Builds frame 0 with build_hybrid(curvature_floor_scale=...) and renders each.
The goal is to show the curvature discs in the flat/depth-edge region are no
longer smaller than the S2 discs once the floors match.
"""

from __future__ import annotations

import sys
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

import h_pipeline_final as H  # noqa: E402


def _data_dir() -> Path:
    for base in (H.ROOT.parent.parent.parent, H.ROOT.parent.parent):
        d = base / "986-SceneFlow" / "rgbd_dataset_freiburg1_desk"
        if (d / "rgb.txt").exists():
            return d
    raise FileNotFoundError("986-SceneFlow dataset not found")


def _load(idx: int):
    d = _data_dir()
    pairs = H.associate(d)
    fr = pairs[idx]
    map1, map2, K = H.undistort_maps((480, 640), H.FR1_INTRINSICS)
    bgr = H.remap_rgb(H.load_rgb(fr.rgb_path), map1, map2)
    z = H.remap_depth(H.load_depth(fr.depth_path), map1, map2)
    z[(z < H.GEO_CFG["z_min"]) | (z > H.GEO_CFG["z_max"])] = 0.0
    return bgr, z, K


def _render(g, bgr, K, shape):
    depth, index, _ = H.rasterize_discs(g, K, shape)
    hit = index >= 0
    rgb = bgr[..., ::-1].astype(np.float32) / 255.0
    out = np.zeros((*shape, 3), np.float32)
    out[hit] = g.color[index[hit]]
    # overlay disc centres so disc SIZE/placement is directly visible against color
    marker = out.copy()
    for (u, v) in g.pixel:
        if 0 <= v < shape[0] and 0 <= u < shape[1]:
            cv2.circle(marker, (int(u), int(v)), 1, (0, 0, 0), -1)
    return out, marker


def _u8(c):
    return (np.clip(c, 0, 1)[..., ::-1] * 255).astype(np.uint8)


def _label(img, s):
    o = img.copy()
    cv2.rectangle(o, (0, 0), (o.shape[1], 28), (0, 0, 0), -1)
    cv2.putText(o, s, (8, 21), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 2)
    return o


def main() -> None:
    bgr, z, K = _load(0)
    shape = z.shape

    g_old, keep_old, tex = H.build_hybrid(bgr, z, K, 0.6)
    g_new, keep_new, tex = H.build_hybrid(bgr, z, K, 0.6, curvature_floor_scale=np.sqrt(2.0))

    r_old, m_old = _render(g_old, bgr, K, shape)
    r_new, m_new = _render(g_new, bgr, K, shape)

    # per-type median radius
    def fmt(g):
        n = len(g)
        if n == 0:
            return "N=0"
        sx = g.scale[:, 0] * 1000.0
        sy = g.scale[:, 1] * 1000.0
        return (f"N={n}  r1 med={np.median(sx):.2f}mm  "
                f"r2 med={np.median(sy):.2f}mm  mean={sx.mean():.2f}mm")

    px = g_new.pixel
    is_tex = np.zeros(len(g_new), bool)
    if len(g_new):
        is_tex = tex[px[:, 1], px[:, 0]]

    print("OLD (floor = r_fp):", fmt(g_old))
    print("NEW (floor = r_fp*sqrt2):", fmt(g_new))
    print(f"  new S2/tex discs      : {int(is_tex.sum())}")
    print(f"  new curvature discs   : {int((~is_tex).sum())}")

    panel = np.vstack([
        np.hstack([
            _label(bgr, "input RGB"),
            _label(_u8(r_old), "OLD floor=r_fp  " + fmt(g_old)),
            _label(_u8(r_new), "NEW floor=r_fp*sqrt2  " + fmt(g_new)),
        ]),
        np.hstack([
            _label(bgr, "input RGB (dark)"),
            _label(_u8(m_old), "OLD disc centres"),
            _label(_u8(m_new), "NEW disc centres"),
        ]),
    ])

    out_dir = H.ROOT.parent / "output_H_floor"
    out_dir.mkdir(parents=True, exist_ok=True)
    p = out_dir / "floor_compare_frame0.png"
    cv2.imwrite(str(p), panel)
    print(f"wrote {p}  shape={panel.shape}")


if __name__ == "__main__":
    import time
    t0 = time.perf_counter()
    main()
    print(f"elapsed {time.perf_counter() - t0:.1f} s")