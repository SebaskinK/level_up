"""Compare frame-0-only render vs 10-frame render in the desk-edge region."""
import sys
from pathlib import Path

import cv2
import numpy as np

SEQ = Path(__file__).resolve().parent
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SEQ))
sys.path.insert(0, str(SFLOW))

import h_pipeline_final as H  # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402

OUT = SEQ.parent / "output_f0_10frame"

pairs = SF.associate(SF.DATA, max_dt=0.02)[:1]
h, w = SF.load_rgb(pairs[0].rgb_path).shape[:2]
map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)
bgr0, z0, _ = SF.load_pair(pairs, 0, map1, map2)

g0, _, _, owner0 = H.build_hybrid_with_owner(bgr0, z0, K, SF.TEX_Q)
print("frame0 N =", len(g0))

def render(g):
    depth, index, _ = H.rasterize_discs(g, K, (h, w))
    hit = np.isfinite(depth)
    out = np.zeros((h, w, 3), np.float32)
    out[hit] = g.color[index[hit]]
    return (np.clip(out, 0, 1) * 255).astype(np.uint8)

r0 = render(g0)
cv2.imwrite(str(OUT / "dbg_f0only.png"), r0)

hard = cv2.imread(str(OUT / "f0_hard.png"))
gt = cv2.imread(str(OUT / "f0_gt.png"))

y0, y1, x0, x1 = 366, 400, 400, 640
for name, im in [("gt", gt), ("f0only", r0), ("10frame", hard)]:
    reg = im[y0:y1, x0:x1].astype(np.float32)
    print(f"{name:8s} behind-edge mean BGR = {reg.mean(axis=(0,1)).round(1)}")

# white-over-gray metric in behind-edge region for f0only vs 10frame
def white_over_gray(im):
    im = im.astype(np.float32)[y0:y1, x0:x1]
    hw = im.min(axis=2) > 175
    gs = (gt.astype(np.float32)[y0:y1, x0:x1].mean(axis=2) > 40) & \
         (gt.astype(np.float32)[y0:y1, x0:x1].mean(axis=2) < 150)
    return int((hw & gs).sum())

print("white-over-gray pixels (behind-edge): f0only =", white_over_gray(r0),
      " 10frame =", white_over_gray(hard))