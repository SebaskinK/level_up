"""Same-renderer, same-frame, two-model coverage comparison (frame 0).

Decisive test of "incremental has more holes than single-frame":

  single-frame : H.build_hybrid(bgr0, z0, K, 0.6)
  final model  : 10-frame incremental result, placed back to frame 0
                 (T = FL9^-1, since frame0 GT = identity)

Both rendered identically -- hard ray-disc, EWA@1.0, EWA@0.33 -- and scored on
the SAME eval_mask. If incremental has genuinely more holes, eval_cov will be
lower than single-frame at every render setting.

Also localizes the extra holes: pixels covered by single-frame's raster but NOT
by the final model's raster (true coverage loss), split by what disc is
supposed to own them.
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

SEQ = Path(__file__).resolve().parent
SINGLE = SEQ.parent.parent / "SINGLE FRAME" / "scripts"
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SINGLE))
sys.path.insert(0, str(SFLOW))

import h_pipeline_final as H  # noqa: E402
from exp_surfel_render import render_ewa  # noqa: E402
from tum_io import (  # noqa: E402
    FR1_INTRINSICS, associate, load_depth, load_rgb,
    remap_depth, remap_rgb, undistort_maps,
)

DATA = Path("/home/sti/Work/986-SceneFlow/rgbd_dataset_freiburg1_desk")
RENDER_DIR = SEQ.parent / "output_absorb_v2" / "render"


def stat(name, cov_hard, cov_ewa1, cov_ewa033):
    print(f"  {name:14s} hard_cov={cov_hard:.4f}  "
          f"ewa1_eval={cov_ewa1[0]:.4f}/{cov_ewa1[1]:.4f}  "
          f"ewa033_eval={cov_ewa033[0]:.4f}/{cov_ewa033[1]:.4f}")


def main() -> None:
    pairs = associate(DATA)
    fr = pairs[0]
    sample = load_rgb(fr.rgb_path)
    h, w = sample.shape[:2]
    map1, map2, K = undistort_maps((h, w), FR1_INTRINSICS)
    bgr = remap_rgb(load_rgb(fr.rgb_path), map1, map2)
    z = remap_depth(load_depth(fr.depth_path), map1, map2)
    z[(z < H.GEO_CFG["z_min"]) | (z > H.GEO_CFG["z_max"])] = 0.0
    normal_ref, eval_mask = H.eval_setup(z, K)
    n_eval = int(eval_mask.sum())

    # --- single frame ---
    g_sf, _, _ = H.build_hybrid(bgr, z, K, 0.6)
    d, idx, _ = H.rasterize_discs(g_sf, K, (h, w))
    hit_sf = np.isfinite(d)
    col1_sf, _, wt1_sf = render_ewa(g_sf, K, (h, w), mode="normalized", cov_scale=1.0)
    col033_sf, _, wt033_sf = render_ewa(g_sf, K, (h, w), mode="normalized", cov_scale=0.33)
    h1_sf = wt1_sf > 0
    h033_sf = wt033_sf > 0

    print(f"[single-frame] N={len(g_sf)} eval_px={n_eval}")
    stat("single-frame", float(hit_sf.mean()),
         (float((h1_sf & eval_mask).sum() / n_eval), float(h1_sf.mean())),
         (float((h033_sf & eval_mask).sum() / n_eval), float(h033_sf.mean())))

    # --- final model -> frame0 ---
    npz = np.load(RENDER_DIR / "model_final.npz", allow_pickle=True)
    ax1 = npz["axis1"] if npz["axis1"].shape else None
    ax2 = npz["axis2"] if npz["axis2"].shape else None
    g = H.Gaussians(
        mu=npz["mu"], normal=npz["normal"], scale=npz["scale"],
        quat=npz["quat"], color=npz["color"], alpha=npz["alpha"],
        pixel=npz["pixel"], axis1=ax1, axis2=ax2,
    )
    FL9 = (npz["FL9"], npz["FL9_t"])
    FL9_inv_R, FL9_inv_t = FL9[0].T, -FL9[0].T @ FL9[1]
    g0 = H.Gaussians(
        mu=g.mu @ FL9_inv_R.T + FL9_inv_t,
        normal=g.normal @ FL9_inv_R.T,
        scale=g.scale, quat=g.quat, color=g.color, alpha=g.alpha,
        pixel=g.pixel,
        axis1=g.axis1 @ FL9_inv_R.T if g.axis1 is not None else None,
        axis2=g.axis2 @ FL9_inv_R.T if g.axis2 is not None else None,
    )
    d, idx, _ = H.rasterize_discs(g0, K, (h, w))
    hit_f = np.isfinite(d)
    col1, _, wt1 = render_ewa(g0, K, (h, w), mode="normalized", cov_scale=1.0)
    col033, _, wt033 = render_ewa(g0, K, (h, w), mode="normalized", cov_scale=0.33)
    h1 = wt1 > 0
    h033 = wt033 > 0

    print(f"[final -> frame0] N={len(g)}")
    stat("final->f0", float(hit_f.mean()),
         (float((h1 & eval_mask).sum() / n_eval), float(h1.mean())),
         (float((h033 & eval_mask).sum() / n_eval), float(h033.mean())))

    # --- true coverage loss in eval region (hard ray-disc, apples-to-apples) ---
    lost = eval_mask & hit_sf & ~hit_f          # single covers, final does NOT
    gained = eval_mask & ~hit_sf & hit_f        # final covers, single does NOT
    print(f"\ntrue coverage delta (hard ray-disc, eval region):")
    print(f"  lost   (SF covers, final doesn't) = {int(lost.sum())} px "
          f"= {100*lost.sum()/n_eval:.2f}%")
    print(f"  gained (final covers, SF doesn't) = {int(gained.sum())} px "
          f"= {100*gained.sum()/n_eval:.2f}%")

    # spatial distribution of lost pixels: which image-region?
    ys, xs = np.where(lost)
    if ys.size:
        print(f"  lost px bbox: rows {ys.min()}..{ys.max()} "
              f"cols {xs.min()}..{xs.max()}")
        # depth of lost pixels vs covered
        zlost = z[lost]
        print(f"  lost px depth: med={np.median(zlost):.3f} "
              f"p10={np.percentile(zlost,10):.3f} p90={np.percentile(zlost,90):.3f}")


if __name__ == "__main__":
    main()