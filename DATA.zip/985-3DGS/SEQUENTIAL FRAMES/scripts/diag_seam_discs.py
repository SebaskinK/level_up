"""Inspect the disc layout across the B2 (cols 609-613) and B3 (cols 630-638)
seams to see whether the gap is a 3D spatial gap or a projection/overlap issue.

For each seam, lists every disc whose projected centre lands in a column band,
with birth frame, projected centre, 3D centre, and projected major/minor radius.
"""
from __future__ import annotations
import sys
from pathlib import Path
import numpy as np

SEQ = Path(__file__).resolve().parent
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SEQ))
sys.path.insert(0, str(SFLOW))
import h_pipeline_final as H
import sequential_fusion_flowonly as SF

d = np.load(SEQ.parent / "output_f0_ellipse_final" / "model_f0.npz")
mu = d["mu"].astype(np.float64)
normal = d["normal"].astype(np.float64)
scale = d["scale"].astype(np.float64)
birth = d["birth"].astype(np.int64)

pairs = SF.associate(SF.DATA, max_dt=0.02)[:11]
sm = SF.load_rgb(pairs[0].rgb_path)
h, w = sm.shape[:2]
m1, m2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)
fx, fy, cx, cy = (float(K[0,0]), float(K[1,1]), float(K[0,2]), float(K[1,2]))
zc = np.maximum(mu[:, 2], 1e-6)
uc = (fx * mu[:, 0] / zc + cx)
vc = (fy * mu[:, 1] / zc + cy)
r_maj = 0.5*(fx+fy) * np.maximum(scale[:, 0], scale[:, 1]) / zc
r_min = 0.5*(fx+fy) * np.minimum(scale[:, 0], scale[:, 1]) / zc

# restrict to row band 370-400
in_band = (vc >= 370) & (vc <= 400)

def dump(name, c0, c1):
    print(f"\n=== {name} cols {c0}-{c1} (row band 370-400 of projected centres) ===")
    m = in_band & (uc >= c0) & (uc <= c1)
    idx = np.nonzero(m)[0]
    order = np.argsort(uc[idx])
    print("  birth  u(px)  v(px)  mu=(x,y,z)[m]        r_maj(px) r_min(px)  z(m)")
    for i in idx[order]:
        print(f"  {birth[i]:4d}  {uc[i]:6.1f} {vc[i]:5.1f}  "
              f"({mu[i,0]:.3f},{mu[i,1]:.3f},{mu[i,2]:.3f})  "
              f"{r_maj[i]:5.1f} {r_min[i]:5.1f}  {mu[i,2]:.3f}")

dump("B2 seam", 605, 618)
dump("B3 seam", 624, 639)