"""Geometry metrics for an analytically built Gaussian field.

Depth is read out via ray-disc intersection, not alpha blending. RTG-SLAM's
ablation (appendix F.3) shows the choice matters enormously at equal Gaussian
count -- Acc. 0.75 vs 2.48 cm, ATE 0.18 vs 1.24 cm -- so the readout is pinned
here as a controlled variable rather than left to a renderer.

Treating each opaque Gaussian as an ellipse disc on its dominant plane follows
Zwicker et al. 2001 surface splatting, as adopted by RTG-SLAM.
"""

from __future__ import annotations

import numpy as np

from gaussian_build import Gaussians


def rasterize_discs(
    g: Gaussians,
    K: np.ndarray,
    shape: tuple[int, int],
    window: int | None = None,
    sigma_extent: float = 1.0,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Front-most ray-disc intersection per pixel.

    With the default radius r = sqrt(2) z / f the projected footprint is
    sqrt(2) px times a foreshortening factor capped at 2, so a small window
    suffices. Enlarged discs need a proportionally larger window -- too small a
    window silently truncates them and flatters the depth error, so the window
    is derived from the actual projected radius unless overridden.

    Returns (depth, index, normal): depth is inf where nothing was hit, index is
    -1 there.
    """
    h, w = shape
    fx, fy, cx, cy = K[0, 0], K[1, 1], K[0, 2], K[1, 2]

    zc = g.mu[:, 2]
    u0 = fx * g.mu[:, 0] / zc + cx
    v0 = fy * g.mu[:, 1] / zc + cy
    r_a = g.scale[:, 0] * sigma_extent
    r_b = g.scale[:, 1] * sigma_extent
    anisotropic = g.axis1 is not None and g.axis2 is not None
    radius = np.maximum(r_a, r_b)

    if window is None:
        proj_px = 0.5 * (fx + fy) * radius / np.maximum(zc, 1e-6)
        window = int(np.ceil(np.percentile(proj_px, 99.5))) + 1
        window = max(2, min(window, 64))

    depth = np.full(h * w, np.inf, dtype=np.float32)
    index = np.full(h * w, -1, dtype=np.int64)

    n = g.normal
    n_dot_mu = np.einsum("ij,ij->i", n, g.mu)

    ub = np.round(u0).astype(np.int64)
    vb = np.round(v0).astype(np.int64)

    for dv in range(-window, window + 1):
        for du in range(-window, window + 1):
            u = ub + du
            v = vb + dv
            ok = (u >= 0) & (u < w) & (v >= 0) & (v < h)
            if not ok.any():
                continue
            idx = np.nonzero(ok)[0]
            uu = u[idx].astype(np.float32)
            vv = v[idx].astype(np.float32)

            # Ray through the pixel centre, camera at the origin.
            d = np.stack([(uu - cx) / fx, (vv - cy) / fy, np.ones_like(uu)], axis=1)
            denom = np.einsum("ij,ij->i", n[idx], d)
            live = np.abs(denom) > 1e-9
            if not live.any():
                continue
            idx = idx[live]
            d = d[live]
            t = n_dot_mu[idx] / denom[live]
            front = t > 0
            if not front.any():
                continue
            idx = idx[front]
            P = d[front] * t[front][:, None]

            # P already lies on the disc plane, so this is the in-plane offset.
            off = P - g.mu[idx]
            if anisotropic:
                # Elliptical support: (a/r_a)^2 + (b/r_b)^2 <= 1 in the local
                # principal frame. r_a is across the sharply curved direction.
                pa = np.einsum("ij,ij->i", off, g.axis1[idx]) / np.maximum(r_a[idx], 1e-9)
                pb = np.einsum("ij,ij->i", off, g.axis2[idx]) / np.maximum(r_b[idx], 1e-9)
                inside = (pa * pa + pb * pb) <= 1.0
            else:
                inside = np.linalg.norm(off, axis=1) <= r_a[idx]
            if not inside.any():
                continue
            idx = idx[inside]
            pz = P[inside, 2].astype(np.float32)
            flat = (v[idx] * w + u[idx]).astype(np.int64)

            # Keep the nearest hit. np.minimum.at resolves ties within the pass;
            # a second scatter recovers which primitive won.
            np.minimum.at(depth, flat, pz)
            won = depth[flat] == pz
            index[flat[won]] = idx[won]

    depth = depth.reshape(h, w)
    index = index.reshape(h, w)
    normal = np.zeros((h, w, 3), dtype=np.float32)
    hit = index >= 0
    normal[hit] = g.normal[index[hit]]
    return depth, index, normal


def evaluate(
    g: Gaussians,
    z_ref: np.ndarray,
    bgr_ref: np.ndarray,
    normal_ref: np.ndarray,
    eval_mask: np.ndarray,
    K: np.ndarray,
) -> dict:
    """Geometry-first metrics. Nothing here goes through alpha compositing."""
    h, w = z_ref.shape
    depth, index, normal = rasterize_discs(g, K, (h, w))

    hit = np.isfinite(depth) & eval_mask
    coverage = float(hit.sum() / max(eval_mask.sum(), 1))

    err = depth[hit] - z_ref[hit]
    rmse = float(np.sqrt(np.mean(err**2)))
    mae = float(np.mean(np.abs(err)))
    med = float(np.median(np.abs(err)))
    p95 = float(np.percentile(np.abs(err), 95))

    # Pointwise normal error, kept for continuity with earlier runs, but it is
    # NOT comparable across disc sizes: it pairs a disc's plane normal with the
    # per-pixel normal at whichever pixel the disc covers, and the per-pixel
    # normal field itself drifts with distance (measured: 1.6 deg at 1 px, 7.1
    # at 5 px, 11.5 at 13 px). A large disc is therefore penalised by
    # construction. Use normal_area_* below to compare across sizes.
    cos = np.clip(np.einsum("ij,ij->i", normal[hit], normal_ref[hit]), -1.0, 1.0)
    ang = np.degrees(np.arccos(np.abs(cos)))
    area_ang = _normal_area_error(g, normal_ref, index, hit)

    rgb_ref = bgr_ref[..., ::-1].astype(np.float32) / 255.0
    col_err = g.color[index[hit]] - rgb_ref[hit]
    col_rmse = float(np.sqrt(np.mean(col_err**2)))

    area = _surface_area(g)
    out = {
        "n_gaussians": len(g),
        "eval_px": int(eval_mask.sum()),
        "coverage": coverage,
        "hole_frac": 1.0 - coverage,
        "depth_rmse_mm": rmse * 1000.0,
        "depth_mae_mm": mae * 1000.0,
        "depth_med_mm": med * 1000.0,
        "depth_p95_mm": p95 * 1000.0,
        "normal_med_deg": float(np.median(ang)),
        "normal_mean_deg": float(np.mean(ang)),
        "normal_p95_deg": float(np.percentile(ang, 95)),
        "color_rmse": col_rmse,
        "color_psnr_db": float(-20.0 * np.log10(max(col_rmse, 1e-12))),
        "surface_area_m2": area,
        "gauss_per_m2": float(len(g) / max(area, 1e-9)),
        "radius_med_mm": float(np.median(g.scale[:, 0]) * 1000.0),
    }
    out.update(area_ang)
    return out


def _normal_area_error(
    g: Gaussians, normal_ref: np.ndarray, index: np.ndarray, hit: np.ndarray
) -> dict:
    """Size-fair normal error: each disc vs the mean normal over what it covers.

    A disc is meant to represent the average orientation of its own footprint,
    so that is what it should be scored against. Comparing it to a single
    per-pixel normal some distance away measures how fast the normal field
    drifts, not how well the disc fits -- which made the pointwise metric a
    monotone function of disc size.
    """
    idx = index[hit]
    if idx.size == 0:
        return {"normal_area_med_deg": float("nan"),
                "normal_area_mean_deg": float("nan"),
                "normal_area_p95_deg": float("nan")}

    nref = normal_ref[hit]
    n_g = len(g)
    acc = np.zeros((n_g, 3), dtype=np.float64)
    # Orient each contribution to the disc's own normal before averaging, so
    # opposing sign conventions cannot cancel.
    sgn = np.sign(np.einsum("ij,ij->i", nref, g.normal[idx]))
    sgn[sgn == 0] = 1.0
    for c in range(3):
        acc[:, c] = np.bincount(idx, weights=nref[:, c] * sgn, minlength=n_g)
    cnt = np.bincount(idx, minlength=n_g)
    live = cnt > 0
    mean_n = acc[live] / cnt[live][:, None]
    ln = np.linalg.norm(mean_n, axis=1)
    ok = ln > 1e-9
    mean_n = mean_n[ok] / ln[ok][:, None]
    cos = np.clip(np.einsum("ij,ij->i", mean_n, g.normal[live][ok]), -1.0, 1.0)
    ang = np.degrees(np.arccos(np.abs(cos)))
    return {
        "normal_area_med_deg": float(np.median(ang)),
        "normal_area_mean_deg": float(np.mean(ang)),
        "normal_area_p95_deg": float(np.percentile(ang, 95)),
    }


def _surface_area(g: Gaussians) -> float:
    """Sum of disc areas, discounted by overlap of the sqrt(2) covering rule.

    A disc of radius sqrt(2) z / f spans 2x the area of the pixel footprint it
    is meant to cover, so the raw sum double counts by that factor.
    """
    return float(np.sum(np.pi * g.scale[:, 0] * g.scale[:, 1]) / 2.0)
