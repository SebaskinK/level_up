"""Re-locate the user's 3 vertical fractures correctly.

The user says the fracture band is NOT in frame-0's FOV — it appears
progressively as the camera moves. So it must live in the black-border region
(cols beyond frame-0's GT-valid boundary) that got filled by later-frame discs
(black-edge fill), i.e. discs with birth > 0. Re-render the final model to
frame 0 and map holes over the FULL right edge, split by GT-valid vs
border-filled, and report the nearest disc birth frame.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

SEQ = Path(__file__).resolve().parent
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SEQ))
sys.path.insert(0, str(SFLOW))

import h_pipeline_final as H            # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402

FINAL = SEQ.parent / "output_f0_ellipse_final" / "model_f0.npz"
Z_MIN, Z_MAX = 0.4, 4.0


def tangent_basis(n):
    n = n.astype(np.float64)
    n = n / np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-12)
    ref = np.tile(np.array([0.0, 0.0, 1.0]), (n.shape[0], 1))
    ref[np.abs(n[:, 2]) > 0.9] = np.array([1.0, 0.0, 0.0])
    t1 = np.cross(ref, n)
    t1 = t1 / np.maximum(np.linalg.norm(t1, axis=1, keepdims=True), 1e-12)
    t2 = np.cross(n, t1)
    return t1, t2


def load_g(path: Path):
    d = np.load(path)
    mu = d["mu"].astype(np.float64)
    normal = d["normal"].astype(np.float64)
    scale = d["scale"].astype(np.float64)
    color = d["color"].astype(np.float64)
    birth = d["birth"].astype(np.int64)
    t1, t2 = tangent_basis(normal)
    g = H.Gaussians(
        mu=mu, normal=normal, scale=scale,
        quat=H._quat_from_frame(t1.astype(np.float32), t2.astype(np.float32), normal.astype(np.float32)),
        color=color, alpha=None,
        pixel=np.zeros((len(mu), 2), np.int32),
        axis1=t1.astype(np.float32), axis2=t2.astype(np.float32))
    return g, birth


def main() -> None:
    pairs = SF.associate(SF.DATA, max_dt=0.02)[: 11]
    sm = SF.load_rgb(pairs[0].rgb_path)
    h, w = sm.shape[:2]
    m1, m2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)
    bgr0, z0, _ = SF.load_pair(pairs, 0, m1, m2)
    valid = (z0 > Z_MIN) & (z0 < Z_MAX)

    g, birth = load_g(FINAL)
    depth, index, _ = H.rasterize_discs(g, K, (h, w))
    idx = index.astype(np.int64)
    hit = np.isfinite(depth)
    # disc birth per pixel
    pix_birth = np.full((h, w), -1, np.int32)
    pix_birth[hit] = birth[idx[hit]]

    # full right edge region rows 320..420, cols 520..640
    R0, R1, C0 = 320, 420, 520
    sub_hit = hit[R0:R1, C0:]
    sub_valid = valid[R0:R1, C0:]
    sub_birth = pix_birth[R0:R1, C0:]

    print("rows 320-419, cols 520-639:")
    print("col : GTvalid | covered | holes | coveredBirthHist(0..10) | hole nearest birth")
    for c in range(C0, w, 4):
        m_gt = sub_valid[:, c-C0]
        m_hit = sub_hit[:, c-C0]
        hole = m_gt & ~m_hit              # holes inside frame-0 FOV
        filled = (~m_gt) & m_hit          # border region filled by later frames
        print(f"{c:4d}: GTvalid={m_gt.sum():3d} covered={m_hit.sum():3d} "
              f"holesInFOV={hole.sum():3d} filledBorder={filled.sum():3d}")

    # map holes BROKEN DOWN by GT-valid (frame-0 observed) vs border-filled
    # find holes in the border-filled region: rendered coverage has gaps inside cols beyond GT-valid
    # a "crack" = GT-invalid pixel that has coverage neighbours but is itself not covered
    print("\n--- right-edge filled-border coverage gaps (potential cracks) per row ---")
    for r in range(320, 420):
        gtrow = valid[r]
        hitrow = hit[r]
        # rightmost GT-valid col at this row
        gcol = np.where(gtrow)[0]
        gmax = gcol.max() if gcol.size else -1
        # filled region = cols > gmax (until rendered coverage stops)
        if gmax < 0:
            continue
        beyond = slice(gmax, w)
        filled = (~gtrow[beyond]) & hitrow[beyond]
        hole = (~gtrow[beyond]) & (~hitrow[beyond])
        # coverage bounding: find contiguous rendered region starting at gmax
        if filled.any():
            # holes among the filled strip (cols where GT invalid, between covered cols)
            gap = hole & filled  # placeholder
            nfilled = filled.sum()
            # birth frames of discs covering the filled strip
            fb = pix_birth[r, beyond][hitrow[beyond]]
            if fb.size:
                print(f"  row {r}: GTmax={gmax} filledBorder={nfilled} "
                      f"birthHist={np.bincount(fb, minlength=11).tolist()}")


if __name__ == "__main__":
    main()