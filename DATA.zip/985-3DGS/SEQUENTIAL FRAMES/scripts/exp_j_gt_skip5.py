"""Experiment J: novel-view RGB + depth at frame n+5 using TUM GT poses.

Build 3DGS from frame n (final hybrid pipeline), rigidly transform by
Mrel = inv(M_{n+5}) @ M_n from groundtruth.txt (nearest timestamp),
rasterize with the default ray-disc renderer.

Outputs (output_J/):
  novelview_rgb_skip5.png / _small.png
  novelview_depth_skip5.png / _small.png
"""

from __future__ import annotations

import sys
import time
from pathlib import Path

import cv2
import numpy as np

HERE = Path(__file__).resolve().parent
SEQ_ROOT = HERE.parent
SINGLE_SCRIPTS = SEQ_ROOT.parent / "SINGLE FRAME" / "scripts"
sys.path.insert(0, str(SINGLE_SCRIPTS))
import h_pipeline_final as H  # noqa: E402

SKIP = 5
N_PAIRS = 10
OUT = SEQ_ROOT / "output_J"
CHAT_ID = "oc_24e5672a0b8e55b633e5d5e7759b22c5"


def data_dir() -> Path:
    for p in Path(__file__).resolve().parents:
        cand = p / "986-SceneFlow" / "rgbd_dataset_freiburg1_desk"
        if cand.exists():
            return cand
    raise FileNotFoundError("rgbd_dataset_freiburg1_desk")


def q_to_R(qx, qy, qz, qw):
    return np.array([
        [1 - 2 * (qy * qy + qz * qz), 2 * (qx * qy - qz * qw), 2 * (qx * qz + qy * qw)],
        [2 * (qx * qy + qz * qw), 1 - 2 * (qx * qx + qz * qz), 2 * (qy * qz - qx * qw)],
        [2 * (qx * qz - qy * qw), 2 * (qy * qz + qx * qw), 1 - 2 * (qx * qx + qy * qy)],
    ])


def parse_tum(path):
    poses = []
    for line in Path(path).read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        p = line.split()
        t = np.array(list(map(float, p[1:4])))
        T = np.eye(4)
        T[:3, :3] = q_to_R(*map(float, p[4:8]))
        T[:3, 3] = t
        poses.append((float(p[0]), T))
    return poses


def pose_at(poses, t):
    ts = np.array([p[0] for p in poses])
    j = int(np.argmin(np.abs(ts - t)))
    return poses[j][1], abs(ts[j] - t)


def transform_gaussians(g, Mrel):
    R = Mrel[:3, :3].astype(np.float32)
    t = Mrel[:3, 3].astype(np.float32)
    mu = g.mu @ R.T + t
    normal = g.normal @ R.T
    axis1 = g.axis1 @ R.T if g.axis1 is not None else None
    axis2 = g.axis2 @ R.T if g.axis2 is not None else None
    return H.Gaussians(
        mu=mu.astype(np.float32), normal=normal.astype(np.float32),
        scale=g.scale, quat=H._quat_from_normal(normal),
        color=g.color, alpha=g.alpha, pixel=g.pixel,
        axis1=axis1.astype(np.float32) if axis1 is not None else None,
        axis2=axis2.astype(np.float32) if axis2 is not None else None,
    )


def colorize_depth(z, mask, z_min=0.4, z_max=4.0):
    mm = z * 1000.0
    norm = (mm - z_min * 1000.0) / (z_max * 1000.0 - z_min * 1000.0)
    vis = cv2.applyColorMap((np.clip(norm, 0.0, 1.0) * 255.0).astype(np.uint8),
                            cv2.COLORMAP_TURBO)
    vis[~mask] = 0
    return vis


def colorize_diff_mm(d, mask, vmax=100.0):
    vis = cv2.applyColorMap((np.clip(d / vmax, 0.0, 1.0) * 255.0).astype(np.uint8),
                            cv2.COLORMAP_JET)
    vis[~mask] = 0
    return vis


def label(img, s):
    o = img.copy()
    cv2.rectangle(o, (0, 0), (o.shape[1], 34), (0, 0, 0), -1)
    cv2.putText(o, s, (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 2)
    return o


def shrink(img, scale=0.35):
    return cv2.resize(img, (0, 0), fx=scale, fy=scale, interpolation=cv2.INTER_AREA)


def main():
    dd = data_dir()
    pairs = H.associate(dd)
    gt = parse_tum(dd / "groundtruth.txt")
    map1, map2, K = H.undistort_maps((480, 640), H.FR1_INTRINSICS)
    OUT.mkdir(parents=True, exist_ok=True)

    rgb_rows = [[], [], [], []]
    dep_rows = [[], [], [], []]
    print(f"{'n':>4}{'tgt':>5}{'Ngs':>8}{'hit':>8}{'psnr':>8}{'rmse':>8}{'med':>8}{'dt0':>8}{'dt1':>8}",
          flush=True)

    for n in range(N_PAIRS):
        t = n + SKIP
        fr0, fr1 = pairs[n], pairs[t]
        bgr0 = H.remap_rgb(H.load_rgb(fr0.rgb_path), map1, map2)
        z0 = H.remap_depth(H.load_depth(fr0.depth_path), map1, map2)
        bgr1 = H.remap_rgb(H.load_rgb(fr1.rgb_path), map1, map2)
        z1 = H.remap_depth(H.load_depth(fr1.depth_path), map1, map2)

        t0 = time.perf_counter()
        g, _, _ = H.build_hybrid(bgr0, z0, K, 0.6)
        dt_build = time.perf_counter() - t0

        M0, dt0 = pose_at(gt, fr0.t_rgb)
        M1, dt1 = pose_at(gt, fr1.t_rgb)
        Mrel = np.linalg.inv(M1) @ M0
        gt_g = transform_gaussians(g, Mrel)
        depth, index, _ = H.rasterize_discs(gt_g, K, (480, 640))
        hit = index >= 0

        render = np.zeros((480, 640, 3), dtype=np.uint8)
        rgb = np.clip(gt_g.color[index[hit]], 0.0, 1.0)
        render[hit] = (rgb[:, ::-1] * 255.0).astype(np.uint8)

        err_rgb = render.astype(np.float32) / 255.0 - (bgr1.astype(np.float32) / 255.0)
        psnr = -20.0 * np.log10(np.sqrt(np.mean(err_rgb[hit] ** 2)) + 1e-12)

        hit_d = np.isfinite(depth)
        m = hit_d & H.depth_valid(z1)
        err_d = (depth[m] - z1[m]) * 1000.0
        rmse = float(np.sqrt(np.mean(err_d ** 2))) if m.any() else float("nan")
        med = float(np.median(np.abs(err_d))) if m.any() else float("nan")
        print(f"{n:>4}{t:>5}{len(g):>8}{hit.mean():>8.3f}{psnr:>8.2f}"
              f"{rmse:>8.1f}{med:>8.1f}{dt0*1e3:>7.1f}ms{dt1*1e3:>7.1f}ms  "
              f"({dt_build:.1f}s)", flush=True)

        rgb_rows[0].append(label(bgr0, f"frame {n} rgb"))
        rgb_rows[1].append(label(bgr1, f"frame {t} rgb"))
        rgb_rows[2].append(label(render, f"GS f{n}->f{t}"))
        rgb_rows[3].append(label(cv2.absdiff(render, bgr1), f"diff PSNR={psnr:.1f}"))

        v0, v1 = H.depth_valid(z0), H.depth_valid(z1)
        dep_rows[0].append(label(colorize_depth(z0, v0), f"frame {n} depth"))
        dep_rows[1].append(label(colorize_depth(z1, v1), f"frame {t} depth"))
        dep_rows[2].append(label(colorize_depth(depth, hit_d), f"GS f{n}->f{t} depth"))
        diff = np.abs(depth - z1) * 1000.0
        dep_rows[3].append(label(colorize_diff_mm(diff, m), f"|diff|mm RMSE={rmse:.1f}"))

        if n == 0:
            cv2.imwrite(str(OUT / "f0_to_f5_rgb.png"), render)
            cv2.imwrite(str(OUT / "f0_to_f5_depth.png"), colorize_depth(depth, hit_d))

    rgb_panel = np.vstack([np.hstack(r) for r in rgb_rows])
    dep_panel = np.vstack([np.hstack(r) for r in dep_rows])
    cv2.imwrite(str(OUT / "novelview_rgb_skip5.png"), rgb_panel)
    cv2.imwrite(str(OUT / "novelview_depth_skip5.png"), dep_panel)
    cv2.imwrite(str(OUT / "novelview_rgb_skip5_small.png"), shrink(rgb_panel))
    cv2.imwrite(str(OUT / "novelview_depth_skip5_small.png"), shrink(dep_panel))
    print(f"wrote {OUT}", flush=True)


if __name__ == "__main__":
    main()
