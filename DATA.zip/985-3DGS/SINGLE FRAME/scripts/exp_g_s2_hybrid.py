"""S2 seeding + geometry resampling inside large homogeneous regions.

Pipeline:
  1. S2 uniform stride-2 seeding.
  2. Merge S2 seeds into regions by RGB + normal + depth similarity.
  3. Small regions keep their original S2 Gaussians.
  4. Large regions are re-sampled with the curvature-based pipeline restricted
     to the region's S2 seed pixels.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from exp_g_aniso_real import CFG as GEO_CFG, eval_setup  # noqa: E402
from exp_e_curvature_sample import curvature_mask  # noqa: E402
from gaussian_build import build_gaussians, build_gaussians_curvature  # noqa: E402
from metrics import evaluate, rasterize_discs  # noqa: E402
from rgbd_io import (  # noqa: E402
    FR1_INTRINSICS,
    associate,
    load_depth,
    load_rgb,
    remap_depth,
    remap_rgb,
    undistort_maps,
)


class UnionFind:
    def __init__(self, n: int):
        self.parent = np.arange(n, dtype=np.int64)

    def find(self, x: int) -> int:
        p = self.parent[x]
        if p != x:
            self.parent[x] = self.find(p)
            return self.parent[x]
        return x

    def union(self, a: int, b: int) -> None:
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            self.parent[ra] = rb


def can_merge(g, i: int, j: int, color_thresh: float, normal_thresh_deg: float,
              depth_rel_thresh: float) -> bool:
    col_diff = float(np.linalg.norm(g.color[i] - g.color[j]))
    if col_diff > color_thresh:
        return False
    cos = np.clip(np.dot(g.normal[i], g.normal[j]), -1.0, 1.0)
    ang = np.degrees(np.arccos(abs(cos)))
    if ang > normal_thresh_deg:
        return False
    zi, zj = g.mu[i, 2], g.mu[j, 2]
    if abs(zi - zj) > depth_rel_thresh * max(zi, zj, 1e-6):
        return False
    return True


def label(img: np.ndarray, text: str) -> np.ndarray:
    out = img.copy()
    cv2.rectangle(out, (0, 0), (out.shape[1], 34), (0, 0, 0), -1)
    cv2.putText(out, text, (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
    return out


def colorize_depth(z: np.ndarray, mask: np.ndarray, z_min: float = 0.4, z_max: float = 4.0) -> np.ndarray:
    mm = z * 1000.0
    norm = (mm - z_min * 1000.0) / (z_max * 1000.0 - z_min * 1000.0)
    norm = np.clip(norm, 0.0, 1.0)
    vis = (norm * 255.0).astype(np.uint8)
    vis = cv2.applyColorMap(vis, cv2.COLORMAP_TURBO)
    vis[~mask] = 0
    return vis


def render_color(g, shape, K):
    depth, index, _ = rasterize_discs(g, K, shape)
    hit = index >= 0
    render = np.zeros((*shape, 3), dtype=np.uint8)
    rgb = np.clip(g.color[index[hit]], 0.0, 1.0)
    render[hit] = (rgb[:, ::-1] * 255.0).astype(np.uint8)
    return render, depth, hit


def psnr_on_mask(g, index, hit, bgr, mask):
    m = hit & mask
    if not m.any():
        return 0.0
    err = g.color[index[m]] - (bgr[..., ::-1].astype(np.float32) / 255.0)[m]
    return -20.0 * np.log10(max(float(np.sqrt(np.mean(err ** 2))), 1e-12))


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--data", default=str(
        ROOT.parent.parent / "986-SceneFlow" / "rgbd_dataset_freiburg1_desk"))
    p.add_argument("--out", default=str(ROOT.parent / "output_G_refactor"))
    p.add_argument("--frame", type=int, default=0)
    p.add_argument("--color-thresh", type=float, default=30.0,
                   help="FH04 Lab patch threshold k (larger = more merging)")
    p.add_argument("--normal-thresh", type=float, default=10.0)
    p.add_argument("--depth-rel-thresh", type=float, default=0.03)
    p.add_argument("--min-area-px", type=int, default=200,
                   help="minimum original-pixel area of a region to trigger geometry resampling")
    p.add_argument("--color-std-thresh", type=float, default=0.05,
                   help="max per-region RGB std for a large region to be resampled "
                        "(higher = more geometry, lower = more S2); 0=keep all as S2")
    args = p.parse_args()

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    pairs = associate(Path(args.data))
    fr = pairs[args.frame]
    sample = load_rgb(pairs[0].rgb_path)
    map1, map2, K = undistort_maps(sample.shape[:2], FR1_INTRINSICS)
    bgr = remap_rgb(load_rgb(fr.rgb_path), map1, map2)
    z = remap_depth(load_depth(fr.depth_path), map1, map2)
    h, w = z.shape

    normal_ref, eval_mask = eval_setup(z, K)
    rgb = bgr[..., ::-1].astype(np.float32) / 255.0

    # 1. S2 uniform seeding.
    g_s2 = build_gaussians(
        bgr, z, K,
        z_min=GEO_CFG["z_min"], z_max=GEO_CFG["z_max"],
        disc_rel=GEO_CFG["disc_rel"], stride=2,
        prefilter="gauss", prefilter_size=int(GEO_CFG["gauss_sigma"]),
    )

    # 2. Region merging on S2 grid using Felzenszwalb-Huttenlocher on 9x9 Lab patches.
    xs = g_s2.pixel[:, 0]
    ys = g_s2.pixel[:, 1]

    lab = cv2.cvtColor((rgb * 255.0).astype(np.uint8), cv2.COLOR_RGB2LAB).astype(np.float32)
    patch_lab = cv2.blur(lab, (9, 9))
    patch_color = patch_lab[ys, xs].astype(np.float32)
    orig_color = g_s2.color.copy()
    g_s2.color = patch_color  # use patch colour for segmentation

    labels = np.full((h, w), -1, dtype=np.int64)
    labels[ys, xs] = np.arange(len(g_s2), dtype=np.int64)

    edges = []
    step = 2
    for i, (u, v) in enumerate(g_s2.pixel):
        for du, dv in ((step, 0), (0, step)):
            u2, v2 = u + du, v + dv
            if u2 < w and v2 < h:
                j = labels[v2, u2]
                if j < 0:
                    continue
                # Geometry hard constraints: only consider edges that are
                # roughly coplanar and at similar depth.
                cos = np.clip(np.dot(g_s2.normal[i], g_s2.normal[j]), -1.0, 1.0)
                ang = np.degrees(np.arccos(abs(cos)))
                if ang > args.normal_thresh:
                    continue
                zi, zj = g_s2.mu[i, 2], g_s2.mu[j, 2]
                if abs(zi - zj) > args.depth_rel_thresh * max(zi, zj, 1e-6):
                    continue
                weight = float(np.linalg.norm(patch_color[i] - patch_color[j]))
                edges.append((weight, i, j))

    def fh_merge(n, edges, k):
        uf = UnionFind(n)
        size = np.ones(n, dtype=np.int64)
        internal = np.zeros(n, dtype=np.float32)
        edges = sorted(edges, key=lambda x: x[0])
        for w, i, j in edges:
            ri, rj = uf.find(i), uf.find(j)
            if ri == rj:
                continue
            tau_i = internal[ri] + k / size[ri]
            tau_j = internal[rj] + k / size[rj]
            if w <= min(tau_i, tau_j):
                uf.parent[ri] = rj
                size[rj] = size[ri] + size[rj]
                internal[rj] = w
        return uf

    uf = fh_merge(len(g_s2), edges, args.color_thresh)

    comp = np.array([uf.find(i) for i in range(len(g_s2))], dtype=np.int64)
    unique, counts = np.unique(comp, return_counts=True)
    areas = counts * step * step

    # Per-region RGB standard deviation (using original per-seed colours).
    label_to_idx = {label_id: idx for idx, label_id in enumerate(unique)}
    sum_rgb = np.zeros((len(unique), 3), dtype=np.float64)
    sum_sq = np.zeros((len(unique), 3), dtype=np.float64)
    np.add.at(sum_rgb, [label_to_idx[l] for l in comp], orig_color)
    np.add.at(sum_sq, [label_to_idx[l] for l in comp], orig_color ** 2)
    means = sum_rgb / np.maximum(counts[:, None], 1)
    std_rgb = np.sqrt(np.maximum(sum_sq / np.maximum(counts[:, None], 1) - means ** 2, 0.0))
    # Use mean std across channels as a single texture score.
    region_std = std_rgb.mean(axis=1)

    large_labels = {label_id for label_id, area, std in zip(unique, areas, region_std)
                    if int(area) >= args.min_area_px and std <= args.color_std_thresh}

    # Restore original per-pixel colours for rendering.
    g_s2.color = orig_color

    keep_small = np.zeros(len(g_s2), dtype=bool)
    seed_mask = np.zeros((h, w), dtype=bool)
    for i, label_id in enumerate(comp):
        if label_id in large_labels:
            seed_mask[ys[i], xs[i]] = True
        else:
            keep_small[i] = True
    # Dilate by one pixel so the region mask covers the full 2x2 blocks represented by S2 seeds.
    large_mask = cv2.dilate(seed_mask.astype(np.uint8), np.ones((3, 3), np.uint8)).astype(bool)

    print(f"S2: {len(g_s2)}  large regions: {len(large_labels)}  "
          f"large seeds: {int(large_mask.sum())}  small seeds kept: {int(keep_small.sum())}")

    cv2.imwrite(str(out_dir / f"seed_mask_f{args.frame:02d}.png"),
                (seed_mask.astype(np.uint8) * 255))
    cv2.imwrite(str(out_dir / f"large_mask_f{args.frame:02d}.png"),
                (large_mask.astype(np.uint8) * 255))

    # 3. Geometry resampling on large-region seeds.
    if large_mask.any():
        keep_full = curvature_mask(
            z, K, GEO_CFG["eps"], GEO_CFG["gauss_sigma"],
            GEO_CFG["z_min"], GEO_CFG["z_max"], GEO_CFG["disc_rel"],
            GEO_CFG["overlap"], GEO_CFG["r_max"],
            foreshorten=False, aniso_claim=True, edge_fallback_fp=True,
        )
        keep = keep_full & large_mask
        if not keep.any():
            g_geo = None
        else:
            g_geo = build_gaussians_curvature(
                bgr, z, K, eps=GEO_CFG["eps"], gauss_sigma=GEO_CFG["gauss_sigma"],
                r_max=GEO_CFG["r_max"], shrink=GEO_CFG["shrink"],
                normal_mode="disc_inliers", z_min=GEO_CFG["z_min"],
                z_max=GEO_CFG["z_max"], disc_rel=GEO_CFG["disc_rel"],
                mask=keep, prefilter="gauss", prefilter_size=int(GEO_CFG["gauss_sigma"]),
            )
    else:
        g_geo = None

    # 4. Combine geometry-resampled large regions + untouched small S2 seeds.
    parts = []
    if g_geo is not None:
        parts.append(g_geo)
    if keep_small.any():
        idx = np.nonzero(keep_small)[0]
        parts.append(type(g_s2)(
            mu=g_s2.mu[idx], normal=g_s2.normal[idx], scale=g_s2.scale[idx],
            quat=g_s2.quat[idx], color=g_s2.color[idx], alpha=g_s2.alpha[idx],
            pixel=g_s2.pixel[idx],
        ))

    if not parts:
        raise RuntimeError("no Gaussians produced")

    g_hybrid = type(parts[0])(
        mu=np.concatenate([p.mu for p in parts], axis=0),
        normal=np.concatenate([p.normal for p in parts], axis=0),
        scale=np.concatenate([p.scale for p in parts], axis=0),
        quat=np.concatenate([p.quat for p in parts], axis=0),
        color=np.concatenate([p.color for p in parts], axis=0),
        alpha=np.concatenate([p.alpha for p in parts], axis=0),
        pixel=np.concatenate([p.pixel for p in parts], axis=0),
    )

    # 5. Metrics and panels.
    render_s2, depth_s2, hit_s2 = render_color(g_s2, z.shape, K)
    render_hyb, depth_hyb, hit_hyb = render_color(g_hybrid, z.shape, K)

    m_s2 = evaluate(g_s2, z, bgr, normal_ref, eval_mask, K)
    m_hyb = evaluate(g_hybrid, z, bgr, normal_ref, eval_mask, K)

    _, idx_s2, _ = rasterize_discs(g_s2, K, z.shape)
    _, idx_hyb, _ = rasterize_discs(g_hybrid, K, z.shape)
    psnr_s2 = psnr_on_mask(g_s2, idx_s2, hit_s2, bgr, eval_mask)
    psnr_hyb = psnr_on_mask(g_hybrid, idx_hyb, hit_hyb, bgr, eval_mask)

    print(f"S2:     N={len(g_s2):6d}  RMSE={m_s2['depth_rmse_mm']:.2f}mm  "
          f"cov={m_s2['coverage']:.3f}  hole={m_s2['hole_frac']*100:.2f}%  PSNR={psnr_s2:.1f}dB")
    print(f"hybrid: N={len(g_hybrid):6d}  RMSE={m_hyb['depth_rmse_mm']:.2f}mm  "
          f"cov={m_hyb['coverage']:.3f}  hole={m_hyb['hole_frac']*100:.2f}%  PSNR={psnr_hyb:.1f}dB")

    from gaussian_build import depth_valid
    valid_depth_mask = depth_valid(z)

    depth_panel = np.hstack([
        label(colorize_depth(z, valid_depth_mask, 0.4, 4.0), "original depth"),
        label(colorize_depth(depth_s2, hit_s2, 0.4, 4.0),
              f"S2  N={len(g_s2)}  RMSE={m_s2['depth_rmse_mm']:.2f}mm"),
        label(colorize_depth(depth_hyb, hit_hyb, 0.4, 4.0),
              f"hybrid  N={len(g_hybrid)}  RMSE={m_hyb['depth_rmse_mm']:.2f}mm"),
    ])

    rgb_panel = np.hstack([
        label(bgr, "original RGB"),
        label(render_s2, f"S2  PSNR={psnr_s2:.1f}dB  N={len(g_s2)}"),
        label(render_hyb, f"hybrid  PSNR={psnr_hyb:.1f}dB  N={len(g_hybrid)}"),
    ])

    hole = eval_mask & ~hit_hyb
    hole_vis = bgr.copy()
    hole_vis[hole] = (0, 0, 255)
    hole_panel = label(hole_vis, f"hybrid hole map  N={len(g_hybrid)}  hole={hole.sum()/max(eval_mask.sum(),1)*100:.2f}%")

    cv2.imwrite(str(out_dir / f"depth_s2_hybrid_f{args.frame:02d}.png"), depth_panel)
    cv2.imwrite(str(out_dir / f"rgb_s2_hybrid_f{args.frame:02d}.png"), rgb_panel)
    cv2.imwrite(str(out_dir / f"hole_s2_hybrid_f{args.frame:02d}.png"), hole_panel)
    print(f"wrote {out_dir / f'depth_s2_hybrid_f{args.frame:02d}.png'}")
    print(f"wrote {out_dir / f'rgb_s2_hybrid_f{args.frame:02d}.png'}")


if __name__ == "__main__":
    main()
