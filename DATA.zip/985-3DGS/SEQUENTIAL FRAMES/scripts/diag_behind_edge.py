"""Find discs covering the behind-desk-edge region (y 366-400, x 400-640)."""
import sys
from pathlib import Path

import numpy as np

SEQ = Path(__file__).resolve().parent
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SEQ))
sys.path.insert(0, str(SFLOW))

import h_pipeline_final as H  # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402

OUT = SEQ.parent / "output_f0_10frame"

d = np.load(OUT / "model_f0.npz")
mu = d["mu"].astype(np.float32)
normal = d["normal"].astype(np.float32)
scale = d["scale"].astype(np.float32)

raw = (OUT / "model.ply").read_bytes()
arr = np.frombuffer(raw[raw.index(b"end_header\n") + len(b"end_header\n"):],
                    dtype=np.float32).reshape(-1, 17)
sh_c0 = 0.28209479177387814
col = (arr[:, 6:9] * sh_c0 + 0.5)  # back to linear rgb [0..1]

pairs = SF.associate(SF.DATA, max_dt=0.02)[:1]
h, w = SF.load_rgb(pairs[0].rgb_path).shape[:2]
map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)

# reconstruct axis1/axis2 from quaternion (ply rot) to keep anisotropy
rot = arr[:, 13:17].astype(np.float32)
q = rot / np.maximum(np.linalg.norm(rot, axis=1, keepdims=True), 1e-12)

def qmat(qq):
    x, y, z, ww = qq[:, 0], qq[:, 1], qq[:, 2], qq[:, 3]
    R = np.empty((len(qq), 3, 3), np.float32)
    R[:, 0, 0] = 1 - 2 * (y * y + z * z)
    R[:, 0, 1] = 2 * (x * y - z * ww)
    R[:, 0, 2] = 2 * (x * z + y * ww)
    R[:, 1, 0] = 2 * (x * y + z * ww)
    R[:, 1, 1] = 1 - 2 * (x * x + z * z)
    R[:, 1, 2] = 2 * (y * z - x * ww)
    R[:, 2, 0] = 2 * (x * z - y * ww)
    R[:, 2, 1] = 2 * (y * z + x * ww)
    R[:, 2, 2] = 1 - 2 * (x * x + y * y)
    return R

R = qmat(q)
axis1 = R[..., 0]  # x-axis of disc frame ~ tangent1
axis2 = R[..., 1]

g = H.Gaussians(mu=mu, normal=normal, scale=scale, quat=rot,
                color=col.astype(np.float32),
                alpha=np.ones(len(mu), np.float32),
                pixel=np.zeros((len(mu), 2), np.int32),
                axis1=axis1, axis2=axis2)
depth, index, _ = H.rasterize_discs(g, K, (h, w))

y0, y1, x0, x1 = 366, 400, 400, 640
idx = index[y0:y1, x0:x1]
hit = idx >= 0
owners, counts = np.unique(idx[hit], return_counts=True)
print("discs owning behind-edge region (idx, npix, color, r1, r2, mu, nz):")
for o, c in sorted(zip(owners, counts), key=lambda t: -t[1])[:25]:
    print(f"  idx{o:5d} npix={c:4d} col=({col[o,0]:.2f},{col[o,1]:.2f},{col[o,2]:.2f}) "
          f"r1={scale[o,0]:.4f} r2={scale[o,1]:.4f} "
          f"mu=({mu[o,0]:.3f},{mu[o,1]:.3f},{mu[o,2]:.3f}) nz={normal[o,2]:.2f}")