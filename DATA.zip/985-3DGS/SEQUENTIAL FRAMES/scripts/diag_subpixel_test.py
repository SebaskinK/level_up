"""Definitive test: are the right-edge holes real 3D tiling gaps or just
sub-pixel rasterization undersampling of near-edge-on thin ellipses?

For each hole pixel, intersect the nearest disc's plane with the ray through
BOTH the pixel centre (what rasterize_discs does) and 4 sub-pixel offsets,
then test the 3D `|P - mu| <= r1` circle/ellipse membership. If sub-pixel
rays hit but the centre ray misses, the surface is covered and only the
integer-pixel hard renderer is at fault.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

SEQ = Path(__file__).resolve().parent
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SEQ))
sys.path.insert(0, str(SFLOW))

import h_pipeline_final as H            # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402

FINAL = SEQ.parent / "output_f0_ellipse_final" / "model_f0.npz"
F0 = SEQ.parent / "output_f0_0frame" / "model_f0.npz"
Z_MIN, Z_MAX = 0.4, 4.0


def tangent_basis(n):
    n = n.astype(np.float64)
    n = n / np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-12)
    ref = np.tile(np.array([0.0, 0.0, 1.0]), (n.shape[0], 1))
    ref[np.abs(n[:, 2]) > 0.9] = np.array([1.0, 0.0, 0.0])
    t1 = np.cross(ref, n)
    t1 = t1 / np.maximum(np.linalg.norm(t1, axis=1, keepdims=True), 1e-12)
    t2 = np.cross(n, t1)
    return t1, t2


def load_g(path: Path):
    d = np.load(path)
    mu = d["mu"].astype(np.float64)
    normal = d["normal"].astype(np.float64)
    scale = d["scale"].astype(np.float64)
    color = d["color"].astype(np.float64)
    birth = d["birth"].astype(np.int64)
    t1, t2 = tangent_basis(normal)
    g = H.Gaussians(
        mu=mu, normal=normal, scale=scale,
        quat=H._quat_from_frame(t1.astype(np.float32), t2.astype(np.float32), normal.astype(np.float32)),
        color=color, alpha=None,
        pixel=np.zeros((len(mu), 2), np.int32),
        axis1=t1.astype(np.float32), axis2=t2.astype(np.float32))
    return g, birth


def main() -> None:
    pairs = SF.associate(SF.DATA, max_dt=0.02)[: 11]
    sm = SF.load_rgb(pairs[0].rgb_path)
    h, w = sm.shape[:2]
    m1, m2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)
    bgr0, z0, _ = SF.load_pair(pairs, 0, m1, m2)
    valid = (z0 > Z_MIN) & (z0 < Z_MAX)

    offs = [(0.25, 0.25), (0.75, 0.25), (0.25, 0.75), (0.75, 0.75)]

    for name, path in [("FINAL10", FINAL), ("FRAME0", F0)]:
        g, birth = load_g(path)
        depth, index, _ = H.rasterize_discs(g, K, (h, w))
        hole = ~np.isfinite(depth) & valid
        R0, R1, C0 = 335, 390, 560
        reg = hole[R0:R1, C0:]
        yy, xx = np.nonzero(reg)
        hy = yy + R0
        hx = xx + C0

        fx, fy, cx, cy = (float(K[0,0]), float(K[1,1]), float(K[0,2]), float(K[1,2]))
        # nearest disc centre in image
        zc = np.maximum(g.mu[:, 2], 1e-6)
        uc = (fx * g.mu[:, 0] / zc + cx).astype(np.float64)
        vc = (fy * g.mu[:, 1] / zc + cy).astype(np.float64)
        CH = 512
        best_i = np.full(hy.size, -1, np.int32)
        for s in range(0, hy.size, CH):
            e = min(s + CH, hy.size)
            du = hx[s:e, None] - uc[None, :]
            dv = hy[s:e, None] - vc[None, :]
            dd = du*du + dv*dv
            best_i[s:e] = dd.argmin(axis=1)
        idx = best_i
        mu = g.mu[idx]
        nrm = g.normal[idx]
        r1 = g.scale[idx, 0]
        r2 = g.scale[idx, 1]
        n_dot_mu = np.einsum("ij,ij->i", nrm, mu)
        iso = np.abs(r1 - r2) < 1e-6 * np.maximum(r1, 1e-9)

        # test membership for centre + 4 sub-pixel offsets, against nearest disc (isotropic exact)
        def covered(u, v):
            uu = (u - cx) / fx
            vv = (v - cy) / fy
            dvec = np.stack([uu, vv, np.ones_like(uu)], axis=1)
            denom = np.einsum("ij,ij->i", nrm, dvec)
            live = np.abs(denom) > 1e-9
            t = np.full_like(denom, np.nan)
            t[live] = n_dot_mu[live] / denom[live]
            ok = live & (t > 0)
            P = np.zeros_like(dvec)
            P[ok] = dvec[ok] * t[ok][:, None]
            off = P - mu
            # only trust isotropic membership exactly (tangent-basis axes are approx for aniso)
            pa = np.einsum("ij,ij->i", off, g.axis1[idx].astype(np.float64))
            pb = np.einsum("ij,ij->i", off, g.axis2[idx].astype(np.float64))
            inside = ((pa/r1)**2 + (pb/r2)**2) <= 1.0
            return ok & inside

        centre = covered(hx.astype(np.float64), hy.astype(np.float64))
        sub_hit = np.zeros(hy.size, bool)
        for du, dv in offs:
            m = covered(hx.astype(np.float64)+du, hy.astype(np.float64)+dv)
            sub_hit |= m
        print(f"\n=== {name}: {hy.size} holes ===")
        print(f"  centre ray hits nearest disc: {centre.sum()} ({centre.mean():.3f})")
        print(f"  any 2x2 sub-pixel ray hits nearest disc: {sub_hit.sum()} ({sub_hit.mean():.3f})")
        print(f"  centre MISS but sub-pixel HIT (thin ellipse undersampling): {(~centre & sub_hit).sum()}")
        print(f"  neither centre nor sub-pixel hit (true 3D gap for this disc): {(~centre & ~sub_hit).sum()}")
        print(f"  S2(iso) among holes: {iso.mean():.3f}")
        # for the iso subset, this membership test is exact
        isoM = iso
        print(f"  [iso subset n={isoM.sum()}] centre={(centre[isoM]).mean():.3f} "
              f"subpixel_hit={(sub_hit[isoM]).mean():.3f} "
              f"centre_miss_subpixel_hit={((~centre & sub_hit)[isoM]).mean():.3f} "
              f"true_gap={((~centre & ~sub_hit)[isoM]).mean():.3f}")


if __name__ == "__main__":
    main()