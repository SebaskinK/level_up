"""EWA surface splatting renderer for the analytic surfel field.

The existing `rasterize_discs` does a *hard* ray-disc nearest-hit test: each
pixel takes the front-most disc and its centre colour, with no falloff and no
blending. That produces the hard, aliased look the docs call "an opaque-surfel
readout".

This file adds a proper EWA (Elliptical Weighted Average) surface splatter —
the standard high-quality surfel rendering method (Zwicker et al. 2001) and the
same projective-covariance mechanism used by 3DGS / 2DGS / Gaussian Surfels. It
leaves `h_pipeline_final.rasterize_discs` untouched.

Two blend modes:

* `mode="normalized"`  — opaque surfels, colour = Σ w·c / Σ w. Zwicker's weighted
  average. Smooth, anti-aliased, hole-free. This is the *best visual* mode.
* `mode="alpha"`       — front-to-back 3DGS alpha compositing of the same 2D
  Gaussians (alpha is still the fixed 0.99 built into the primitives).

The 3D covariance is built from the same closed-form quantities the pipeline
already stores (axis1 / axis2 / normal + scale [r1, r2, thin]) and projected by
the perspective Jacobian, exactly like 3DGS. Nothing here is fitted or trained.
"""

from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np

import h_pipeline_final as H


# ---------------------------------------------------------------------------
# covariance helpers
# ---------------------------------------------------------------------------

def _tangent_basis(n: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Orthonormal in-plane tangents (t1, t2) for normals n (N, 3)."""
    ref = np.zeros_like(n, dtype=np.float32)
    ref[:, 2] = 1.0
    parallel = np.abs(n[:, 2]) > 0.9
    ref[parallel, 2] = 0.0
    ref[parallel, 0] = 1.0
    t1 = np.cross(ref, n)
    t1 /= np.maximum(np.linalg.norm(t1, axis=1, keepdims=True), 1e-12)
    t2 = np.cross(n, t1)
    return t1, t2


def _projected_covariance(g: H.Gaussians, K: np.ndarray, cov_scale: float = 1.0):
    """Per-surfel 2D (pixel-space) Gaussian covariance.

    Returns (u0, v0, cov_u, cov_v, cov_uv, inv_uu, inv_uv, inv_vv, lam_max)
    for surfels with mu_z > 0. cov is in pixel units; lam_max is the largest
    eigenvalue of the 2x2 covariance (for the splat footprint radius).

    `cov_scale` shrinks the effective Gaussian (all three axes) before projection.
    Shrinking the covariance (cov_scale < 1) sharpens the render by pulling each
    splat's energy toward its centre, while the 3-sigma bbox in `render_ewa`
    still covers the *full* (now smaller) Gaussian — so nothing is truncated and
    no hard edge appears, unlike shrinking the bbox truncation radius.
    """
    fx, fy, cx, cy = K[0, 0], K[1, 1], K[0, 2], K[1, 2]
    x, y, z = g.mu[:, 0], g.mu[:, 1], g.mu[:, 2]
    n = g.normal.astype(np.float32)
    if g.axis1 is not None and g.axis2 is not None:
        e1 = g.axis1.astype(np.float32)
        e2 = g.axis2.astype(np.float32)
    else:
        e1, e2 = _tangent_basis(n)
    s0 = g.scale[:, 0].astype(np.float32) * cov_scale
    s1 = g.scale[:, 1].astype(np.float32) * cov_scale
    s2 = g.scale[:, 2].astype(np.float32) * cov_scale

    # 3D covariance Sigma = s0^2 e1 e1^T + s1^2 e2 e2^T + s2^2 n n^T  (N,3,3)
    w0, w1, w2 = s0 * s0, s1 * s1, s2 * s2
    Sig = (np.einsum("ni,nj,n->nij", e1, e1, w0)
           + np.einsum("ni,nj,n->nij", e2, e2, w1)
           + np.einsum("ni,nj,n->nij", n, n, w2))

    # Perspective projection Jacobian J (2x3) per surfel; M = J.
    zc = np.maximum(z, 1e-6)
    J00 = fx / zc
    J02 = -fx * x / (zc * zc)
    J11 = fy / zc
    J12 = -fy * y / (zc * zc)
    M = np.zeros((n.shape[0], 2, 3), dtype=np.float32)
    M[:, 0, 0] = J00
    M[:, 0, 2] = J02
    M[:, 1, 1] = J11
    M[:, 1, 2] = J12

    # Sigma2 = M Sigma M^T  (N,2,2).
    MT = M.transpose(0, 2, 1)                    # (N,3,2)
    t = np.einsum("nij,njk->nik", Sig, MT)       # Sigma M^T  (N,3,2)
    S2 = np.einsum("nij,njk->nik", M, t)         # M Sigma M^T  (N,2,2)
    a = S2[:, 0, 0]
    b = S2[:, 1, 1]
    c = S2[:, 0, 1]
    det = a * b - c * c
    det = np.maximum(det, 1e-12)
    # Inverse of [[a,c],[c,b]].
    ia = b / det
    ib = a / det
    ic = -c / det
    lam_max = 0.5 * (a + b) + np.sqrt(np.maximum(0.25 * (a - b) ** 2 + c * c, 0.0))

    u0 = fx * x / zc + cx
    v0 = fy * y / zc + cy
    return u0, v0, ia, ic, ib, lam_max


# ---------------------------------------------------------------------------
# EWA splatting renderer
# ---------------------------------------------------------------------------

def render_ewa(g: H.Gaussians, K: np.ndarray, shape: tuple[int, int],
               sigma_extent: float = 2.0, mode: str = "normalized",
               cov_scale: float = 0.33):
    """Forward-splat the surfel field into an image.

    Returns `(color, depth, weight)`:
      * color  — (H, W, 3) float linear RGB in [0, 1]
      * depth  — (H, W) float, weighted mean of exact ray-plane depths (inf = hole)
      * weight — (H, W) float, summed splat weight (0 = no coverage)

    `cov_scale` (default 1.0) shrinks the Gaussian before projection to sharpen
    the render (de-blur) *without* truncating it — the 3-sigma bbox still covers
    the whole Gaussian, so no hard edge/jaggies appear.
    """
    if len(g) == 0:
        h, w = shape
        return (np.zeros((h, w, 3), np.float32),
                np.full((h, w), np.inf, np.float32),
                np.zeros((h, w), np.float32))

    h, w = shape
    fx, fy, cx, cy = K[0, 0], K[1, 1], K[0, 2], K[1, 2]
    u0, v0, ia, ic, ib, lam_max = _projected_covariance(g, K, cov_scale)
    zc = np.maximum(g.mu[:, 2], 1e-6)

    n = g.normal.astype(np.float32)
    n_dot_mu = np.einsum("ij,ij->i", n, g.mu)

    # Front / finite / positive-definite covariance guard.
    keep = (zc > 1e-6) & (lam_max > 1e-6) & (ia > 0) & (ib > 0)
    keep &= (np.abs(ic) <= np.sqrt(ia * ib))
    idx_keep = np.nonzero(keep)[0]

    color_sum = np.zeros((h * w, 3), dtype=np.float64)
    weight_sum = np.zeros(h * w, dtype=np.float64)
    depth_sum = np.zeros(h * w, dtype=np.float64)

    # Precompute per-pixel ray direction (for exact plane depth at pixel).
    yy, xx = np.meshgrid(np.arange(h), np.arange(w), indexing="ij")
    dx = (xx - cx) / fx
    dy = (yy - cy) / fy

    for i in idx_keep:
        r = sigma_extent * float(np.sqrt(lam_max[i]))
        r = max(r, 1.0)
        bbox = int(np.ceil(r))
        uc = int(round(float(u0[i])))
        vc = int(round(float(v0[i])))
        y0, y1 = max(vc - bbox, 0), min(vc + bbox + 1, h)
        x0, x1 = max(uc - bbox, 0), min(uc + bbox + 1, w)
        if x0 >= x1 or y0 >= y1:
            continue

        du = xx[y0:y1, x0:x1] - float(u0[i])
        dv = yy[y0:y1, x0:x1] - float(v0[i])
        # Mahalanobis distance^2 for the 2x2 covariance [[a,c],[c,b]] -> inv.
        d2 = ia[i] * du * du + 2.0 * ic[i] * du * dv + ib[i] * dv * dv
        wt = np.exp(-0.5 * np.clip(d2, 0.0, None))
        wt = wt.astype(np.float32)
        if not wt.any():
            continue

        # Exact ray-plane depth at each splatted pixel (matches ray-disc semantics).
        denom = (n[i, 0] * dx[y0:y1, x0:x1]
                 + n[i, 1] * dy[y0:y1, x0:x1] + n[i, 2])
        live = np.abs(denom) > 1e-9
        t = np.full_like(denom, np.inf, dtype=np.float32)
        t[live] = n_dot_mu[i] / denom[live]
        wgt = wt * (t > 0)

        flat = (yy[y0:y1, x0:x1] * w + xx[y0:y1, x0:x1]).ravel().astype(np.int64)
        col = g.color[i].astype(np.float64)

        cv = wgt.ravel()
        valid = cv > 0
        if not valid.any():
            continue
        f = flat[valid]
        cvv = cv[valid]
        tv = t.ravel()[valid]

        if mode == "alpha":
            # Front-to-back compositing: C += (1 - T_prev) * alpha * c.
            # Approximate by per-surfel independent alpha weights here, then
            # normalize later only if weights collapse. Kept simple: same as
            # normalized but scale weight by alpha.
            cvv = cvv * float(np.clip(g.alpha[i], 0.0, 1.0))
        np.add.at(weight_sum, f, cvv.astype(np.float64))
        np.add.at(depth_sum, f, (tv * cvv).astype(np.float64))
        for ch in range(3):
            np.add.at(color_sum[:, ch], f, cvv * col[ch])

    weight = (weight_sum.reshape(h, w)).astype(np.float32)
    color = np.divide(color_sum, weight_sum[:, None],
                      out=np.zeros_like(color_sum),
                      where=weight_sum[:, None] > 0)
    color = np.clip(color.reshape(h, w, 3), 0.0, 1.0).astype(np.float32)
    depth = np.divide(depth_sum, weight_sum,
                      out=np.full(h * w, np.inf, dtype=np.float64),
                      where=weight_sum > 0).reshape(h, w).astype(np.float32)
    return color, depth, weight


# ---------------------------------------------------------------------------
# metrics (mirrors h_pipeline_final.evaluate: linear-space colour RMSE/PSNR)
# ---------------------------------------------------------------------------

def _liner_psnr(render: np.ndarray, rgb_ref: np.ndarray, mask: np.ndarray) -> float:
    err = render - rgb_ref
    m = mask & np.isfinite(render).all(axis=-1) if render.ndim == 3 else mask
    if render.ndim == 3:
        col_rmse = float(np.sqrt(np.mean(err[m] ** 2)))
    return float(-20.0 * np.log10(max(col_rmse, 1e-12)))


def _color_rmse(render: np.ndarray, rgb_ref: np.ndarray, mask: np.ndarray) -> float:
    err = render - rgb_ref
    return float(np.sqrt(np.mean(err[mask] ** 2)))


def _depth_rmse(depth: np.ndarray, z_ref: np.ndarray, mask: np.ndarray) -> float:
    err = depth - z_ref
    return float(np.sqrt(np.mean(err[mask] ** 2)))


# ---------------------------------------------------------------------------
# driver: frame 0 self-render + one novel-view pair
# ---------------------------------------------------------------------------

def _render_uint8(color: np.ndarray, weight: np.ndarray) -> np.ndarray:
    img = (np.clip(color, 0.0, 1.0)[..., ::-1] * 255.0).astype(np.uint8)
    img[weight <= 0] = 0
    return img


def _label(img: np.ndarray, s: str) -> np.ndarray:
    o = img.copy()
    cv2.rectangle(o, (0, 0), (o.shape[1], 30), (0, 0, 0), -1)
    cv2.putText(o, s, (8, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 255), 2)
    return o


def _data_dir() -> Path:
    # ROOT = <repo>/SINGLE FRAME/scripts, so 986-SceneFlow sits three levels up
    # (it is a sibling of 985-3DGS under ~/Work).
    for base in (H.ROOT.parent.parent.parent, H.ROOT.parent.parent):
        d = base / "986-SceneFlow" / "rgbd_dataset_freiburg1_desk"
        if (d / "rgb.txt").exists():
            return d
    raise FileNotFoundError("986-SceneFlow dataset not found")


def _load(idx: int):
    data_dir = _data_dir()
    pairs = H.associate(data_dir)
    fr = pairs[idx]
    map1, map2, K = H.undistort_maps((480, 640), H.FR1_INTRINSICS)
    bgr = H.remap_rgb(H.load_rgb(fr.rgb_path), map1, map2)
    z = H.remap_depth(H.load_depth(fr.depth_path), map1, map2)
    z[(z < H.GEO_CFG["z_min"]) | (z > H.GEO_CFG["z_max"])] = 0.0
    return bgr, z, K


def main():
    out_dir = H.ROOT.parent / "output_H"
    out_dir.mkdir(parents=True, exist_ok=True)

    bgr, z, K = _load(0)
    rgb_ref = bgr[..., ::-1].astype(np.float32) / 255.0
    normal_ref, eval_mask = H.eval_setup(z, K)

    g, _, _ = H.build_hybrid(bgr, z, K, 0.6)

    # --- reference: original hard ray-disc ---
    d_old, idx_old, _ = H.rasterize_discs(g, K, (480, 640))
    hit_old = np.isfinite(d_old) & eval_mask
    old_render = np.zeros((480, 640, 3), np.float32)
    old_render[hit_old] = g.color[idx_old[hit_old]]
    psnr_old = _color_rmse_psnr(old_render, rgb_ref, hit_old)
    rmse_old_d = _depth_rmse(d_old, z, hit_old)

    # --- EWA normalized ---
    col_n, dep_n, wt_n = render_ewa(g, K, (480, 640), mode="normalized")
    hit_n = (wt_n > 0) & eval_mask
    psnr_n = _color_rmse_psnr(col_n, rgb_ref, hit_n)
    rmse_n_d = _depth_rmse(dep_n, z, hit_n)

    # --- EWA alpha ---
    col_a, dep_a, wt_a = render_ewa(g, K, (480, 640), mode="alpha")
    hit_a = (wt_a > 0) & eval_mask
    psnr_a = _color_rmse_psnr(col_a, rgb_ref, hit_a)
    rmse_a_d = _depth_rmse(dep_a, z, hit_a)

    print(f"N={len(g)}")
    print(f"{'method':>12}{'cov':>8}{'hole':>8}{'psnr_db':>9}{'d_rmse_mm':>10}")
    for name, m, rmse in [
        ("raydisc", hit_old, rmse_old_d),
        ("ewa_norm", hit_n, rmse_n_d),
        ("ewa_alpha", hit_a, rmse_a_d),
    ]:
        cov = float(m.sum() / max(eval_mask.sum(), 1))
        psnr = {"raydisc": psnr_old, "ewa_norm": psnr_n, "ewa_alpha": psnr_a}[name]
        print(f"{name:>12}{cov:>8.4f}{1 - cov:>8.4f}{psnr:>9.2f}{rmse * 1000:>10.2f}")

    panel = np.vstack([
        np.hstack([_label(bgr, "GT rgb"),
                   _label(_render_uint8(old_render, np.isfinite(d_old)), "ray-disc"),
                   _label(_render_uint8(col_n, wt_n), "EWA normalized"),
                   _label(_render_uint8(col_a, wt_a), "EWA alpha"),
                   _label(cv2.absdiff(_render_uint8(col_n, wt_n), bgr),
                          f"|EWA-GT|  PSNR={psnr_n:.2f}")]),
    ])
    p0 = out_dir / "surfel_render_frame0.png"
    cv2.imwrite(str(p0), panel)
    print(f"wrote {p0}  shape={panel.shape}")

    # --- novel-view pair 0 -> 1 (off-axis shows the smoothness benefit) ---
    bgr1, z1, _ = _load(1)
    rgb_ref1 = bgr1[..., ::-1].astype(np.float32) / 255.0
    (poses, _) = _parse_tum(_data_dir().parent / "output_final" / "trajectory.txt")
    Mrel = np.linalg.inv(poses[1][1]) @ poses[0][1]
    gt = _transform_gaussians(g, Mrel)
    col_nv, _, wt_nv = render_ewa(gt, K, (480, 640), mode="normalized")
    panel2 = np.vstack([
        np.hstack([_label(bgr1, "target frame 1"),
                   _label(_render_uint8(col_nv, wt_nv), "EWA novel-view 0->1"),
                   _label(cv2.absdiff(_render_uint8(col_nv, wt_nv), bgr1),
                          "|novel - target|")]),
    ])
    p1 = out_dir / "surfel_render_novelview.png"
    cv2.imwrite(str(p1), panel2)
    print(f"wrote {p1}  shape={panel2.shape}")


# re-export the colour-error PSNR helper name (kept local for clarity)
def _color_rmse_psnr(render, rgb_ref, mask):
    return _liner_psnr(render, rgb_ref, mask)


def _parse_tum(path):
    import h_pipeline_final as _  # noqa
    from exp_novelview import parse_tum
    return parse_tum(path), None


def _transform_gaussians(g, Mrel):
    from exp_novelview import transform_gaussians
    return transform_gaussians(g, Mrel)


if __name__ == "__main__":
    import time
    t0 = time.perf_counter()
    main()
    print(f"elapsed {time.perf_counter() - t0:.1f} s")