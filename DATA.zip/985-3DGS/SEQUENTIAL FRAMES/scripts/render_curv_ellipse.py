"""Project the curvature discs' emitted footprint ellipses into frame 0.

Uses the MULTI-FRAME (incremental) h_pipeline_final -- the copy whose
`edge_distance_limit` now treats FOV-border void as non-seam. Overlays:

  * RED   = curvature disc emitted footprint ellipse (projected r1 x r2)
  * CYAN  = depth_jump_mask (valid-valid big step = the ONLY thing that now
            shrinks a disc's radius)
  * BLUE  = invalid depth (void: FOV border + sensor holes), dimmed

Saves a full frame + a zoomed bottom/right border strip so the FOV-edge case is
visible: border discs should now project PAST the frame edge instead of being
clipped to it.
"""

from __future__ import annotations

import sys
from pathlib import Path

import cv2
import numpy as np

SEQ = Path(__file__).resolve().parent          # multi-frame H
SINGLE = SEQ.parent.parent / "SINGLE FRAME" / "scripts"
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SFLOW))
sys.path.insert(0, str(SINGLE))    # exp_surfel_render (unused here) / tum_io fallback
sys.path.insert(0, str(SEQ))       # multi-frame H wins

import h_pipeline_final as H  # noqa: E402
from tum_io import (  # noqa: E402
    FR1_INTRINSICS, associate, load_depth, load_rgb,
    remap_depth, remap_rgb, undistort_maps,
)

DATA = Path("/home/sti/Work/986-SceneFlow/rgbd_dataset_freiburg1_desk")
OUT = SEQ.parent / "output_absorb_v2" / "curv_ellipse"
OUT.mkdir(parents=True, exist_ok=True)

N_PTS = 40
TH = np.linspace(0, 2 * np.pi, N_PTS, endpoint=False)


def main() -> None:
    pairs = associate(DATA)
    fr = pairs[0]
    sample = load_rgb(fr.rgb_path)
    h, w = sample.shape[:2]
    map1, map2, K = undistort_maps((h, w), FR1_INTRINSICS)
    bgr = remap_rgb(load_rgb(fr.rgb_path), map1, map2)
    z = remap_depth(load_depth(fr.depth_path), map1, map2)
    z[(z < H.GEO_CFG["z_min"]) | (z > H.GEO_CFG["z_max"])] = 0.0

    valid = H.depth_valid(z)
    g, keep_geo, tex_mask = H.build_hybrid(bgr, z, K, 0.6)

    # build_hybrid's concatenate drops axis1/axis2 (S2 discs have none). Re-emit
    # the curvature discs alone to recover their principal axes for the ellipse.
    geo = H.compute_scene_geometry(
        z, K, H.GEO_CFG["eps"], H.GEO_CFG["gauss_sigma"], H.GEO_CFG["disc_rel"],
    )
    r_cap = H.tex_boundary_limit(z, K, tex_mask, tol_px=4.5)
    g_curv = H.emit_curvature_discs(
        bgr, z, K, eps=H.GEO_CFG["eps"], gauss_sigma=H.GEO_CFG["gauss_sigma"],
        r_max=H.GEO_CFG["r_max"], shrink=H.GEO_CFG["shrink"],
        z_min=H.GEO_CFG["z_min"], z_max=H.GEO_CFG["z_max"],
        disc_rel=H.GEO_CFG["disc_rel"], mask=keep_geo & ~tex_mask,
        r_cap=r_cap, geo=geo,
    )
    n_curv = len(g_curv)
    n_s2 = int((~tex_mask).sum() > 0) and (len(g) - len(g_curv))
    print(f"N={len(g)} curv={n_curv} s2={n_s2}")

    fx, fy, cx, cy = K[0, 0], K[1, 1], K[0, 2], K[1, 2]

    # base image: dimmed RGB
    vis = (bgr.astype(np.float32) * 0.55).astype(np.uint8).copy()

    # void (invalid depth) -> blue tint
    void = ~valid
    vis[void] = (vis[void].astype(np.float32) * 0.4 + np.array([120, 60, 20], np.float32)).astype(np.uint8)

    # depth-jump mask -> cyan
    jump = H.depth_jump_mask(z, H.GEO_CFG["disc_rel"], valid=valid)
    vis[jump] = (255, 255, 0)

    # curvature emitted footprint ellipses -> red
    mu = g_curv.mu.astype(np.float64)
    a1 = g_curv.axis1.astype(np.float64)
    a2 = g_curv.axis2.astype(np.float64)
    r1 = g_curv.scale[:, 0].astype(np.float64)
    r2 = g_curv.scale[:, 1].astype(np.float64)
    for i in range(mu.shape[0]):
        # 3D ellipse boundary: mu + r1 cos t a1 + r2 sin t a2
        cs = np.cos(TH)
        sn = np.sin(TH)
        pts = (mu[i][None, :]
               + (r1[i] * cs)[:, None] * a1[i][None, :]
               + (r2[i] * sn)[:, None] * a2[i][None, :])
        zc = np.maximum(pts[:, 2], 1e-6)
        u = fx * pts[:, 0] / zc + cx
        v = fy * pts[:, 1] / zc + cy
        epts = np.rint(np.stack([u, v], axis=1)).astype(np.int32)
        epts = np.clip(epts, [0, 0], [w - 1, h - 1])
        cv2.polylines(vis, [epts], True, (0, 0, 255), 1, cv2.LINE_8)

    # legend bar
    bar = np.full((56, w, 3), 25, np.uint8)
    lg = [
        ((0, 0, 255), "curvature emitted footprint ellipse"),
        ((255, 255, 0), "depth_jump_mask (the only radius shrinker now)"),
        ((120, 60, 20), "invalid depth (void: FOV border + holes)"),
    ]
    x = 8
    for col, name in lg:
        cv2.rectangle(bar, (x, 8), (x + 18, 26), col, -1)
        cv2.rectangle(bar, (x, 8), (x + 18, 26), (220, 220, 220), 1)
        cv2.putText(bar, name, (x + 24, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.42,
                    (220, 220, 220), 1, cv2.LINE_AA)
        x += 24 + 8 * len(name) + 32

    full = np.vstack([vis, bar])
    cv2.imwrite(str(OUT / "curv_ellipse_frame0.png"), full)

    # zoom on the right border (where FOV clipping used to bind hard)
    x0, x1, y0, y1 = w - 220, w, 0, h
    zoom = cv2.resize(vis[y0:y1, x0:x1], (220 * 2, h * 2), interpolation=cv2.INTER_NEAREST)
    cv2.imwrite(str(OUT / "curv_ellipse_right_border.png"), zoom)

    print(f"saved -> {OUT}")


if __name__ == "__main__":
    main()