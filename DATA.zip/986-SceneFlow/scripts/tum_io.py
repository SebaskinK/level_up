"""TUM RGB-D I/O: timestamps, RGB-D association, depth, ground truth."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np

# Freiburg1 (Kinect) camera, RGB-D dataset paper / TUM tools.
FR1_INTRINSICS = dict(
    fx=517.3,
    fy=516.5,
    cx=318.6,
    cy=255.3,
    dist=np.array([0.2624, -0.9531, -0.0054, 0.0026, 1.1633], dtype=np.float64),
)
DEPTH_SCALE = 5000.0


@dataclass
class Pair:
    t_rgb: float
    t_depth: float
    rgb_path: Path
    depth_path: Path


def _load_stamp_file(path: Path) -> list[tuple[float, str]]:
    rows = []
    with path.open() as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            ts, rel = line.split()
            rows.append((float(ts), rel))
    return rows


def associate(
    data_dir: Path,
    max_dt: float = 0.02,
) -> list[Pair]:
    """Nearest-neighbour RGB–depth association, each depth used at most once."""
    data_dir = Path(data_dir)
    rgb_rows = _load_stamp_file(data_dir / "rgb.txt")
    depth_rows = _load_stamp_file(data_dir / "depth.txt")
    depth_ts = np.array([t for t, _ in depth_rows], dtype=np.float64)
    used = np.zeros(len(depth_rows), dtype=bool)
    pairs: list[Pair] = []
    for t_rgb, rgb_rel in rgb_rows:
        k = int(np.argmin(np.abs(depth_ts - t_rgb)))
        if used[k] or abs(depth_ts[k] - t_rgb) > max_dt:
            continue
        used[k] = True
        pairs.append(
            Pair(
                t_rgb=t_rgb,
                t_depth=depth_ts[k],
                rgb_path=data_dir / rgb_rel,
                depth_path=data_dir / depth_rows[k][1],
            )
        )
    return pairs


def load_rgb(path: Path) -> np.ndarray:
    img = cv2.imread(str(path), cv2.IMREAD_COLOR)
    if img is None:
        raise FileNotFoundError(path)
    return img


def load_depth(path: Path, scale: float = DEPTH_SCALE) -> np.ndarray:
    raw = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)
    if raw is None:
        raise FileNotFoundError(path)
    z = raw.astype(np.float32) / scale
    z[raw == 0] = 0.0
    return z


def camera_matrix(intr: dict | None = None) -> np.ndarray:
    p = intr or FR1_INTRINSICS
    K = np.array(
        [[p["fx"], 0.0, p["cx"]], [0.0, p["fy"], p["cy"]], [0.0, 0.0, 1.0]],
        dtype=np.float64,
    )
    return K


def undistort_maps(shape_hw: tuple[int, int], intr: dict | None = None):
    h, w = shape_hw
    K = camera_matrix(intr)
    dist = (intr or FR1_INTRINSICS)["dist"]
    new_k, _ = cv2.getOptimalNewCameraMatrix(K, dist, (w, h), 0, (w, h))
    map1, map2 = cv2.initUndistortRectifyMap(K, dist, None, new_k, (w, h), cv2.CV_32FC1)
    return map1, map2, new_k


def remap_rgb(bgr: np.ndarray, map1, map2) -> np.ndarray:
    return cv2.remap(bgr, map1, map2, interpolation=cv2.INTER_LINEAR)


def remap_depth(z: np.ndarray, map1, map2) -> np.ndarray:
    return cv2.remap(z, map1, map2, interpolation=cv2.INTER_NEAREST)


def load_groundtruth(path: Path) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return timestamps (N,), translations (N,3), quaternions xyzw (N,4)."""
    ts, txyz, quat = [], [], []
    with Path(path).open() as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            v = line.split()
            ts.append(float(v[0]))
            txyz.append([float(v[1]), float(v[2]), float(v[3])])
            # file is qx qy qz qw
            quat.append([float(v[4]), float(v[5]), float(v[6]), float(v[7])])
    return (
        np.asarray(ts, dtype=np.float64),
        np.asarray(txyz, dtype=np.float64),
        np.asarray(quat, dtype=np.float64),
    )


def quat_xyzw_to_R(q: np.ndarray) -> np.ndarray:
    x, y, z, w = q
    n = np.sqrt(x * x + y * y + z * z + w * w)
    x, y, z, w = x / n, y / n, z / n, w / n
    return np.array(
        [
            [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
            [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
            [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
        ],
        dtype=np.float64,
    )


def interpolate_pose(
    t_query: float,
    ts: np.ndarray,
    txyz: np.ndarray,
    quat: np.ndarray,
) -> tuple[np.ndarray, np.ndarray] | None:
    """Linear t + SLERP q. Returns (R_wc, t_wc) or None if out of range."""
    if t_query < ts[0] or t_query > ts[-1]:
        return None
    i = int(np.searchsorted(ts, t_query, side="right") - 1)
    i = min(i, len(ts) - 2)
    t0, t1 = ts[i], ts[i + 1]
    a = 0.0 if t1 == t0 else (t_query - t0) / (t1 - t0)
    t_wc = (1 - a) * txyz[i] + a * txyz[i + 1]
    q = _slerp(quat[i], quat[i + 1], a)
    return quat_xyzw_to_R(q), t_wc


def _slerp(q0: np.ndarray, q1: np.ndarray, a: float) -> np.ndarray:
    q0 = q0 / np.linalg.norm(q0)
    q1 = q1 / np.linalg.norm(q1)
    dot = float(np.clip(np.dot(q0, q1), -1.0, 1.0))
    if dot < 0:
        q1 = -q1
        dot = -dot
    if dot > 0.9995:
        q = (1 - a) * q0 + a * q1
        return q / np.linalg.norm(q)
    theta = np.arccos(dot)
    s = np.sin(theta)
    return (np.sin((1 - a) * theta) / s) * q0 + (np.sin(a * theta) / s) * q1


def relative_camera_motion(
    R_wc0: np.ndarray,
    t_wc0: np.ndarray,
    R_wc1: np.ndarray,
    t_wc1: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    """Camera ego-motion T_01 such that T_wc1 = T_wc0 @ T_01.

    R_01 = R_wc0^T R_wc1, t_01 = R_wc0^T (t_wc1 - t_wc0)
    """
    R_01 = R_wc0.T @ R_wc1
    t_01 = R_wc0.T @ (t_wc1 - t_wc0)
    return R_01, t_01
