"""Curvature-adaptive quadtree sampling.

Experiment A showed uniform downsampling fails: scaling the radius with the
stride buys coverage but costs 4-5x depth accuracy, because a flat disc cannot
follow a curved surface -- the edge error is ~ r * tan(theta). So the disc size
must follow local curvature instead of a global stride.

A block may collapse to one Gaussian when the surface under it is locally
planar and uniform in colour. Planarity is measured as the residual to a
least-squares plane, computed in closed form from summed moments via integral
images, so every candidate block is O(1) regardless of size.
"""

from __future__ import annotations

import numpy as np


def _integral(a: np.ndarray) -> np.ndarray:
    """Summed-area table with a zero row/column, so any box sum is 4 lookups."""
    out = np.zeros((a.shape[0] + 1, a.shape[1] + 1), dtype=np.float64)
    np.cumsum(np.cumsum(a.astype(np.float64), axis=0), axis=1, out=out[1:, 1:])
    return out


class BlockStats:
    """Closed-form plane fit and colour variance over arbitrary axis-aligned boxes.

    The fit is on **inverse depth**, not depth. For a plane n.X = d with
    X = z K^-1 u, we get z (n . K^-1 u) = d, hence

        1/z = (n . K^-1 u) / d

    which is exactly affine in (u, v). Depth itself is rational, not affine: on
    a 30-degree plane spanning 128 px, fitting z leaves a 1.7e-3 residual purely
    from perspective, while fitting 1/z leaves 2.6e-16. Testing z would have
    subdivided flat surfaces for no reason -- the tolerance would be spent on
    perspective rather than on curvature.

    Residuals are converted back to metres via dz = z^2 d(1/z) so the tolerance
    stays a physical depth error.

    Fitting w = a*u + b*v + c needs only the 3x3 normal equations built from
    sums of {u^2, uv, v^2, u, v, 1} and {uw, vw, w}. All are box sums, so
    integral images give every block in constant time.
    """

    def __init__(self, z: np.ndarray, rgb: np.ndarray, valid: np.ndarray):
        h, w = z.shape
        us, vs = np.meshgrid(
            np.arange(w, dtype=np.float64), np.arange(h, dtype=np.float64)
        )
        m = valid.astype(np.float64)
        inv = np.where(valid, 1.0 / np.maximum(z, 1e-6), 0.0).astype(np.float64)
        zm = np.where(valid, z, 0.0).astype(np.float64)

        self.h, self.w = h, w
        self.I = {
            "n": _integral(m),
            "u": _integral(us * m),
            "v": _integral(vs * m),
            "uu": _integral(us * us * m),
            "uv": _integral(us * vs * m),
            "vv": _integral(vs * vs * m),
            "w": _integral(inv),
            "uw": _integral(us * inv),
            "vw": _integral(vs * inv),
            "ww": _integral(inv * inv),
            "z": _integral(zm),
        }
        self.Ic = [_integral(np.where(valid, rgb[..., c], 0.0)) for c in range(3)]
        self.Icc = [
            _integral(np.where(valid, rgb[..., c] ** 2, 0.0)) for c in range(3)
        ]

    def _box(self, table, y0, x0, y1, x1):
        return table[y1, x1] - table[y0, x1] - table[y1, x0] + table[y0, x0]

    def plane_residual(self, y0: int, x0: int, y1: int, x1: int) -> tuple[float, int]:
        """RMS depth residual (metres) of the best-fit plane, and point count."""
        g = lambda k: self._box(self.I[k], y0, x0, y1, x1)  # noqa: E731
        n = g("n")
        if n < 4:
            return float("inf"), int(n)

        A = np.array(
            [[g("uu"), g("uv"), g("u")], [g("uv"), g("vv"), g("v")], [g("u"), g("v"), n]]
        )
        b = np.array([g("uw"), g("vw"), g("w")])
        try:
            coef = np.linalg.solve(A, b)
        except np.linalg.LinAlgError:
            return float("inf"), int(n)

        # ||r||^2 = ww - 2 c.b + c A c, expanded so no per-pixel pass is needed.
        ss = g("ww") - 2.0 * coef @ b + coef @ A @ coef
        rms_inv = np.sqrt(max(ss, 0.0) / n)
        z_mean = g("z") / n
        return float(rms_inv * z_mean * z_mean), int(n)

    def color_std(self, y0: int, x0: int, y1: int, x1: int) -> float:
        n = self._box(self.I["n"], y0, x0, y1, x1)
        if n < 1:
            return float("inf")
        var = 0.0
        for c in range(3):
            s = self._box(self.Ic[c], y0, x0, y1, x1)
            ss = self._box(self.Icc[c], y0, x0, y1, x1)
            var += max(ss / n - (s / n) ** 2, 0.0)
        return float(np.sqrt(var / 3.0))

    def plane_fit(self, y0: int, x0: int, y1: int, x1: int):
        """Least-squares plane over the block: returns (coef, A, b, n) or None.

        coef = (a, b, c) for 1/z = a*u + b*v + c.
        """
        g = lambda k: self._box(self.I[k], y0, x0, y1, x1)  # noqa: E731
        n = g("n")
        if n < 4:
            return None
        A = np.array(
            [[g("uu"), g("uv"), g("u")], [g("uv"), g("vv"), g("v")], [g("u"), g("v"), n]]
        )
        b = np.array([g("uw"), g("vw"), g("w")])
        try:
            coef = np.linalg.solve(A, b)
        except np.linalg.LinAlgError:
            return None
        return coef, A, b, int(n)

    def plane_normal(self, y0: int, x0: int, y1: int, x1: int, K: np.ndarray):
        """Surface normal straight out of the plane fit.

        With 1/z = a*u + b*v + c and n.X = d, matching coefficients term by term
        (K^-1 u = [(u-cx)/fx, (v-cy)/fy, 1]) and fixing d = 1 gives

            nx = a*fx,  ny = b*fy,  nz = c + a*cx + b*cy

        Verified against a synthetic tilted plane to 1.2e-06 degrees. This beats
        averaging per-pixel normals over the block: the fit is a least-squares
        estimate over every pixel at once, so it suppresses the per-pixel noise
        that averaging merely passes through.
        """
        fit = self.plane_fit(y0, x0, y1, x1)
        if fit is None:
            return None
        (a, b, c), _, _, _ = fit
        fx, fy, cx, cy = K[0, 0], K[1, 1], K[0, 2], K[1, 2]
        nv = np.array([a * fx, b * fy, c + a * cx + b * cy], dtype=np.float64)
        nn = np.linalg.norm(nv)
        if nn < 1e-12:
            return None
        nv /= nn
        return nv if nv[2] < 0 else -nv

    def mean_depth(self, y0: int, x0: int, y1: int, x1: int) -> float:
        n = self._box(self.I["n"], y0, x0, y1, x1)
        if n < 1:
            return 0.0
        return float(self._box(self.I["z"], y0, x0, y1, x1) / n)

    def valid_frac(self, y0: int, x0: int, y1: int, x1: int) -> float:
        n = self._box(self.I["n"], y0, x0, y1, x1)
        return float(n / max((y1 - y0) * (x1 - x0), 1))


def quadtree_blocks(
    z: np.ndarray,
    rgb: np.ndarray,
    valid: np.ndarray,
    plane_tol: float = 0.002,
    color_tol: float = 0.05,
    min_size: int = 2,
    max_size: int = 32,
    min_valid_frac: float = 0.75,
    quant_coeff: float = 0.0,
    K: np.ndarray | None = None,
) -> list[tuple[int, int, int, int]] | tuple[list, np.ndarray]:
    """Split until each block is locally planar and uniform, or hits min_size.

    plane_tol is an absolute depth residual in metres, bounding the disc edge
    error r*tan(theta), which is a metric quantity rather than a relative one.

    quant_coeff raises the tolerance to match the sensor's own resolution:
    a disparity-quantized depth map cannot resolve steps below
    dz = quant_coeff * z^2, so demanding a residual finer than that asks the
    quadtree to fit noise. On TUM, quant_coeff = 0.0029 gives 11.6 mm at 2 m --
    ten times the 1 mm tolerance that was starving the merge test, which left
    64% of blocks pinned at min_size and turned the quadtree into an expensive
    stride-2. Set to 0 for a sensor whose quantization is already far below the
    pixel footprint.

    Blocks that are mostly invalid are split rather than kept, so occlusion
    boundaries end up as small blocks instead of one large wrong plane.

    If K is given, also returns per-block plane normals from the fit.
    """
    st = BlockStats(z, rgb, valid)
    h, w = z.shape
    out: list[tuple[int, int, int, int]] = []
    normals: list[np.ndarray] = []

    stack = []
    for y in range(0, h, max_size):
        for x in range(0, w, max_size):
            stack.append((y, x, min(y + max_size, h), min(x + max_size, w)))

    while stack:
        y0, x0, y1, x1 = stack.pop()
        size = max(y1 - y0, x1 - x0)
        vf = st.valid_frac(y0, x0, y1, x1)
        if vf <= 0.0:
            continue

        if size <= min_size:
            if vf > 0.0:
                out.append((y0, x0, y1, x1))
                if K is not None:
                    normals.append(st.plane_normal(y0, x0, y1, x1, K))
            continue

        res, n = st.plane_residual(y0, x0, y1, x1)
        tol = plane_tol
        if quant_coeff > 0.0:
            zm = st.mean_depth(y0, x0, y1, x1)
            tol = max(tol, quant_coeff * zm * zm)
        ok = (
            n >= 4
            and vf >= min_valid_frac
            and res <= tol
            and st.color_std(y0, x0, y1, x1) <= color_tol
        )
        if ok:
            out.append((y0, x0, y1, x1))
            if K is not None:
                normals.append(st.plane_normal(y0, x0, y1, x1, K))
            continue

        ym, xm = (y0 + y1) // 2, (x0 + x1) // 2
        for by0, bx0, by1, bx1 in (
            (y0, x0, ym, xm),
            (y0, xm, ym, x1),
            (ym, x0, y1, xm),
            (ym, xm, y1, x1),
        ):
            if by1 > by0 and bx1 > bx0:
                stack.append((by0, bx0, by1, bx1))

    if K is None:
        return out
    fallback = np.array([0.0, 0.0, -1.0])
    nrm = np.array([fallback if n is None else n for n in normals], dtype=np.float32)
    return out, nrm
