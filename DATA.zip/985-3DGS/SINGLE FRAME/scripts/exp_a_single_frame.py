"""Experiment A: single-frame closed loop.

One RGB-D frame -> analytic Gaussians -> ray-disc readout -> compare against the
input depth, normals and colour. No pose, no multi-frame fusion, no renderer
training. Answers the one question everything else depends on: is closed-form
construction accurate enough?
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from gaussian_build import (  # noqa: E402
    backproject,
    build_gaussians,
    depth_discontinuity_mask,
    depth_valid,
    normals_from_depth,
    prefilter_depth,
)
from metrics import evaluate  # noqa: E402
from rgbd_io import (  # noqa: E402
    FR1_INTRINSICS,
    associate,
    load_depth,
    load_rgb,
    remap_depth,
    remap_rgb,
    undistort_maps,
)


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--data", default=str(ROOT.parent.parent / "986-SceneFlow" / "rgbd_dataset_freiburg1_desk"))
    p.add_argument("--out", default=str(ROOT.parent / "output_A"))
    p.add_argument("--frames", type=int, default=10, help="how many frames to evaluate")
    p.add_argument("--strides", type=int, nargs="+", default=[1, 2, 4])
    p.add_argument("--z-min", type=float, default=0.4)
    p.add_argument("--z-max", type=float, default=4.0)
    p.add_argument("--disc-rel", type=float, default=0.02)
    p.add_argument(
        "--prefilter",
        nargs="+",
        default=["none", "gauss"],
        help="depth prefilter used for normals only (none|box|bilateral|gauss); "
             "gauss is the validated choice -- on a synthetic 45 deg plane with "
             "TUM quantization it recovers the normal to 0.06 deg, bilateral to "
             "3.07 deg, median not at all (14.01 deg)",
    )
    p.add_argument("--prefilter-size", type=int, default=3)
    args = p.parse_args()

    data_dir = Path(args.data)
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    pairs = associate(data_dir)[: args.frames]
    if not pairs:
        raise SystemExit(f"no RGB-D pairs under {data_dir}")

    sample = load_rgb(pairs[0].rgb_path)
    map1, map2, K = undistort_maps(sample.shape[:2], FR1_INTRINSICS)

    rows = []
    for i, fr in enumerate(pairs):
        bgr = remap_rgb(load_rgb(fr.rgb_path), map1, map2)
        z = remap_depth(load_depth(fr.depth_path), map1, map2)

        eval_mask_base = (
            depth_valid(z)
            & (z > args.z_min)
            & (z < args.z_max)
            & ~depth_discontinuity_mask(z, args.disc_rel, valid=depth_valid(z))
        )

        for pf in args.prefilter:
            # Reference normals use the same prefilter, so the metric measures
            # construction fidelity rather than the filter's own smoothing.
            z_ref_grad = prefilter_depth(z, pf, args.prefilter_size, valid=depth_valid(z))
            normal_ref, n_ok = normals_from_depth(z_ref_grad, K)
            eval_mask = eval_mask_base & n_ok

            for stride in args.strides:
                t0 = time.perf_counter()
                g = build_gaussians(
                    bgr, z, K,
                    z_min=args.z_min, z_max=args.z_max,
                    disc_rel=args.disc_rel, stride=stride,
                    prefilter=pf, prefilter_size=args.prefilter_size,
                )
                t_build = time.perf_counter() - t0

                t0 = time.perf_counter()
                m = evaluate(g, z, bgr, normal_ref, eval_mask, K)
                t_eval = time.perf_counter() - t0

                m.update(
                    frame=i, stride=stride, prefilter=pf,
                    build_ms=t_build * 1e3, eval_ms=t_eval * 1e3,
                )
                rows.append(m)
                print(
                    f"[f{i:02d} {pf:9s} s{stride}] N={m['n_gaussians']:6d} "
                    f"cov={m['coverage']:.3f} "
                    f"rmse={m['depth_rmse_mm']:6.2f}mm "
                    f"med={m['depth_med_mm']:5.2f}mm "
                    f"normal={m['normal_med_deg']:5.2f}deg "
                    f"build={t_build*1e3:6.1f}ms",
                    flush=True,
                )

    summary = {}
    for pf in args.prefilter:
        for stride in args.strides:
            sel = [r for r in rows if r["stride"] == stride and r["prefilter"] == pf]
            summary[f"{pf}_stride{stride}"] = {
                k: float(np.mean([r[k] for r in sel]))
                for k in (
                    "n_gaussians", "coverage", "hole_frac",
                    "depth_rmse_mm", "depth_mae_mm", "depth_med_mm", "depth_p95_mm",
                    "normal_med_deg", "normal_mean_deg", "normal_p95_deg",
                    "color_rmse", "color_psnr_db",
                    "gauss_per_m2", "radius_med_mm", "build_ms",
                )
            }

    (out_dir / "summary.json").write_text(json.dumps(summary, indent=2))
    _write_csv(out_dir / "frames.csv", rows)
    print("\n=== summary (mean over frames) ===")
    print(json.dumps(summary, indent=2))
    print(f"wrote {out_dir}")


def _write_csv(path: Path, rows: list[dict]) -> None:
    import csv

    keys = list(rows[0].keys())
    with path.open("w", newline="") as f:
        wr = csv.DictWriter(f, fieldnames=keys)
        wr.writeheader()
        wr.writerows(rows)


if __name__ == "__main__":
    main()
