"""Experiment H (S2 fallback variant): texture mask switches to S2, not footprint.

gamma path from the design discussion: pixels inside the texture mask are NOT
sent through the curvature pipeline at all; they are covered by an independent
stride-2 S2 build restricted to the mask. Pixels outside the mask use the full
curvature pipeline. The two primitives sets are concatenated; overlaps are
resolved by the ray-disc nearest-hit test.

Baselines: full S2 and full curvature.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from exp_g_aniso_real import CFG as GEO_CFG, eval_setup  # noqa: E402
from exp_e_curvature_sample import curvature_mask  # noqa: E402
from exp_h_texture_mask import texture_mask, concat  # noqa: E402
from gaussian_build import (
    build_gaussians,
    build_gaussians_curvature,
    compute_curvature_geometry,
    tex_boundary_limit,
)  # noqa: E402
from metrics import evaluate, rasterize_discs  # noqa: E402
from rgbd_io import (  # noqa: E402
    FR1_INTRINSICS,
    associate,
    load_depth,
    load_rgb,
    remap_depth,
    remap_rgb,
    undistort_maps,
)


def build_s2_fallback(dbgr, z, K, texture_quantile: float,
                      radius_scale: float = np.sqrt(2.0),
                      tex_boundary_tol_px: float = 4.5):
    """Texture mask -> S2 (stride 2) inside, curvature outside.

    Pixels inside the texture mask are covered by an independent stride-2 S2
    build restricted to the mask; pixels outside use the curvature pipeline with
    its radius clamped by tex_boundary_limit so a large flat disc cannot poke past
    the colour boundary (no depth edge there) into the texture region. Overlaps
    are resolved by the ray-disc nearest-hit test.
    """
    rgb = dbgr[..., ::-1].astype(np.float32) / 255.0
    tex_mask = texture_mask(rgb, texture_quantile)

    # Curvature pipeline on the NON-texture region only.
    r_cap = None
    if tex_boundary_tol_px > 0:
        r_cap = tex_boundary_limit(z, K, tex_mask, tol_px=tex_boundary_tol_px)
    geo = compute_curvature_geometry(
        z, K, GEO_CFG["eps"], GEO_CFG["gauss_sigma"], GEO_CFG["disc_rel"],
    )
    keep_geo = curvature_mask(
        z, K, GEO_CFG["eps"], GEO_CFG["gauss_sigma"], GEO_CFG["z_min"],
        GEO_CFG["z_max"], GEO_CFG["disc_rel"], GEO_CFG["overlap"], GEO_CFG["r_max"],
        foreshorten=False, aniso_claim=True, edge_fallback_fp=True,
        r_cap=r_cap, geo=geo,
    )
    keep_geo = keep_geo & ~tex_mask

    parts = []
    if keep_geo.any():
        parts.append(build_gaussians_curvature(
            dbgr, z, K, eps=GEO_CFG["eps"], gauss_sigma=GEO_CFG["gauss_sigma"],
            r_max=GEO_CFG["r_max"], shrink=GEO_CFG["shrink"],
            normal_mode="disc_inliers_fast", z_min=GEO_CFG["z_min"], z_max=GEO_CFG["z_max"],
            disc_rel=GEO_CFG["disc_rel"], mask=keep_geo, prefilter="gauss",
            prefilter_size=int(GEO_CFG["gauss_sigma"]), r_cap=r_cap, geo=geo,
        ))

    # S2 restricted to the texture region, reusing the geometry already computed
    # for the curvature side (same sigma), so the smoothed depth / normal /
    # discontinuity mask are not recomputed.
    if tex_mask.any():
        parts.append(build_gaussians(
            dbgr, z, K, z_min=GEO_CFG["z_min"], z_max=GEO_CFG["z_max"],
            disc_rel=GEO_CFG["disc_rel"], stride=2, mask=tex_mask,
            radius_scale=radius_scale, geo=geo,
        ))

    return concat(parts), keep_geo, tex_mask


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--data", default=str(
        ROOT.parent.parent / "986-SceneFlow" / "rgbd_dataset_freiburg1_desk"))
    p.add_argument("--out", default=str(ROOT.parent / "output_H"))
    p.add_argument("--frames", type=int, default=3)
    p.add_argument("--quantiles", type=float, nargs="+", default=[0.6])
    args = p.parse_args()

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    pairs = associate(Path(args.data))
    sample = load_rgb(pairs[0].rgb_path)
    map1, map2, K = undistort_maps(sample.shape[:2], FR1_INTRINSICS)

    methods = ["S2", "curv"]
    methods += [f"s2q{q:g}" for q in args.quantiles]

    print(f"{'frame':>6}{'method':>10}{'N':>8}{'cover':>8}{'hole':>8}"
          f"{'rmse_mm':>9}{'med_mm':>8}{'n_area':>8}{'psnr':>7}")
    acc = {m: [] for m in methods}
    for i, fr in enumerate(pairs[:args.frames]):
        bgr = remap_rgb(load_rgb(fr.rgb_path), map1, map2)
        z = remap_depth(load_depth(fr.depth_path), map1, map2)
        normal_ref, eval_mask = eval_setup(z, K)

        g_s2 = build_gaussians(
            bgr, z, K, z_min=GEO_CFG["z_min"], z_max=GEO_CFG["z_max"],
            disc_rel=GEO_CFG["disc_rel"], stride=2,
            prefilter="gauss", prefilter_size=int(GEO_CFG["gauss_sigma"]),
        )
        m = evaluate(g_s2, z, bgr, normal_ref, eval_mask, K)
        acc["S2"].append(m)
        print(f"{i:>6}{'S2':>10}{m['n_gaussians']:>8d}{m['coverage']:>8.3f}"
              f"{m['hole_frac']:>8.3f}{m['depth_rmse_mm']:>9.2f}{m['depth_med_mm']:>8.2f}"
              f"{m['normal_area_med_deg']:>8.2f}{m['color_psnr_db']:>7.2f}", flush=True)

        keep_curv = curvature_mask(
            z, K, GEO_CFG["eps"], GEO_CFG["gauss_sigma"], GEO_CFG["z_min"],
            GEO_CFG["z_max"], GEO_CFG["disc_rel"], GEO_CFG["overlap"], GEO_CFG["r_max"],
            foreshorten=False, aniso_claim=True, edge_fallback_fp=True,
        )
        g_curv = build_gaussians_curvature(
            bgr, z, K, eps=GEO_CFG["eps"], gauss_sigma=GEO_CFG["gauss_sigma"],
            r_max=GEO_CFG["r_max"], shrink=GEO_CFG["shrink"],
            normal_mode="disc_inliers", z_min=GEO_CFG["z_min"], z_max=GEO_CFG["z_max"],
            disc_rel=GEO_CFG["disc_rel"], mask=keep_curv, prefilter="gauss",
            prefilter_size=int(GEO_CFG["gauss_sigma"]),
        )
        m = evaluate(g_curv, z, bgr, normal_ref, eval_mask, K)
        acc["curv"].append(m)
        print(f"{i:>6}{'curv':>10}{m['n_gaussians']:>8d}{m['coverage']:>8.3f}"
              f"{m['hole_frac']:>8.3f}{m['depth_rmse_mm']:>9.2f}{m['depth_med_mm']:>8.2f}"
              f"{m['normal_area_med_deg']:>8.2f}{m['color_psnr_db']:>7.2f}", flush=True)

        for q in args.quantiles:
            tag = f"s2q{q:g}"
            g_h, _, _ = build_s2_fallback(bgr, z, K, q)
            m = evaluate(g_h, z, bgr, normal_ref, eval_mask, K)
            acc[tag].append(m)
            print(f"{i:>6}{tag:>10}{m['n_gaussians']:>8d}"
                  f"{m['coverage']:>8.3f}{m['hole_frac']:>8.3f}"
                  f"{m['depth_rmse_mm']:>9.2f}{m['depth_med_mm']:>8.2f}"
                  f"{m['normal_area_med_deg']:>8.2f}{m['color_psnr_db']:>7.2f}",
                  flush=True)

    print("-" * 100)
    for mth in methods:
        rs = acc[mth]
        if not rs:
            continue
        f = lambda k: float(np.mean([x[k] for x in rs]))  # noqa: E731
        print(f"{'MEAN':>6}{mth:>10}{f('n_gaussians'):>8.0f}{f('coverage'):>8.3f}"
              f"{f('hole_frac'):>8.3f}{f('depth_rmse_mm'):>9.2f}{f('depth_med_mm'):>8.2f}"
              f"{f('normal_area_med_deg'):>8.2f}{f('color_psnr_db'):>7.2f}")

    print(f"\nwrote metrics to {out_dir}")


if __name__ == "__main__":
    main()