"""Diagnose FOV-boundary radius clipping vs true depth-break clipping.

Two questions from the edge-fallback discussion:

  Q1. How much of the "radius pressed to floor" population is FOV truncation
      (image border / invalid depth touching the frame edge) vs a TRUE interior
      depth break (invalid depth surrounded by valid depth)?  Only the latter
      is a real geometric seam; the former is a sensor-FOV artifact that, in a
      continuously-moving sequence, the next frame should simply observe.

  Q2. Does `depth_discontinuity_mask` mislabel the image border via np.roll
      wraparound?  The current implementation rolls the neighbour column off the
      far edge, so the rightmost column's "right neighbour" is the leftmost
      column -- the border break detection is data-coincidence.  A corrected
      version treats off-image neighbours as void.

Reported, per frame:
  * valid-pixel count; void split into border-touching vs interior components
  * clipped = pixels whose emitted radius is pushed to the footprint floor
    (min(r_max, r_edge) < r_fp*sqrt(2)), split by NEAREST void type
  * border-ring clipping + FOV-truncated component pixel share
  * roll-vs-corrected discontinuity disagreement on the image border
"""

from __future__ import annotations

import sys
from pathlib import Path

import cv2
import numpy as np

SEQ = Path(__file__).resolve().parent
sys.path.insert(0, str(SEQ))

import h_pipeline_final as H  # noqa: E402

DATA = Path("/home/sti/Work/986-SceneFlow/rgbd_dataset_freiburg1_desk")
FLOOR_SCALE = np.sqrt(2.0)


def _void_components(z):
    """Label invalid-depth pixels; classify each component border-touching or not."""
    h, w = z.shape
    void = (z <= 0).astype(np.uint8)
    n, labels, stats, _ = cv2.connectedComponentsWithStats(void, 8, cv2.CV_32S)
    border_touch = np.zeros(n, dtype=bool)
    for c in range(1, n):
        x, y, cw, ch = stats[c][0], stats[c][1], stats[c][2], stats[c][3]
        border_touch[c] = (x == 0) or (y == 0) or (x + cw >= w) or (y + ch >= h)
    # per-void-pixel: which component, and does it touch the border
    comp_id = labels.copy()
    touches = border_touch[labels]          # label 0 = background (valid), False
    return labels, border_touch, touches


def _corrected_disc_mask(z, rel_thresh, valid):
    """depth_discontinuity_mask with off-image neighbours treated as void.

    Same 4-neighbour max-step logic, but a neighbour outside the image is made
    invalid (z=0) instead of wrapped around by np.roll.
    """
    h, w = z.shape
    # pad by 1 with an invalid border so an off-image neighbour reads as void
    zp = np.zeros((h + 2, w + 2), dtype=np.float32)
    vp = np.zeros((h + 2, w + 2), dtype=bool)
    zp[1:-1, 1:-1] = z
    vp[1:-1, 1:-1] = valid
    step = np.full(z.shape, -1.0, dtype=np.float32)
    for dy, dx in ((0, 1), (0, -1), (1, 0), (-1, 0)):
        shifted = zp[1 + dy: 1 + dy + h, 1 + dx: 1 + dx + w]
        nbr_valid = vp[1 + dy: 1 + dy + h, 1 + dx: 1 + dx + w]
        d = np.where(nbr_valid, np.abs(z - shifted), np.inf)
        step = np.maximum(step, d)
    edge = step > rel_thresh * np.maximum(z, 1e-6)
    return edge & valid


def analyze(z, K):
    cfg = H.GEO_CFG
    valid = H.depth_valid(z)
    h, w = z.shape
    geo = H.compute_scene_geometry(z, K, cfg["eps"], cfg["gauss_sigma"],
                                   cfg["disc_rel"], valid_depth=valid)

    labels, border_touch, touches = _void_components(z)

    lim = np.minimum(cfg["r_max"], geo.r_edge)
    floor = geo.r_fp * FLOOR_SCALE
    clipped = valid & (lim < floor)

    # ---- attribute each clipped pixel to the nearest depth-discontinuity
    # SOURCE, not nearest void. Two sources make up disc_mask:
    #   (a) void-adjacent: a valid pixel with an invalid 4-neighbour  -> FOV trunc
    #       (FOV touches the border) or an isolated hole.
    #   (b) depth-jump: valid pixel whose 4-neighbour is valid but depth steps
    #       beyond rel_thresh -> a TRUE geometric seam (table edge, object edge).
    pad = 1
    zp = np.zeros((h + 2, w + 2), dtype=np.float32)
    vp = np.zeros((h + 2, w + 2), dtype=bool)
    zp[1:-1, 1:-1] = z
    vp[1:-1, 1:-1] = valid
    void_adj = np.zeros_like(valid)
    jump = np.zeros_like(valid)
    for dy, dx in ((0, 1), (0, -1), (1, 0), (-1, 0)):
        nb = vp[1 + dy: 1 + dy + h, 1 + dx: 1 + dx + w]
        zb = zp[1 + dy: 1 + dy + h, 1 + dx: 1 + dx + w]
        void_adj |= valid & ~nb
        jump |= valid & nb & (np.abs(z - zb) > cfg["disc_rel"] * np.maximum(z, 1e-6))
    # nearest source mask per valid pixel via distance transform
    d_void_adj = cv2.distanceTransform((~void_adj).astype(np.uint8),
                                       cv2.DIST_L2, 5)
    d_jump = cv2.distanceTransform((~jump).astype(np.uint8), cv2.DIST_L2, 5)
    # attribute each CLIPPED pixel to its nearest discontinuity source
    near_void_clip = clipped & (d_void_adj <= d_jump)
    near_jump_clip = clipped & (d_jump < d_void_adj)
    near_both_clip = clipped & void_adj & jump

    n_valid = int(valid.sum())
    n_void = int((~valid).sum())

    R = 8
    ring = np.zeros((h, w), dtype=bool)
    ring[:R, :] = ring[:, :R] = True
    ring[-R:, :] = ring[:, -R:] = True
    ring &= valid

    out = {
        "n_valid": n_valid,
        "n_void": n_void,
        "n_void_border": int(((~valid) & touches).sum()),
        "n_void_interior": int(((~valid) & ~touches).sum()),
        "n_void_components": int(labels.max()),
        "n_components_border": int(border_touch[1:].sum()),
        "n_clipped": int(clipped.sum()),
        "n_clipped_void_adj": int(near_void_clip.sum()),
        "n_clipped_jump": int(near_jump_clip.sum()),
        "n_clipped_both": int(near_both_clip.sum()),
        "n_ring_valid": int(ring.sum()),
        "n_ring_clipped": int((ring & clipped).sum()),
        # spatial location of clipped pixels: median/p90 Chebyshev distance to frame
        "clip_dist_edge_med": float(_clip_dist_to_edge(clipped)),
    }

    roll_edge = H.depth_discontinuity_mask(z, cfg["disc_rel"], valid=valid)
    corr_edge = _corrected_disc_mask(z, cfg["disc_rel"], valid)
    border = np.zeros((h, w), dtype=bool)
    border[0, :] = border[-1, :] = border[:, 0] = border[:, -1] = True
    border &= valid
    disagree = border & (roll_edge != corr_edge)
    out["n_border_valid"] = int(border.sum())
    out["n_roll_mislabel"] = int(disagree.sum())
    return out


def _clip_dist_to_edge(clipped):
    ys, xs = np.where(clipped)
    if ys.size == 0:
        return float("nan")
    h, w = clipped.shape
    d = np.minimum(np.minimum(ys, h - 1 - ys), np.minimum(xs, w - 1 - xs))
    return float(np.median(d))


def main() -> None:
    pairs = H.associate(DATA, max_dt=0.02)[:11]
    sample = H.load_rgb(pairs[0].rgb_path)
    h, w = sample.shape[:2]
    map1, map2, K = H.undistort_maps((h, w), H.FR1_INTRINSICS)

    hdr = (f"{'f':>2} {'valid':>7} {'void':>7} {'vbord':>6} {'vint':>6} "
           f"{'cmp_b':>6} {'clip':>6} {'c_voidadj':>9} {'c_jump':>6} {'c_both':>6} "
           f"{'ring':>6} {'ring_clip':>9} {'clip_dmed':>9} {'roll_mis':>8}")
    print(hdr)
    for i in range(len(pairs)):
        fr = pairs[i]
        bgr = H.remap_rgb(H.load_rgb(fr.rgb_path), map1, map2)
        z = H.remap_depth(H.load_depth(fr.depth_path), map1, map2)
        z[z < H.GEO_CFG["z_min"]] = 0.0
        z[z > H.GEO_CFG["z_max"]] = 0.0
        r = analyze(z, K)
        print(f"{i:>2} {r['n_valid']:>7} {r['n_void']:>7} "
              f"{r['n_void_border']:>6} {r['n_void_interior']:>6} "
              f"{r['n_components_border']:>6} "
              f"{r['n_clipped']:>6} {r['n_clipped_void_adj']:>9} "
              f"{r['n_clipped_jump']:>6} {r['n_clipped_both']:>6} "
              f"{r['n_ring_valid']:>6} {r['n_ring_clipped']:>9} "
              f"{r['clip_dist_edge_med']:>9.0f} "
              f"{r['n_roll_mislabel']:>8}")


if __name__ == "__main__":
    main()