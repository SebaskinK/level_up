"""PREV vs NEW frame-0 blue attribution: absorb-first (no guard) vs + old-draw guard.

PREV = output_blue_reason_oldfp  (absorb-first, N=81349, blue=5928 px)
NEW  = output_blue_reason_olddraw(old-draw guard,  N=77324, blue=2217 px)

Both sides are read from the attribution runs' own report.txt -- no number is
typed in by hand. Bars are split by the gate that rejected the nearest OLD disc;
the bottom row shows the two blue-reason maps side by side.

Run:  python scripts/cmp_olddraw_blue_f0.py
"""

from __future__ import annotations

import argparse
import re
from pathlib import Path

import cv2
import matplotlib
import numpy as np

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

SEQ = Path(__file__).resolve().parent
ROOT = SEQ.parent
BLOCK = "BLUE & f0-measured (redundant overdraw)"
BLOCK_L = "BLUE & f0-measured, LEFT x<128"
GATES = ["NO_NBR", "PLANE_FAIL", "RADIUS_FAIL", "COLOUR_FAIL", "WOULD_ABSORB"]
GATE_COLORS = ["#6e6e6e", "#e04b4b", "#e8c33a", "#f08a2a", "#3ec03e"]


def parse_block(text: str, header: str) -> dict:
    m = re.search(re.escape(header), text)
    if not m:
        raise SystemExit(f"header not found: {header}")
    tail = text[m.end():]
    out = {"total": int(re.search(r":\s*(\d+) px", tail).group(1))}
    for g in GATES:
        gm = re.search(rf"^\s+{g}\s+:\s*px=\s*(\d+)", tail, re.M)
        out[g] = int(gm.group(1)) if gm else 0
    return out


def headline(text: str) -> int:
    return int(re.search(r"BLUE \(front-most[^=]*= (\d+) px", text).group(1))


def caps(lines: list[str], width: int) -> np.ndarray:
    bar = np.full((18 * len(lines) + 12, width, 3), 20, np.uint8)
    for i, ln in enumerate(lines):
        cv2.putText(bar, ln, (8, 16 + 18 * i), cv2.FONT_HERSHEY_SIMPLEX,
                    0.42, (232, 232, 232), 1, cv2.LINE_AA)
    return bar


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--prev", default="output_blue_reason_oldfp")
    ap.add_argument("--new", default="output_blue_reason_olddraw")
    ap.add_argument("--prev-lbl", default="PREV: absorb-first, no guard")
    ap.add_argument("--new-lbl", default="NEW: + old-draw guard")
    args = ap.parse_args()
    prev_dir, new_dir = ROOT / args.prev, ROOT / args.new

    pt, nt = (prev_dir / "report.txt").read_text(), (new_dir / "report.txt").read_text()
    p, n = parse_block(pt, BLOCK), parse_block(nt, BLOCK)
    pl, nl = parse_block(pt, BLOCK_L), parse_block(nt, BLOCK_L)

    fig, axes = plt.subplots(1, 2, figsize=(15.5, 5.2), dpi=105)
    for ax, pb, nb, tag in [(axes[0], p, n, "ALL blue"), (axes[1], pl, nl, "LEFT band x<128")]:
        x = np.arange(len(GATES))
        pv, nv = [pb[g] for g in GATES], [nb[g] for g in GATES]
        ax.bar(x - 0.2, pv, 0.4, label=f"{args.prev_lbl}  blue={pb['total']} px",
               color=GATE_COLORS, alpha=0.45, edgecolor="k", linewidth=0.6)
        ax.bar(x + 0.2, nv, 0.4, label=f"{args.new_lbl}  blue={nb['total']} px",
               color=GATE_COLORS, edgecolor="k", linewidth=0.6)
        for xi, (a, b) in enumerate(zip(pv, nv)):
            ax.text(xi - 0.2, a, str(a), ha="center", va="bottom", fontsize=8)
            ax.text(xi + 0.2, b, str(b), ha="center", va="bottom", fontsize=8,
                    fontweight="bold")
        ax.set_xticks(x)
        ax.set_xticklabels([g.replace("_", "\n") for g in GATES], fontsize=9)
        ax.set_title(f"{tag}: blue px by rejecting gate of the nearest old disc", fontsize=10)
        ax.set_ylabel("blue pixels", fontsize=9)
        ax.grid(axis="y", alpha=0.25)
        ax.legend(fontsize=8, loc="upper right")
    fig.tight_layout()
    fig.canvas.draw()
    chart = cv2.cvtColor(np.asarray(fig.canvas.buffer_rgba()), cv2.COLOR_RGBA2BGR)
    plt.close(fig)

    mp, mn = cv2.imread(str(prev_dir / "blue_reason.png")), cv2.imread(str(new_dir / "blue_reason.png"))
    maps = []
    for im, lbl in [(mp, args.prev_lbl), (mn, args.new_lbl)]:
        im = im[:480]
        im = cv2.resize(im, (chart.shape[1] // 2 - 6, int(im.shape[0] * (chart.shape[1] / 2 - 6) / im.shape[1])),
                        interpolation=cv2.INTER_NEAREST)
        bar = np.full((28, im.shape[1], 3), 20, np.uint8)
        cv2.putText(bar, lbl, (8, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (235, 235, 235), 1, cv2.LINE_AA)
        maps.append(np.vstack([bar, im]))
    sep = np.full((maps[0].shape[0], 6, 3), 255, np.uint8)
    map_row = np.hstack([maps[0], sep, maps[1]])
    if map_row.shape[1] < chart.shape[1]:
        map_row = np.hstack([map_row, np.full((map_row.shape[0], chart.shape[1] - map_row.shape[1], 3), 18, np.uint8)])
    body = np.vstack([chart, np.full((6, chart.shape[1], 3), 255, np.uint8), map_row[:, :chart.shape[1]]])

    tot_p, tot_n = headline(pt), headline(nt)
    lines = [
        f"FRAME-0 BLUE PIXELS  (blue = front-most disc born f1-80 where f0 measured depth, |dz|/z<0.05)",
        f"ALL blue: {args.prev_lbl} {tot_p} px  ->  {args.new_lbl} {tot_n} px  "
        f"({100*(tot_n-tot_p)/tot_p:+.1f}%).   LEFT x<128: {pl['total']} -> {nl['total']} px "
        f"({100*(nl['total']-pl['total'])/pl['total']:+.1f}%).",
        f"WOULD_ABSORB (green): ALL {p['WOULD_ABSORB']} -> {n['WOULD_ABSORB']} px "
        f"({100*(n['WOULD_ABSORB']-p['WOULD_ABSORB'])/p['WOULD_ABSORB']:+.1f}%),  "
        f"LEFT {pl['WOULD_ABSORB']} -> {nl['WOULD_ABSORB']} px "
        f"({100*(nl['WOULD_ABSORB']-pl['WOULD_ABSORB'])/pl['WOULD_ABSORB']:+.1f}%).",
        "Guard: after stage-0 absorb, a leftover pixel the OLD model already rasterises at the same depth "
        "is claimed by that disc (owner registered) instead of birthing a duplicate on top of it.",
        f"RADIUS_FAIL (yellow) is now the top remaining source: ALL {n['RADIUS_FAIL']} px "
        f"({100*n['RADIUS_FAIL']/n['total']:.1f}%), LEFT {nl['RADIUS_FAIL']} px -- "
        f"the old discs' frozen radii do not reach those pixels (real raster gaps), so the newborn is needed to fill them.",
    ]
    out = np.vstack([body, caps(lines, body.shape[1])])
    dst = new_dir / "cmp_olddraw_blue_f0.png"
    cv2.imwrite(str(dst), out)
    print("saved ->", dst, out.shape)
    for tag, pb, nb in [("ALL ", p, n), ("LEFT", pl, nl)]:
        print(tag, "PREV", {g: pb[g] for g in GATES}, "total", pb["total"])
        print(tag, "NEW ", {g: nb[g] for g in GATES}, "total", nb["total"])


if __name__ == "__main__":
    main()