"""Mask panel: what changed, visually, from the refactor.

Six panels on one frame 0:
  (a) raw depth (normalised)
  (b) valid = z>0           -- the new single source of truth
  (c) edge mask BEFORE fix  -- double lines around void stripes
  (d) edge mask AFTER fix   -- one line per real boundary
  (e) holes (foreshorten OFF) over RGB   -- red
  (f) normal tilt field over RGB -- tilted surfaces colored
"""

from __future__ import annotations

import sys
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from gaussian_build import (  # noqa: E402
    depth_discontinuity_mask,
    depth_valid,
    edge_distance_limit,
    normals_from_depth,
    prefilter_depth,
)
from metrics import rasterize_discs  # noqa: E402
from rgbd_io import (  # noqa: E402
    FR1_INTRINSICS,
    associate,
    load_depth,
    load_rgb,
    remap_depth,
    remap_rgb,
    undistort_maps,
)
from exp_g_slope import CFG, build  # noqa: E402, reuses production builder


def edge_old(z, rel=0.02):
    step = np.zeros_like(z, dtype=np.float32)
    for dy, dx in ((0, 1), (0, -1), (1, 0), (-1, 0)):
        sh = np.roll(np.roll(z, dy, axis=0), dx, axis=1)
        step = np.maximum(step, np.abs(z - sh))
    return step > rel * np.maximum(z, 1e-6)


def main() -> None:
    data = ROOT.parent.parent / "986-SceneFlow" / "rgbd_dataset_freiburg1_desk"
    pairs = associate(Path(data))
    sample = load_rgb(pairs[0].rgb_path)
    map1, map2, K = undistort_maps(sample.shape[:2], FR1_INTRINSICS)
    bgr = remap_rgb(load_rgb(pairs[0].rgb_path), map1, map2)
    z = remap_depth(load_depth(pairs[0].depth_path), map1, map2)

    zd = depth_valid(z)
    e_new = depth_discontinuity_mask(z, CFG["disc_rel"], valid=zd)
    e_old = edge_old(z, CFG["disc_rel"])

    normal_ref, _ = normals_from_depth(
        prefilter_depth(z, "gauss", int(CFG["gauss_sigma"]), valid=zd), K)
    tilt = np.degrees(np.arccos(np.clip(np.abs(normal_ref[..., 2]), 0, 1)))

    g, _ = build(bgr, z, K, False)
    depth, index, _ = rasterize_discs(g, K, z.shape)
    eval_mask = (
        zd & (z > CFG["z_min"]) & (z < CFG["z_max"])
        & ~depth_discontinuity_mask(z, CFG["disc_rel"], valid=zd)
    )
    hit = np.isfinite(depth) & eval_mask
    hole = eval_mask & ~hit

    def panel(rgb, title):
        return cv2.cvtColor(rgb, cv2.COLOR_BGR2RGB)

    # (a) raw depth
    za = z.copy()
    za[~zd] = np.nan
    d = np.nan_to_num(za, nan=np.nanmedian(za[zd]))
    dn = 255 * (d - d.min()) / (d.max() - d.min())
    dn = cv2.normalize(d, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    a = cv2.cvtColor(dn, cv2.COLOR_GRAY2BGR)

    # (b) valid
    b = np.zeros((*zd.shape, 3), np.uint8)
    b[zd] = (255, 255, 255)
    b[~zd] = (0, 0, 100)

    def edges_vis(e, base):
        vis = base.copy()
        vis[e] = (0, 255, 255)
        vis[~zd] = (100, 0, 100) if base is None else vis[~zd]
        return vis

    c = edges_vis(e_old, bgr.copy())
    d_p = edges_vis(e_new, bgr.copy())

    e = bgr.copy()
    e[hole] = (0, 0, 255)

    f = bgr.copy()
    for th, col in ((60, (0, 0, 255)), (45, (0, 128, 255)), (30, (0, 255, 255))):
        m = tilt > th
        f[m] = col
    f[~zd] = (100, 0, 100)

    titles = [
        "(a) raw depth", "(b) valid(z>0)",
        "(c) edge BEFORE", "(d) edge AFTER (refactor)",
        "(e) holes (fore OFF)", "(f) normal tilt field",
    ]
    tiles = [a, b, c, d_p, e, f]

    th, tw = 240, 320
    H = np.zeros((2 * (th + 24), 3 * (tw + 4), 3), np.uint8)
    for i, (t, img) in enumerate(zip(titles, tiles)):
        img = cv2.resize(img, (tw, th))
        img = cv2.copyMakeBorder(img, 22, 2, 2, 2, cv2.BORDER_CONSTANT, value=(30, 30, 30))
        cv2.putText(img, t, (6, 16), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1, cv2.LINE_AA)
        r, c0 = divmod(i, 3)
        H[r * (th + 24): (r + 1) * (th + 24),
          c0 * (tw + 4): (c0 + 1) * (tw + 4)] = img

    out = ROOT.parent / "output_G_refactor" / "mask_panel.png"
    cv2.imwrite(str(out), H)
    print("wrote", out)

    n_old = e_old.sum()
    n_new = e_new.sum()
    print(f"edge px before {n_old}  after {n_new}  ({100.0*n_new/n_old:.1f}%)")
    dv = (z > 0)
    print(f"edge px inside void: before {100.0*(e_old & ~dv).mean()/(e_old.mean()):.1f}%"
          f"  after {100.0*(e_new & ~dv).mean()/(e_new.mean()):.1f}%")


if __name__ == "__main__":
    main()
