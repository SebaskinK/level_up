"""Step 1: is the normal field biased by depth quantization?

Everything reported as "normal accuracy" so far was self-consistency -- the
disc's plane normal compared against the per-pixel normal field derived from the
same smoothed depth. Ground truth never entered the metric.

This is a controlled synthetic test where truth is exact by construction: render
a plane of known tilt, apply the depth quantization law measured on TUM
(dz = 0.0029 z^2), and measure the ANGULAR error of the recovered normal.

Hypothesis: quantization turns a smooth slope into a staircase.
  * on a tread   z_u = z_v = 0        -> normal reads [0,0,-1], |n_z| = 1
  * on a riser   the gradient is huge -> |n_z| ~ 0
So the distribution should be bimodal and |n_z| biased HIGH (toward face-on),
which is what the real data shows (median 0.700 where the fitted plane says
0.466). Pure noise would scatter, not bias, so a bias implicates the staircase.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from gaussian_build import normals_from_depth  # noqa: E402
from rgbd_io import FR1_INTRINSICS, camera_matrix  # noqa: E402

H, W = 480, 640
MARGIN = 60


def plane_depth(K: np.ndarray, tilt_deg: float, z_centre: float) -> tuple[np.ndarray, np.ndarray]:
    """Depth map of a plane tilted about the x axis, plus its true unit normal."""
    fx, fy, cx, cy = K[0, 0], K[1, 1], K[0, 2], K[1, 2]
    us, vs = np.meshgrid(
        np.arange(W, dtype=np.float64), np.arange(H, dtype=np.float64)
    )
    a = np.radians(tilt_deg)
    n = np.array([0.0, np.sin(a), -np.cos(a)])
    d = -z_centre * np.cos(a)
    z = d / (n[1] * (vs - cy) / fy + n[2])
    return z.astype(np.float32), n


def quantize(z: np.ndarray, coeff: float) -> np.ndarray:
    """Disparity-style quantization: uniform in 1/z, so dz grows as coeff*z^2."""
    if coeff <= 0:
        return z
    inv = 1.0 / np.maximum(z, 1e-6)
    return (1.0 / (np.round(inv / coeff) * coeff)).astype(np.float32)


def angular_error(n_est: np.ndarray, n_true: np.ndarray, mask: np.ndarray) -> np.ndarray:
    cos = np.clip(np.abs(n_est[mask] @ n_true), -1.0, 1.0)
    return np.degrees(np.arccos(cos))


def smooth(z: np.ndarray, mode: str, param: float) -> np.ndarray:
    if mode == "none":
        return z
    if mode == "gauss":
        return cv2.GaussianBlur(z, (0, 0), param)
    if mode == "bilateral":
        return cv2.bilateralFilter(z, int(param), 0.02, int(param))
    if mode == "median":
        return cv2.medianBlur(z, int(param) | 1)
    raise ValueError(mode)


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--quant", type=float, default=0.0029, help="TUM disparity law coefficient")
    p.add_argument("--z", type=float, default=2.0)
    p.add_argument("--tilts", type=float, nargs="+", default=[0, 15, 30, 45, 60, 75])
    args = p.parse_args()

    K = camera_matrix(FR1_INTRINSICS)
    m = np.zeros((H, W), bool)
    m[MARGIN:-MARGIN, MARGIN:-MARGIN] = True

    print("=" * 96)
    print("1. ANGULAR ERROR vs TILT   (clean plane, then TUM quantization applied)")
    print("=" * 96)
    print(f"{'tilt':>6}{'|nz| true':>11}{'clean err':>12}{'quant err':>12}"
          f"{'|nz| med':>10}{'bias':>9}{'p10 |nz|':>10}")
    for t in args.tilts:
        z, n_true = plane_depth(K, t, args.z)
        zq = quantize(z, args.quant)
        n_c, ok_c = normals_from_depth(z, K)
        n_q, ok_q = normals_from_depth(zq, K)
        e_c = angular_error(n_c, n_true, m & ok_c)
        e_q = angular_error(n_q, n_true, m & ok_q)
        nz = np.abs(n_q[..., 2])[m & ok_q]
        print(f"{t:>5.0f}°{abs(n_true[2]):>11.3f}{np.median(e_c):>11.2f}°"
              f"{np.median(e_q):>11.2f}°{np.median(nz):>10.3f}"
              f"{np.median(nz) - abs(n_true[2]):>+9.3f}{np.percentile(nz, 10):>10.3f}")

    print()
    print("=" * 96)
    print("2. IS THE DISTRIBUTION BIMODAL?  (tilt 45 deg, quantized)")
    print("=" * 96)
    z, n_true = plane_depth(K, 45.0, args.z)
    zq = quantize(z, args.quant)
    n_q, ok = normals_from_depth(zq, K)
    nz = np.abs(n_q[..., 2])[m & ok]
    hist, edges = np.histogram(nz, bins=10, range=(0, 1))
    for i in range(10):
        bar = "#" * int(60 * hist[i] / hist.max())
        print(f"  |n_z| {edges[i]:.1f}-{edges[i+1]:.1f} {hist[i]:>7d}  {bar}")
    print(f"  true |n_z| = {abs(n_true[2]):.3f}")
    print(f"  fraction within 0.05 of 1.0 (tread, i.e. gradient killed): "
          f"{100*(nz > 0.95).mean():.1f}%")
    print(f"  fraction below 0.2 (riser): {100*(nz < 0.2).mean():.1f}%")

    print()
    print("=" * 96)
    print("3. CAN SMOOTHING FIX IT?   (tilt 45 deg, quantized, angular error)")
    print("=" * 96)
    print(f"{'smoothing':<20}{'median err':>12}{'p90 err':>10}{'|nz| med':>10}{'bias':>9}")
    for mode, param in (
        ("none", 0), ("gauss", 1), ("gauss", 2), ("gauss", 3), ("gauss", 5),
        ("gauss", 8), ("bilateral", 5), ("bilateral", 9), ("median", 5),
    ):
        zs = smooth(zq, mode, param)
        n_s, ok_s = normals_from_depth(zs, K)
        e = angular_error(n_s, n_true, m & ok_s)
        nz = np.abs(n_s[..., 2])[m & ok_s]
        tag = mode if param == 0 else f"{mode} {param:g}"
        print(f"{tag:<20}{np.median(e):>11.2f}°{np.percentile(e, 90):>9.2f}°"
              f"{np.median(nz):>10.3f}{np.median(nz) - abs(n_true[2]):>+9.3f}")

    print()
    print("=" * 96)
    print("4. HOW MUCH QUANTIZATION IS TOLERABLE?  (tilt 45, gauss sigma=3)")
    print("=" * 96)
    print(f"{'coeff':>10}{'step@2m':>10}{'median err':>12}{'bias':>9}")
    for c in (0.0, 0.0002, 0.0005, 0.001, 0.0029, 0.006):
        zq2 = quantize(z, c)
        zs = cv2.GaussianBlur(zq2, (0, 0), 3)
        n_s, ok_s = normals_from_depth(zs, K)
        e = angular_error(n_s, n_true, m & ok_s)
        nz = np.abs(n_s[..., 2])[m & ok_s]
        print(f"{c:>10.4f}{c*4*1000:>9.1f}mm{np.median(e):>11.2f}°"
              f"{np.median(nz) - abs(n_true[2]):>+9.3f}")
    print()
    print("pixel footprint z/f at 2 m = %.2f mm (for comparison with the step)"
          % (2.0 / 517 * 1000))


if __name__ == "__main__":
    main()


def ransac_plane(
    z: np.ndarray, K: np.ndarray, box, tol_m: float, iters: int = 200, seed: int = 0
):
    """RANSAC plane over an image box, in inverse-depth (affine) coordinates.

    Least squares over a hand-picked rectangle was the earlier mistake: no
    residual check, so a box straddling a table edge silently returned the
    compromise between two surfaces and that fake plane became the "truth".
    RANSAC plus an explicit residual report makes the failure visible.

    Returns (normal, inlier_fraction, residual_rms_m, n_points) or None.
    """
    fx, fy, cx, cy = K[0, 0], K[1, 1], K[0, 2], K[1, 2]
    ys, xs = box
    Y, X = np.mgrid[ys, xs]
    zz = z[ys, xs].astype(np.float64)
    m = (zz > 0.3) & (zz < 5.0) & np.isfinite(zz)
    if m.sum() < 100:
        return None
    U = ((X - cx) / fx)[m]
    V = ((Y - cy) / fy)[m]
    W = 1.0 / zz[m]
    zc = np.median(zz[m])
    # Convert the metric tolerance to inverse depth: d(1/z) = dz / z^2.
    tol_inv = tol_m / (zc * zc)

    rng = np.random.default_rng(seed)
    n = U.size
    best_in = None
    best_cnt = 0
    A_all = np.stack([U, V, np.ones(n)], axis=1)
    for _ in range(iters):
        idx = rng.choice(n, 3, replace=False)
        try:
            coef = np.linalg.solve(A_all[idx], W[idx])
        except np.linalg.LinAlgError:
            continue
        inl = np.abs(A_all @ coef - W) < tol_inv
        c = int(inl.sum())
        if c > best_cnt:
            best_cnt, best_in = c, inl
    if best_in is None or best_cnt < 50:
        return None

    coef, *_ = np.linalg.lstsq(A_all[best_in], W[best_in], rcond=None)
    resid_inv = A_all[best_in] @ coef - W[best_in]
    resid_m = float(np.sqrt(np.mean(resid_inv**2)) * zc * zc)
    nv = np.asarray(coef, dtype=np.float64)
    nv /= max(np.linalg.norm(nv), 1e-12)
    if nv[2] > 0:
        nv = -nv
    return nv, best_cnt / n, resid_m, n


def find_planar_blocks(
    z: np.ndarray, K: np.ndarray, size: int = 48, stride: int = 24,
    min_inlier: float = 0.85, quant_coeff: float = 0.00291, seed: int = 0,
):
    """Sweep the frame for blocks that really are a single plane.

    Hand-picking blocks was how the earlier "truth" went wrong: a rectangle
    across a table edge fits a plane through two surfaces and reports a normal
    that belongs to neither. Accept a block only when RANSAC finds a high inlier
    fraction AND the residual stays under the local quantization step, so the
    plane is not being asked to explain more than the sensor can resolve.

    Returns a list of (box, normal, inlier_frac, residual_m, z_med).
    """
    h, w = z.shape
    out = []
    for y0 in range(0, h - size + 1, stride):
        for x0 in range(0, w - size + 1, stride):
            box = (slice(y0, y0 + size), slice(x0, x0 + size))
            zz = z[box]
            m = (zz > 0.3) & (zz < 5.0) & np.isfinite(zz)
            if m.mean() < 0.9:
                continue
            zc = float(np.median(zz[m]))
            r = ransac_plane(z, K, box, tol_m=4.0 * quant_coeff * zc * zc, seed=seed)
            if r is None:
                continue
            nv, inl, res, _ = r
            if inl >= min_inlier and res < quant_coeff * zc * zc:
                out.append((box, nv, inl, res, zc))
    return out
