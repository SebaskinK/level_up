"""Deep-dive on the left-edge newborns that fail the CO-PLANAR gate only.

Question: of the left-edge "residual" stacking candidates (neither relink nor
absorb can claim them), the plane-only-fail group is ~56%. Are these genuinely a
different surface (real non-coplanarity -> correct reject), or are they the same
surface just pushed over the plane budget (threshold over-fire)?

Reports, for the plane-only-fail group (passes radius, fails plane):
  - point-plane distance vs budget: absolute dist, budget, ratio dist/budget
  - normal angle vs old disc (diagnostic only, not a pipeline gate)
  - tangential offset vs old disc footprint radius
  - depth z of the newborn, birth frame histogram
  - projected (u, v) mean/spread (are they hugging the FOV left border?)
  - colour distance vs old disc

Also splits the plane-fail group into bands by dist/budget ratio to see how much
of it is "just barely over" (1.0-1.5x) vs "way over" (>=2x).

Usage:
    python diag_plane_fail.py <output_dir>
"""
from __future__ import annotations

import sys
from pathlib import Path

import cv2
import numpy as np
from scipy.spatial import cKDTree

SEQ = Path(__file__).resolve().parent
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
SINGLE = SEQ.parent.parent / "SINGLE FRAME" / "scripts"
sys.path.insert(0, str(SFLOW))
sys.path.insert(0, str(SINGLE))
sys.path.insert(0, str(SEQ))

import h_pipeline_final as H                # noqa: E402
import sequential_fusion_flowonly as SF     # noqa: E402

K_SIGMA = SF.K_SIGMA
FX, FY, CX, CY = 517.306408, 516.469215, 318.643040, 255.313989


def depth_sigma(z: np.ndarray, sigma_ref: float = 0.0031, z_ref: float = 0.75):
    return sigma_ref * (np.maximum(z, 0.3) / z_ref) ** 1.33


def pct(a, p):
    return float(np.percentile(a, p)) if a.size else float("nan")


def main() -> None:
    out = Path(sys.argv[1])
    left_u = 80.0

    d = np.load(out / "model_f0.npz")
    mu = d["mu"].astype(np.float64)
    normal = d["normal"].astype(np.float64)
    color = d["color"].astype(np.float64)
    birth = d["birth"].astype(np.int32)
    scale = d["scale"].astype(np.float64)

    n = normal / np.maximum(np.linalg.norm(normal, axis=1, keepdims=True), 1e-12)
    zc = mu[:, 2]
    u = FX * mu[:, 0] / np.maximum(zc, 1e-6) + CX
    v = FY * mu[:, 1] / np.maximum(zc, 1e-6) + CY

    # real frame-0 per-pixel texture std (for the accurate colour budget)
    pairs = SF.associate(SF.DATA, max_dt=0.02)
    sample = SF.load_rgb(pairs[0].rgb_path)
    h0, w0 = sample.shape[:2]
    map1, map2, K = SF.undistort_maps((h0, w0), SF.FR1_INTRINSICS)
    bgr0, z0, _ = SF.load_pair(pairs, 0, map1, map2)
    rgb0 = bgr0[..., ::-1].astype(np.float32) / 255.0
    sigma0 = np.sqrt(np.maximum(H.texture_variance(rgb0, win=9), H.TEX_VAR_THR))

    old = birth == 0
    new = birth > 0
    left_new = new & (u < left_u)
    print(f"N={len(mu)}  old={int(old.sum())}  new={int(new.sum())}  "
          f"left-edge new (u<{left_u:g})={int(left_new.sum())}")

    kk = 24
    lnew_idx = np.flatnonzero(left_new)
    birth_l = birth[left_new]
    tree = cKDTree(mu)
    d3k, jk = tree.query(mu[lnew_idx], k=kk)
    d3 = np.full(lnew_idx.shape[0], np.inf)
    j = np.full(lnew_idx.shape[0], -1, dtype=np.int64)
    for kk_i in range(kk):
        nn = jk[:, kk_i]
        is_earlier = birth[nn] < birth_l
        take = is_earlier & (d3k[:, kk_i] < d3)
        d3[take] = d3k[take, kk_i]
        j[take] = nn[take]
    has_older = j >= 0

    jc = np.where(has_older, j, 0)
    mu_o = mu[jc]
    n_o = n[jc]
    c_o = color[jc]
    mu_n = mu[lnew_idx]
    n_n = n[lnew_idx]
    c_n = color[lnew_idx]
    birth_n = birth_l

    plane = np.abs(np.einsum("ij,ij->i", mu_n - mu_o, n_o))
    off = mu_n - mu_o
    off_t = off - np.einsum("ij,ij->i", off, n_o)[:, None] * n_o
    tan = np.linalg.norm(off_t, axis=1)
    dot = np.clip(np.abs(np.einsum("ij,ij->i", n_n, n_o)), 0.0, 1.0)
    ang = np.degrees(np.arccos(dot))
    dcol = np.linalg.norm(c_n - c_o, axis=1)
    r_o = np.maximum(scale[jc, 0], scale[jc, 1])
    z_o = mu_o[:, 2]
    gate_p = K_SIGMA * depth_sigma(z_o)

    plane_pass = plane < gate_p
    norm_pass = ang < 30.0
    radius_pass = tan <= r_o

    ov = has_older & (d3 < 0.05)
    print(f"OVERLAP (older nbr & 3D<5cm): {int(ov.sum())}/{int(left_new.sum())} "
          f"({100*ov.mean():.1f}%)")

    p_ov = plane_pass[ov]
    r_ov = radius_pass[ov]
    res = ov.copy()
    res[ov] = ~p_ov & r_ov          # plane-only fail group: passes radius, fails plane

    m = res
    if not m.any():
        print("no plane-only-fail discs found")
        return

    ratio = plane[m] / gate_p[m]
    print("\n=== plane-only-fail group (passes radius, FAILS plane) ===")
    print(f"  n = {int(m.sum())}")
    print(f"  point-plane dist  med={np.median(plane[m]):.5f}  p75={pct(plane[m],75):.5f} "
          f"p90={pct(plane[m],90):.5f}  max={plane[m].max():.5f}")
    print(f"  plane budget      med={np.median(gate_p[m]):.5f}  p75={pct(gate_p[m],75):.5f}")
    print(f"  dist/budget ratio med={np.median(ratio):.2f}  p75={pct(ratio,75):.2f} "
          f"p90={pct(ratio,90):.2f}  max={ratio.max():.2f}")

    bands = [("1.0-1.5x", (1.0, 1.5)), ("1.5-2x", (1.5, 2.0)),
             ("2-4x", (2.0, 4.0)), (">=4x", (4.0, np.inf))]
    print("  ratio bands:")
    for tag, (lo, hi) in bands:
        b = (ratio >= lo) & (ratio < hi)
        print(f"    {tag:8s} {int(b.sum()):6d} ({100*b.mean():.1f}%)")

    print(f"  normal angle      med={np.median(ang[m]):.2f} deg  p75={pct(ang[m],75):.2f} "
          f"p90={pct(ang[m],90):.2f}")
    print(f"  normal<30deg frac = {100*norm_pass[m].mean():.1f}%")
    print(f"  tangent offset    med={np.median(tan[m]):.4f}  vs foot.radius med={np.median(r_o[m]):.4f}")
    print(f"  new disc depth z  med={np.median(mu_n[m,2]):.3f} p25={pct(mu_n[m,2],25):.3f} "
          f"p75={pct(mu_n[m,2],75):.3f}")
    print(f"  colour dist       med={np.median(dcol[m]):.4f} p75={pct(dcol[m],75):.4f} p90={pct(dcol[m],90):.4f}")
    print(f"  projected u       med={np.median(u[lnew_idx[m]]):.1f} p10={pct(u[lnew_idx[m]],10):.1f} "
          f"p90={pct(u[lnew_idx[m]],90):.1f}   (FOV left border u=0)")
    print(f"  projected v       med={np.median(v[lnew_idx[m]]):.1f} p10={pct(v[lnew_idx[m]],10):.1f} "
          f"p90={pct(v[lnew_idx[m]],90):.1f}")
    print(f"  birth-frame hist (10-frame bins): "
          f"{np.bincount(np.clip(birth_n[m] // 10, 0, 9), minlength=10).tolist()}")

    # ---- full residual, split by gate-fail combo AND by visibility in frame 0 ----
    # residual = fails BOTH relink (plane&colour) and absorb (plane&radius&colour),
    # colour budget = sqrt((K*sigma_tex)^2 + light^2) with K=6 and the REAL frame-0
    # 9x9 texture std at the OLD disc's projected pixel.
    up_o = np.clip(np.rint(u[jc]).astype(np.int32), 0, w0 - 1)
    vp_o = np.clip(np.rint(v[jc]).astype(np.int32), 0, h0 - 1)
    sig_real = sigma0[vp_o, up_o]
    cbudget = np.sqrt((6.0 * sig_real) ** 2 + SF.COLOR_LIGHT_MAX ** 2)
    cpass = dcol <= cbudget
    relink_acc = plane_pass & cpass
    absorb_acc = plane_pass & radius_pass & cpass
    res_all = ov & ~relink_acc & ~absorb_acc
    fp = res_all & ~plane_pass          # plane fail (either radius)
    fr = res_all & plane_pass & ~radius_pass          # plane pass, radius fail
    fc = res_all & plane_pass & radius_pass           # plane & radius pass, colour fail
    un = u[lnew_idx]
    on_screen = (un >= 0.0) & (un < left_u)
    print("\n=== residual (fails relink AND absorb) split by gate AND frame-0 visibility ===")
    print(f"  total residual = {int(res_all.sum())}")
    for tag, grp in [("plane-fail (any radius)", fp),
                     ("radius-only", fr),
                     ("colour-only", fc)]:
        g = grp
        off = g & ~on_screen
        onv = g & on_screen
        print(f"  {tag:22s} n={int(g.sum()):5d}  off-frame(u<0)={int(off.sum()):5d} "
              f"({100*off.sum()/max(g.sum(),1):.0f}%)  visible(0<=u<80)={int(onv.sum()):5d} "
              f"({100*onv.sum()/max(g.sum(),1):.0f}%)")
        if g.any():
            print(f"       u med={np.median(un[g]):.1f} p10={pct(un[g],10):.1f} p90={pct(un[g],90):.1f}  "
                  f"plane/dbudget med={np.median(plane[g]/gate_p[g]):.2f}  "
                  f"normal med={np.median(ang[g]):.1f}deg")

    # ---- K_SIGMA retune read-out: is the plane over-fire "same-surface & barely
    # over" (=> raise K_SIGMA cleanly) or "rotated / way over" (=> do NOT loosen)? ----
    pf = fp  # plane-fail group (fails plane, any radius)
    if pf.any():
        ratio_pf = plane[pf] / gate_p[pf]
        coplanar = ang[pf] < 30.0
        barely = (ratio_pf >= 1.0) & (ratio_pf < 2.0)
        far = ratio_pf >= 2.0
        print("\n=== K_SIGMA retune read-out (plane-fail group) ===")
        print(f"  n_plane_fail = {int(pf.sum())}")
        print(f"  coplanar(<30deg) & barely(1-2x)  -> fixable by raising K_SIGMA : "
              f"{int((coplanar & barely).sum())} ({100*(coplanar&barely).mean():.1f}%)")
        print(f"  coplanar & far(>=2x)             -> planar but large gap (curvature?) : "
              f"{int((coplanar & far).sum())} ({100*(coplanar&far).mean():.1f}%)")
        print(f"  rotated(>=30deg) any ratio       -> different surface, keep rejecting: "
              f"{int((~coplanar).sum())} ({100*(~coplanar).mean():.1f}%)")
        # what K_SIGMA value would admit each percentile of the coplanar subset's ratio
        rc = ratio_pf[coplanar]
        for q in (50, 75, 90):
            print(f"    K_SIGMA to admit coplanar p{q}: {3.0 * pct(rc, q):.2f}")


# ---- colour-gate read-out: the visible colour-only discs vs their budget ----
    # budget = sqrt((K*sigma_tex)^2 + light^2), K=6, light capped. sigma_tex is the
    # REAL frame-0 9x9 texture std at the OLD disc's projected pixel (not the floor).
    if fc.any():
        up_o = np.clip(np.rint(u[jc]).astype(np.int32), 0, w0 - 1)
        vp_o = np.clip(np.rint(v[jc]).astype(np.int32), 0, h0 - 1)
        sig_real = sigma0[vp_o, up_o]
        Kc = 6.0
        light_cap = SF.COLOR_LIGHT_MAX
        bud = np.sqrt((Kc * sig_real) ** 2 + light_cap ** 2)     # full-length budget
        dcol_fc = dcol[fc]
        bud_fc = bud[fc]
        print("\n=== colour-only fail group: disc-colour dist vs colour budget (K=6, real sigma) ===")
        print(f"  n = {int(fc.sum())}   (visible 0<=u<80: {int((fc & on_screen).sum())})")
        print(f"  budget (K=6, real sigma) med={np.median(bud_fc):.4f} p25={pct(bud_fc,25):.4f} "
              f"p75={pct(bud_fc,75):.4f}")
        print(f"  dcol med={np.median(dcol_fc):.4f} p75={pct(dcol_fc,75):.4f} "
              f"p90={pct(dcol_fc,90):.4f} max={dcol_fc.max():.4f}")
        r = dcol_fc / bud_fc
        for tag, (lo, hi) in [("<1x", (-np.inf, 1.0)), ("1-1.5x", (1.0, 1.5)),
                              ("1.5-2x", (1.5, 2.0)), (">=2x", (2.0, np.inf))]:
            b = (r >= lo) & (r < hi)
            print(f"    {tag:8s} {int(b.sum()):5d} ({100*b.mean():.1f}%)")


if __name__ == "__main__":
    main()