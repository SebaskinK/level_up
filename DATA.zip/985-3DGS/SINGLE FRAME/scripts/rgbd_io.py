"""TUM RGB-D loading. Minimal subset needed for single-frame experiments.

The target sensor delivers depth natively per RGB pixel; TUM does not, so the
association step here is a stand-in for what the sensor gives for free.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np

FR1_INTRINSICS = dict(
    fx=517.306408,
    fy=516.469215,
    cx=318.643040,
    cy=255.313989,
    k1=0.262383,
    k2=-0.953104,
    p1=-0.005358,
    p2=0.002628,
    k3=1.163314,
)

DEPTH_SCALE = 5000.0


@dataclass
class Frame:
    t_rgb: float
    t_depth: float
    rgb_path: Path
    depth_path: Path


def camera_matrix(intr: dict) -> np.ndarray:
    return np.array(
        [[intr["fx"], 0.0, intr["cx"]], [0.0, intr["fy"], intr["cy"]], [0.0, 0.0, 1.0]]
    )


def _read_index(path: Path) -> list[tuple[float, str]]:
    out = []
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        ts, rel = line.split()
        out.append((float(ts), rel))
    return out


def associate(data_dir: Path, max_dt: float = 0.02) -> list[Frame]:
    rgb = _read_index(data_dir / "rgb.txt")
    depth = _read_index(data_dir / "depth.txt")
    d_ts = np.array([t for t, _ in depth])
    used = set()
    pairs = []
    for t, rel in rgb:
        j = int(np.argmin(np.abs(d_ts - t)))
        if j in used or abs(d_ts[j] - t) > max_dt:
            continue
        used.add(j)
        pairs.append(Frame(t, float(d_ts[j]), data_dir / rel, data_dir / depth[j][1]))
    return pairs


def load_rgb(path: Path) -> np.ndarray:
    img = cv2.imread(str(path), cv2.IMREAD_COLOR)
    if img is None:
        raise FileNotFoundError(path)
    return img


def load_depth(path: Path) -> np.ndarray:
    raw = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)
    if raw is None:
        raise FileNotFoundError(path)
    return raw.astype(np.float32) / DEPTH_SCALE


def undistort_maps(shape: tuple[int, int], intr: dict):
    h, w = shape
    K = camera_matrix(intr)
    dist = np.array([intr["k1"], intr["k2"], intr["p1"], intr["p2"], intr["k3"]])
    K_new, _ = cv2.getOptimalNewCameraMatrix(K, dist, (w, h), 0.0, (w, h))
    map1, map2 = cv2.initUndistortRectifyMap(K, dist, None, K_new, (w, h), cv2.CV_32FC1)
    return map1, map2, K_new


def remap_rgb(img: np.ndarray, map1, map2) -> np.ndarray:
    return cv2.remap(img, map1, map2, cv2.INTER_LINEAR)


def remap_depth(z: np.ndarray, map1, map2) -> np.ndarray:
    return cv2.remap(z, map1, map2, cv2.INTER_NEAREST)
