"""Attribute the 80-frame model's frame-0 "dirty" area to newborn discs.

Runs the same 80-frame fusion (aging off), records every disc's birth frame +
source (S2/curvature), transforms the final model back to frame-0, rasterizes it
onto frame-0, then for every pixel fronted by a NEWBORN disc (source>=0, i.e. a
disc added after frame 0) reports the AREA (pixel count) broken down by birth
frame and by source. Area, not disc count -- a few huge void-spilling discs can
dominate far more pixels than many small ones.

Also renders a frame-0 "newborn-front" mask map (colour-coded by birth-decade).
"""

from __future__ import annotations

import time
from pathlib import Path

import cv2
import numpy as np

import h_pipeline_final as H
import sequential_fusion_flowonly as SF


def pm_compose(a, b):
    Ra, ta = a
    Rb, tb = b
    return Rb @ Ra, Rb @ ta + tb


def pm_inv(a):
    R, t = a
    return R.T, -R.T @ t


def concat(lst):
    return np.concatenate(lst, axis=0)


def main() -> None:
    OUT = SF.SEQ.parent / "output_newborn_area_tex4e4"
    OUT.mkdir(parents=True, exist_ok=True)

    NPAIR = 81
    AGE_MAX = 1000000
    W_MIN = 0.0

    pairs = SF.associate(SF.DATA, max_dt=0.02)[:NPAIR]
    sample = SF.load_rgb(pairs[0].rgb_path)
    h, w = sample.shape[:2]
    map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)

    print("building frame-0 model ...", flush=True)
    bgr0, z0, _ = SF.load_pair(pairs, 0, map1, map2)
    g0, _, _, owner0 = H.build_hybrid_with_owner(bgr0, z0, K, SF.TEX_Q)
    n_init = len(g0)
    print(f"n_init={n_init}  TEX_VAR_THR={H.TEX_VAR_THR:g}", flush=True)

    src_l = [np.full(n_init, -1, dtype=np.int8)]
    bir_l = [np.zeros(n_init, dtype=np.int32)]

    model = SF.Model(
        g=g0,
        w=np.ones(n_init, dtype=np.float32),
        age=np.zeros(n_init, dtype=np.int32),
        owner=owner0,
        birth=np.zeros(n_init, dtype=np.int32),
    )
    FL = [None] * NPAIR
    FL[0] = (np.eye(3), np.zeros(3))
    prev_FL = FL[0]
    prev_sf, prev_dt = None, 1.0
    bgr_a, z_a = bgr0, z0

    t0 = time.perf_counter()
    for i in range(NPAIR - 1):
        bgr_b, z_b, _ = SF.load_pair(pairs, i + 1, map1, map2)
        dt = pairs[i + 1].t_rgb - pairs[i].t_rgb
        sf = SF.compute_scene_flow(bgr_a, bgr_b, z_a, z_b, K,
                                   prev=prev_sf, dt=dt, prev_dt=prev_dt)
        R_10, t_10 = SF.se3_exp(sf.xi)
        FL[i + 1] = pm_compose(prev_FL, (R_10, t_10))

        n_before = len(model.g)
        rec = SF.fuse_frame(model, sf, z_a, z_b, bgr_b, K,
                            age_max=AGE_MAX, w_min=W_MIN, frame_idx=i,
                            R_10=R_10, t_10=t_10)
        n_new = rec["n_new"]
        if n_new:
            src_l.append(np.concatenate([
                np.zeros(rec["n_s2"], dtype=np.int8),
                np.ones(rec["n_curv"], dtype=np.int8),
            ]))
            bir_l.append(np.full(n_new, i, dtype=np.int32))
        if (i + 1) % 10 == 0:
            print(f"[{i+1:03d}] N={len(model.g)} cum={time.perf_counter()-t0:.1f}s", flush=True)
        bgr_a, z_a = bgr_b, z_b
        prev_sf, prev_dt = sf, dt
        prev_FL = FL[i + 1]

    g = model.g
    print(f"final N={len(g)}  -> frame 0 ...", flush=True)
    g0f = SF.transform_to_next(g, *pm_inv(FL[NPAIR - 1]))
    if g0f.axis1 is None or g0f.axis2 is None:
        raise RuntimeError("final model lacks axis1/axis2")
    source = concat(src_l)
    birth = concat(bir_l)
    assert len(source) == len(birth) == len(g)

    print("rasterizing 80-frame model onto frame 0 ...", flush=True)
    depth80, index80, _ = H.rasterize_discs(g0f, K, (h, w))
    hit = np.isfinite(depth80)

    front_birth = birth[index80[hit]]
    front_source = source[index80[hit]]
    newborn = front_source >= 0            # disc added after frame 0
    n_new_px = int(newborn.sum())

    print("=" * 72)
    print(f"frame-0 valid pixels            = {int(hit.sum())}")
    print(f"fronted by NEWBORN discs (area) = {n_new_px}  ({100*n_new_px/max(1,hit.sum()):.2f}%)")
    # area by source
    for lbl, sval in [("S2", 0), ("curv", 1)]:
        sel = newborn & (front_source == sval)
        print(f"  {lbl:>4}: area={int(sel.sum())}  ({100*sel.sum()/max(1,n_new_px):.1f}% of newborn)")
    # area by birth decade
    bnew = front_birth[newborn]
    bins = np.arange(0, 81, 10)
    hist, edges = np.histogram(bnew, bins=bins)
    print("  newborn area by birth frame (10-frame bins):")
    for k in range(len(hist)):
        print(f"    {int(edges[k]):3d}-{int(edges[k+1]-1):3d}: {hist[k]:7d} px  ({100*hist[k]/max(1,n_new_px):5.1f}%)")
    # area by source per decade
    print("  curv-area by birth frame:")
    for k in range(len(hist)):
        sel = newborn & (front_source == 1) & (front_birth >= edges[k]) & (front_birth < edges[k+1])
        if hist[k]:
            print(f"    {int(edges[k]):3d}-{int(edges[k+1]-1):3d}: curv={int(sel.sum()):6d}  s2={hist[k]-int(sel.sum()):6d}")

    # unique newborn discs that front any pixel, and their total fronted area top-20
    print("=" * 72)
    disc_of_px = index80[hit][newborn]     # global index of each newborn-fronted pixel
    area_by_disc = np.bincount(disc_of_px)
    nfront_discs = int((area_by_disc > 0).sum())
    print(f"unique newborn discs fronting frame-0 = {nfront_discs}")
    order = np.argsort(area_by_disc)[::-1]
    print("  top-15 discs by fronted area (global_idx, area_px, source, birth):")
    shown = 0
    for gi in order:
        a = area_by_disc[gi]
        if a == 0:
            break
        print(f"    idx={gi:7d}  area={a:6d}px  src={source[gi]}  birth={birth[gi]}")
        shown += 1
        if shown >= 15:
            break

    # save colour-coded newborn-front map (by birth decade)
    map_img = np.zeros((h, w, 3), np.uint8)
    decades = np.clip(front_birth // 10, 0, 7)
    hud = {0:(0,0,255),1:(0,100,255),2:(0,180,255),3:(0,255,200),
           4:(0,255,80),5:(120,255,0),6:(220,255,0),7:(255,180,0)}
    ys, xs = np.where(hit)
    for d, col in hud.items():
        ms = newborn & (decades == d)
        if ms.any():
            map_img[ys[ms], xs[ms]] = col
    map_img = cv2.addWeighted(bgr0, 0.35, map_img, 0.65, 0)
    cv2.putText(map_img, f"newborn-front area: {n_new_px}px ({100*n_new_px/max(1,hit.sum()):.1f}%)  colour=birth decade",
                (8, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1, cv2.LINE_AA)
    cv2.imwrite(str(OUT / "f0_newborn_area_map.png"), map_img)
    print("wrote f0_newborn_area_map.png", flush=True)
    print("done", flush=True)


if __name__ == "__main__":
    main()