"""Analytic construction of 3D Gaussians from a single RGB-D frame.

No gradient descent. Every attribute is a closed-form function of depth,
its image gradients, and the intrinsics:

  position  : backprojection
  normal    : cross product of the two analytic surface tangents
  scale     : ElasticFusion surfel footprint, sqrt(2) * z / f
  opacity   : fixed (RTG-SLAM uses 0.99 for surface Gaussians, lr_alpha = 0)
  colour    : SH DC term, exactly invertible from RGB

See RESEARCH.md sections 1 and 2 for derivations and known limits.
"""

from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np

from curvature import curvature_radii, scale_space_curvature  # noqa: E402

SH_C0 = 0.28209479177387814
OPAQUE_ALPHA = 0.99
THIN_AXIS_RATIO = 0.1


@dataclass
class Gaussians:
    mu: np.ndarray  # (N, 3) centres, camera frame
    normal: np.ndarray  # (N, 3) unit normals = shortest axis
    scale: np.ndarray  # (N, 3) [r1, r2, thin]
    quat: np.ndarray  # (N, 4) wxyz, shortest axis aligned to normal
    color: np.ndarray  # (N, 3) linear RGB in [0, 1]
    alpha: np.ndarray  # (N,)
    pixel: np.ndarray  # (N, 2) source pixel (u, v), for diagnostics
    axis1: np.ndarray | None = None  # (N, 3) in-plane axis for scale[:, 0]
    axis2: np.ndarray | None = None  # (N, 3) in-plane axis for scale[:, 1]

    def __len__(self) -> int:
        return self.mu.shape[0]


@dataclass
class CurvatureGeometry:
    """The per-pixel geometric quantities shared by coverage sampling and emission.

    Both curvature_mask (seed spacing) and build_gaussians_curvature (disc
    emission) need the same smoothed depth, normal, and principal curvatures.
    Computing them once and passing the result around halves the most expensive
    work in the pipeline (the win x win quadric fit and the disc-inlier normal
    loop), and guarantees the claim radius and the emitted radius come from the
    same numbers.
    """
    z_grad: np.ndarray
    normal: np.ndarray  # (H, W, 3) unit normals, camera-facing
    n_ok: np.ndarray
    k1: np.ndarray
    k2: np.ndarray
    t1: np.ndarray  # (H, W, 3) principal tangent (thinnest disc direction)
    c_ok: np.ndarray
    dir_img: np.ndarray  # (H, W, 2) principal direction in image space
    r_k1: np.ndarray  # sqrt(2 eps / |k1|), short (thin) axis radius
    r_k2: np.ndarray  # long axis radius
    r_fp: np.ndarray  # surfel footprint radius
    r_edge: np.ndarray  # edge_distance_limit radius
    disc_mask: np.ndarray  # depth_discontinuity_mask, shared by every valid gate
    valid_depth: np.ndarray


def backproject(z: np.ndarray, K: np.ndarray) -> np.ndarray:
    h, w = z.shape
    fx, fy, cx, cy = K[0, 0], K[1, 1], K[0, 2], K[1, 2]
    xs, ys = np.meshgrid(np.arange(w, dtype=np.float32), np.arange(h, dtype=np.float32))
    return np.stack([(xs - cx) * z / fx, (ys - cy) * z / fy, z], axis=-1)


def depth_valid(z: np.ndarray) -> np.ndarray:
    """Measured depth: z > 0. Single source of truth for "valid reading".

    TUM reports 0 where the IR projector is shadowed; a real natively-per-pixel
    RGB-D sensor would have no such stripes, but the definition is the same.
    Every consumer that must not treat a void as a measurement reads it from here
    (masked_gauss, depth_discontinuity_mask, edge_distance_limit) rather than
    re-deriving validity with its own convention.
    """
    return z > 0


def masked_gauss(
    z: np.ndarray, sigma: float, valid: np.ndarray | None = None, floor: float = 0.05,
) -> np.ndarray:
    """Gaussian smoothing that never averages an invalid reading into a valid one.

    TUM depth carries wide invalid stripes (z = 0) in the IR projector's shadow:
    12.9% of frame 0, median stripe width 9 px and p75 37 px. A plain
    GaussianBlur treats those zeros as depth measurements, so a valid pixel next
    to a stripe gets pulled toward zero -- measured median shift 377 mm at 0-2 px
    from the stripe, 166 mm at 2-4 px, 50 mm at 4-6 px. That fabricates an
    enormous depth gradient, and hence tilt: 99% of pixels within 4 px of a
    stripe read a surface tilt above 60 deg. Frame-wide, 17.1% of valid pixels
    reported >60 deg tilt where only 10.7% do once the zeros are excluded.

    Normalized convolution fixes it: blur z*m and m separately and divide, so the
    result is the Gaussian-weighted mean over the VALID neighbours only. Still
    linear in the valid region, so d(G*z) = (dG)*z still holds there and the
    normal and the curvature keep describing one and the same surface.

    Inside a stripe the weight vanishes, so the value is taken from progressively
    wider kernels. Leaving zeros there would just move the same fake step a few
    pixels out, where the 3x3 Sobel and the 9x9 quadric stencil would find it
    again. Those pixels are rejected downstream by z > z_min on the RAW depth, so
    the extrapolated value only ever acts as a smooth boundary condition.
    """
    if valid is None:
        valid = depth_valid(z)
    m = valid.astype(np.float32)
    zm = (z * m).astype(np.float32)
    num = cv2.GaussianBlur(zm, (0, 0), sigma)
    den = cv2.GaussianBlur(m, (0, 0), sigma)
    out = num / np.maximum(den, 1e-9)
    bad = den < floor
    if bad.any():
        s = sigma
        for _ in range(5):
            s *= 2.0
            n2 = cv2.GaussianBlur(zm, (0, 0), s)
            d2 = cv2.GaussianBlur(m, (0, 0), s)
            ok = d2 >= floor
            fill = bad & ok
            if fill.any():
                out[fill] = (n2 / np.maximum(d2, 1e-9))[fill]
            bad &= ~ok
            if not bad.any():
                break
        if bad.any():
            out[bad] = float(np.median(z[m > 0])) if m.any() else 0.0
    return out.astype(np.float32)


def masked_gauss_fast(
    z: np.ndarray, sigma: float, valid: np.ndarray | None = None, floor: float = 0.05,
) -> np.ndarray:
    """`masked_gauss`'s normalized convolution with the wide-kernel fallback run
    on a half-res pyramid instead of full resolution.

    The fallback loop in `masked_gauss` only touches pixels whose RAW depth is
    invalid (z = 0, inside an IR-shadow stripe): the first-pass mask blur already
    keeps den >= floor for every raw-valid pixel, so `out` here is bit-identical
    to `masked_gauss` on every raw-valid pixel (verified: max diff = 0.0). The
    discarded interior values act only as boundary conditions for the local
    Sobel/quadric stencils, and the ~few-1/m curvature they induce never flips a
    keep decision: on fr1/desk frame 0 the emitted primitive set and the rendered
    RGB are pixel-identical (array_equal == True), N/RMSE/PSNR/hole unchanged.

    Each half-res step approximates the next doubled sigma: a Gaussian is a
    low-pass, so area-downsampling then a fixed sigma=3 blur is the same operator
    to within the pyramid's interpolation error, at a fraction of a wide kernel's
    cost. That error is exactly why this is a *fast* variant rather than a drop-in
    replacement of `masked_gauss`.
    """
    if valid is None:
        valid = depth_valid(z)
    m = valid.astype(np.float32)
    zm = (z * m).astype(np.float32)
    num = cv2.GaussianBlur(zm, (0, 0), sigma)
    den = cv2.GaussianBlur(m, (0, 0), sigma)
    out = num / np.maximum(den, 1e-9)
    bad = den < floor
    if bad.any():
        shape = (z.shape[1], z.shape[0])
        zc, mc = zm, m
        for _ in range(5):
            lw, lh = zc.shape[1] // 2, zc.shape[0] // 2
            zc = cv2.resize(zc, (lw, lh), interpolation=cv2.INTER_AREA)
            mc = cv2.resize(mc, (lw, lh), interpolation=cv2.INTER_AREA)
            n2 = cv2.GaussianBlur(zc, (0, 0), sigma)
            d2 = cv2.GaussianBlur(mc, (0, 0), sigma)
            n2 = cv2.resize(n2, shape, interpolation=cv2.INTER_LINEAR)
            d2 = cv2.resize(d2, shape, interpolation=cv2.INTER_LINEAR)
            ok = d2 >= floor
            fill = bad & ok
            if fill.any():
                out[fill] = (n2 / np.maximum(d2, 1e-9))[fill]
            bad &= ~ok
            if not bad.any():
                break
        if bad.any():
            out[bad] = float(np.median(z[m > 0])) if m.any() else 0.0
    return out.astype(np.float32)


def prefilter_depth(
    z: np.ndarray, mode: str = "none", size: int = 5,
    valid: np.ndarray | None = None,
    fast_gauss: bool = True,
) -> np.ndarray:
    """Suppress depth quantization before differentiating.

    TUM depth is disparity-quantized: the step between adjacent representable
    depths follows dz ~ 0.0029 z^2, i.e. 2.9 mm at 1 m but 11.6 mm at 2 m. That
    staircase dominates the Sobel response and wrecks the normals -- a synthetic
    plane with no noise at all goes from 0.00 to 30 deg median normal error once
    quantized this way. A sensor with natively per-pixel depth would not need
    this step; it is here to keep TUM usable.

    Bilateral preserves depth edges, box does not.
    """
    if mode == "none":
        return z
    if mode == "box":
        return cv2.blur(z, (size, size))
    if mode == "bilateral":
        return cv2.bilateralFilter(z, size, 0.02, size)
    if mode == "gauss":
        # Only the Gaussian is scale-space consistent: d(G*z) = (dG)*z, so the
        # first and second derivatives describe the *same* smoothed surface.
        # Bilateral is non-linear, so its effective scale differs between the
        # normal and the curvature -- measured 11 deg median disagreement and a
        # 34% curvature discrepancy on the same pixels.
        #
        # Masked, so invalid readings (z = 0) are not averaged in; see
        # masked_gauss for what that was costing. fast_gauss switches the
        # wide-kernel fallback to the pyramid approximation (masked_gauss_fast).
        return masked_gauss_fast(z, float(size), valid=valid) if fast_gauss \
            else masked_gauss(z, float(size), valid=valid)
    raise ValueError(f"unknown prefilter mode: {mode}")


def normals_from_depth(z: np.ndarray, K: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Analytic surface normal from depth gradients.

    dP/du and dP/dv follow from differentiating the backprojection; the normal is
    their cross product. O(1) per pixel: two Sobel passes and one cross product,
    no neighbourhood search. Requires depth gradients to be trustworthy, which
    holds only when depth is natively per-pixel (no warp resampling).

    Returns (normal, valid) with normals facing the camera.
    """
    h, w = z.shape
    fx, fy, cx, cy = K[0, 0], K[1, 1], K[0, 2], K[1, 2]
    xs, ys = np.meshgrid(np.arange(w, dtype=np.float32), np.arange(h, dtype=np.float32))

    zu = cv2.Sobel(z, cv2.CV_32F, 1, 0, ksize=3) / 8.0
    zv = cv2.Sobel(z, cv2.CV_32F, 0, 1, ksize=3) / 8.0

    dPdu = np.stack([(z + (xs - cx) * zu) / fx, (ys - cy) * zu / fy, zu], axis=-1)
    dPdv = np.stack([(xs - cx) * zv / fx, (z + (ys - cy) * zv) / fy, zv], axis=-1)

    n = np.cross(dPdu, dPdv)
    norm = np.linalg.norm(n, axis=-1)
    valid = norm > 1e-12
    n = n / np.where(valid, norm, 1.0)[..., None]
    # Camera looks down +Z, so the visible side of a surface has n_z < 0.
    flip = n[..., 2] > 0
    n[flip] *= -1.0
    return n.astype(np.float32), valid


def depth_discontinuity_mask(
    z: np.ndarray, rel_thresh: float = 0.02, valid: np.ndarray | None = None,
) -> np.ndarray:
    """True where a VALID surface ends: a big depth step or into a void.

    Gradients are meaningless across an occlusion boundary, so no Gaussian may be
    built there. This is a property of the scene, not a sensor defect.

    The centre pixel must itself be valid. A void (z = 0) is a missing
    measurement, not a surface at zero distance, so it is never flagged and never
    compared into a neighbour. Requiring the centre to be valid is what turns the
    old double line into one line per real boundary: on a wide invalid stripe the
    old mask flagged |valid - 0| from both sides AND the 0-vs-0 interior, painting
    a 4 px band of edge pixels of which 33.7% were inside the void itself. Now only
    the valid pixels adjacent to the stripe (the two genuine surface terminations)
    are flagged, one line each.
    """
    if valid is None:
        valid = depth_valid(z)
    step = np.full(z.shape, -1.0, dtype=np.float32)
    for dy, dx in ((0, 1), (0, -1), (1, 0), (-1, 0)):
        shifted = np.roll(np.roll(z, dy, axis=0), dx, axis=1)
        # Treat an invalid neighbour as a hard zero step: the surface terminates.
        nbr = np.where(np.roll(np.roll(valid, dy, axis=0), dx, axis=1), shifted, 0.0)
        step = np.maximum(step, np.abs(z - nbr))
    edge = step > rel_thresh * np.maximum(z, 1e-6)
    return edge & valid


def surfel_radius(z: np.ndarray, nz: np.ndarray, K: np.ndarray) -> np.ndarray:
    """ElasticFusion surfel radius. Zero free parameters.

        r  = sqrt(2) * z / mean_focal      pixel footprint, sqrt(2) covers the
                                           square pixel's diagonal (no holes)
        rn = min(2r, r / |n_z|)            foreshortening compensation, capped
                                           so grazing angles cannot blow up

    The derivation assumes one pixel maps to one surface sample. On a natively
    aligned RGB-D sensor that holds literally rather than approximately.
    """
    mean_focal = 0.5 * (K[0, 0] + K[1, 1])
    r = np.sqrt(2.0) * z / mean_focal
    return np.minimum(2.0 * r, r / np.maximum(np.abs(nz), 1e-6))


def _quat_from_normal(n: np.ndarray) -> np.ndarray:
    """Rotation taking the local z axis onto the normal, as a wxyz quaternion.

    The tangent frame is arbitrary: the disc is rotationally symmetric because
    the two in-plane scales are equal.
    """
    ref = np.tile(np.array([0.0, 0.0, 1.0], dtype=np.float32), (n.shape[0], 1))
    parallel = np.abs(n[:, 2]) > 0.9
    ref[parallel] = np.array([1.0, 0.0, 0.0], dtype=np.float32)

    t1 = np.cross(ref, n)
    t1 /= np.maximum(np.linalg.norm(t1, axis=1, keepdims=True), 1e-12)
    t2 = np.cross(n, t1)

    R = np.stack([t1, t2, n], axis=-1)  # columns
    tr = R[:, 0, 0] + R[:, 1, 1] + R[:, 2, 2]
    q = np.zeros((n.shape[0], 4), dtype=np.float32)

    m0 = tr > 0
    s = np.sqrt(np.maximum(tr[m0] + 1.0, 1e-12)) * 2.0
    q[m0, 0] = 0.25 * s
    q[m0, 1] = (R[m0, 2, 1] - R[m0, 1, 2]) / s
    q[m0, 2] = (R[m0, 0, 2] - R[m0, 2, 0]) / s
    q[m0, 3] = (R[m0, 1, 0] - R[m0, 0, 1]) / s

    rest = ~m0
    if rest.any():
        Rr = R[rest]
        d = np.stack([Rr[:, 0, 0], Rr[:, 1, 1], Rr[:, 2, 2]], axis=1)
        k = np.argmax(d, axis=1)
        qr = np.zeros((Rr.shape[0], 4), dtype=np.float32)
        for axis in range(3):
            sel = k == axis
            if not sel.any():
                continue
            a, b, c = axis, (axis + 1) % 3, (axis + 2) % 3
            Rs = Rr[sel]
            s = np.sqrt(np.maximum(1.0 + Rs[:, a, a] - Rs[:, b, b] - Rs[:, c, c], 1e-12)) * 2.0
            qr[sel, 0] = (Rs[:, c, b] - Rs[:, b, c]) / s
            qr[sel, 1 + a] = 0.25 * s
            qr[sel, 1 + b] = (Rs[:, b, a] + Rs[:, a, b]) / s
            qr[sel, 1 + c] = (Rs[:, c, a] + Rs[:, a, c]) / s
        q[rest] = qr

    return q / np.maximum(np.linalg.norm(q, axis=1, keepdims=True), 1e-12)


def rgb_to_sh_dc(rgb: np.ndarray) -> np.ndarray:
    """Exact inverse of the 3DGS DC term. Only order 0 is available per frame."""
    return (rgb - 0.5) / SH_C0


def build_gaussians(
    bgr: np.ndarray,
    z: np.ndarray,
    K: np.ndarray,
    z_min: float = 0.4,
    z_max: float = 4.0,
    disc_rel: float = 0.02,
    stride: int = 1,
    mask: np.ndarray | None = None,
    prefilter: str = "none",
    prefilter_size: int = 5,
    valid_depth: np.ndarray | None = None,
    radius_scale: float = 1.0,
    geo: CurvatureGeometry | None = None,
) -> Gaussians:
    """One Gaussian per selected pixel, all attributes in closed form.

    Positions stay on the raw depth; only the normals are differentiated from
    the prefiltered copy, so smoothing never displaces a measurement.

    Pass `geo` (from compute_curvature_geometry, already used by
    build_gaussians_curvature) to reuse its smoothed depth / normal / validity /
    discontinuity mask instead of recomputing them for stride sampling. This is
    correct only when the caller wants the *same* scale (geo is built at
    gauss_sigma); otherwise omit geo and the standalone path is used.
    """
    if geo is not None:
        valid_depth = geo.valid_depth
        z_grad, normal, n_ok = geo.z_grad, geo.normal, geo.n_ok
        disc_mask = geo.disc_mask
    else:
        if valid_depth is None:
            valid_depth = depth_valid(z)
        z_grad = prefilter_depth(z, prefilter, prefilter_size, valid=valid_depth)
        normal, n_ok = normals_from_depth(z_grad, K)
        disc_mask = depth_discontinuity_mask(z, disc_rel, valid=valid_depth)
    X = backproject(z, K)
    r = surfel_radius(z, normal[..., 2], K) * radius_scale

    valid = (
        n_ok & valid_depth & (z > z_min) & (z < z_max)
        & ~disc_mask
    )
    if mask is not None:
        valid &= mask
    if stride > 1:
        keep = np.zeros_like(valid)
        keep[::stride, ::stride] = True
        valid &= keep

    ys, xs = np.where(valid)
    n = normal[ys, xs]
    rad = r[ys, xs].astype(np.float32)
    scale = np.stack([rad, rad, THIN_AXIS_RATIO * rad], axis=1)
    color = bgr[ys, xs][:, ::-1].astype(np.float32) / 255.0

    return Gaussians(
        mu=X[ys, xs].astype(np.float32),
        normal=n,
        scale=scale,
        quat=_quat_from_normal(n),
        color=color,
        alpha=np.full(ys.shape[0], OPAQUE_ALPHA, dtype=np.float32),
        pixel=np.stack([xs, ys], axis=1).astype(np.int32),
    )


def build_gaussians_curvature(
    bgr: np.ndarray,
    z: np.ndarray,
    K: np.ndarray,
    eps: float = 0.001,
    gauss_sigma: float = 3.0,
    r_max: float = 0.15,
    normal_mode: str = "disc_inliers_fast",
    plane_win_px: float = 9.0,
    plane_inset: float = 0.9,
    shrink: float = 1.0,
    z_min: float = 0.4,
    z_max: float = 4.0,
    disc_rel: float = 0.02,
    stride: int = 1,
    mask: np.ndarray | None = None,
    prefilter: str = "none",
    prefilter_size: int = 5,
    valid_depth: np.ndarray | None = None,
    r_cap: np.ndarray | None = None,
    geo: CurvatureGeometry | None = None,
) -> Gaussians:
    """Anisotropic discs sized by principal curvature (idea 1).

    r_i = clip( sqrt(2 eps / |k_i|),  footprint,  r_max )

    The sagitta of a disc of radius r on a surface of normal curvature k is
    ~0.5 k r^2, so bounding it by eps gives the per-direction radius. Being
    per-direction is the whole point: on a cylinder the axial curvature is zero
    and the disc may stretch along the axis while staying thin across it, which
    an isotropic disc cannot express.

    Curvature comes from a Gaussian scale-space (see scale_space_curvature); the
    footprint rule still caps the result so a flat wall does not produce one
    unbounded disc.

    Pass `geo` (from compute_curvature_geometry) to reuse the smoothed depth,
    normal, curvature, and radius fields already computed for coverage sampling
    instead of recomputing them here. When omitted the fields are computed
    internally, preserving the standalone-caller behaviour.
    """
    if geo is not None:
        valid_depth = geo.valid_depth
        z_grad, normal, n_ok = geo.z_grad, geo.normal, geo.n_ok
        k1, k2, t1, c_ok, dir_img = geo.k1, geo.k2, geo.t1, geo.c_ok, geo.dir_img
        r_k1, r_k2, r_fp, r_edge = geo.r_k1, geo.r_k2, geo.r_fp, geo.r_edge
        disc_mask = geo.disc_mask
    else:
        if valid_depth is None:
            valid_depth = depth_valid(z)
        # Normals and curvature MUST come from the same smoothed depth. mix of
        # bilateral (normals) and gauss (curvature) was the dominant error source
        # in experiment D: 11 deg median normal disagreement and 34% curvature
        # discrepancy on identical pixels. The normal uses this same scale.
        z_grad = prefilter_depth(z, "gauss", gauss_sigma, valid=valid_depth)
        normal, n_ok = normals_from_depth(z_grad, K)
        k1, k2, t1, c_ok, dir_img = scale_space_curvature(z_grad, K)
        r_k1, r_k2 = curvature_radii(k1, k2, eps)
        r_fp = surfel_radius(z, normal[..., 2], K)
        r_edge = edge_distance_limit(z, K, disc_rel, valid=valid_depth)
        disc_mask = depth_discontinuity_mask(z, disc_rel, valid=valid_depth)
    X = backproject(z, K)
    valid = (
        n_ok & c_ok & valid_depth
        & (z > z_min) & (z < z_max)
        & ~disc_mask
    )
    if mask is not None:
        valid &= mask
    if stride > 1:
        keep = np.zeros_like(valid)
        keep[::stride, ::stride] = True
        valid &= keep

    ys, xs = np.where(valid)
    n = normal[ys, xs]
    fp = r_fp[ys, xs].astype(np.float32)

    # The footprint is a LOWER bound, not a cap. Capping at it defeats the whole
    # idea: sqrt(2 eps / k) on a flat wall is hundreds of mm while a single
    # pixel's footprint is ~4 mm, so min() would always pick 4 mm and the discs
    # would never grow. A disc need only be large enough to cover its own pixel;
    # how far apart discs sit is decided by coverage_sample instead.
    lim = np.minimum(r_max, r_edge[ys, xs])
    if r_cap is not None:
        lim = np.minimum(lim, r_cap[ys, xs])
    r1 = np.clip(r_k1[ys, xs], fp, np.maximum(lim, fp)).astype(np.float32)
    r2 = np.clip(r_k2[ys, xs], fp, np.maximum(lim, fp)).astype(np.float32)
    # Shrink the disc away from its own edge. The curvature radius is where the
    # sagitta hits eps, so the edge is exactly the worst-error ring; pulling in
    # by a few percent makes the *used* region stay well below eps. Coverage is
    # unaffected because overlap=0.7 already leaves the neighbours to fill in.
    r1 = (r1 * shrink).astype(np.float32)
    r2 = (r2 * shrink).astype(np.float32)

    if normal_mode == "disc_inliers":
        # Self-consistent ordering: the radii are known first, then the normal is
        # fitted over exactly the ellipse those radii define. Previously the
        # normal came from a fixed window with no relation to the disc (measured
        # 4x larger than the disc it was meant to describe).
        f_mean = 0.5 * (K[0, 0] + K[1, 1])
        zc = z[ys, xs]
        ra_px = (r1 * shrink) * f_mean / np.maximum(zc, 1e-6)
        rb_px = (r2 * shrink) * f_mean / np.maximum(zc, 1e-6)
        n_fit = _normal_from_disc_inliers(
            z_grad, K, ys, xs, n.astype(np.float64), ra_px, rb_px, dir_img[ys, xs],
        )
        ok_fit = np.linalg.norm(n_fit, axis=1) > 0.5
        # A disc covering ~1 pixel cannot support a fit; its own pixel normal is
        # already the right answer there.
        n = np.where(ok_fit[:, None], n_fit, n).astype(np.float32)
        n = n / np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-12)
    elif normal_mode == "disc_inliers_fast":
        f_mean = 0.5 * (K[0, 0] + K[1, 1])
        zc = z[ys, xs]
        ra_px = (r1 * shrink) * f_mean / np.maximum(zc, 1e-6)
        rb_px = (r2 * shrink) * f_mean / np.maximum(zc, 1e-6)
        n_fit = _normal_from_disc_inliers_fast(
            z_grad, K, ys, xs, n.astype(np.float64), normal, ra_px, rb_px,
            dir_img[ys, xs],
        )
        ok_fit = np.linalg.norm(n_fit, axis=1) > 0.5
        n = np.where(ok_fit[:, None], n_fit, n).astype(np.float32)
        n = n / np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-12)
    elif normal_mode == "fixed_window":
        n = _plane_normal_window(
            z_grad, K, ys, xs, n, X[ys, xs].astype(np.float64), plane_win_px,
            inset=plane_inset,
        )
        bad = np.linalg.norm(n, axis=1) < 0.5
        if bad.any():
            n[bad] = normal[ys[bad], xs[bad]]
        n = n / np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-12)
    elif normal_mode != "perpixel":
        raise ValueError(f"unknown normal_mode: {normal_mode}")

    # Re-orthogonalise the curvature direction against the normal.
    a1 = t1[ys, xs]
    a1 = a1 - np.einsum("ij,ij->i", a1, n)[:, None] * n
    a1n = np.linalg.norm(a1, axis=1, keepdims=True)
    degenerate = (a1n < 1e-9).ravel()
    a1 = a1 / np.maximum(a1n, 1e-12)
    if degenerate.any():
        fb = np.tile(np.array([1.0, 0.0, 0.0], np.float32), (degenerate.sum(), 1))
        fb = fb - np.einsum("ij,ij->i", fb, n[degenerate])[:, None] * n[degenerate]
        a1[degenerate] = fb / np.maximum(
            np.linalg.norm(fb, axis=1, keepdims=True), 1e-12
        )
    a2 = np.cross(n, a1)

    scale = np.stack([r1, r2, THIN_AXIS_RATIO * np.minimum(r1, r2)], axis=1)
    return Gaussians(
        mu=X[ys, xs].astype(np.float32),
        normal=n,
        scale=scale,
        quat=_quat_from_normal(n),
        color=bgr[ys, xs][:, ::-1].astype(np.float32) / 255.0,
        alpha=np.full(ys.shape[0], OPAQUE_ALPHA, dtype=np.float32),
        pixel=np.stack([xs, ys], axis=1).astype(np.int32),
        axis1=a1.astype(np.float32),
        axis2=a2.astype(np.float32),
    )


def _plane_normal_window(
    z_grad: np.ndarray, K: np.ndarray, ys: np.ndarray, xs: np.ndarray,
    center_n: np.ndarray, center_X: np.ndarray,
    win_px: float,
    inset: float = 0.9,
    plane_tol_rel: float = 0.06,
) -> np.ndarray:
    """Per-centre normals from a least-squares inverse-depth plane fit.

    A single pixel's normal carries depth-noise error. For a small disc that is
    fine, but a large disc multiplies it out to r*tan(theta) at the edge. Fitting
    a plane over the disc's own footprint averages the noise down roughly as
    1/sqrt(N), which is what lets a large disc afford its own size.

    The mask must reject the OTHER surface across an occlusion boundary, not the
    depth variation of a slope. Comparing each sample to the centre depth does
    the latter: on a 60 deg slope a 9 px window swings depth by 3% of z, so the
    old 2% gate threw away legitimately coplanar samples and the fit collapsed
    (24 deg, everywhere). Instead, predict each sample's depth from the plane
    through the centre (using the centre's per-pixel normal) and reject by the
    deviation from THAT. Because 1/z is affine in (u, v) on a plane, a slope's
    samples deviate ~0 by construction; only a true occlusion jump does.

    The window size is driven by how many samples the noise needs averaged, not
    by the disc radius. Sizing it by the radius was circular.

    Returns (N, 3) unit normals facing the camera.
    """
    h, w = z_grad.shape
    fx, fy, cx, cy = K[0, 0], K[1, 1], K[0, 2], K[1, 2]

    n_out = np.zeros((ys.size, 3), dtype=np.float32)
    r_fixed = max(int(round(win_px)), 2)

    for i in range(ys.size):
        r = r_fixed
        y0, y1 = max(ys[i] - r, 0), min(ys[i] + r + 1, h)
        x0, x1 = max(xs[i] - r, 0), min(xs[i] + r + 1, w)
        Y, X = np.mgrid[y0:y1, x0:x1]
        zz = z_grad[y0:y1, x0:x1].astype(np.float64)
        rr = np.hypot(X - xs[i], Y - ys[i])
        m = (rr <= inset * r) & np.isfinite(zz) & (zz > 1e-6)
        if m.sum() < 8:
            continue

        U = ((X - cx) / fx)[m]
        V = ((Y - cy) / fy)[m]
        ww = (1.0 / zz)[m]

        # Plane prediction: extent of the drop is what the centre's plane says.
        # n0 . K^-1 [u,v,1] = n0 . (X0 / z0) ... 1/z_pred = (n0.Kinv u) / (n0.P0)
        n0 = center_n[i]
        P0 = center_X[i]
        d0 = n0 @ P0
        invz_pred = (n0[0] * U + n0[1] * V + n0[2]) / d0
        dev_m = np.abs(ww - invz_pred) * (P0[2] ** 2)  # dz ~= z^2 * d(1/z)
        m2 = m.copy()
        m2[m] = m[m] & (dev_m < plane_tol_rel * P0[2])

        sel = m2[m]
        if sel.sum() < 8:
            continue
        A = np.stack([U[sel], V[sel], np.ones(sel.sum())], axis=1)
        c, *_ = np.linalg.lstsq(A, ww[sel], rcond=None)
        # U, V are NORMALISED coords, so 1/z = (n . [U, V, 1]) / d makes the
        # coefficients the normal directly. The pixel-coordinate form
        # (alpha*fx, beta*fy, gamma + alpha*cx + beta*cy) belongs to a fit in
        # raw (u, v) and mixing the two conventions costs ~71 deg on a 45 deg
        # plane -- which is what sank every previous attempt at plane normals.
        nv = np.asarray(c, dtype=np.float64)
        nn = np.linalg.norm(nv)
        if nn < 1e-12:
            continue
        nv = nv / nn
        n_out[i] = nv if nv[2] < 0 else -nv
    return n_out


def edge_distance_limit(
    z: np.ndarray, K: np.ndarray, disc_rel: float = 0.02,
    valid: np.ndarray | None = None,
) -> np.ndarray:
    """Largest metric radius that keeps a disc clear of a depth discontinuity.

    Without this, a legitimately large disc near an occlusion boundary pokes out
    into free space and wins the depth test for background pixels: measured RMSE
    blew up to ~190 mm (p95 615 mm) while the median stayed at 10 mm, i.e. purely
    outlier-driven. Capping the radius by the distance to the nearest depth edge
    removes the mechanism instead of clipping the symptom.

    Same failure mode as the quadtree's radius bug, but there the discs were
    oversized by a wrong constant; here they are correctly sized and simply have
    nowhere to sit.
    """
    edge = depth_discontinuity_mask(z, disc_rel, valid=valid)
    free = (~edge).astype(np.uint8)
    dist_px = cv2.distanceTransform(free, cv2.DIST_L2, 3)
    return (dist_px * z / (0.5 * (K[0, 0] + K[1, 1]))).astype(np.float32)


def tex_boundary_limit(
    z: np.ndarray, K: np.ndarray, tex_mask: np.ndarray, tol_px: float = 0.0,
) -> np.ndarray:
    """Largest metric radius that keeps a disc within tol_px of the texture mask.

    Counterpart to edge_distance_limit: there the "wall" is a depth discontinuity,
    here it is the texture/colour boundary. A large flat disc whose centre sits in
    the non-texture region can legally cross a colour boundary where depth is flat
    (no depth edge -> edge_distance_limit does not fire) and over-paint the
    neighbouring texture region. This returns, per pixel, the radius whose
    projected footprint extends at most tol_px past the texture mask edge, so the
    caller can clamp the disc before it bleeds across.

    tol_px > 0 allows the disc to poke tol_px INTO the mask: the texture mask is
    dilated by the variance window (win/2 ~ 4.5 px) beyond the true texture, so
    poking past the mask edge by that margin still does not cover real texture.
    """
    free = (~tex_mask).astype(np.uint8)
    dist_px = cv2.distanceTransform(free, cv2.DIST_L2, 3)
    mean_focal = 0.5 * (K[0, 0] + K[1, 1])
    return (np.maximum(dist_px + tol_px, 0.0) * z / mean_focal).astype(np.float32)


def compute_curvature_geometry(
    z: np.ndarray,
    K: np.ndarray,
    eps: float,
    gauss_sigma: float,
    disc_rel: float,
    valid_depth: np.ndarray | None = None,
    fast_gauss: bool = True,
) -> CurvatureGeometry:
    """Compute the shared geometric quantities once for coverage + emission.

    This is the single source of truth for the smoothed depth, normal, principal
    curvatures, and the two derived radius fields (curvature and footprint/edge
    limits) that both `curvature_mask` (seed spacing) and
    `build_gaussians_curvature` (disc emission) consume. Computing them once
    instead of twice halves the quadric fit and normal-derivative work, and
    structurally prevents the claim radius from ever diverging from the emitted
    radius.
    """
    if valid_depth is None:
        valid_depth = depth_valid(z)
    z_grad = prefilter_depth(z, "gauss", gauss_sigma, valid=valid_depth,
                             fast_gauss=fast_gauss)
    normal, n_ok = normals_from_depth(z_grad, K)
    k1, k2, t1, c_ok, dir_img = scale_space_curvature(z_grad, K)
    r_k1, r_k2 = curvature_radii(k1, k2, eps)
    r_fp = surfel_radius(z, normal[..., 2], K)
    r_edge = edge_distance_limit(z, K, disc_rel, valid=valid_depth)
    disc_mask = depth_discontinuity_mask(z, disc_rel, valid=valid_depth)
    return CurvatureGeometry(
        z_grad=z_grad, normal=normal, n_ok=n_ok,
        k1=k1, k2=k2, t1=t1, c_ok=c_ok, dir_img=dir_img,
        r_k1=r_k1, r_k2=r_k2, r_fp=r_fp, r_edge=r_edge,
        disc_mask=disc_mask, valid_depth=valid_depth,
    )


def coverage_sample(
    radius_px: np.ndarray,
    valid: np.ndarray,
    overlap: float = 0.7,
) -> np.ndarray:
    """Greedy coverage sampling: keep a pixel only if no accepted disc covers it.

    Curvature sizes each disc but does not by itself reduce the primitive count
    -- one disc per pixel stays one disc per pixel however large it grows. The
    count only falls if the sampling spacing follows the local radius, which is
    what this does: candidates are visited largest-radius-first, and an accepted
    disc claims the pixels it covers so they are never emitted themselves.

    overlap < 1 shrinks the claimed area so neighbours still overlap slightly,
    which is what keeps coverage hole-free.

    The claim is a square, which is what numpy slicing gives for free. A circular
    claim was tried and reverted: it only moved holes from 10.3% to 7.9% and did
    not change their character at all (68% of components stayed 1-2 px slivers),
    so the shape of the claim was never the real problem -- see the foreshortening
    note below.

    Returns a boolean mask of accepted pixels.
    """
    h, w = valid.shape
    ys, xs = np.where(valid)
    if ys.size == 0:
        return np.zeros_like(valid)

    rp = radius_px[ys, xs]
    order = np.argsort(-rp)
    ys, xs, rp = ys[order], xs[order], rp[order]

    claimed = np.zeros((h, w), dtype=bool)
    keep = np.zeros(ys.size, dtype=bool)
    for i in range(ys.size):
        y, x = ys[i], xs[i]
        if claimed[y, x]:
            continue
        keep[i] = True
        r = max(int(rp[i] * overlap), 0)
        y0, y1 = max(y - r, 0), min(y + r + 1, h)
        x0, x1 = max(x - r, 0), min(x + r + 1, w)
        claimed[y0:y1, x0:x1] = True

    out = np.zeros_like(valid)
    out[ys[keep], xs[keep]] = True
    return out


def coverage_sample_elliptical(
    r_px: np.ndarray,
    valid: np.ndarray,
    overlap: float = 0.7,
    nz: np.ndarray | None = None,
    dir_u: np.ndarray | None = None,
    dir_v: np.ndarray | None = None,
    min_nz: float = 0.15,
) -> np.ndarray:
    """Greedy coverage sampling claiming an ellipse matched to the disc projection.

    The square claim in coverage_sample is an implementation accident. A disc
    projects to an ellipse with semi-major r_px perpendicular to the surface tilt
    and semi-minor r_px*|n_z| along it. Once overlap > |n_z| the square covers
    pixels no disc actually reaches (tilt > arccos(overlap) = 53 deg at
    overlap=0.6), which is exactly where the holes sit. Claiming the true
    projection instead closes those holes at cost 1/|n_z| rather than the
    isotropic 1/|n_z|^2 that foreshortening pays on all axes.

    nz, dir_u, dir_v are per-pixel |n_z| and the image-space tilt unit direction
    (du, dv) = normalize(nx/fx, ny/fy) along which the projection is squashed.
    When nz is None the claim falls back to the square path, so this is a strict
    extension of the old behaviour and the old code path is preserved for A/B.
    """
    h, w = valid.shape
    ys, xs = np.where(valid)
    if ys.size == 0:
        return np.zeros_like(valid)

    rp = r_px[ys, xs].astype(np.float32)
    order = np.argsort(-rp)
    ys, xs, rp = ys[order], xs[order], rp[order]

    if nz is None:
        nz_col = np.ones(ys.size, dtype=np.float32)
    else:
        nz_col = np.abs(nz[ys, xs]).astype(np.float32)[order]
    if dir_u is None or dir_v is None:
        du_col = None
        dv_col = None
    else:
        du_col = dir_u[ys, xs].astype(np.float32)[order]
        dv_col = dir_v[ys, xs].astype(np.float32)[order]

    claimed = np.zeros((h, w), dtype=bool)
    keep = np.zeros(ys.size, dtype=bool)
    for i in range(ys.size):
        y, x = ys[i], xs[i]
        if claimed[y, x]:
            continue
        keep[i] = True
        a = float(rp[i]) * overlap
        if du_col is None or dv_col is None:
            r = max(int(round(a)), 0)
            y0, y1 = max(y - r, 0), min(y + r + 1, h)
            x0, x1 = max(x - r, 0), min(x + r + 1, w)
            claimed[y0:y1, x0:x1] = True
            continue
        b = a * max(float(nz_col[i]), min_nz)
        du, dv = float(du_col[i]), float(dv_col[i])
        r = max(int(np.ceil(max(a, b))), 0)
        y0, y1 = max(y - r, 0), min(y + r + 1, h)
        x0, x1 = max(x - r, 0), min(x + r + 1, w)
        if x0 >= x1 or y0 >= y1:
            continue
        Y, X = np.mgrid[y0:y1, x0:x1]
        py = Y - y
        px = X - x
        ca = px * du + py * dv      # along the tilt (short axis)
        cb = px * (-dv) + py * du   # perpendicular to the tilt (long axis)
        m = (ca / b) ** 2 + (cb / a) ** 2 <= 1.0
        claimed[y0:y1, x0:x1] |= m

    out = np.zeros_like(valid)
    out[ys[keep], xs[keep]] = True
    return out


def coverage_sample_elliptical_fast(
    r_px: np.ndarray,
    valid: np.ndarray,
    overlap: float = 0.7,
    nz: np.ndarray | None = None,
    dir_u: np.ndarray | None = None,
    dir_v: np.ndarray | None = None,
    min_nz: float = 0.15,
) -> np.ndarray:
    """Same greedy elliptical coverage as `coverage_sample_elliptical`, faster.

    Semantics are identical -- the same largest-first traversal over the same
    candidates, the same ellipse equation, the same `claimed |= m` state. The
    only changes are implementation-level, all hoisted out of the per-candidate
    Python loop:

      * the full-frame (YY, XX) coordinate mesh is built once instead of one
        np.mgrid per emitting disc,
      * the per-candidate scalars (a, b, du, dv) and the clip bounds (y0/y1/
        x0/x1) are precomputed as arrays, so the loop body only indexes them.

    The loop over 254k candidates is unchanged in structure (a sequential greedy
    is required: a later disc may not be kept if an earlier, larger one claimed
    its centre), so the remaining cost is the sequential scan + the ellipse
    arithmetic of the ~31k discs that actually emit.
    """
    h, w = valid.shape
    ys, xs = np.where(valid)
    if ys.size == 0:
        return np.zeros_like(valid)

    rp = r_px[ys, xs].astype(np.float32)
    order = np.argsort(-rp)
    ys, xs, rp = ys[order], xs[order], rp[order]

    if nz is None:
        nz_col = np.ones(ys.size, dtype=np.float32)
    else:
        nz_col = np.abs(nz[ys, xs]).astype(np.float32)[order]
    if dir_u is None or dir_v is None:
        du_col = None
        dv_col = None
    else:
        du_col = dir_u[ys, xs].astype(np.float32)[order]
        dv_col = dir_v[ys, xs].astype(np.float32)[order]

    # Hoist every per-candidate quantity into an array (or the square path).
    a_col = (rp * overlap).astype(np.float32)
    if du_col is None or dv_col is None:
        # Square claim path: radius is round(overlap * rp).
        r_col = np.maximum(np.rint(a_col).astype(np.int64), 0)
        y0c = np.maximum(ys - r_col, 0)
        y1c = np.minimum(ys + r_col + 1, h)
        x0c = np.maximum(xs - r_col, 0)
        x1c = np.minimum(xs + r_col + 1, w)
    else:
        b_col = a_col * np.maximum(nz_col, min_nz)
        r_col = np.maximum(np.ceil(np.maximum(a_col, b_col)).astype(np.int64), 0)
        y0c = np.maximum(ys - r_col, 0)
        y1c = np.minimum(ys + r_col + 1, h)
        x0c = np.maximum(xs - r_col, 0)
        x1c = np.minimum(xs + r_col + 1, w)

    YY, XX = np.meshgrid(np.arange(h), np.arange(w), indexing="ij")
    claimed = np.zeros((h, w), dtype=bool)
    keep = np.zeros(ys.size, dtype=bool)
    for i in range(ys.size):
        y, x = ys[i], xs[i]
        if claimed[y, x]:
            continue
        keep[i] = True
        if du_col is None or dv_col is None:
            y0, y1 = int(y0c[i]), int(y1c[i])
            x0, x1 = int(x0c[i]), int(x1c[i])
            claimed[y0:y1, x0:x1] = True
            continue
        a = float(a_col[i])
        b = float(b_col[i])
        du, dv = float(du_col[i]), float(dv_col[i])
        y0, y1 = int(y0c[i]), int(y1c[i])
        x0, x1 = int(x0c[i]), int(x1c[i])
        if x0 >= x1 or y0 >= y1:
            continue
        py = YY[y0:y1, x0:x1] - y
        px = XX[y0:y1, x0:x1] - x
        ca = px * du + py * dv        # along the tilt (short axis)
        cb = px * (-dv) + py * du     # perpendicular to the tilt (long axis)
        m = (ca / b) ** 2 + (cb / a) ** 2 <= 1.0
        claimed[y0:y1, x0:x1] |= m

    out = np.zeros_like(valid)
    out[ys[keep], xs[keep]] = True
    return out


def _normal_from_disc_inliers(
    z_grad: np.ndarray, K: np.ndarray, ys: np.ndarray, xs: np.ndarray,
    center_n: np.ndarray, r_px_a: np.ndarray, r_px_b: np.ndarray,
    dirs_img: np.ndarray,
    plane_tol_rel: float = 0.06,
) -> np.ndarray:
    """Normal from the disc's OWN inliers, tied to its anisotropic footprint.

    Fixes the inconsistency where the normal came from a fixed-radius window that
    had nothing to do with the disc. Here the window IS the disc: two in-plane
    semi-axes r_px_a, r_px_b along the image-space direction dirs_img and its
    perpendicular. The disc and its normal now share the same points.

    The inlier gate predicts each sample's depth from the plane through the
    centre (via the centre's per-pixel normal) and rejects only genuine
    occlusion jumps, not slope variation -- because 1/z is affine in (u, v) on a
    plane. One refinement pass: the mask is built from the per-pixel normal, the
    fit then returns a better normal.

    Returns (N, 3) unit normals facing the camera.
    """
    h, w = z_grad.shape
    fx, fy, cx, cy = K[0, 0], K[1, 1], K[0, 2], K[1, 2]
    n_out = np.zeros((ys.size, 3), dtype=np.float32)

    for i in range(ys.size):
        yc, xc = ys[i], xs[i]
        n0 = center_n[i]
        # Normalise direction and build the perpendicular (image space).
        du, dv = dirs_img[i]
        dl = max(np.hypot(du, dv), 1e-9)
        du, dv = du / dl, dv / dl
        pu, pv = -dv, du
        ra = max(r_px_a[i], 1.0)
        rb = max(r_px_b[i], 1.0)
        bbox = int(np.ceil(max(ra, rb))) + 1
        y0, y1 = max(yc - bbox, 0), min(yc + bbox + 1, h)
        x0, x1 = max(xc - bbox, 0), min(xc + bbox + 1, w)
        Y, X = np.mgrid[y0:y1, x0:x1]
        zz = z_grad[y0:y1, x0:x1].astype(np.float64)
        if zz.size == 0:
            continue
        px = X - xc
        py = Y - yc
        ca = px * du + py * dv          # along the thin direction
        cb = px * pu + py * pv          # along the long direction
        inside = (ca / ra) ** 2 + (cb / rb) ** 2 <= 1.0
        m = inside & np.isfinite(zz) & (zz > 1e-6)
        if m.sum() < 8:
            continue
        U = ((X - cx) / fx)[m]
        V = ((Y - cy) / fy)[m]
        W = (1.0 / zz)[m]
        # Plane prediction through the center point.
        P0 = np.array([(xc - cx) / fx * z_grad[yc, xc],
                       (yc - cy) / fy * z_grad[yc, xc],
                       z_grad[yc, xc]], dtype=np.float64)
        d0 = n0 @ P0
        invz_pred = (n0[0] * U + n0[1] * V + n0[2]) / d0
        dev_m = np.abs(W - invz_pred) * (P0[2] ** 2)
        keep = dev_m < plane_tol_rel * P0[2]
        U, V, W = U[keep], V[keep], W[keep]
        if U.size < 8:
            continue
        A = np.stack([U, V, np.ones(U.size)], axis=1)
        coef, *_ = np.linalg.lstsq(A, W, rcond=None)
        nv = np.asarray(coef, dtype=np.float64)
        nn = np.linalg.norm(nv)
        if nn < 1e-12:
            continue
        nv = nv / nn
        n_out[i] = nv if nv[2] < 0 else -nv
    return n_out


def _normal_from_disc_inliers_fast(
    z_grad: np.ndarray,
    K: np.ndarray,
    ys: np.ndarray,
    xs: np.ndarray,
    center_n: np.ndarray,
    normal_full: np.ndarray,
    r_px_a: np.ndarray,
    r_px_b: np.ndarray,
    dirs_img: np.ndarray,
    normal_tol_deg: float = 30.0,
) -> np.ndarray:
    """Faster disc normal: inlier gate by angle, combine by unit-normal sum.

    Replaces the two most expensive parts of `_normal_from_disc_inliers` with
    cheaper equivalents that answer the SAME question ("which pixels share the
    disc's plane, and what is that plane's normal?"):

      * the depth-plane prediction gate (U,V,W backproject + 1/z + dot) is
        replaced by a normal dot-product gate -- a pixel on the same tilted
        plane has the SAME normal, so `normal_full @ n0 > cos(tol)` keeps it and
        rejects the other side of an occlusion (whose normal points elsewhere).
        This drops the whole U/V/W/1/z projection (~27% of the old cost).
      * np.linalg.lstsq (SVD of a 3x3 per disc) is replaced by averaging the
        inlier per-pixel normals as unit vectors -- on a plane the mean of the
        unit normals coincides with the least-squares estimate direction to
        first order, at ~1/5 the cost.

    The disc centre still picks its own elliptical window, so this and the
    original could disagree on the inlier set only where angle and
    depth-prediction disagree (near occlusion boundaries at grazing angles).
    Returns unit normals facing the camera; a zero-vector row means "could not
    fit" and is handled by the caller exactly like the original.
    """
    cos_tol = float(np.cos(np.deg2rad(normal_tol_deg)))
    h, w = z_grad.shape[:2]
    YY, XX = np.meshgrid(np.arange(h), np.arange(w), indexing="ij")
    n_out = np.zeros((ys.size, 3), dtype=np.float32)
    for i in range(ys.size):
        yc, xc = ys[i], xs[i]
        n0 = center_n[i]
        du, dv = dirs_img[i]
        dl = max(float(np.hypot(du, dv)), 1e-9)
        du, dv = du / dl, dv / dl
        pu, pv = -dv, du
        ra = max(float(r_px_a[i]), 1.0)
        rb = max(float(r_px_b[i]), 1.0)
        bbox = int(np.ceil(max(ra, rb))) + 1
        y0, y1 = max(yc - bbox, 0), min(yc + bbox + 1, h)
        x0, x1 = max(xc - bbox, 0), min(xc + bbox + 1, w)
        if x0 >= x1 or y0 >= y1:
            continue
        zz = z_grad[y0:y1, x0:x1]
        px = XX[y0:y1, x0:x1] - xc
        py = YY[y0:y1, x0:x1] - yc
        ca = px * du + py * dv
        cb = px * pu + py * pv
        nn = normal_full[y0:y1, x0:x1]
        dot = nn[..., 0] * n0[0] + nn[..., 1] * n0[1] + nn[..., 2] * n0[2]
        m = ((ca / ra) ** 2 + (cb / rb) ** 2 <= 1.0) & (zz > 1e-6) & (dot > cos_tol)
        if m.sum() < 8:
            continue
        acc = nn[m].sum(axis=0)
        ln = float(np.linalg.norm(acc))
        if ln < 1e-12:
            continue
        nv = acc / ln
        n_out[i] = nv if nv[2] < 0 else -nv
    return n_out
