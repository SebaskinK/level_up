"""Test the hypothesis: hit-branch one-point update moves right-edge S2 discs
leftward, opening a gap on the right that new-FOV S2 fill does not close.

Cheap test: no scene flow re-run. We compare
  * the frame-0 initial discs (build_hybrid_with_owner on frame 0 alone), and
  * the first n0 discs of the FINAL model transformed back to frame 0
    (output_discmask_align/model_f0.npz, birth==0 block).

With no aging pruning the disc indices are stable, so npz['mu'][:n0] is exactly
the frame-0-born discs after 10 frames of hit updates. Their projected-centre
displacement (du, dv) in frame-0 pixels IS the accumulated hit-branch drift.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

SEQ = Path(__file__).resolve().parent
SINGLE = SEQ.parent.parent / "SINGLE FRAME" / "scripts"
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SFLOW))
sys.path.insert(0, str(SINGLE))
sys.path.insert(0, str(SEQ))

import h_pipeline_final as H            # noqa: E402  (multi-frame copy)
import sequential_fusion_flowonly as SF  # noqa: E402

NPZ = SEQ.parent / "output_discmask_align" / "model_f0.npz"
DEPTH_NPY = SEQ.parent / "output_discmask_align" / "f0_depth_hard.npy"


def main() -> None:
    d = np.load(NPZ)
    mu_f = d["mu"].astype(np.float64)      # final, frame-0 coords
    scale_f = d["scale"].astype(np.float64)
    birth_f = d["birth"]
    n = len(mu_f)

    # frame-0 initial model (same call as render_f0_images)
    pairs = SF.associate(SF.DATA, max_dt=0.02)[: 11]
    sample = SF.load_rgb(pairs[0].rgb_path)
    h, w = sample.shape[:2]
    map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)
    bgr0, z0, _ = SF.load_pair(pairs, 0, map1, map2)
    g0, _, _, _ = H.build_hybrid_with_owner(bgr0, z0, K, SF.TEX_Q)
    n0 = len(g0)
    mu_i = g0.mu.astype(np.float64)        # initial, frame-0 coords
    scale_i = g0.scale.astype(np.float64)

    print(f"n_init={n0}  n_final={n}  npz first-n0 all birth==0: "
          f"{bool(np.all(birth_f[:n0] == 0))}")

    fx, fy, cx, cy = (float(K[0, 0]), float(K[1, 1]), float(K[0, 2]), float(K[1, 2]))

    def prj(mu):
        zc = np.maximum(mu[:, 2], 1e-6)
        return fx * mu[:, 0] / zc + cx, fy * mu[:, 1] / zc + cy

    ui, vi = prj(mu_i)
    uf, vf = prj(mu_f[:n0])
    du = uf - ui
    dv = vf - vi
    drift = np.hypot(du, dv)

    iso_i = np.abs(scale_i[:, 0] - scale_i[:, 1]) < 1e-6 * np.maximum(scale_i[:, 0], 1e-9)
    iso_f = np.abs(scale_f[:n0, 0] - scale_f[:n0, 1]) < 1e-6 * np.maximum(scale_f[:n0, 0], 1e-9)

    print("\n== frame-0-born discs: projected-centre drift over 10 frames == ")
    print(f"  all (n={n0}):   du median={np.median(du):+.2f}px  |du| median={np.median(np.abs(du)):.2f}"
          f"  dv median={np.median(dv):+.2f}px")
    for name, m in [("isotropic(S2)", iso_i), ("anisotropic(curv)", ~iso_i)]:
        if m.any():
            print(f"  {name:16s} (n={m.sum():6d}): du med={np.median(du[m]):+.2f}  "
                  f"|du| med={np.median(np.abs(du[m])):.2f}  moved-left frac={np.mean(du[m] < -0.5):.3f}")

    # right-edge band in frame-0 projection (the gray-strip lives near right border)
    for lo, hi in [(w - 120, w - 60), (w - 60, w)]:
        m = (ui >= lo) & (ui < hi)
        if not m.any():
            continue
        print(f"\n  band u in [{lo},{hi}) (n={m.sum()}):")
        for name, mm in [("  iso", m & iso_i), ("  aniso", m & (~iso_i))]:
            if mm.any():
                print(f"    {name:8s} n={mm.sum():5d} du med={np.median(du[mm]):+.2f}  "
                      f"moved-left frac={np.mean(du[mm] < -0.5):.3f}  "
                      f"|du| p90={np.percentile(np.abs(du[mm]), 90):.2f}")

    # holes (ray coverage) in right half, and nearest INITIAL disc drift
    depth_h = np.load(DEPTH_NPY)          # 0.0 where ray render missed
    valid = (z0 > SF.Z_MIN) & (z0 < SF.Z_MAX)
    hole = (depth_h == 0) & valid
    hl = hole.sum()
    print(f"\n== ray holes = {hl} ({100.0*hl/valid.sum():.3f}% of valid) ==")

    # nearest frame-0-born disc centre (brute force, cheap: ~4k holes x 31k discs too big,
    # so only measure displacement stats of discs sitting immediately left of a hole).
    hy, hx = np.nonzero(hole & (np.arange(w)[None, :] >= w // 2))
    if hy.size:
        print(f"  right-half holes: {hy.size}")
        cols = np.bincount(hx, minlength=w)
        nz = np.flatnonzero(cols > 0)
        if nz.size:
            print(f"  hole column range: [{nz.min()},{nz.max()}]  "
                  f"rightmost-40col counts: {cols[w-40:].tolist()}")

    # Does drift open the right edge? For frame-0-born discs whose initial centre
    # is within the right-most band, how far did their right (east) foot move?
    m = (ui >= w - 80) & (ui < w) & iso_i
    if m.any():
        r_px = scale_i[m, 0] * (0.5 * (fx + fy)) / np.maximum(mu_i[m, 2], 1e-6)
        right_foot_i = ui[m] + r_px
        r_f = scale_f[np.flatnonzero(m)[:0] if False else m, 0] * (0.5 * (fx + fy)) / np.maximum(mu_f[:n0][m, 2], 1e-6)
        right_foot_f = uf[m] + r_f
        print(f"\n  right-band iso discs (n={m.sum()}): right-foot px shift med="
              f"{np.median(right_foot_f - right_foot_i):+.2f} (negative = foot retracts left)")

    print("\nDone.")


if __name__ == "__main__":
    main()