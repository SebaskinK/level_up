"""SE(3) helpers for rigid-induced scene flow. No IMU."""

from __future__ import annotations

import numpy as np


def hat(w: np.ndarray) -> np.ndarray:
    wx, wy, wz = w
    return np.array(
        [[0.0, -wz, wy], [wz, 0.0, -wx], [-wy, wx, 0.0]],
        dtype=np.float64,
    )


def se3_exp(xi: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """xi = [wx, wy, wz, vx, vy, vz]  ->  (R, t) with X' = R X + t."""
    w = xi[:3]
    v = xi[3:]
    theta = float(np.linalg.norm(w))
    if theta < 1e-12:
        return np.eye(3) + hat(w), v.copy()
    k = w / theta
    K = hat(k)
    R = np.eye(3) + np.sin(theta) * K + (1.0 - np.cos(theta)) * (K @ K)
    V = (
        np.eye(3)
        + (1.0 - np.cos(theta)) / theta * K
        + (theta - np.sin(theta)) / theta * (K @ K)
    )
    return R, V @ v


def se3_log(R: np.ndarray, t: np.ndarray) -> np.ndarray:
    c = np.clip((np.trace(R) - 1.0) * 0.5, -1.0, 1.0)
    theta = float(np.arccos(c))
    if theta < 1e-12:
        return np.concatenate([np.zeros(3), t])
    w = (
        theta
        / (2.0 * np.sin(theta))
        * np.array([R[2, 1] - R[1, 2], R[0, 2] - R[2, 0], R[1, 0] - R[0, 1]])
    )
    a = (1.0 - np.cos(theta)) / (theta * theta)
    b = (theta - np.sin(theta)) / (theta ** 3)
    V = np.eye(3) + a * hat(w) + b * (hat(w) @ hat(w))
    v = np.linalg.solve(V, t)
    return np.concatenate([w, v])


def scale_twist(xi: np.ndarray, ratio: float) -> np.ndarray:
    """Constant-twist prediction: ξ_new ≈ ξ_old * (dt_new / dt_old)."""
    return xi * ratio


def apply_point_motion(X: np.ndarray, R: np.ndarray, t: np.ndarray) -> np.ndarray:
    """X: (..., 3) -> (..., 3)."""
    return X @ R.T + t
