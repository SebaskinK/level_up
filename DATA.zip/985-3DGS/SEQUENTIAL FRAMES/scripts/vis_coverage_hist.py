"""Coverage multiplicity histogram for the CURVATURE filling region (single frame 0).

Question: in the non-texture (curvature-filled) region, how many disc FOOTPRINTS
cover each pixel? This counts GEOMETRIC overlap (full r ellipse), ignoring z-order
-- NOT the greedy 'claimed' test (that only blocks candidate CENTRES, at 0.6r).

We recompute the curvature discs WITH axis1/axis2 kept (the concat in build_hybrid
drops them), so the inside test is the exact anisotropic (pa/ra)^2+(pb/rb)^2<=1
used by rasterize_discs.
"""

import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent
SINGLE = ROOT.parent.parent / "SINGLE FRAME" / "scripts"
sys.path.insert(0, str(SINGLE))

import h_pipeline_final as H  # noqa: E402


def count_coverage(g, K, shape):
    """Per-pixel count of disc footprints covering it (geometry only, no z-order).
    g must have axis1/axis2 set (curvature discs)."""
    h, w = shape
    fx, fy, cx, cy = K[0, 0], K[1, 1], K[0, 2], K[1, 2]
    zc = g.mu[:, 2]
    u0 = fx * g.mu[:, 0] / np.maximum(zc, 1e-6) + cx
    v0 = fy * g.mu[:, 1] / np.maximum(zc, 1e-6) + cy
    ra = g.scale[:, 0]
    rb = g.scale[:, 1]
    radius = np.maximum(ra, rb)
    proj = 0.5 * (fx + fy) * radius / np.maximum(zc, 1e-6)
    window = int(np.ceil(np.percentile(proj, 99.5))) + 1
    window = max(2, min(window, 80))

    n = g.normal.astype(np.float32)
    e1 = g.axis1.astype(np.float32)
    e2 = g.axis2.astype(np.float32)
    n_dot_mu = np.einsum("ij,ij->i", n, g.mu)
    count = np.zeros(h * w, dtype=np.int32)

    ub = np.round(u0).astype(np.int64)
    vb = np.round(v0).astype(np.int64)
    for dv in range(-window, window + 1):
        for du in range(-window, window + 1):
            u = ub + du
            v = vb + dv
            ok = (u >= 0) & (u < w) & (v >= 0) & (v < h)
            if not ok.any():
                continue
            idx = np.nonzero(ok)[0]
            uu = u[idx].astype(np.float32)
            vv = v[idx].astype(np.float32)
            d = np.stack([(uu - cx) / fx, (vv - cy) / fy, np.ones_like(uu)], axis=1)
            denom = np.einsum("ij,ij->i", n[idx], d)
            live = np.abs(denom) > 1e-9
            if not live.any():
                continue
            idx = idx[live]
            d = d[live]
            t = n_dot_mu[idx] / denom[live]
            front = t > 0
            if not front.any():
                continue
            idx = idx[front]
            P = d[front] * t[front][:, None]
            off = P - g.mu[idx]
            pa = np.einsum("ij,ij->i", off, e1[idx]) / np.maximum(ra[idx], 1e-9)
            pb = np.einsum("ij,ij->i", off, e2[idx]) / np.maximum(rb[idx], 1e-9)
            inside = (pa * pa + pb * pb) <= 1.0
            if not inside.any():
                continue
            idx = idx[inside]
            flat = (v[idx] * w + u[idx]).astype(np.int64)
            np.add.at(count, flat, 1)
    return count.reshape(h, w)


def main() -> None:
    d = Path("/home/sti/Work/986-SceneFlow/rgbd_dataset_freiburg1_desk")
    pairs = H.associate(d)
    fr = pairs[0]
    map1, map2, K = H.undistort_maps((480, 640), H.FR1_INTRINSICS)
    bgr = H.remap_rgb(H.load_rgb(fr.rgb_path), map1, map2)
    z = H.remap_depth(H.load_depth(fr.depth_path), map1, map2)
    z[(z < H.GEO_CFG["z_min"]) | (z > H.GEO_CFG["z_max"])] = 0.0

    rgb = bgr[..., ::-1].astype(np.float32) / 255.0
    tex = H.texture_mask(rgb, 0.6)
    r_cap = H.tex_boundary_limit(z, K, tex, tol_px=4.5)
    geo = H.compute_scene_geometry(
        z, K, H.GEO_CFG["eps"], H.GEO_CFG["gauss_sigma"], H.GEO_CFG["disc_rel"],
    )
    keep_geo = H.select_curvature_seeds(
        z, K, H.GEO_CFG["eps"], H.GEO_CFG["gauss_sigma"], H.GEO_CFG["z_min"],
        H.GEO_CFG["z_max"], H.GEO_CFG["disc_rel"], H.GEO_CFG["overlap"],
        H.GEO_CFG["r_max"], foreshorten=False, edge_fallback_fp=True,
        r_cap=r_cap, geo=geo,
    )
    keep_geo = keep_geo & ~tex
    g_curv = H.emit_curvature_discs(
        bgr, z, K, eps=H.GEO_CFG["eps"], gauss_sigma=H.GEO_CFG["gauss_sigma"],
        r_max=H.GEO_CFG["r_max"], shrink=H.GEO_CFG["shrink"],
        z_min=H.GEO_CFG["z_min"], z_max=H.GEO_CFG["z_max"],
        disc_rel=H.GEO_CFG["disc_rel"], mask=keep_geo, r_cap=r_cap, geo=geo,
    )
    print(f"curvature discs = {len(g_curv)}  (axis1/axis2 kept: "
          f"{g_curv.axis1 is not None})")

    count = count_coverage(g_curv, K, (480, 640))

    # curvature-filling region = non-texture valid-depth area
    region = (~tex) & (z > H.GEO_CFG["z_min"]) & (z < H.GEO_CFG["z_max"])
    c_region = count[region]

    total = region.sum()
    print(f"curvature region pixels = {total}")
    print("coverage multiplicity histogram (geometry overlap, no z-order):")
    print(f"  {'k':>3} {'pixels':>10} {'frac':>8}")
    for k in range(0, int(c_region.max()) + 1):
        nk = int((c_region == k).sum())
        print(f"  {k:>3} {nk:>10} {nk / total:>8.4f}")
    covered = c_region[c_region > 0]
    print(f"covered (>0) panting mean={covered.mean():.2f}  "
          f"med={np.median(covered):.1f}  p90={np.percentile(covered, 90):.1f}  "
          f"max={covered.max()}")


if __name__ == "__main__":
    main()