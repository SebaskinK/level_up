归档快照 2026-09-18

代码状态：S2 盘心默认修正 (+0.5) 已落盘并设为默认。
h_pipeline_final.py / incremental_hybrid.py 与 backup/20260918_003750 完全一致（本轮无新代码改动）。

本轮产物：分析归档见同目录 ARCHIVE_20260918.md。
结果：N=42235（基线42210），hard 1.27% / EWA 0.56%；右侧竖向裂缝定性为贴边角 sub-pixel 伪影，不改。
