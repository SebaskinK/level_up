"""Sequential RGB-D surfel fusion (A1): PURE FLOW identity, zero full-model ray-disc.

Frame 0: build_hybrid.
Later frames: 986 scene flow (DIS residual + rigid inlier expand) warps the
pixel->disc table; each existing disc's centre is flow-tracked to the new frame
and updated from a single pixel -- position/colour/normal running-averaged,
radius frozen (`update_hits_onepoint`, the one-point-per-disc anti-drift policy).

Contrast with sequential_fusion.py (baseline) and sequential_fusion_indexed.py:
  * owner is NEVER recomputed by full-model rasterize_discs(g, ...).
  * leftover pixels go STRAIGHT to build_hybrid -- no hit_old gate against the
    existing model (that gate is the "second ray-disc usage", removed here).
  * New discs register their claim ellipse into owner (from build_hybrid_region,
    claim-based), so the next frame's flow warp knows those pixels are already
    owned -- O(N_new), and no ray-disc for that either.
Poses are 986-produced, not TUM GT.
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np

SEQ = Path(__file__).resolve().parent
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SEQ))
sys.path.insert(0, str(SFLOW))

import h_pipeline_final as H  # noqa: E402
import incremental_hybrid as INC  # noqa: E402
from rigid_motion import depth_sigma, invert_point_motion  # noqa: E402
from scene_flow import compute_scene_flow  # noqa: E402
from se3 import se3_exp  # noqa: E402
from tum_io import (  # noqa: E402
    FR1_INTRINSICS,
    associate,
    interpolate_pose,
    load_depth,
    load_groundtruth,
    load_rgb,
    relative_camera_motion,
    remap_depth,
    remap_rgb,
    undistort_maps,
)

DATA = Path("/home/sti/Work/986-SceneFlow/rgbd_dataset_freiburg1_desk")
Z_MIN, Z_MAX = H.GEO_CFG["z_min"], H.GEO_CFG["z_max"]
TEX_Q = 0.6
K_SIGMA = 3.0
COLOR_GATE_K = 2.0          # colour gate: distance <= k * local texture sigma
COLOR_GATE_VAR_FLOOR = 1e-4  # floor so a flat wall (near-zero variance) still allows slight noise
TEX_BOUNDARY_TOL_PX = 4.5    # curvature discs may poke this far into the texture mask edge


@dataclass
class Model:
    g: H.Gaussians
    w: np.ndarray
    age: np.ndarray
    owner: np.ndarray  # int32 (H, W), -1 empty; in current camera
    birth: np.ndarray  # int32 (N,), frame index the disc was first created
    cnt: np.ndarray    # float32 (N,), observation count for colour/normal averaging


def _subset(g: H.Gaussians, keep: np.ndarray) -> H.Gaussians:
    ax1 = g.axis1[keep] if g.axis1 is not None else None
    ax2 = g.axis2[keep] if g.axis2 is not None else None
    return H.Gaussians(
        mu=g.mu[keep],
        normal=g.normal[keep],
        scale=g.scale[keep],
        quat=g.quat[keep],
        color=g.color[keep],
        alpha=g.alpha[keep],
        pixel=g.pixel[keep],
        axis1=ax1,
        axis2=ax2,
    )


def transform_to_next(g: H.Gaussians, R_10: np.ndarray, t_10: np.ndarray) -> H.Gaussians:
    """Point-motion X1 = R_10 X0 + t_10, same convention as 986 xi."""
    R = R_10.astype(np.float32)
    t = t_10.astype(np.float32)
    mu = g.mu @ R.T + t
    n = g.normal @ R.T
    nn = np.linalg.norm(n, axis=1, keepdims=True)
    n = n / np.maximum(nn, 1e-8)
    ax1 = g.axis1 @ R.T if g.axis1 is not None else None
    ax2 = g.axis2 @ R.T if g.axis2 is not None else None
    if ax1 is not None:
        ax1 = ax1 / np.maximum(np.linalg.norm(ax1, axis=1, keepdims=True), 1e-8)
    if ax2 is not None:
        ax2 = ax2 / np.maximum(np.linalg.norm(ax2, axis=1, keepdims=True), 1e-8)
    return H.Gaussians(
        mu=mu.astype(np.float32),
        normal=n.astype(np.float32),
        scale=g.scale,
        quat=H._quat_from_normal(n),
        color=g.color,
        alpha=g.alpha,
        pixel=g.pixel,
        axis1=None if ax1 is None else ax1.astype(np.float32),
        axis2=None if ax2 is None else ax2.astype(np.float32),
    )


def owner_from_raster(g: H.Gaussians, K: np.ndarray, shape: tuple[int, int]) -> np.ndarray:
    _, index, _ = H.rasterize_discs(g, K, shape)
    return index.astype(np.int32)


def warp_owner(owner: np.ndarray, u: np.ndarray, v: np.ndarray, valid: np.ndarray) -> np.ndarray:
    h, w = owner.shape
    out = np.full((h, w), -1, dtype=np.int32)
    ys, xs = np.where(valid & (owner >= 0))
    if xs.size == 0:
        return out
    x1 = np.clip(np.rint(xs + u[ys, xs]).astype(np.int32), 0, w - 1)
    y1 = np.clip(np.rint(ys + v[ys, xs]).astype(np.int32), 0, h - 1)
    out[y1, x1] = owner[ys, xs]
    return out



def _fill_owner_backward(owner_w, owner_src, sf):
    """If forward round missed, take identity from backward flow."""
    if sf.bw_u is None:
        return owner_w
    h, w = owner_w.shape
    xs_g, ys_g = np.meshgrid(np.arange(w, dtype=np.float32), np.arange(h, dtype=np.float32))
    x0 = xs_g + sf.bw_u
    y0 = ys_g + sf.bw_v
    inb = (x0 >= 0) & (x0 <= w - 1) & (y0 >= 0) & (y0 <= h - 1)
    x0i = np.clip(np.rint(x0).astype(np.int32), 0, w - 1)
    y0i = np.clip(np.rint(y0).astype(np.int32), 0, h - 1)
    src_id = owner_src[y0i, x0i]
    src_ok = inb & (src_id >= 0) & sf.valid[y0i, x0i]
    take = (owner_w < 0) & src_ok
    owner_w = owner_w.copy()
    owner_w[take] = src_id[take]
    return owner_w


# how far a leftover pixel searches for an old disc: the radius of a 9x9 window,
# matching the texture-variance aggregation window in the single-frame baseline.
ABSORB_NBR_R = 4  # (9x9 window) // 2


def point_to_plane(X: np.ndarray, mu: np.ndarray, n: np.ndarray) -> np.ndarray:
    return np.abs(np.einsum("ij,ij->i", X - mu, n))


def absorb_leftover_pixels(
    g: H.Gaussians,
    w_conf: np.ndarray,
    age: np.ndarray,
    cnt: np.ndarray,
    leftover: np.ndarray,
    owner: np.ndarray,
    z1: np.ndarray,
    bgr1: np.ndarray,
    K: np.ndarray,
    geo: H.CurvatureGeometry,
):
    """Light-weight per-pixel absorb of leftover strips into neighbour discs.

    "先判后建": a leftover pixel is either folded into an existing neighbour disc
    (weighted `sum_x/sum_wp` update -- the same algebra as the flow hit branch --
    plus the disc's in-plane footprint is nudged toward the pixel), or left alone
    so `build_hybrid_region` materialises it as a new disc. Only the positions /
    colours / scales of touched discs are updated in place; normals and quats stay
    frozen (small edge discs have no inlier population to re-fit, see OPEN_ITEMS
    §1.6.5).

    Gates, in order (all must pass for pixel p -> disc s):
      1. co-planar   : point-to-plane(p, s) < k * sigma(z)
      2. radius      : tangential offset of p on s's plane <= r_k(p), the
                       curvature sagitta budget r_k(p)=sqrt(2 eps/|k|) -- the
                       radius a flat disc may legally grow to at p. This is the
                       core gate: it separates "flat strip, absorb" from
                       "high-curvature pixel, build its own small disc".
      3. colour      : ||c(p) - c(s)|| <= k * local 9x9 texture sigma -- a flat
                       texture boundary (poster vs wall) has flat depth so gates
                       1-2 pass, yet it must NOT be absorbed across colours.
    No normal-angle gate: the flow identity already carries the geometry (see
    OPEN_ITEMS §1.1); these leftover pixels have NO flow identity, so the
    point-to-plane distance is the only orientation check. A pixel that sat on
    the disc's plane surrounds p with the same normal anyway once the sagitta
    gate shrinks r_k on curved strips.

    Returns `absorbed` (bool HxW). Updates `g.mu` / `g.color` / `g.scale` and
    `w_conf` / `cnt` in place; only the absorbed pixels' discs are touched.
    """
    h, w = leftover.shape
    ys, xs = np.where(leftover)
    if ys.size == 0:
        return np.zeros_like(leftover), 0

    n_all = len(g)
    X1 = H.backproject(z1, K)          # (H, W, 3)

    # r_k1 came from the caller's shared geometry (`geo`), the same field
    # `build_hybrid_region` reuses -- NOT recomputed here (OPEN_ITEMS §1.6.5).
    r_k = geo.r_k1

    # Neighbour discs per leftover pixel: ALL owners inside the (2R+1)x(2R+1)
    # window, R = ABSORB_NBR_R -- the same footprint as the 9x9 texture-variance
    # box the colour gate uses. Among candidates passing all three gates, take
    # the one with the smallest in-plane (tangential) offset d_proj, the exact
    # quantity the disc footprint growth consumes. Not the first box hit (that
    # had a top-left bias), and not full 3D Euclidean distance (that mixes in
    # the out-of-plane residual gate 1 already budgets separately).
    rgb1 = bgr1[..., ::-1].astype(np.float32) / 255.0
    Xp = X1[ys, xs]                        # (P,3) leftover points
    sig_p = depth_sigma(z1[ys, xs])        # (P,) gate-1 budget
    rk_p = r_k[ys, xs]                     # (P,) gate-2 budget (sagitta)
    rgb_p = rgb1[ys, xs]                   # (P,3) leftover colour
    sigma_tex = np.sqrt(np.maximum(
        H.texture_variance(rgb1, win=9)[ys, xs], COLOR_GATE_VAR_FLOOR,
    ))                                     # (P,) gate-3 budget (9x9 texture std)

    best = np.full(xs.shape[0], -1, dtype=np.int32)
    best_d = np.full(xs.shape[0], np.inf, dtype=np.float32)
    has_nbr = np.zeros(xs.shape[0], dtype=bool)
    for dy in range(-ABSORB_NBR_R, ABSORB_NBR_R + 1):
        for dx in range(-ABSORB_NBR_R, ABSORB_NBR_R + 1):
            if dy == 0 and dx == 0:
                continue
            ny = ys + dy
            nx = xs + dx
            inb = (ny >= 0) & (ny < h) & (nx >= 0) & (nx < w)
            cand = np.full(xs.shape[0], -1, dtype=np.int32)
            cand[inb] = owner[ny[inb], nx[inb]]
            has = inb & (cand >= 0)
            has_nbr |= has
            if not has.any():
                continue
            idx = np.flatnonzero(has)
            c = cand[idx]
            mu_c = g.mu[c]
            n_c = g.normal[c]
            # gate 1: point-to-plane
            d1 = point_to_plane(Xp[idx], mu_c, n_c)
            g1 = d1 < (K_SIGMA * sig_p[idx])
            # gate 2: tangential offset within the sagitta budget
            off = Xp[idx] - mu_c
            off_t = off - np.einsum("ij,ij->i", off, n_c)[:, None] * n_c
            d2 = np.linalg.norm(off_t, axis=1)
            g2 = d2 <= rk_p[idx]
            # gate 3: colour
            d3 = np.linalg.norm(rgb_p[idx] - g.color[c], axis=1)
            g3 = d3 <= (COLOR_GATE_K * sigma_tex[idx])
            ok = g1 & g2 & g3
            if not ok.any():
                continue
            i_ok = idx[ok]
            d_ok = d2[ok]
            improve = d_ok < best_d[i_ok]
            best[i_ok[improve]] = c[ok][improve]
            best_d[i_ok[improve]] = d_ok[improve]

    n_absorbed = int((best >= 0).sum())
    n_no_nbr = int((~has_nbr).sum())
    n_reject = int((has_nbr & (best < 0)).sum())
    print(f"[absorb-debug] n_leftover={xs.size} no_nbr={n_no_nbr} "
          f"reject={n_reject} pass={n_absorbed}", flush=True)

    have = best >= 0
    if not have.any():
        return np.zeros_like(leftover), 0

    ys, xs, best = ys[have], xs[have], best[have]
    Xp = Xp[have]

    # weighted update: position uses depth confidence (1/sigma^2), colour uses an
    # OBSERVATION COUNT (+1 per absorbed pixel) -- colour noise is independent of
    # depth, so it does not inherit the depth-sigma weight (Keller/ElasticFusion
    # surfel fusion convention).
    w_obs = 1.0 / np.maximum(depth_sigma(z1[ys, xs]) ** 2, 1e-8)
    rgb = bgr1[ys, xs][:, ::-1].astype(np.float64) / 255.0
    sum_x = np.zeros((n_all, 3), dtype=np.float64)
    sum_c = np.zeros((n_all, 3), dtype=np.float64)
    sum_wp = np.zeros(n_all, dtype=np.float64)
    sum_wc = np.zeros(n_all, dtype=np.float64)
    np.add.at(sum_x, best, Xp * w_obs[:, None])
    np.add.at(sum_wp, best, w_obs)
    np.add.at(sum_c, best, rgb)
    np.add.at(sum_wc, best, 1.0)

    touched = sum_wp > 0
    mu_old = g.mu[touched].copy()
    den = w_conf[touched] + sum_wp[touched]
    g.mu[touched] = (
        (w_conf[touched, None] * g.mu[touched] + sum_x[touched]) / den[:, None]
    ).astype(np.float32)
    col = sum_wc > 0
    den_c = cnt[col] + sum_wc[col]
    g.color[col] = (
        (cnt[col, None] * g.color[col] + sum_c[col]) / den_c[:, None]
    ).astype(np.float32)
    np.clip(g.color, 0.0, 1.0, out=g.color)
    w_conf[touched] = den.astype(np.float32)
    cnt[col] = den_c.astype(np.float32)
    age[touched] = 0
    # scale nudge: centre taken as the weighted mean; the radius is recomputed
    # from the centre movement so the old footprint's far edge stays covered,
    # then extended to the absorbed pixels (thin axis frozen).
    delta = g.mu[touched] - mu_old
    for k, t in enumerate(np.where(touched)[0]):
        sel = best == t
        o = Xp[sel] - g.mu[t]
        if g.axis1 is not None and g.axis2 is not None:
            d1 = float(abs(delta[k] @ g.axis1[t]))
            d2 = float(abs(delta[k] @ g.axis2[t]))
            p1 = float(np.abs(o @ g.axis1[t]).max())
            p2 = float(np.abs(o @ g.axis2[t]).max())
            g.scale[t, 0] = max(float(g.scale[t, 0]) + d1, p1)
            g.scale[t, 1] = max(float(g.scale[t, 1]) + d2, p2)
        else:
            dn = float(np.linalg.norm(delta[k]))
            pr = float(np.linalg.norm(o, axis=1).max())
            g.scale[t, 0] = g.scale[t, 1] = max(float(g.scale[t, 0]) + dn, pr)

    absorbed = np.zeros_like(leftover)
    absorbed[ys, xs] = True
    # register absorbed pixels as owned by their neighbour disc, so next frame's
    # flow warp carries their identity (otherwise they would re-surface as
    # leftover and need re-absorbing every frame).
    owner[ys, xs] = best
    return absorbed, int(xs.size)


def owner_birth_map(owner: np.ndarray, birth: np.ndarray) -> np.ndarray:
    """Per-pixel disc birth frame: birth[owner[y,x]], -1 where owner is empty.

    Convenience for the common `owner -> disc id -> birth` double index
    (visualisation, revisit/relayer analysis) without scattering `birth[owner]`
    everywhere. Returns int32 (H, W); caller must not read birth on the -1 cell.
    """
    h, w = owner.shape[:2]
    out = np.full((h, w), -1, dtype=np.int32)
    owned = owner >= 0
    out[owned] = birth[np.clip(owner[owned], 0, len(birth) - 1)]
    return out


def update_hits_onepoint(
    g: H.Gaussians,
    prev_mu: np.ndarray,
    w_conf: np.ndarray,
    age: np.ndarray,
    cnt: np.ndarray,
    sf,
    z1: np.ndarray,
    bgr1: np.ndarray,
    K: np.ndarray,
    normal_field: np.ndarray,
    n_ok: np.ndarray,
) -> tuple[int, int, int]:
    """One point per disc per frame (anti-drift hit update).

    Iterates over existing discs -- NOT over owner pixels. For each disc the
    previous-frame centre is flow-tracked to the current frame, and that single
    pixel supplies one depth/colour/normal observation which is cross-frame
    running-averaged. Same-frame region weighting is removed, so the crescent
    coverage of a small edge disc can no longer drag its centre directionally
    (that centroid pull was the directional-drift root cause).

    Updated in place: g.mu (position), g.color, g.normal, plus the tangent frame
    and quaternion re-derived from the new normal. g.scale (radius) is left
    frozen: a rigid static scene keeps a surface patch's world radius constant,
    and the old "grow radius toward the observations" logic was the growth half
    of the drift. Position uses the depth-sigma weight w_conf; colour / normal
    use the observation count `cnt` (not w_conf) so their running average does
    not inherit the depth-confidence growth of a long-lived disc. `cnt` and `age`
    accumulate once per written disc.

    Returns (n_upd, n_gate_fail, n_cand): n_cand is the number of discs whose
    centre tracked to a valid-depth pixel, n_gate_fail the subset failing the
    point-to-plane / colour gates, n_upd the subset actually written.
    """
    n = len(g)
    if n == 0:
        return 0, 0, 0
    h, w = z1.shape
    fx, fy, cx, cy = float(K[0, 0]), float(K[1, 1]), float(K[0, 2]), float(K[1, 2])

    # Previous-frame centre pixel, then forward-flow it to the current frame.
    zc = prev_mu[:, 2]
    px = fx * prev_mu[:, 0] / np.maximum(zc, 1e-6) + cx
    py = fy * prev_mu[:, 1] / np.maximum(zc, 1e-6) + cy
    pxi = np.rint(px).astype(np.int32)
    pyi = np.rint(py).astype(np.int32)
    inb = (pxi >= 0) & (pxi < w) & (pyi >= 0) & (pyi < h)
    pxi_c = np.clip(pxi, 0, w - 1)
    pyi_c = np.clip(pyi, 0, h - 1)
    cu = px + sf.u[pyi_c, pxi_c]
    cv = py + sf.v[pyi_c, pxi_c]
    fok = inb & sf.valid[pyi_c, pxi_c]
    cxi = np.rint(cu).astype(np.int32)
    cyi = np.rint(cv).astype(np.int32)
    cok = fok & (cxi >= 0) & (cxi < w) & (cyi >= 0) & (cyi < h)

    z_obs = np.zeros(n, dtype=np.float32)
    z_obs[cok] = z1[cyi[cok], cxi[cok]]
    dok = cok & (z_obs > Z_MIN) & (z_obs < Z_MAX)
    n_cand = int(dok.sum())
    if n_cand == 0:
        return 0, 0, 0

    idx = np.flatnonzero(dok)
    zi = z_obs[idx]
    X1 = np.stack(
        [(cxi[idx] - cx) * zi / fx, (cyi[idx] - cy) * zi / fy, zi], axis=1,
    )

    # gates: point-to-plane, then colour against the local 9x9 texture std.
    dist = point_to_plane(X1, g.mu[idx], g.normal[idx])
    g1 = dist < (K_SIGMA * depth_sigma(zi))
    rgb1 = bgr1[..., ::-1].astype(np.float32) / 255.0
    tex_sigma = np.sqrt(np.maximum(
        H.texture_variance(rgb1, win=9), COLOR_GATE_VAR_FLOOR,
    ))
    rgb_obs = rgb1[cyi[idx], cxi[idx]]
    dcol = np.linalg.norm(rgb_obs - g.color[idx], axis=1)
    g2 = dcol <= (COLOR_GATE_K * tex_sigma[cyi[idx], cxi[idx]])

    ok = g1 & g2
    n_gate_fail = int((~ok).sum())
    n_upd = int(ok.sum())
    if n_upd == 0:
        return 0, n_gate_fail, n_cand

    s = idx[ok]
    zi = zi[ok]
    w_obs = 1.0 / np.maximum(depth_sigma(zi) ** 2, 1e-8)

    # position: depth-confidence weighted cross-frame running average.
    den = w_conf[s] + w_obs
    g.mu[s] = (
        (w_conf[s, None] * g.mu[s] + w_obs[:, None] * X1[ok]) / den[:, None]
    ).astype(np.float32)
    w_conf[s] = den.astype(np.float32)

    # colour: observation-count weighted running average (not depth-sigma w_conf).
    rgb_ok = rgb1[cyi[s], cxi[s]]
    g.color[s] = (
        (cnt[s, None] * g.color[s] + rgb_ok) / (cnt[s, None] + 1.0)
    ).astype(np.float32)
    np.clip(g.color[s], 0.0, 1.0, out=g.color[s])

    # normal: observation-count weighted unit-sum, renormalised -- the same rule
    # as the single-frame curvature-disc inlier fit (unweighted unit-normal sum).
    n_obs = normal_field[cyi[s], cxi[s]]
    nvalid = n_ok[cyi[s], cxi[s]]
    if nvalid.any():
        ss = s[nvalid]
        acc = cnt[ss, None] * g.normal[ss] + n_obs[nvalid]
        accn = np.linalg.norm(acc, axis=1, keepdims=True)
        g.normal[ss] = (acc / np.maximum(accn, 1e-12)).astype(np.float32)
        if g.axis1 is not None and g.axis2 is not None:
            a1 = g.axis1[ss] - np.einsum(
                "ij,ij->i", g.axis1[ss], g.normal[ss],
            )[:, None] * g.normal[ss]
            a1 /= np.maximum(np.linalg.norm(a1, axis=1, keepdims=True), 1e-12)
            a2 = np.cross(g.normal[ss], a1)
            a2 /= np.maximum(np.linalg.norm(a2, axis=1, keepdims=True), 1e-12)
            g.axis1[ss] = a1.astype(np.float32)
            g.axis2[ss] = a2.astype(np.float32)
            g.quat[ss] = H._quat_from_frame(a1, a2, g.normal[ss]).astype(np.float32)

    age[s] = 0
    cnt[s] += 1.0
    return n_upd, n_gate_fail, n_cand


def recheck_owned_gate(
    g: H.Gaussians,
    owner: np.ndarray,
    z1: np.ndarray,
    K: np.ndarray,
) -> np.ndarray:
    """Per-pixel gate re-check for owner-covered pixels (leftover accuracy only).

    The one-point hit update still drives disc parameters; this is a separate,
    read-only pass that re-validates every owned pixel against the disc it maps
    to. A pixel whose point-to-plane distance falls outside its disc's gate is
    dropped from `owner` so it flows into the leftover branch
    (S2 / absorb / curvature). Point-to-plane only, matching the original hit
    gate -- no colour gate here, because a flow-tracked pixel is by construction
    the same surface point, so colour change is shading, not a texture boundary.
    """
    h, w = z1.shape
    fx, fy, cx, cy = float(K[0, 0]), float(K[1, 1]), float(K[0, 2]), float(K[1, 2])
    keep = np.zeros((h, w), dtype=bool)
    ys, xs = np.nonzero(owner >= 0)
    if ys.size == 0:
        return keep
    ids = owner[ys, xs]
    zi = z1[ys, xs]
    X = np.stack([(xs - cx) * zi / fx, (ys - cy) * zi / fy, zi], axis=1)
    ok = point_to_plane(X, g.mu[ids], g.normal[ids]) < (K_SIGMA * depth_sigma(zi))
    keep[ys[ok], xs[ok]] = True
    return keep


def fuse_frame(
    model: Model,
    sf,
    z0: np.ndarray,
    z1: np.ndarray,
    bgr1: np.ndarray,
    K: np.ndarray,
    age_max: int,
    w_min: float,
    frame_idx: int,
    R_10: np.ndarray | None = None,
    t_10: np.ndarray | None = None,
    no_absorb: bool = False,
) -> dict:
    h, w = z0.shape
    fx, fy, cx, cy = float(K[0, 0]), float(K[1, 1]), float(K[0, 2]), float(K[1, 2])
    if R_10 is None or t_10 is None:
        if sf.xi is None:
            raise RuntimeError("scene flow produced no twist")
        R_10, t_10 = se3_exp(sf.xi)
    g = transform_to_next(model.g, R_10, t_10)
    n_old = len(g)
    w_conf = model.w.copy()
    age = model.age.copy() + 1
    birth = model.birth.copy()
    cnt = model.cnt.copy()

    owner_w = warp_owner(model.owner, sf.u, sf.v, sf.valid)
    expanded = sf.expanded if sf.expanded is not None else np.zeros((h, w), dtype=bool)
    owner_w = _fill_owner_backward(owner_w, model.owner, sf)

    # Shared geometry is computed once per frame and reused by both the hit
    # normal lookup and the leftover branch (S2/absorb/curvature).
    geo = H.compute_scene_geometry(
        z1, K, H.GEO_CFG["eps"], H.GEO_CFG["gauss_sigma"], H.GEO_CFG["disc_rel"],
    )
    n_upd, n_gate_fail, n_cand = update_hits_onepoint(
        g, model.g.mu, w_conf, age, cnt, sf, z1, bgr1, K, geo.normal, geo.n_ok,
    )

    hit = owner_w >= 0
    gate_keep = recheck_owned_gate(g, owner_w, z1, K)
    owned = hit & gate_keep
    n_gate_drop = int(hit.sum() - owned.sum())
    leftover = (z1 > Z_MIN) & (z1 < Z_MAX) & ~owned
    n_new = 0
    n_absorb = 0
    new_px = np.zeros((0, 2), np.int32)
    n_s2 = 0
    n_curv = 0
    owner_curv = None

    # Leftover re-order: (1) S2 fill the texture part, (2) absorb what remains
    # into old/S2 discs, (3) curvature fill the still-uncovered non-texture part.
    # Geometry / texture mask / r_cap are computed once and shared by all three
    # stages (the r_k1 the absorb gates reuse lives inside `geo`).
    if leftover.any():
        n_leftover = int(leftover.sum())
        tex_mask_full = H.texture_mask(
            bgr1[..., ::-1].astype(np.float32) / 255.0, TEX_Q,
        )
        r_cap = H.tex_boundary_limit(z1, K, tex_mask_full, tol_px=TEX_BOUNDARY_TOL_PX)

        # (1) S2 fill.
        g_s2, owner_s2 = INC.s2_parts(bgr1, z1, K, tex_mask_full, leftover, geo)
        n_s2 = len(g_s2)
        owner_abs = owner_w.astype(np.int32).copy()
        if n_s2:
            s2_glob = np.where(owner_s2 >= 0, n_old + owner_s2, -1).astype(np.int32)
            owner_abs = np.where(s2_glob >= 0, s2_glob, owner_abs)
            g = H.concatenate_gaussians([g, g_s2])
            w_conf = np.concatenate([w_conf, np.ones(n_s2, dtype=np.float32)])
            age = np.concatenate([age, np.zeros(n_s2, dtype=np.int32)])
            birth = np.concatenate([birth, np.full(n_s2, frame_idx, dtype=np.int32)])
            cnt = np.concatenate([cnt, np.ones(n_s2, dtype=np.float32)])

        # (2) absorb the pixels not owned by old or S2 discs.
        remaining = leftover & ~(owner_abs >= 0)
        if not no_absorb and remaining.any():
            absorbed, n_absorb = absorb_leftover_pixels(
                g, w_conf, age, cnt, remaining, owner_abs, z1, bgr1, K, geo,
            )
            if n_absorb:
                remaining = remaining & ~absorbed

        # (3) curvature fill on the still-uncovered non-texture leftover.
        g_curv, owner_curv = INC.curvature_parts(
            bgr1, z1, K, remaining, tex_mask_full, geo, r_cap,
        )
        n_curv = len(g_curv)
        if n_curv:
            g = H.concatenate_gaussians([g, g_curv])
            w_conf = np.concatenate([w_conf, np.ones(n_curv, dtype=np.float32)])
            age = np.concatenate([age, np.zeros(n_curv, dtype=np.int32)])
            birth = np.concatenate([birth, np.full(n_curv, frame_idx, dtype=np.int32)])
            cnt = np.concatenate([cnt, np.ones(n_curv, dtype=np.float32)])

        n_new = n_s2 + n_curv
        if n_new:
            if n_s2 and n_curv:
                new_px = np.vstack([g_s2.pixel, g_curv.pixel]).astype(np.int32)
            elif n_s2:
                new_px = g_s2.pixel.copy()
            else:
                new_px = g_curv.pixel.copy()
        else:
            new_px = np.zeros((0, 2), np.int32)
    else:
        n_leftover = 0
        owner_abs = owner_w.astype(np.int32).copy()

    # Indexed owner (n -> n+1): flow-warped identity (+ absorbed pixels, which
    # `absorb_leftover_pixels` registers directly into `owner_abs`) + new discs'
    # claim footprints. S2 discs precede curvature discs, so curvature ids are
    # offset past the S2 block. No ray-disc, no full-model rasterize_discs.
    owner_pre = owner_abs.astype(np.int32).copy()
    if n_curv and owner_curv is not None:
        curv_glob = np.where(owner_curv >= 0, n_old + n_s2 + owner_curv, -1).astype(np.int32)
        take = (curv_glob >= 0) & (owner_pre < 0)
        owner_pre[take] = curv_glob[take]

    n_pre = len(g)
    dead = (age > age_max) & (w_conf < w_min)
    if dead.any() and (~dead).sum() >= 8:
        keep = ~dead
        remap = np.full(n_pre, -1, dtype=np.int32)
        remap[keep] = np.arange(int(keep.sum()), dtype=np.int32)
        g = _subset(g, keep)
        w_conf = w_conf[keep]
        age = age[keep]
        birth = birth[keep]
        cnt = cnt[keep]
        valid_owner = owner_pre >= 0
        owner = np.where(
            valid_owner, remap[np.clip(owner_pre, 0, n_pre - 1)], -1
        ).astype(np.int32)
    else:
        owner = owner_pre

    model.g, model.w, model.age, model.owner = g, w_conf, age, owner
    model.birth = birth
    model.cnt = cnt
    depth_valid = (z1 > Z_MIN) & (z1 < Z_MAX)
    n_owned = int(np.sum((owner >= 0) & depth_valid))
    return {
        "n": len(g),
        "n_upd": n_upd,
        "n_new": n_new,
        "n_absorb": n_absorb,
        "n_leftover": n_leftover,
        "n_gate_fail": n_gate_fail,
        "n_gate_drop": n_gate_drop,
        "n_owned": n_owned,
        "n_cand": int(n_cand),
        "valid_frac": float(sf.valid.mean()),
        "expanded_frac": float(expanded.mean()),
        "leftover_frac": float(leftover.mean()),
        "n_dead": int(dead.sum()) if dead.size else 0,
        "leftover": leftover,
        "new_px": new_px,
        "hit": hit,
        "owner_final": owner,          # (H, W) int32; -1 empty
        "birth": birth,                # (N,) birth frame per disc
        "z1": z1,                      # for backprojecting the viz in-world
    }



def _draw_new(bgr, leftover, hit, new_px, rec) -> np.ndarray:
    vis = bgr.copy()
    overlay = vis.astype(np.float32)
    leftover_bgr = (0, 160, 255)
    new_bgr = (0, 0, 255)
    m = leftover
    overlay[m] = 0.45 * overlay[m] + 0.55 * np.array(leftover_bgr, np.float32)
    vis = np.clip(overlay, 0, 255).astype(np.uint8)
    for u, v in new_px:
        cv2.circle(vis, (int(u), int(v)), 2, new_bgr, -1, lineType=cv2.LINE_AA)
    h, w = vis.shape[:2]
    bar = np.full((52, w, 3), 30, np.uint8)
    items = [
        (leftover_bgr, "leftover mask (orphan / gate-fail)"),
        (new_bgr, "new disc centres"),
    ]
    x = 8
    for col, name in items:
        cv2.rectangle(bar, (x, 8), (x + 16, 24), col, -1)
        cv2.rectangle(bar, (x, 8), (x + 16, 24), (240, 240, 240), 1)
        cv2.putText(bar, name, (x + 22, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.45,
                    (220, 220, 220), 1, cv2.LINE_AA)
        x += 22 + 8 * len(name) + 28
    cv2.putText(
        bar,
        f"new={rec['n_new']} leftover={100*rec['leftover_frac']:.1f}% "
        f"upd={rec['n_upd']} N={rec['n']}",
        (8, 44), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (220, 220, 220), 1, cv2.LINE_AA,
    )
    return np.vstack([vis, bar])


def _draw_ownership(bgr, owner: np.ndarray, birth: np.ndarray,
                    cur_frame: int) -> np.ndarray:
    """Per-pixel ownership, three discrete classes (legend colours == pixel colours).

    Classes (mutually exclusive):
      * NEW this frame      (birth == cur_frame)  -> CYAN   (0,255,255)
      * OLD tracked         (birth <  cur_frame)  -> GREEN  (0,255,0)
      * NOT owned (no flow identity)              -> GRAY   (dimmed)
    """
    h, w = owner.shape[:2]
    owned = owner >= 0
    birth_map = owner_birth_map(owner, birth)
    is_new = owned & (birth_map == cur_frame)
    is_old = owned & (birth_map < cur_frame)

    out = np.full((h, w, 3), 60, np.uint8)
    out[ownership_not_owned := ~owned] = (
        0.55 * bgr[~owned] + 0.45 * np.array([40, 40, 40], np.float32)
    ).astype(np.uint8)
    out[is_old] = (0, 255, 0)      # BGR green
    out[is_new] = (0, 0, 255)    # BGR red

    # legend bar (exact same colours)
    bar = np.full((64, w, 3), 30, np.uint8)
    items = [
        ((0, 0, 255), "NEW this frame (birth == cur)"),
        ((0, 255, 0),   "OLD tracked (birth < cur)"),
        ((70, 70, 70),  "NOT owned (no flow identity)"),
    ]
    x = 8
    for col, name in items:
        cv2.rectangle(bar, (x, 10), (x + 18, 30), col, -1)
        cv2.rectangle(bar, (x, 10), (x + 18, 30), (240, 240, 240), 1)
        cv2.putText(bar, name, (x + 24, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.42,
                    (220, 220, 220), 1, cv2.LINE_AA)
        x += 24 + 8 * len(name) + 30
    cv2.putText(bar, f"pixel ownership  (frame {cur_frame}): "
                     f"new={int(is_new.sum())} old={int(is_old.sum())} "
                     f"none={int((~owned).sum())}",
                (8, 54), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (220, 220, 220), 1, cv2.LINE_AA)
    return np.vstack([out, bar])


def load_pair(pairs, i, map1, map2):
    p = pairs[i]
    bgr = remap_rgb(load_rgb(p.rgb_path), map1, map2)
    z = remap_depth(load_depth(p.depth_path), map1, map2)
    z[z < Z_MIN] = 0.0
    z[z > Z_MAX] = 0.0
    return bgr, z, p.t_rgb


def write_ply(path: Path, g: H.Gaussians) -> None:
    """Standard 3DGS PLY (binary_little_endian, sh_degree 0).

    Conventions matched to the reference rasterizer:
      * f_dc = (linear_rgb - 0.5) / SH_C0
      * opacity = logit(alpha)
      * scale = log([r1, r2, thin]) along rot's x/y/z (thin = normal)
      * rot = wxyz quaternion, shortest axis aligned to normal
    """
    n = len(g)
    sh_c0 = 0.28209479177387814
    rgb = np.clip(g.color, 0.0, 1.0).astype(np.float64)
    f_dc = (rgb - 0.5) / sh_c0
    alpha = np.clip(g.alpha, 1e-6, 1.0 - 1e-6).astype(np.float64)
    opacity = np.log(alpha / (1.0 - alpha))
    scale = np.log(np.maximum(g.scale, 1e-12).astype(np.float64))
    rot = g.quat.astype(np.float64)
    header = (
        "ply\n"
        "format binary_little_endian 1.0\n"
        f"element vertex {n}\n"
        "property float x\nproperty float y\nproperty float z\n"
        "property float nx\nproperty float ny\nproperty float nz\n"
        "property float f_dc_0\nproperty float f_dc_1\nproperty float f_dc_2\n"
        "property float opacity\n"
        "property float scale_0\nproperty float scale_1\nproperty float scale_2\n"
        "property float rot_0\nproperty float rot_1\nproperty float rot_2\nproperty float rot_3\n"
        "end_header\n"
    )
    cols = np.concatenate(
        [g.mu, g.normal, f_dc, opacity[:, None], scale, rot], axis=1
    ).astype(np.float64)
    with path.open("wb") as f:
        f.write(header.encode("ascii"))
        f.write(cols.astype("<f4").tobytes())


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--max-pairs", type=int, default=10)
    p.add_argument("--out", default=str(SEQ.parent / "output_K"))
    p.add_argument("--age-max", type=int, default=8)
    p.add_argument("--w-min", type=float, default=2.0)
    p.add_argument("--save-ply", action="store_true")
    p.add_argument("--save-vis", action="store_true", default=True)
    p.add_argument("--no-save-vis", action="store_false", dest="save_vis")
    p.add_argument("--vis-owner", action="store_true",
                   help="also write per-pixel owner visualizations (owner_XXXX.png)")
    p.add_argument("--gt-pose", action="store_true",
                   help="use TUM ground-truth camera motion instead of 986 xi")
    p.add_argument("--no-absorb", action="store_true",
                   help="skip absorb_leftover_pixels: every leftover pixel goes "
                        "straight to build_hybrid_region (edge-fallback default).")
    args = p.parse_args()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    vis_dir = out / "vis"
    if args.save_vis or args.vis_owner:
        vis_dir.mkdir(exist_ok=True)

    pairs = associate(DATA, max_dt=0.02)
    if args.max_pairs > 0:
        pairs = pairs[: args.max_pairs + 1]
    if args.gt_pose:
        gt_ts, gt_t, gt_q = load_groundtruth(DATA / "groundtruth.txt")
    sample = load_rgb(pairs[0].rgb_path)
    h, w = sample.shape[:2]
    map1, map2, K = undistort_maps((h, w), FR1_INTRINSICS)

    bgr0, z0, _ = load_pair(pairs, 0, map1, map2)
    g0, _, _, owner0 = H.build_hybrid_with_owner(bgr0, z0, K, TEX_Q)
    model = Model(
        g=g0,
        w=np.ones(len(g0), dtype=np.float32),
        age=np.zeros(len(g0), dtype=np.int32),
        owner=owner0,
        birth=np.zeros(len(g0), dtype=np.int32),
        cnt=np.ones(len(g0), dtype=np.float32),
    )
    rows = [{"i": -1, "n": len(g0), "n_upd": 0, "n_new": len(g0),
             "n_absorb": 0, "n_leftover": 0, "n_gate_fail": 0, "n_gate_drop": 0,
             "valid_frac": 1.0,
             "expanded_frac": 0.0, "leftover_frac": 0.0, "n_dead": 0,
             "n_owned": 0, "n_cand": 0}]
    print(f"[init] N={len(g0)}", flush=True)

    prev_sf = None
    prev_dt = 1.0
    bgr_a, z_a = bgr0, z0
    for i in range(len(pairs) - 1):
        bgr_b, z_b, _ = load_pair(pairs, i + 1, map1, map2)
        dt = pairs[i + 1].t_rgb - pairs[i].t_rgb
        sf = compute_scene_flow(
            bgr_a, bgr_b, z_a, z_b, K,
            prev=prev_sf, dt=dt, prev_dt=prev_dt,
        )
        R_10 = t_10 = None
        if args.gt_pose:
            m0 = interpolate_pose(pairs[i].t_rgb, gt_ts, gt_t, gt_q)
            m1 = interpolate_pose(pairs[i + 1].t_rgb, gt_ts, gt_t, gt_q)
            if m0 is None or m1 is None:
                raise RuntimeError(f"GT pose out of range at pair {i}")
            R_eg, t_eg = relative_camera_motion(*m0, *m1)
            R_10, t_10 = invert_point_motion(R_eg, t_eg)
        rec = fuse_frame(model, sf, z_a, z_b, bgr_b, K, args.age_max, args.w_min,
                         i, R_10, t_10, no_absorb=args.no_absorb)
        rec["i"] = i
        if args.save_vis:
            vis = _draw_new(bgr_b, rec["leftover"], rec["hit"], rec["new_px"], rec)
            cv2.imwrite(str(vis_dir / f"new_{i:04d}.png"), vis)
        if args.save_vis or args.vis_owner:
            vis2 = _draw_ownership(bgr_b, rec["owner_final"], rec["birth"], i)
            cv2.imwrite(str(vis_dir / f"owner_{i:04d}.png"), vis2)
        rec.pop("leftover", None)
        rec.pop("new_px", None)
        rec.pop("hit", None)
        rec.pop("owner_final", None)
        rec.pop("birth", None)
        rec.pop("z1", None)
        rows.append(rec)
        print(
            f"[{i:03d}] N={rec['n']} upd={rec['n_upd']} new={rec['n_new']} "
            f"abs={rec['n_absorb']} left_px={rec['n_leftover']} "
            f"owned={rec['n_owned']} cand={rec['n_cand']} "
            f"fail={rec['n_gate_fail']} drop={rec['n_gate_drop']} "
            f"valid={rec['valid_frac']:.2f} "
            f"exp={rec['expanded_frac']:.2f} left={rec['leftover_frac']:.2f} "
            f"dead={rec['n_dead']}",
            flush=True,
        )
        bgr_a, z_a = bgr_b, z_b
        prev_sf, prev_dt = sf, dt

    keys = list(rows[0].keys())
    with (out / "fusion.csv").open("w", newline="") as f:
        wri = csv.DictWriter(f, fieldnames=keys)
        wri.writeheader()
        wri.writerows(rows)
    summary = {
        "n_frames": len(rows) - 1,
        "n_init": rows[0]["n"],
        "n_final": rows[-1]["n"],
        "n_upd_mean": float(np.mean([r["n_upd"] for r in rows[1:]])),
        "n_new_mean": float(np.mean([r["n_new"] for r in rows[1:]])),
    }
    (out / "summary.json").write_text(json.dumps(summary, indent=2))
    if args.save_ply:
        write_ply(out / "model.ply", model.g)
    print(json.dumps(summary, indent=2))
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
