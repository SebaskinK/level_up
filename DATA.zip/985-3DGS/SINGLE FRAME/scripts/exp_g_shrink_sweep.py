"""Sweep shrink (and optionally min_nz) while keeping overlap=0.6 fixed.

Reports coverage, hole fraction, depth error, primitive count, and small-hole
statistics for frame 0 of fr1/desk.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from exp_e_curvature_sample import curvature_mask  # noqa: E402
from gaussian_build import (  # noqa: E402
    build_gaussians_curvature,
    depth_discontinuity_mask,
    depth_valid,
    normals_from_depth,
    prefilter_depth,
)
from metrics import evaluate, rasterize_discs  # noqa: E402
from rgbd_io import (  # noqa: E402
    FR1_INTRINSICS,
    associate,
    camera_matrix,
    load_depth,
    load_rgb,
    remap_depth,
    remap_rgb,
    undistort_maps,
)

BASE_CFG = dict(
    eps=0.001,
    gauss_sigma=3.0,
    r_max=0.05,
    disc_rel=0.02,
    overlap=0.6,
    z_min=0.4,
    z_max=4.0,
)


def build(bgr, z, K, shrink, min_nz=0.15):
    keep = curvature_mask(
        z, K,
        BASE_CFG["eps"], BASE_CFG["gauss_sigma"],
        BASE_CFG["z_min"], BASE_CFG["z_max"],
        BASE_CFG["disc_rel"], BASE_CFG["overlap"], BASE_CFG["r_max"],
        foreshorten=False,
        aniso_claim=True,
        min_nz=min_nz,
        edge_fallback_fp=True,
    )
    g = build_gaussians_curvature(
        bgr, z, K,
        eps=BASE_CFG["eps"],
        gauss_sigma=BASE_CFG["gauss_sigma"],
        r_max=BASE_CFG["r_max"],
        shrink=shrink,
        normal_mode="disc_inliers",
        z_min=BASE_CFG["z_min"],
        z_max=BASE_CFG["z_max"],
        disc_rel=BASE_CFG["disc_rel"],
        mask=keep,
        prefilter="gauss",
        prefilter_size=int(BASE_CFG["gauss_sigma"]),
    )
    return g, keep


def eval_setup(z, K):
    zd = depth_valid(z)
    z_grad = prefilter_depth(z, "gauss", int(BASE_CFG["gauss_sigma"]), valid=zd)
    normal_ref, n_ok = normals_from_depth(z_grad, K)
    eval_mask = (
        n_ok & zd
        & (z > BASE_CFG["z_min"])
        & (z < BASE_CFG["z_max"])
        & ~depth_discontinuity_mask(z, BASE_CFG["disc_rel"], valid=zd)
    )
    return normal_ref, eval_mask


def small_hole_stats(hole_mask):
    """Return (n_components, n_small_components, small_px, total_hole_px)."""
    from cv2 import connectedComponentsWithStats
    num, labels, stats, _ = connectedComponentsWithStats(hole_mask.astype(np.uint8), connectivity=8)
    # component 0 is background
    areas = stats[1:, cv2.CC_STAT_AREA]
    n_small = int((areas <= 2).sum())
    small_px = int(areas[areas <= 2].sum())
    return num - 1, n_small, small_px, int(hole_mask.sum())


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--data", default=str(
        ROOT.parent.parent / "986-SceneFlow" / "rgbd_dataset_freiburg1_desk"))
    p.add_argument("--out", default=str(ROOT.parent / "output_G_refactor"))
    p.add_argument("--frames", type=int, default=3)
    args = p.parse_args()

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    K = camera_matrix(FR1_INTRINSICS)

    pairs = associate(Path(args.data))
    sample = load_rgb(pairs[0].rgb_path)
    map1, map2, Ku = undistort_maps(sample.shape[:2], FR1_INTRINSICS)

    shrink_values = [0.70, 0.80, 0.85, 0.90, 0.95, 1.00]
    min_nz_values = [0.05, 0.10, 0.15, 0.20]

    print("=" * 110)
    print("Sweep 1: shrink with min_nz=0.15")
    print(f"{'shrink':>8}{'N':>8}{'cover':>8}{'hole%':>8}{'rmse':>8}{'med':>8}{'n_area':>8}{'r_med':>8}{'comp':>8}{'small':>8}{'small_px':>10}")
    print("-" * 110)
    for shrink in shrink_values:
        row_acc = []
        for i, fr in enumerate(pairs[:args.frames]):
            bgr = remap_rgb(load_rgb(fr.rgb_path), map1, map2)
            z = remap_depth(load_depth(fr.depth_path), map1, map2)
            normal_ref, eval_mask = eval_setup(z, K)
            g, _ = build(bgr, z, K, shrink=shrink, min_nz=0.15)
            m = evaluate(g, z, bgr, normal_ref, eval_mask, K)
            row_acc.append(m)

            if i == 0:
                depth, _, _ = rasterize_discs(g, K, z.shape)
                hit = np.isfinite(depth) & eval_mask
                hole = eval_mask & ~hit
                vis = bgr.copy()
                vis[hole] = (0, 0, 255)
                cv2.imwrite(str(out_dir / f"hole_shrink{shrink:.2f}_f0.png"), vis)
                n_comp, n_small, small_px, total_hole_px = small_hole_stats(hole)

        avg = {k: float(np.mean([r[k] for r in row_acc])) for k in row_acc[0]}
        print(f"{shrink:>8.2f}{avg['n_gaussians']:>8.1f}{avg['coverage']:>8.3f}{avg['hole_frac']*100:>8.2f}"
              f"{avg['depth_rmse_mm']:>8.2f}{avg['depth_med_mm']:>8.2f}{avg['normal_area_med_deg']:>8.2f}"
              f"{avg['radius_med_mm']:>8.2f}{n_comp:>8d}{n_small:>8d}{small_px:>10d}/{total_hole_px}")

    print("\n" + "=" * 110)
    print("Sweep 2: min_nz with shrink=0.85")
    print(f"{'min_nz':>8}{'N':>8}{'cover':>8}{'hole%':>8}{'rmse':>8}{'med':>8}{'n_area':>8}{'r_med':>8}{'comp':>8}{'small':>8}{'small_px':>10}")
    print("-" * 110)
    for min_nz in min_nz_values:
        row_acc = []
        for i, fr in enumerate(pairs[:args.frames]):
            bgr = remap_rgb(load_rgb(fr.rgb_path), map1, map2)
            z = remap_depth(load_depth(fr.depth_path), map1, map2)
            normal_ref, eval_mask = eval_setup(z, K)
            g, _ = build(bgr, z, K, shrink=0.85, min_nz=min_nz)
            m = evaluate(g, z, bgr, normal_ref, eval_mask, K)
            row_acc.append(m)

            if i == 0:
                depth, _, _ = rasterize_discs(g, K, z.shape)
                hit = np.isfinite(depth) & eval_mask
                hole = eval_mask & ~hit
                vis = bgr.copy()
                vis[hole] = (0, 0, 255)
                cv2.imwrite(str(out_dir / f"hole_minnz{min_nz:.2f}_f0.png"), vis)
                n_comp, n_small, small_px, total_hole_px = small_hole_stats(hole)

        avg = {k: float(np.mean([r[k] for r in row_acc])) for k in row_acc[0]}
        print(f"{min_nz:>8.2f}{avg['n_gaussians']:>8.1f}{avg['coverage']:>8.3f}{avg['hole_frac']*100:>8.2f}"
              f"{avg['depth_rmse_mm']:>8.2f}{avg['depth_med_mm']:>8.2f}{avg['normal_area_med_deg']:>8.2f}"
              f"{avg['radius_med_mm']:>8.2f}{n_comp:>8d}{n_small:>8d}{small_px:>10d}/{total_hole_px}")


if __name__ == "__main__":
    main()
