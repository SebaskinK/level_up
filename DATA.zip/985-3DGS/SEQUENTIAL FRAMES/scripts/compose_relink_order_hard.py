"""Hard (ray-disc) render A/B for the relink-order ablation: GT | A | B, full + left crop."""

from __future__ import annotations

import sys
from pathlib import Path

import cv2
import numpy as np

SEQ = Path(__file__).resolve().parent
A = SEQ.parent / "output_f0_80frame_olddraw"
B = SEQ.parent / "output_f0_80frame_flowfirst"


def cap(img, text, h=30):
    bar = np.full((h, img.shape[1], 3), 20, np.uint8)
    cv2.putText(bar, text, (8, 21), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                (235, 235, 235), 1, cv2.LINE_AA)
    return np.vstack([img, bar])


def dif(img_a, img_b):
    d = np.abs(img_a.astype(np.int16) - img_b.astype(np.int16)).max(axis=2)
    v = np.zeros((*d.shape, 3), np.uint8)
    v[..., 2] = np.clip(d * 3, 0, 255)          # red = disagreement
    return v


gt = cv2.imread(str(A / "f0_gt.png"))
ha = cv2.imread(str(A / "f0_hard.png"))
hb = cv2.imread(str(B / "f0_hard.png"))
gt, ha, hb = gt[:480], ha[:480], hb[:480]     # drop the baked-in caption bar
h = min(gt.shape[0], ha.shape[0], hb.shape[0])
gt, ha, hb = gt[:h], ha[:h], hb[:h]

full = np.hstack([
    cap(gt, "GT frame0 (undistorted)"),
    cap(ha, "A relink-first (current default) 81f"),
    cap(hb, "B flow-first (legacy relink order) 81f"),
    cap(dif(ha, hb), "|A-B| hard render (red = differs)"),
])
out = B / "cmp_relink_order_hard.png"
cv2.imwrite(str(out), full)

crop = np.hstack([cap(x[:, :224], t) for x, t in
                  [(gt, "GT"), (ha, "A relink-first"), (hb, "B flow-first"),
                   (dif(ha, hb), "|A-B|")]])
crop = cv2.resize(crop, None, fx=2.0, fy=2.0, interpolation=cv2.INTER_NEAREST)
out2 = B / "cmp_relink_order_hard_left.png"
cv2.imwrite(str(out2), crop)
print("saved ->", out)
print("saved ->", out2)
d = np.abs(ha.astype(np.int16) - hb.astype(np.int16)).max(axis=2)
print(f"hard-render disagreement: mean={d.mean():.2f}/255  "
      f"px>20 = {int((d > 20).sum())} ({100 * (d > 20).mean():.2f}%)")