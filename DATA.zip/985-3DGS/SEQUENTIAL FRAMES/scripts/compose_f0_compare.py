"""Compose the 0/3/6-frame f0 renderings into side-by-side comparison montages."""

from pathlib import Path

import cv2
import numpy as np

SEQ = Path(__file__).resolve().parent
BASE = SEQ.parent
LABELS = ["GT", "f0 only", "first 3", "first 6"]
DIRS = [BASE / "output_f0_0frame", BASE / "output_f0_0frame",
        BASE / "output_f0_3frame", BASE / "output_f0_6frame"]


def load(p):
    img = cv2.imread(str(p))
    if img is None:
        raise FileNotFoundError(p)
    return img


def montage(images, labels, out, bar_h=36):
    h, w = images[0].shape[:2]
    bar = np.full((bar_h, w * len(images), 3), 30, np.uint8)
    if labels:
        for i, lab in enumerate(labels):
            cv2.putText(bar, lab, (i * w + 8, bar_h - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (240, 240, 240), 1, cv2.LINE_AA)
    row = np.hstack(images)
    cv2.imwrite(str(out), np.vstack([bar, row]))
    print(f"wrote {out}")


def main():
    outdir = BASE / "output_f0_compare"
    outdir.mkdir(parents=True, exist_ok=True)

    for kind in ["ellipse", "hard", "ewa", "depth"]:
        if kind == "depth":
            gt_name = "f0_depth_gt.png"
            m_name = "f0_depth_hard.png"
        else:
            gt_name = "f0_gt.png"
            m_name = f"f0_{kind}.png"
        imgs = [load(DIRS[1] / gt_name)]
        for d in DIRS[1:]:
            imgs.append(load(d / m_name))
        # ensure uniform size
        h = min(i.shape[0] for i in imgs)
        w = min(i.shape[1] for i in imgs)
        imgs = [i[:h, :w] for i in imgs]
        montage(imgs, LABELS, outdir / f"cmp_{kind}.png")


if __name__ == "__main__":
    main()