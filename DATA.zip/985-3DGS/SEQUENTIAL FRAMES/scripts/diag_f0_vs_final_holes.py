"""Is the ray hole already present in the frame-0-ONLY model, or introduced by
sequential fusion? Cheap check: run build_hybrid on frame 0 alone and count
valid-region ray holes, then compare with the 10-frame final model."""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

SEQ = Path(__file__).resolve().parent
SINGLE = SEQ.parent.parent / "SINGLE FRAME" / "scripts"
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SFLOW))
sys.path.insert(0, str(SINGLE))
sys.path.insert(0, str(SEQ))

import h_pipeline_final as H            # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402

OUT = SEQ.parent / "output_discmask_align"


def main() -> None:
    pairs = SF.associate(SF.DATA, max_dt=0.02)[: 11]
    sample = SF.load_rgb(pairs[0].rgb_path)
    h, w = sample.shape[:2]
    map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)
    bgr0, z0, _ = SF.load_pair(pairs, 0, map1, map2)

    g0, _, _, _ = H.build_hybrid_with_owner(bgr0, z0, K, SF.TEX_Q)
    depth0, idx0, _ = H.rasterize_discs(g0, K, (h, w))
    valid = (z0 > SF.Z_MIN) & (z0 < SF.Z_MAX)
    hole0 = ~np.isfinite(depth0) & valid

    depth_f = np.load(OUT / "f0_depth_hard.npy")
    hole_f = (depth_f == 0) & valid

    print(f"frame0-only model: N={len(g0)}  ray holes(valid)={hole0.sum()} "
          f"({100.0*hole0.sum()/valid.sum():.3f}%)")
    print(f"10-frame model:    N={None}  ray holes(valid)={hole_f.sum()} "
          f"({100.0*hole_f.sum()/valid.sum():.3f}%)")
    same = hole0 & hole_f
    intro = hole_f & ~hole0
    persist = hole_f & hole0
    print(f"holes present in BOTH: {same.sum()}")
    print(f"holes ONLY in frame0-only: {(hole0 & ~hole_f).sum()}")
    print(f"holes ONLY in 10-frame (introduced by fusion): {intro.sum()}")

    def colinfo(m, name):
        if not m.any():
            print(f"  {name}: none")
            return
        ys, xs = np.nonzero(m)
        ch = np.bincount(xs, minlength=w)
        nz = np.flatnonzero(ch > 0)
        print(f"  {name} (n={m.sum()}): cols [{xs.min()},{xs.max()}] "
              f"rows [{ys.min()},{ys.max()}]  right-half={(xs >= w//2).sum()}")
        # right-half condensed column histogram
        rr = nz[nz >= w // 2]
        if rr.size:
            print(f"    right-half col hist: { {int(c): int(ch[c]) for c in rr} }")

    print("\nspatial distribution:")
    colinfo(intro, "introduced(10-frame only)")
    colinfo(persist, "persistent(both)")


if __name__ == "__main__":
    main()