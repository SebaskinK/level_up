"""Find solid vertical crack bands (connected hole components, tall & thin) in
the final model rendered to frame 0, over the whole image, and report their
exact bounding boxes + covering-disc birth frames. This directly targets the
user's 'three vertical cracks with width'.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

SEQ = Path(__file__).resolve().parent
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SEQ))
sys.path.insert(0, str(SFLOW))

import h_pipeline_final as H            # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402

FINAL = SEQ.parent / "output_f0_ellipse_final" / "model_f0.npz"
Z_MIN, Z_MAX = 0.4, 4.0


def tangent_basis(n):
    n = n.astype(np.float64)
    n = n / np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-12)
    ref = np.tile(np.array([0.0, 0.0, 1.0]), (n.shape[0], 1))
    ref[np.abs(n[:, 2]) > 0.9] = np.array([1.0, 0.0, 0.0])
    t1 = np.cross(ref, n)
    t1 = t1 / np.maximum(np.linalg.norm(t1, axis=1, keepdims=True), 1e-12)
    t2 = np.cross(n, t1)
    return t1, t2


def load_g(path: Path):
    d = np.load(path)
    mu = d["mu"].astype(np.float64)
    normal = d["normal"].astype(np.float64)
    scale = d["scale"].astype(np.float64)
    color = d["color"].astype(np.float64)
    birth = d["birth"].astype(np.int64)
    t1, t2 = tangent_basis(normal)
    g = H.Gaussians(
        mu=mu, normal=normal, scale=scale,
        quat=H._quat_from_frame(t1.astype(np.float32), t2.astype(np.float32), normal.astype(np.float32)),
        color=color, alpha=None,
        pixel=np.zeros((len(mu), 2), np.int32),
        axis1=t1.astype(np.float32), axis2=t2.astype(np.float32))
    return g, birth


def main() -> None:
    pairs = SF.associate(SF.DATA, max_dt=0.02)[: 11]
    sm = SF.load_rgb(pairs[0].rgb_path)
    h, w = sm.shape[:2]
    m1, m2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)
    bgr0, z0, _ = SF.load_pair(pairs, 0, m1, m2)
    valid = (z0 > Z_MIN) & (z0 < Z_MAX)

    g, birth = load_g(FINAL)
    depth, index, _ = H.rasterize_discs(g, K, (h, w))
    idx = index.astype(np.int64)
    # holes = rendered not covered, ANYWHERE (including border-filled region)
    hole = ~np.isfinite(depth)
    pix_birth = np.full((h, w), -1, np.int32)

    # per-hole pixel, find covering-disc birth of NEIGHBOURING covered pixels is hard;
    # instead label connected components of holes
    import scipy.ndimage as ndi
    lbl, n = ndi.label(hole.astype(np.uint8), structure=np.ones((3, 3)))
    print(f"total connected hole components = {n}")
    comps = []
    for i in range(1, n + 1):
        ys, xs = np.nonzero(lbl == i)
        r0, r1, c0, c1 = ys.min(), ys.max(), xs.min(), xs.max()
        hh, ww = r1 - r0 + 1, c1 - c0 + 1
        area = len(ys)
        if ww <= 4 and hh >= 5 and area >= 8 and c1 >= 480:
            comps.append((area, hh, ww, r0, r1, c0, c1))
    comps.sort(reverse=True)
    print(f"\ncrack candidates (width<=4, height>=5, area>=8, right half): {len(comps)}")
    print("area height width  rows        cols")
    for area, hh, ww, r0, r1, c0, c1 in comps[:40]:
        print(f"{area:4d} {hh:6d} {ww:4d}  {r0:3d}-{r1:3d}  {c0:3d}-{c1:3d}")

    # for the top component's neighbourhood: birth of discs covering the ring around it
    if comps:
        area, hh, ww, r0, r1, c0, c1 = comps[0]
        ring = np.zeros((h, w), bool)
        rr0, rr1 = max(r0 - 4, 0), min(r1 + 5, h)
        cc0, cc1 = max(c0 - 4, 0), min(c1 + 5, w)
        sub = hole[rr0:rr1, cc0:cc1]
        # print ascii of this window
        print(f"\nascii of top crack window rows {rr0}-{rr1} cols {cc0}-{cc1} ('#'=hole '.'=covered):")
        for r in range(rr0, rr1):
            line = "".join("#" if hole[r, c] else "." for c in range(cc0, cc1))
            print(f"{r:3d} {line}")


if __name__ == "__main__":
    main()