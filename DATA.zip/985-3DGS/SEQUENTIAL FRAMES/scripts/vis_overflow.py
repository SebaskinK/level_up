"""Visualize new-disc footprint overflow outside the leftover (flow-miss) region.

Frame n=0 -> n+1. Answers: does a disc created on the leftover region cover
pixels OUTSIDE the leftover region, and where?

Pixel classes (mutually exclusive, draw order = priority top->bottom):
  * OVERFLOW   new disc footprint outside leftover, on old-owned valid depth
  * COVERED    new disc footprint inside leftover
  * LEFTOVER   leftover pixel NOT covered by any new disc footprint (still hole)
  * OLD-OWNED  valid depth, old model owns it, no new footprint
  * NO-DEPTH   invalid depth
"""

import sys
from pathlib import Path

import cv2
import numpy as np

SEQ = Path(__file__).resolve().parent
SINGLE = SEQ.parent.parent / "SINGLE FRAME" / "scripts"
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SINGLE))
sys.path.insert(0, str(SFLOW))
sys.path.insert(0, str(SEQ))

import h_pipeline_final as H  # noqa: E402
import incremental_hybrid as INC  # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402
from scene_flow import compute_scene_flow  # noqa: E402
from se3 import se3_exp  # noqa: E402
from tum_io import (  # noqa: E402
    associate, load_rgb, load_depth, undistort_maps, FR1_INTRINSICS,
    remap_rgb, remap_depth,
)

OUT = SEQ.parent / "output_inc_vis"


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    pairs = associate(SF.DATA)
    h, w = load_rgb(pairs[0].rgb_path).shape[:2]
    map1, map2, K = undistort_maps((h, w), FR1_INTRINSICS)

    def lp(i):
        p = pairs[i]
        bgr = remap_rgb(load_rgb(p.rgb_path), map1, map2)
        z = remap_depth(load_depth(p.depth_path), map1, map2)
        z[z < SF.Z_MIN] = 0.0
        z[z > SF.Z_MAX] = 0.0
        return bgr, z

    bgr0, z0 = lp(0)
    g0, _, _ = H.build_hybrid(bgr0, z0, K, SF.TEX_Q)
    model = SF.Model(
        g=g0, w=np.ones(len(g0), np.float32), age=np.zeros(len(g0), np.int32),
        owner=SF.owner_from_raster(g0, K, (h, w)), birth=np.zeros(len(g0), np.int32),
        cnt=np.ones(len(g0), np.float32),
    )

    bgr1, z1 = lp(1)
    sf = compute_scene_flow(bgr0, bgr1, z0, z1, K, prev=None, dt=1.0, prev_dt=1.0)
    R_10, t_10 = se3_exp(sf.xi)
    owner_w = SF.warp_owner(model.owner, sf.u, sf.v, sf.valid)
    owner_w = SF._fill_owner_backward(owner_w, model.owner, sf)

    valid_depth = (z1 > SF.Z_MIN) & (z1 < SF.Z_MAX)
    leftover = valid_depth & (owner_w < 0)
    g_new = INC.build_hybrid_region(bgr1, z1, K, SF.TEX_Q, leftover)

    _, idx_new, _ = H.rasterize_discs(g_new, K, (h, w))
    new_hit = idx_new >= 0

    # classes
    overflow = new_hit & ~leftover & valid_depth & (owner_w >= 0)
    covered = new_hit & leftover
    still_hole = leftover & ~new_hit
    old_owned = valid_depth & (owner_w >= 0) & ~new_hit
    no_depth = ~valid_depth

    # BGR colours (user reads colours; also print an explicit legend)
    c_overflow = (0, 0, 255)     # red
    c_covered = (0, 255, 0)      # green
    c_hole = (255, 200, 0)       # cyan-ish (BGR: 255,200,0) -> yellow-orange
    c_old = (255, 255, 255)      # white (dimmed base shows through)
    vis = bgr1.astype(np.float32) * 0.18  # dark base
    vis = vis.astype(np.float32)

    def paint(mask, colour, alpha=0.9):
        nonlocal vis
        m = mask
        vis[m] = (1 - alpha) * vis[m] + alpha * np.array(colour, np.float32)

    paint(no_depth, (30, 30, 30), 1.0)
    paint(old_owned, (90, 90, 90), 1.0)
    paint(still_hole, c_hole, 1.0)
    paint(covered, c_covered, 1.0)
    paint(overflow, c_overflow, 1.0)

    # NOTE: pure per-pixel classes only. NO disc-centre markers, NO overlays --
    # any non-per-pixel glyph would alias into spurious regular patterns.

    vis = np.clip(vis, 0, 255).astype(np.uint8)

    # legend bar
    items = [
        (c_overflow, "OVERFLOW: new disc footprint outside leftover (on old-owned)"),
        (c_covered, "COVERED: new disc footprint inside leftover"),
        (c_hole, "STILL-HOLE: leftover pixel not covered by new disc"),
        ((90, 90, 90), "OLD-OWNED: valid depth, old model owns, no new footprint"),
        ((30, 30, 30), "NO-DEPTH"),
    ]
    bar = np.full((30 + 20 * len(items), w, 3), 20, np.uint8)
    y = 8
    for col, name in items:
        cv2.rectangle(bar, (8, y), (8 + 16, y + 14), col, -1)
        cv2.rectangle(bar, (8, y), (8 + 16, y + 14), (240, 240, 240), 1)
        cv2.putText(bar, name, (8 + 24, y + 12), cv2.FONT_HERSHEY_SIMPLEX, 0.42,
                    (220, 220, 220), 1, cv2.LINE_AA)
        y += 20

    stats = (
        f"leftover={int(leftover.sum())}  new_discs={len(g_new)}  "
        f"covered={int(covered.sum())}  overflow={int(overflow.sum())}  "
        f"still_hole={int(still_hole.sum())}"
    )
    cv2.putText(bar, stats, (8, y + 8), cv2.FONT_HERSHEY_SIMPLEX, 0.45,
                (220, 220, 220), 1, cv2.LINE_AA)

    img = np.vstack([vis, bar])
    path = OUT / "overflow_frame01.png"
    cv2.imwrite(str(path), img)
    print(f"wrote {path}")
    print(f"  leftover px        = {int(leftover.sum())}")
    print(f"  new discs          = {len(g_new)}")
    print(f"  covered (in-region)     = {int(covered.sum())}")
    print(f"  overflow (out-region)   = {int(overflow.sum())}  "
          f"({100*overflow.sum()/max(new_hit.sum(),1):.1f}% of footprint)")
    print(f"  still-hole (uncovered)  = {int(still_hole.sum())}")


if __name__ == "__main__":
    main()