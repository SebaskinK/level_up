"""Attribute the frame-0 BLUE pixels: born f1-80 AND sitting on the f0 surface.

The frame-0 owner classification (`diag_left_oldnew_color.py`) paints a pixel BLUE
when the front-most disc there was born after frame 0 yet its depth agrees with the
frame-0 depth map (|dz|/z < 0.05). Those are the redundant overdraws that make the
left edge look mottled, so this script answers "why is each of them still there":

  A. was the pixel actually MEASURED in frame 0? (z0 valid there)
       * z0 valid  -> f0 saw that surface; a disc born later is pure redundancy.
       * z0 invalid-> the pixel was outside f0's valid depth; new here is expected.
  B. for the redundant ones, which birth gate let the new disc through
     (NO_NBR / PLANE_FAIL / RADIUS_FAIL / COLOUR_FAIL / WOULD_ABSORB), and was the
     nearest passing neighbour's own ellipse ALREADY covering the pixel.
  C. was the pixel inside an f0-born disc's frozen footprint at all (redundant
     overdraw), or was it an f0 model hole?

Run:  python scripts/diag_blue_pixels_reason.py --frames 81
"""

from __future__ import annotations

import argparse
import json
import time
from collections import Counter
from pathlib import Path

import cv2
import numpy as np

SEQ = Path(__file__).resolve().parent
import sys  # noqa: E402

sys.path.insert(0, str(SEQ))

import h_pipeline_final as H  # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402

DEPTH_TOL = 0.05
REASON_NAMES = {
    SF.LEFT_NBR_NO: "NO_NBR",
    SF.LEFT_NBR_PLANE: "PLANE_FAIL",
    SF.LEFT_NBR_RADIUS: "RADIUS_FAIL",
    SF.LEFT_NBR_COLOUR: "COLOUR_FAIL",
    SF.LEFT_NBR_PASS: "WOULD_ABSORB",
}
REASON_BGR = {
    SF.LEFT_NBR_NO: (110, 110, 110),      # gray
    SF.LEFT_NBR_PLANE: (0, 0, 255),       # red
    SF.LEFT_NBR_RADIUS: (0, 255, 255),    # yellow
    SF.LEFT_NBR_COLOUR: (0, 140, 255),    # orange
    SF.LEFT_NBR_PASS: (0, 220, 0),        # green
}


def pm_compose(a, b):
    Ra, ta = a
    Rb, tb = b
    return Rb @ Ra, Rb @ ta + tb


def pm_inv(a):
    R, t = a
    return R.T, -R.T @ t


def tangent_basis(n: np.ndarray):
    """Same tangent frame `diag_left_oldnew_color` rebuilds, so the rasterisation
    (and therefore the blue pixel set) matches the owner map exactly."""
    ref = np.zeros_like(n)
    ref[:, 2] = 1.0
    flip = np.abs(n[:, 2]) > 0.9
    ref[flip] = np.array([1.0, 0.0, 0.0])
    a1 = np.cross(n, ref)
    a1 /= np.maximum(np.linalg.norm(a1, axis=1, keepdims=True), 1e-9)
    a2 = np.cross(n, a1)
    a2 /= np.maximum(np.linalg.norm(a2, axis=1, keepdims=True), 1e-9)
    return a1, a2


def as_gaussians(mu, normal, scale, color):
    a1, a2 = tangent_basis(normal)
    n = len(mu)
    return H.Gaussians(mu=mu, normal=normal, scale=scale,
                       quat=np.zeros((n, 4)), color=color,
                       alpha=np.ones(n, np.float32),
                       pixel=np.zeros((n, 2), np.int32), axis1=a1, axis2=a2)


def caption_bar_wrapped(img, text, per_line=96):
    parts = text.split(" | ")
    lines, cur = [], ""
    for p in parts:
        cand = p if not cur else cur + " | " + p
        if len(cand) <= per_line or not cur:
            cur = cand
        else:
            lines.append(cur)
            cur = p
    if cur:
        lines.append(cur)
    bar = np.full((18 * len(lines) + 14, img.shape[1], 3), 20, np.uint8)
    for i, ln in enumerate(lines):
        cv2.putText(bar, ln, (8, 22 + 18 * i), cv2.FONT_HERSHEY_SIMPLEX,
                    0.42, (230, 230, 230), 1, cv2.LINE_AA)
    return np.vstack([img, bar])


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--frames", type=int, default=81)
    ap.add_argument("--out", default="output_blue_reason")
    args = ap.parse_args()

    OUT = SEQ.parent / args.out
    OUT.mkdir(parents=True, exist_ok=True)
    NPAIR = args.frames
    AGE_MAX = 1000000
    W_MIN = 0.0

    pairs = SF.associate(SF.DATA, max_dt=0.02)[:NPAIR]
    sample = SF.load_rgb(pairs[0].rgb_path)
    h, w = sample.shape[:2]
    map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)

    bgr0, z0, _ = SF.load_pair(pairs, 0, map1, map2)
    g0, _, _, owner0 = H.build_hybrid_with_owner(bgr0, z0, K, SF.TEX_Q)
    n_init = len(g0)
    print(f"n_init={n_init}", flush=True)

    model = SF.Model(
        g=g0,
        w=np.ones(n_init, dtype=np.float32),
        w_col=np.ones(n_init, dtype=np.float32),
        age=np.zeros(n_init, dtype=np.int32),
        owner=owner0,
        birth=np.zeros(n_init, dtype=np.int32),
        birth_color=g0.color.astype(np.float32).copy(),
    )
    FL = [None] * NPAIR
    FL[0] = (np.eye(3), np.zeros(3))
    prev_sf, prev_dt = None, 1.0
    bgr_a, z_a = bgr0, z0

    rec_idx, rec_birth, rec_src = [], [], []
    rec_reason, rec_dcol, rec_cov, rec_sig = [], [], [], []
    rec_nage = []
    t0 = time.perf_counter()
    for i in range(NPAIR - 1):
        bgr_b, z_b, _ = SF.load_pair(pairs, i + 1, map1, map2)
        dt = pairs[i + 1].t_rgb - pairs[i].t_rgb
        sf = SF.compute_scene_flow(bgr_a, bgr_b, z_a, z_b, K,
                                   prev=prev_sf, dt=dt, prev_dt=prev_dt)
        R_10, t_10 = SF.se3_exp(sf.xi)
        FL[i + 1] = pm_compose(FL[i], (R_10, t_10))

        n_before = len(model.g)
        rec = SF.fuse_frame(model, sf, z_a, z_b, bgr_b, K,
                            age_max=AGE_MAX, w_min=W_MIN, frame_idx=i,
                            R_10=R_10, t_10=t_10, diag_newborn=True)
        n_after = len(model.g)
        n_new = rec["n_new"]
        if n_new:
            gi = np.arange(n_before, n_after)
            rec_idx.append(gi)
            rec_birth.append(np.full(n_new, i, np.int32))
            rec_src.append(np.concatenate([
                np.zeros(rec["n_s2"], np.int8), np.ones(rec["n_curv"], np.int8)]))
            rec_reason.append(rec["new_reason"])
            rec_dcol.append(rec["new_nbr_dcol"])
            rec_cov.append(rec["new_nbr_covered"])
            rec_sig.append(rec["new_sigma_tex"])
            rec_nage.append(rec["new_nbr_age"])
        if (i + 1) % 20 == 0:
            print(f"[{i+1:03d}] N={len(model.g)} cum={time.perf_counter()-t0:.1f}s",
                  flush=True)
        bgr_a, z_a = bgr_b, z_b
        prev_sf, prev_dt = sf, dt

    N = len(model.g)
    g = model.g
    print(f"final N={N} -> frame 0 ...", flush=True)
    g0f = SF.transform_to_next(g, *pm_inv(FL[NPAIR - 1]))
    g0f = as_gaussians(g0f.mu, g0f.normal, g0f.scale, g0f.color)

    reason = np.full(N, -1, np.int8)
    src = np.full(N, -1, np.int8)
    birth = np.zeros(N, np.int32)
    dcol = np.full(N, np.nan, np.float32)
    sig_tex = np.full(N, np.nan, np.float32)
    nbr_age = np.full(N, np.nan, np.float32)
    covered = np.zeros(N, bool)
    ii = np.concatenate(rec_idx)
    reason[ii] = np.concatenate(rec_reason)
    src[ii] = np.concatenate(rec_src)
    birth[ii] = np.concatenate(rec_birth)
    dcol[ii] = np.concatenate(rec_dcol)
    covered[ii] = np.concatenate(rec_cov)
    sig_tex[ii] = np.concatenate(rec_sig)
    nbr_age[ii] = np.concatenate(rec_nage)

    depth_f, index_f, _ = H.rasterize_discs(g0f, K, (h, w))
    hit = np.isfinite(depth_f)
    own = index_f[hit]
    dz = np.abs(depth_f - z0) / np.maximum(z0, 1e-6)
    on_surf = dz < DEPTH_TOL

    b_px = np.full((h, w), -1, np.int32)
    b_px[hit] = birth[own]
    z0_meas = z0 > SF.Z_MIN                      # frame 0 actually measured depth here
    blue = hit & on_surf & (b_px >= 1)
    blue_meas = blue & z0_meas                   # redundant: f0 saw this surface
    blue_unmeas = blue & ~z0_meas                # f0 had no valid depth here

    ref = bgr0[..., ::-1].astype(np.float32) / 255.0
    err = np.full((h, w), np.nan)
    err[hit] = np.linalg.norm(g0f.color[own] - ref[hit], axis=1)

    lines = []
    add = lines.append
    add(f"N={N}  n_init={n_init}  coverage={hit.mean():.4f}")
    add(f"BLUE (front-most, born f1-80, |dz|/z<{DEPTH_TOL}) = {int(blue.sum())} px")
    add(f"  of which frame-0 MEASURED depth (pure redundancy) = {int(blue_meas.sum())} px "
        f"({100*blue_meas.sum()/max(blue.sum(),1):.1f}%)")
    add(f"  of which frame-0 had NO valid depth (new region)  = {int(blue_unmeas.sum())} px "
        f"({100*blue_unmeas.sum()/max(blue.sum(),1):.1f}%)")
    for nm, msk in [("left x<128", np.arange(w)[None, :] < 128),
                    ("right x>=128", np.arange(w)[None, :] >= 128)]:
        sel = blue & msk
        if sel.sum():
            add(f"  {nm}: blue={int(sel.sum())} px  measured={int((sel & z0_meas).sum())} "
                f"({100*float((sel & z0_meas).sum())/sel.sum():.1f}%)")

    # --- was the blue pixel inside an f0-born disc's frozen footprint? ---
    f0_only = as_gaussians(g0f.mu[:n_init], g0f.normal[:n_init],
                           g0f.scale[:n_init], g0f.color[:n_init])
    try:
        dep0, idx0, _ = H.rasterize_discs(f0_only, K, (h, w))
    except Exception as exc:                                    # pragma: no cover
        dep0 = np.full((h, w), np.nan)
        add(f"  [f0-footprint rasterize failed: {exc}]")
    f0_cov = np.isfinite(dep0)
    for nm, msk in [("all blue", blue), ("blue & f0-measured", blue_meas)]:
        sel = msk
        if sel.sum():
            add(f"  {nm}: inside an f0-born disc footprint = "
                f"{100*float(f0_cov[sel].mean()):.1f}%  "
                f"(so f0 model had no disc there = {100*float((~f0_cov[sel]).mean()):.1f}%)")

    # --- birth-gate reason attribution, weighted by pixels and by discs ---
    def reason_breakdown(msk, label):
        fi = index_f[msk]
        fi = fi[fi >= n_init]
        if fi.size == 0:
            add(f"{label}: none")
            return
        u = np.unique(fi)
        r = reason[u]
        cc = np.bincount(r.clip(0), minlength=5)
        add(f"{label}: {fi.size} px, {u.size} unique discs")
        for k in range(5):
            add(f"    {REASON_NAMES[k]:13s}: px={int((r[np.searchsorted(u, fi)] == k).sum()):6d} "
                f"({100*float((r[np.searchsorted(u, fi)] == k).mean()):5.1f}%)  "
                f"discs={cc[k]:5d} ({cc[k]/max(u.size,1):.3f})")
        add(f"    source: S2={int((src[u] == 0).sum())} curv={int((src[u] == 1).sum())}")
        add(f"    nbr ellipse already covered pixel: "
            f"{int(covered[u].sum())}/{u.size} = {covered[u].mean():.3f}")
        add("    per reason: own-ellipse coverage / disc type / colour gap vs gate")
        r_px_arr = r[np.searchsorted(u, fi)]
        for k in range(5):
            mk = r == k
            if not mk.any():
                continue
            pxk = int((r_px_arr == k).sum())
            s2k = int((src[u][mk] == 0).sum())
            ck = int((src[u][mk] == 1).sum())
            line = (f"      {REASON_NAMES[k]:13s}: px={pxk:6d} discs={int(mk.sum()):5d} "
                    f"covered={covered[u][mk].mean():.3f} "
                    f"S2={s2k:4d} curv={ck:4d}")
            if k in (SF.LEFT_NBR_COLOUR, SF.LEFT_NBR_PASS):
                gap = dcol[u][mk]
                bud = SF.COLOR_GATE_K * sig_tex[u][mk]
                ok = np.isfinite(gap) & np.isfinite(bud) & (bud > 0)
                if ok.any():
                    ratio = gap[ok] / bud[ok]
                    line += (f" gap/budget: med={np.median(ratio):.2f} "
                             f"p90={np.percentile(ratio, 90):.2f} "
                             f"frac>1={float((ratio > 1).mean()):.3f}")
                    # counterfactual: what the OTHER two gates already do --
                    # add the temporal (age/lighting) term in quadrature.
                    bud2 = SF.color_gate_thresh(sig_tex[u][mk], nbr_age[u][mk],
                                                SF.COLOR_GATE_K)
                    r2 = gap / bud2
                    ok2 = np.isfinite(r2)
                    if ok2.any():
                        line += (f" | +age term nbr_age med={np.nanmedian(nbr_age[u][mk]):.0f}: "
                                 f"gap/budget2 med={np.nanmedian(r2[ok2]):.2f} "
                                 f"frac>1={float((r2[ok2] > 1).mean()):.3f}")
            add(line)
        add(f"    gate-3 budget k*sig_tex: med={np.nanmedian(SF.COLOR_GATE_K*sig_tex[u]):.4f} "
            f"p90={np.nanpercentile(SF.COLOR_GATE_K*sig_tex[u], 90):.4f}")
        dd = dcol[u][np.isfinite(dcol[u])]
        if dd.size:
            add(f"    nbr colour gap |dc|: med={np.median(dd):.4f} "
                f"p90={np.percentile(dd, 90):.4f}")
        add(f"    birth frames: {Counter(birth[u].tolist()).most_common(6)}")
        r_px = 0.5 * (K[0, 0] + K[1, 1]) * g0f.scale[u, 0] / np.maximum(g0f.mu[u, 2], 1e-6)
        add(f"    f0 projected radius (px): med={np.median(r_px):.3f} "
            f"p90={np.percentile(r_px, 90):.3f}")

    reason_breakdown(blue_meas, "BLUE & f0-measured (redundant overdraw)")
    left_msk = np.zeros((h, w), bool)
    left_msk[:, :128] = True
    reason_breakdown(blue_meas & left_msk, "BLUE & f0-measured, LEFT x<128")
    reason_breakdown(blue_unmeas, "BLUE & f0-unmeasured (new region)")

    e = err[blue]
    e = e[np.isfinite(e)]
    if e.size:
        add(f"colour err vs f0 image over blue: mean={e.mean():.4f} "
            f"p90={np.percentile(e, 90):.4f}")

    # --- overlays ---
    hard = np.zeros((h, w, 3), np.float32)
    hard[hit] = g0f.color[own]
    hard_bgr = (np.clip(hard, 0, 1) * 255).astype(np.uint8)[..., ::-1].copy()
    hard_bgr[~hit] = 0
    reason_img = hard_bgr.copy()
    for k in range(5):
        m = blue & (index_f >= 0)
        if not m.any():
            continue
        rr = np.zeros((h, w), np.int8)
        rr[hit] = reason[own]
        reason_img[m & (rr == k)] = REASON_BGR[k]

    split_img = hard_bgr.copy()
    split_img[blue_meas] = (60, 60, 255)     # red: redundant (f0 measured it)
    split_img[blue_unmeas] = (255, 200, 0)   # cyan-ish: f0 had no depth

    # --- focus panels for the two traced failure modes ---
    rr_full = np.full((h, w), -1, np.int8)
    rr_full[hit] = reason[own]
    cov_full = np.zeros((h, w), bool)
    cov_full[hit] = covered[own]
    is_s2_full = np.zeros((h, w), bool)
    is_s2_full[hit] = src[own] == 0

    def focus_panel(kind):
        img = hard_bgr.copy()
        m = blue & (rr_full == kind)
        base = REASON_BGR[kind]
        img[m] = base
        img[m & cov_full] = (255, 0, 255) if kind == SF.LEFT_NBR_PASS else (0, 0, 255)
        return img, m

    wa_img, wa_mask = focus_panel(SF.LEFT_NBR_PASS)
    cf_img, cf_mask = focus_panel(SF.LEFT_NBR_COLOUR)
    hw, cw = wa_mask.sum(), cf_mask.sum()
    wa_cov = int((wa_mask & cov_full).sum())
    cf_cov = int((cf_mask & cov_full).sum())
    wa_s2 = int((wa_mask & is_s2_full).sum())
    cf_s2 = int((cf_mask & is_s2_full).sum())

    pair = np.hstack([wa_img, np.full((h, 3, 3), 255, np.uint8), cf_img])
    pair_box = np.hstack([wa_mask, np.zeros((h, 3), bool), cf_mask])
    ys_l, xs_l = np.where(pair_box)
    if ys_l.size:
        x0, x1 = max(int(xs_l.min()) - 20, 0), min(int(xs_l.max()) + 20, pair.shape[1])
        y0, y1 = max(int(ys_l.min()) - 20, 0), min(int(ys_l.max()) + 20, h)
    else:
        x0, y0, x1, y1 = 0, 0, pair.shape[1], h
    crop = pair[y0:y1, x0:x1]
    sc = max(1, min(4, 900 // max(crop.shape[1], 1)))
    crop = cv2.resize(crop, None, fx=sc, fy=sc, interpolation=cv2.INTER_NEAREST)
    pw = pair.shape[1]
    if crop.shape[1] < pw:
        crop = np.hstack([crop, np.zeros((crop.shape[0], pw - crop.shape[1], 3), np.uint8)])
    elif crop.shape[1] > pw:
        crop = crop[:, :pw]
    band = np.full((28, pw, 3), 20, np.uint8)
    cv2.putText(band, f"ZOOM x{sc} on the marked region (left=WOULD_ABSORB, right=COLOUR_FAIL)",
                (8, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (235, 235, 235), 1, cv2.LINE_AA)
    stack = np.vstack([pair, band, crop])
    cap2 = (
        f"frame-0 HARD RAY | LEFT PANEL: WOULD_ABSORB = an OLD disc passed ALL 3 absorb "
        f"gates at the pixel, yet the pixel still spawned a disc ({hw} px) | GREEN = those "
        f"pixels | MAGENTA = neighbour's own ellipse already covered it "
        f"({wa_cov} px, {100*wa_cov/max(hw,1):.1f}%) | S2-born {wa_s2}/{hw} = "
        f"{100*wa_s2/max(hw,1):.1f}%  =>  leak is S2 stage claiming them BEFORE absorb "
        f"| RIGHT PANEL: COLOUR_FAIL = neighbour passed plane+radius, colour gate blocked "
        f"({cw} px) | ORANGE = those pixels | RED = neighbour ellipse already covered it "
        f"({cf_cov} px, {100*cf_cov/max(cw,1):.1f}%) | S2-born {cf_s2}/{cw} = "
        f"{100*cf_s2/max(cw,1):.1f}% | colour gap always > gate (frac>1 = 1.000, med 1.52x) "
        f"| same-frame colour boundary, spatially legit")
    cv2.imwrite(str(OUT / "blue_focus_absorb_colorfail.png"),
                caption_bar_wrapped(stack, cap2, per_line=150))

    cap = (f"frame-0 HARD RAY | blue-class pixels only: born f1-80 & on f0 surface "
           f"| {int(blue.sum())} px "
           f"| RED = frame-0 measured depth there -> redundant overdraw "
           f"({int(blue_meas.sum())} px, {100*blue_meas.sum()/max(blue.sum(),1):.1f}%) "
           f"| CYAN = frame-0 had no valid depth -> genuinely new "
           f"({int(blue_unmeas.sum())} px)")
    cv2.imwrite(str(OUT / "blue_split.png"), caption_bar_wrapped(split_img, cap))
    cv2.imwrite(str(OUT / "blue_reason.png"), caption_bar_wrapped(
        reason_img, "frame-0 HARD RAY | blue-class pixels coloured by BIRTH GATE "
                    "| gray=NO_NBR red=PLANE yellow=RADIUS orange=COLOUR "
                    "green=WOULD_ABSORB | " + cap))
    (OUT / "report.txt").write_text("\n".join(lines) + "\n")
    (OUT / "stats.json").write_text(json.dumps({
        "n": N, "n_init": n_init, "coverage": float(hit.mean()),
        "blue_px": int(blue.sum()), "blue_measured_px": int(blue_meas.sum()),
        "blue_unmeasured_px": int(blue_unmeas.sum()),
    }, indent=2))
    print("\n".join(lines))
    print(f"saved -> {OUT}", flush=True)


if __name__ == "__main__":
    main()