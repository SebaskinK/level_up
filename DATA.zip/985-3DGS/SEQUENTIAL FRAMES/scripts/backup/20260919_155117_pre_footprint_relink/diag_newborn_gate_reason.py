"""Trace, for every new disc that ends up FRONT-most on the left of the frame-0
hard (ray-disc) render: which absorb gate rejected the old disc next to it, and
what colour it was born with.

Runs the same 81-frame fusion as diag_newborn_birth.py (aging off) with
`diag_newborn=True`, so fuse_frame reports per-new-disc:
  * reason : the absorb-gate outcome against the EXISTING owner map at the birth
             pixel (0 NO_NBR / 1 PLANE_FAIL / 2 RADIUS_FAIL / 3 COLOUR_FAIL /
             4 WOULD_ABSORB -- see classify_leftover_neighbours)
  * source : 0 = S2 texture disc, 1 = curvature disc
  * nbr_dcol : colour distance to the nearest plane+radius-passing neighbour
             (the gap the colour gate saw), nan where none
  * birth frame + birth colour (model.birth_color)

Then rasterizes the final model onto frame 0 and reports the split for the
left-region newborn discs, saves maps + a report.

Run:  python scripts/diag_newborn_gate_reason.py
"""

from __future__ import annotations

import time
from collections import Counter
from pathlib import Path

import cv2
import numpy as np

import h_pipeline_final as H
import sequential_fusion_flowonly as SF

REASON_NAMES = {
    SF.LEFT_NBR_NO: "NO_NBR",
    SF.LEFT_NBR_PLANE: "PLANE_FAIL",
    SF.LEFT_NBR_RADIUS: "RADIUS_FAIL",
    SF.LEFT_NBR_COLOUR: "COLOUR_FAIL",
    SF.LEFT_NBR_PASS: "WOULD_ABSORB",
}
REASON_BGR = {
    SF.LEFT_NBR_NO: (110, 110, 110),
    SF.LEFT_NBR_PLANE: (255, 60, 60),
    SF.LEFT_NBR_RADIUS: (255, 255, 0),
    SF.LEFT_NBR_COLOUR: (0, 140, 255),
    SF.LEFT_NBR_PASS: (0, 220, 0),
}
LEFT = 128


def pm_compose(a, b):
    Ra, ta = a
    Rb, tb = b
    return Rb @ Ra, Rb @ ta + tb


def pm_inv(a):
    R, t = a
    return R.T, -R.T @ t


def caption_bar(img: np.ndarray, text: str, h_bar: int = 40) -> np.ndarray:
    w = img.shape[1]
    bar = np.full((h_bar, w, 3), 20, np.uint8)
    cv2.putText(bar, text, (8, h_bar - 12), cv2.FONT_HERSHEY_SIMPLEX,
                0.45, (235, 235, 235), 1, cv2.LINE_AA)
    return np.vstack([img, bar])


def main() -> None:
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--frames", type=int, default=81)
    ap.add_argument("--left", type=int, default=128)
    args = ap.parse_args()

    OUT = SF.SEQ.parent / "output_newborn_reason"
    OUT.mkdir(parents=True, exist_ok=True)

    NPAIR = args.frames
    global LEFT
    LEFT = args.left
    AGE_MAX = 1000000
    W_MIN = 0.0

    pairs = SF.associate(SF.DATA, max_dt=0.02)[:NPAIR]
    sample = SF.load_rgb(pairs[0].rgb_path)
    h, w = sample.shape[:2]
    map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)

    print("building frame-0 model ...", flush=True)
    bgr0, z0, _ = SF.load_pair(pairs, 0, map1, map2)
    g0, _, _, owner0 = H.build_hybrid_with_owner(bgr0, z0, K, SF.TEX_Q)
    n_init = len(g0)
    print(f"n_init={n_init}", flush=True)

    model = SF.Model(
        g=g0,
        w=np.ones(n_init, dtype=np.float32),
        w_col=np.ones(n_init, dtype=np.float32),
        age=np.zeros(n_init, dtype=np.int32),
        owner=owner0,
        birth=np.zeros(n_init, dtype=np.int32),
        birth_color=g0.color.astype(np.float32).copy(),
    )
    FL = [None] * NPAIR
    FL[0] = (np.eye(3), np.zeros(3))
    prev_sf, prev_dt = None, 1.0
    bgr_a, z_a = bgr0, z0

    # per-new-disc records, scattered into full-length arrays by global index
    rec_idx, rec_birth, rec_src = [], [], []
    rec_reason, rec_dcol, rec_color, rec_cov = [], [], [], []

    t0 = time.perf_counter()
    for i in range(NPAIR - 1):
        bgr_b, z_b, _ = SF.load_pair(pairs, i + 1, map1, map2)
        dt = pairs[i + 1].t_rgb - pairs[i].t_rgb
        sf = SF.compute_scene_flow(bgr_a, bgr_b, z_a, z_b, K,
                                   prev=prev_sf, dt=dt, prev_dt=prev_dt)
        R_10, t_10 = SF.se3_exp(sf.xi)
        FL[i + 1] = pm_compose(FL[i], (R_10, t_10))

        n_before = len(model.g)
        rec = SF.fuse_frame(model, sf, z_a, z_b, bgr_b, K,
                            age_max=AGE_MAX, w_min=W_MIN, frame_idx=i,
                            R_10=R_10, t_10=t_10, diag_newborn=True)
        n_after = len(model.g)
        n_new = rec["n_new"]
        assert n_new == rec["n_s2"] + rec["n_curv"] == n_after - n_before
        if n_new:
            gi = np.arange(n_before, n_after)
            reason = rec["new_reason"]
            src = np.concatenate([
                np.zeros(rec["n_s2"], np.int8), np.ones(rec["n_curv"], np.int8)])
            assert reason is not None and reason.shape[0] == n_new
            rec_idx.append(gi)
            rec_birth.append(np.full(n_new, i, np.int32))
            rec_src.append(src)
            rec_reason.append(reason)
            rec_dcol.append(rec["new_nbr_dcol"])
            rec_color.append(model.birth_color[n_before:n_after].astype(np.float32))
            rec_cov.append(rec["new_nbr_covered"])
            if i < 12:
                cc = Counter(reason.tolist())
                print(f"  [birth {i}] new={n_new} " +
                      " ".join(f"{REASON_NAMES[k]}={v}" for k, v in sorted(cc.items())),
                      flush=True)
        if (i + 1) % 10 == 0:
            print(f"[{i+1:03d}] N={len(model.g)} cum={time.perf_counter()-t0:.1f}s",
                  flush=True)
        bgr_a, z_a = bgr_b, z_b
        prev_sf, prev_dt = sf, dt

    N = len(model.g)
    g = model.g
    print(f"final N={N}  -> frame-0 ...", flush=True)
    g0f = SF.transform_to_next(g, *pm_inv(FL[NPAIR - 1]))
    if g0f.axis1 is not None and g0f.axis2 is not None:
        g0f.quat = H._quat_from_frame(g0f.axis1, g0f.axis2, g0f.normal)

    # full-length per-disc records
    reason = np.full(N, -1, np.int8)
    src = np.full(N, -1, np.int8)
    birth = np.zeros(N, np.int32)
    dcol = np.full(N, np.nan, np.float32)
    bcolor = np.full((N, 3), np.nan, np.float32)
    covered = np.zeros(N, bool)
    ii = np.concatenate(rec_idx)
    reason[ii] = np.concatenate(rec_reason)
    src[ii] = np.concatenate(rec_src)
    birth[ii] = np.concatenate(rec_birth)
    dcol[ii] = np.concatenate(rec_dcol)
    bcolor[ii] = np.concatenate(rec_color)
    covered[ii] = np.concatenate(rec_cov)

    print("rasterizing hard ray-disc onto frame 0 ...", flush=True)
    depth_f, index_f, _ = H.rasterize_discs(g0f, K, (h, w))
    hit = np.isfinite(depth_f)
    hard = np.zeros((h, w, 3), np.float32)
    hard[hit] = g0f.color[index_f[hit]]
    hard_bgr = (np.clip(hard, 0, 1) * 255).astype(np.uint8)[..., ::-1].copy()
    hard_bgr[~hit] = 0

    left = np.zeros((h, w), bool)
    left[:, :LEFT] = True

    lines = []
    dbg = np.zeros((h, w, 3), np.uint8)
    dbg[:] = hard_bgr

    for x0, x1 in [(0, 64), (64, 128), (0, 128), (128, 192)]:
        band = np.zeros((h, w), bool)
        band[:, x0:x1] = True
        sel = hit & band
        fi = index_f[sel]
        new_px = fi[fi >= n_init]
        uidx = np.unique(new_px)
        lines.append(f"x[{x0:3d},{x1:3d})  front px={int(sel.sum()):6d}  "
                     f"fronted-by-new px={len(new_px):6d} ({len(new_px)/max(sel.sum(),1):.3f})  "
                     f"unique new discs={len(uidx)}")

    # ---- left-region newborn front discs: reason / source / birth ----
    left_new_px = index_f[hit & left]
    left_new_px = left_new_px[left_new_px >= n_init]
    uidx = np.asarray(np.unique(left_new_px)).reshape(-1).astype(np.int64)
    r = np.asarray(reason[uidx]).reshape(-1)
    s = np.asarray(src[uidx]).reshape(-1)
    b = np.asarray(birth[uidx]).reshape(-1)
    cc = np.bincount(r.clip(0), minlength=5)
    lines.append("")
    lines.append(f"LEFT x<{LEFT}: unique newborn discs front there = {len(uidx)}")
    for k in range(5):
        frac = cc[k] / max(len(uidx), 1)
        lines.append(f"  reason {REASON_NAMES[k]:13s}: discs={cc[k]:6d} ({frac:.3f})  "
                     f"px={int((r == k).sum())}")
    lines.append(f"  source  S2={int((s == 0).sum())}  curv={int((s == 1).sum())}")

    # reason x source cross-tab + front-pixel coverage per source
    fi_left = index_f[hit & left]
    lines.append("  reason x source (discs):")
    for k in range(5):
        lines.append(f"    {REASON_NAMES[k]:13s}: S2={int(((r == k) & (s == 0)).sum()):6d} "
                     f"curv={int(((r == k) & (s == 1)).sum()):6d}")
    for sv, sn in [(0, "S2"), (1, "curv")]:
        pxs = np.isin(fi_left, uidx[s == sv]).sum()
        lines.append(f"  front px owned by {sn:4s}: {int(pxs):6d} "
                     f"({pxs / max(len(fi_left), 1):.3f})  "
                     f"px/disc={pxs / max(int((s == sv).sum()), 1):.1f}")

    # projected pixel radius at frame 0, by source
    fx, fy, cx, cy = (float(K[0, 0]), float(K[1, 1]), float(K[0, 2]), float(K[1, 2]))
    r_px = 0.5 * (fx + fy) * g0f.scale[uidx, 0] / np.maximum(g0f.mu[uidx, 2], 1e-6)
    for sv, sn in [(0, "S2"), (1, "curv")]:
        rr = r_px[s == sv]
        if rr.size:
            lines.append(f"  f0 projected radius {sn:4s}: med={np.median(rr):.4f}px "
                         f"p90={np.percentile(rr, 90):.4f}px max={rr.max():.3f}px")
    lines.append("  f0 projected radius by reason (median px):")
    for k in range(5):
        rr = r_px[r == k]
        if rr.size:
            lines.append(f"    {REASON_NAMES[k]:13s}: n={rr.size:6d} med={np.median(rr):.4f}px")
    # among the "would absorb" pixels, how many are ALREADY inside the nearest
    # passing neighbour's own (frozen) ellipse?
    lines.append("  nearest plane+radius-passing neighbour's ellipse already covers pixel:")
    for k in range(5):
        m = r == k
        if m.sum():
            lines.append(f"    {REASON_NAMES[k]:13s}: {int(covered[uidx][m].sum()):6d}/"
                         f"{int(m.sum()):6d} = {covered[uidx][m].mean():.3f}")
    bh = np.bincount(b, minlength=NPAIR)
    lines.append("  birth hist (5-frame bins):")
    for a in range(0, NPAIR, 5):
        c = int(bh[a:a + 5].sum())
        if c:
            lines.append(f"    {a:3d}-{a+4:3d}: {c:6d}")
    lines.append(f"  top birth frames: {Counter(b.tolist()).most_common(8)}")
    # nbr colour gap by reason
    lines.append("  neighbour colour gap ||c_new_birth - c_neighbour|| by reason:")
    for k in range(5):
        dd = dcol[uidx][r == k]
        dd = np.asarray(dd).reshape(-1)
        dd = dd[np.isfinite(dd)]
        if dd.size:
            lines.append(f"    {REASON_NAMES[k]:13s}: n={dd.size:6d} "
                         f"med={np.median(dd):.4f} p90={np.percentile(dd, 90):.4f}")
    # newborn birth colour by reason (median)
    lines.append("  median BIRTH colour (RGB 0..1) by reason:")
    for k in range(5):
        cl = np.asarray(bcolor[uidx][r == k]).reshape(-1, 3)
        cl = cl[np.isfinite(cl).all(axis=1)]
        if cl.size:
            m = np.median(cl, axis=0)
            lines.append(f"    {REASON_NAMES[k]:13s}: n={cl.shape[0]:6d} "
                         f"rgb=({m[0]:.3f},{m[1]:.3f},{m[2]:.3f})")

    # ---- overlay: reason map on the left + birth map ----
    np.savez(OUT / "records.npz",
             uidx=uidx, reason=r, source=s, birth=b,
             nbr_dcol=dcol[uidx], birth_color=bcolor[uidx],
             nbr_covered=covered[uidx],
             r_px=r_px.astype(np.float32), global_reason=reason,
             global_src=src, global_birth=birth, index_f=index_f.astype(np.int64),
             hit=hit, n_init=np.int32(n_init))
    reason_img = hard_bgr.copy()
    birth_img = hard_bgr.copy()
    for yy, xx in zip(*np.nonzero(hit & left)):
        di = index_f[yy, xx]
        if di < n_init:
            continue
        reason_img[yy, xx] = REASON_BGR[int(reason[di])]
        t = min(birth[di] / (NPAIR - 1), 1.0)
        birth_img[yy, xx] = cv2.applyColorMap(
            np.uint8([[t * 255]]), cv2.COLORMAP_JET)[0, 0]

    cv2.imwrite(str(OUT / "f0_reason_map.png"), caption_bar(
        reason_img, f"HARD RAY f0 | left x<{LEFT} newborn front discs by BIRTH GATE "
                    f"| gray=NO_NBR red=PLANE cyan=RADIUS orange=COLOUR green=WOULD_ABSORB"))
    cv2.imwrite(str(OUT / "f0_birth_map.png"), caption_bar(
        birth_img, f"HARD RAY f0 | left x<{LEFT} newborn front discs by BIRTH FRAME "
                   f"(blue=0 -> red={NPAIR-1})"))
    cv2.imwrite(str(OUT / "f0_hard.png"), caption_bar(
        hard_bgr, f"HARD RAY f0 | 81-frame model | N={N} | TEX_VAR_THR={H.TEX_VAR_THR:g} "
                  f"| COLOR_GATE_K={SF.COLOR_GATE_K:g}"))

    # ---- colour swatch strip: median birth colour per reason ----
    sw = np.full((90, 5 * 140 + 20, 3), 30, np.uint8)
    for k in range(5):
        cl = np.asarray(bcolor[uidx][r == k]).reshape(-1, 3)
        cl = cl[np.isfinite(cl).all(axis=1)]
        x0 = 20 + k * 140
        if cl.size:
            m = np.median(cl, axis=0)
            col = tuple(int(v * 255) for v in m[::-1])
            cv2.rectangle(sw, (x0, 10), (x0 + 120, 70), col, -1)
        cv2.putText(sw, f"{REASON_NAMES[k]}", (x0, 86),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.4, (230, 230, 230), 1, cv2.LINE_AA)
    cv2.imwrite(str(OUT / "birthcolor_by_reason.png"), caption_bar(
        sw, "median BIRTH colour of left-region newborn discs, by reason"))

    report = "\n".join(lines) + "\n"
    (OUT / "report.txt").write_text(report)
    print(report)
    print(f"saved -> {OUT}", flush=True)


if __name__ == "__main__":
    main()