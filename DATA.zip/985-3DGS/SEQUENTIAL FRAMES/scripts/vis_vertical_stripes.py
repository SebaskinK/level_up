"""Hunt for VERTICAL stripe holes in the right-half gray strip.

For each rendered image (hard ray / EWA) and each column x in the right half,
compute the coverage fraction (non-black pixels) inside the gray-strip row band.
A vertical stripe hole = an isolated column whose coverage fraction is much lower
than its neighbours. Reports the strongest such columns.
"""
from __future__ import annotations

import sys
from pathlib import Path

import cv2
import numpy as np

SEQ = Path(__file__).resolve().parent
SINGLE = SEQ.parent.parent / "SINGLE FRAME" / "scripts"
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SFLOW))
sys.path.insert(0, str(SINGLE))
sys.path.insert(0, str(SEQ))

import sequential_fusion_flowonly as SF  # noqa: E402

OUT = SEQ.parent / "output_discmask_align"


def col_coverage(img_bgr, valid_mask, band):
    """non-black fraction per column inside `band` (rows) and valid_mask."""
    nonblack = (img_bgr.sum(axis=2) > 15)
    m = valid_mask & band
    num = (nonblack & m).sum(axis=0).astype(np.float32)
    den = m.sum(axis=0).astype(np.float32)
    return np.where(den > 0, num / np.maximum(den, 1e-6), np.nan)


def main() -> None:
    pairs = SF.associate(SF.DATA, max_dt=0.02)[: 11]
    sample = SF.load_rgb(pairs[0].rgb_path)
    h, w = sample.shape[:2]
    map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)
    bgr0, z0, _ = SF.load_pair(pairs, 0, map1, map2)
    valid = (z0 > SF.Z_MIN) & (z0 < SF.Z_MAX)

    hard = cv2.imread(str(OUT / "f0_hard.png"))
    ewa = cv2.imread(str(OUT / "f0_ewa.png"))

    # gray strip band (from earlier detection): rows 32..426
    r0, r1 = 32, 426
    band = np.zeros((h, w), dtype=bool)
    band[r0:r1, :] = True
    print(f"band rows [{r0},{r1})  valid-in-band={int((valid & band).sum())}")

    half0 = w // 2
    for name, img in [("hard(ray)", hard), ("ewa", ewa)]:
        cov = col_coverage(img, valid, band)
        # use only right-half columns with enough valid rows
        xs = np.arange(half0, w)
        c = cov[xs]
        ok = np.isfinite(c)
        if not ok.any():
            print(f"{name}: no valid columns")
            continue
        # a vertical stripe = column whose coverage is a sharp local dip
        med = np.median(c[ok])
        # local dip: cov[x] much lower than median of +/-5 neighbours
        dips = []
        for i in range(len(xs)):
            lo = max(0, i - 5)
            hi = min(len(xs), i + 6)
            nbr = c[lo:hi][np.isfinite(c[lo:hi])]
            if nbr.size == 0:
                continue
            diff = np.median(nbr) - c[i] if np.isfinite(c[i]) else 0.0
            dips.append((xs[i], c[i], np.median(nbr), diff))
        dips.sort(key=lambda t: -t[3])
        print(f"\n[{name}] median col-coverage in right half = {med:.4f}")
        print(f"  top vertical-stripe (coverage dip) columns:")
        seen = set()
        for x, cv, nb, diff in dips[:25]:
            if diff < 0.05:
                break
            if any(abs(x - s) < 3 for s in seen):
                continue
            seen.add(x)
            print(f"    col {x}: cov={cv:.3f} nbr_med={nb:.3f} dip={diff:.3f}")

    # global column coverage profile for the two rightmost 40 columns (FOV edge)
    print("\nrightmost 20 columns coverage (hard then ewa), band rows: valid only")
    for x in range(w - 20, w):
        ch = col_coverage(hard, valid, band)[x]
        ce = col_coverage(ewa, valid, band)[x]
        flag = " <-- low" if (np.isfinite(ch) and ch < 0.9) else ""
        print(f"  col {x}: hard={ch:.3f} ewa={ce:.3f}{flag}")


if __name__ == "__main__":
    main()