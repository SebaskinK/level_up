# RGB-D Scene Flow → Camera Motion

从 RGB-D 序列估计稠密三维场景流，并由场景流反推相机运动轨迹。
不使用 IMU，不做回环检测，不做全局位姿图优化。

数据集：TUM RGB-D `rgbd_dataset_freiburg1_desk`

方法背景、实验记录与踩坑说明见 [`TECHNICAL_REPORT.md`](TECHNICAL_REPORT.md)。

---

## 快速开始

```bash
cd /home/sti/Work/986-SceneFlow

# 运行主流程（前 200 个关联帧对）
.venv/bin/python scripts/run_pipeline.py --max-pairs 200 --out output_final

# 同时落盘稠密场景流（约 854 KB/帧）
.venv/bin/python scripts/run_pipeline.py --max-pairs 200 --out output_final --save-flow

# 评估 ATE / RPE
.venv/bin/python scripts/eval_ate.py --traj output_final/trajectory.txt

# 逐帧误差曲线
.venv/bin/python scripts/plot_errors.py \
    --csv output_final/frame_errors.csv \
    --out output_final/errors.png
```

matplotlib 需要可写的配置目录：

```bash
export MPLCONFIGDIR=/tmp/mplconfig
```

---

## 目录结构

```
986-SceneFlow/
├── rgbd_dataset_freiburg1_desk/   数据集（解压后）
├── .venv/                          Python 环境
├── output_final/                   当前默认配置的结果
│   ├── trajectory.txt              TUM 格式轨迹
│   ├── frame_errors.csv            逐帧指标
│   ├── summary.json                汇总统计
│   ├── vis/                        光流可视化
│   └── flow/                       稠密场景流 EXR（需 --save-flow）
└── scripts/
    ├── tum_io.py                   数据读取与真值处理
    ├── se3.py                      SE(3) 指数/对数映射
    ├── scene_flow.py               稠密场景流估计
    ├── rigid_motion.py             刚体拟合
    ├── sliding_window.py           三帧滑窗优化
    ├── flow_io.py                   场景流 EXR 读写
    ├── run_pipeline.py             主流程
    ├── eval_ate.py                 ATE / RPE 评估
    ├── plot_errors.py              逐帧误差绘图
    ├── analyze_rotation.py         旋转误差来源分析
    ├── requirements.txt            依赖
    ├── README.md                   本文件
    └── TECHNICAL_REPORT.md         技术文档
```

---

## 模块说明

### `tum_io.py`

TUM 数据集的读取与预处理。

| 函数 | 说明 |
| --- | --- |
| `associate(dir, max_dt)` | RGB 与深度的最近邻时间关联，深度一对一使用，默认窗口 20 ms |
| `load_rgb / load_depth` | 图像读取，深度按 5000 的尺度转为米 |
| `undistort_maps / remap_rgb / remap_depth` | fr1 内参去畸变（深度用最近邻插值） |
| `load_groundtruth` | 读取动捕真值（时间戳 + 平移 + 四元数 xyzw） |
| `interpolate_pose` | 真值位姿插值：平移线性，旋转 SLERP |
| `relative_camera_motion` | 由两个绝对位姿计算相对运动 $T_{01}$ |

常量 `FR1_INTRINSICS`：$f_x=517.3,\ f_y=516.5,\ c_x=318.6,\ c_y=255.3$，含畸变系数。

### `se3.py`

$\mathfrak{se}(3)$ 与 $SE(3)$ 之间的映射。螺旋向量约定为 `[wx, wy, wz, vx, vy, vz]`。

| 函数 | 说明 |
| --- | --- |
| `se3_exp(xi)` | 指数映射，返回 $(R, t)$ |
| `se3_log(R, t)` | 对数映射 |
| `scale_twist(xi, ratio)` | 按时间比例缩放螺旋，用于恒螺旋预测 |
| `apply_point_motion(X, R, t)` | 批量点变换 |

### `scene_flow.py`

稠密场景流估计。**运动约束在此施加**，而非在后续位姿拟合中。

核心函数 `compute_scene_flow(bgr0, bgr1, z0, z1, K, ...)`：

1. 由上一帧螺旋按时间比例预测当前光流（`flow_from_twist`）
2. 用预测光流 warp 目标帧，DIS 只估计**残差光流**
3. 前后向一致性检查（默认 1.5 px）与深度有效性筛选
4. warp 深度得三维对应，拟合螺旋 $\xi$
5. 与刚体模型一致的像素向模型收拢，不一致的保留 DIS 结果

返回的 `SceneFlow` 包含稠密流 `u, v, vz`、三维对应 `X0, X1`、
有效掩膜 `valid`、螺旋 `xi`，以及诊断量 `stats`：

| 诊断量 | 含义 |
| --- | --- |
| `flow_mag_mean` | 光流幅值均值（px） |
| `res_mag_mean` | 残差光流幅值均值（px） |
| `rigid_delta_mean` | 流场偏离刚体模型的平均距离（px） |
| `photo_mean` | warp 后的光度残差 |

`rigid_delta_mean` 是最重要的质量指标，与旋转误差相关系数 +0.72。

传 `motion_constraint=False` 可退化为自由 DIS。

### `rigid_motion.py`

由三维对应求刚体变换 $\mathbf{X}_1 = R\mathbf{X}_0 + t$。

| 函数 | 说明 |
| --- | --- |
| `umeyama(src, dst, w)` | 闭式最小二乘解，支持逐点权重 |
| `depth_sigma(z)` | 对应噪声模型 $\sigma \propto z^{1.33}$（实测拟合） |
| `ransac_rigid(...)` | RANSAC（3 点最小集）+ 深度加权精修 |
| `invert_point_motion` | 点运动 → 相机运动（求逆） |
| `rot_angle_deg / geodesic_deg` | 旋转角与测地距离 |

内点门限固定 3 cm。**不要**改成按深度收紧——实测会让 RPE 旋转从 3.64° 恶化到 7.49°，
原因是远点提供了旋转可观性所需的长基线。加权（软）优于门限（硬）。

### `sliding_window.py`

三帧滑窗联合优化，在 $\mathfrak{se}(3)$ 上用 Gauss-Newton 求解。

$$\min \sum_j \sum_i w_i \|\exp(\xi_j)\mathbf{X}_0^i - \mathbf{X}_1^i\|^2
+ \lambda \sum_j \left\|\frac{\xi_j}{\Delta t_j} - \frac{\xi_{j+1}}{\Delta t_{j+1}}\right\|^2$$

| 函数 | 说明 |
| --- | --- |
| `optimize_window(twists, corrs, dts, lam, quality)` | 窗口联合优化 |
| `quality_scale(rigid_delta, valid_frac)` | 逐帧质量评分，用于自适应 λ |

`lam` 是**相对于数据项 Hessian 迹**的比例，不是绝对权重。
数据项尺度约 $6\times10^8$，直接用绝对权重会让平滑项完全失效。

`quality_scale` 返回 0（干净帧，几乎不平滑）到 4（困难帧，强平滑）。
这样干净帧保持无偏，只有噪声大的帧才借用恒螺旋先验。

### `flow_io.py`

稠密场景流的落盘与读取，采用 OpenEXR 多通道浮点格式。

| 函数 | 说明 |
| --- | --- |
| `write_scene_flow(path, V, valid)` | 传入 `(H, W, 3)` float32，无效像素置 NaN |
| `read_scene_flow(path)` | 返回 `(V, valid)`，掩膜由 `isfinite` 恢复 |

三个通道为相机坐标系下的位移 $(V_X, V_Y, V_Z)$，单位米。
需要图像空间的光流时，用内参重新投影即可。

选择 EXR 的理由：原生支持浮点多通道、NaN 天然表示无效像素、
无损压缩、可用 `tev` 等查看器逐像素读数值。
代价是需要 `imageio` + freeimage 后端——OpenCV 的预编译包不带 EXR 写入器
（`cv2.imwrite` 对 `.exr` 直接报 "could not find a writer"）。
freeimage 来自系统包 `libfreeimage3`，imageio 自带的下载器在本机不可用。

**落盘精度是 half（16 位），不是 float32。** 入参虽为 float32，
但 freeimage 的 EXR 写入器默认用 HALF 像素类型 + PIZ 压缩，
实测往返误差约 $1.7\times10^{-5}$（0.017 mm 量级）。对米制位移可以忽略，
但如果下游要做差分或长链累积，需要知道这一截断。

实测体积约 **854 KB/帧**（640×480，有效像素 64%，20 帧均值，区间 750–943 KB）。
30 Hz 连续录制约 25 MB/s，长时间采集仍需考虑降采样——注意"改用 half-float"
这条路已经走完了，再压只能靠抽稀或有损方案。

### `run_pipeline.py`

主流程。逐帧计算场景流、拟合位姿、滑窗优化、积分为轨迹。

**输出**

| 文件 | 内容 |
| --- | --- |
| `frame_errors.csv` | 逐帧指标与误差 |
| `trajectory.txt` | TUM 格式轨迹：`timestamp tx ty tz qx qy qz qw` |
| `summary.json` | 汇总统计 |
| `vis/pair_*.png` | 光流可视化（绿色为最终流，橙色为预测流） |
| `flow/*.exr` | 稠密场景流，需 `--save-flow` |

**参数**

| 参数 | 默认 | 说明 |
| --- | --- | --- |
| `--data` | `../rgbd_dataset_freiburg1_desk` | 数据集路径 |
| `--out` | `../output` | 输出目录 |
| `--max-pairs` | 80 | 处理的帧对数量，0 表示全部 |
| `--skip` | 1 | 每隔多少对取一次 |
| `--stride` | 4 | 拟合时的像素采样步长 |
| `--max-dt` | 0.02 | RGB-深度关联的时间窗口（秒） |
| `--fb-thresh` | 1.5 | 前后向一致性阈值（px） |
| `--ransac-thresh` | 0.03 | 内点门限（米） |
| `--window` | 3 | 滑窗大小，1 表示禁用 |
| `--smooth-lambda` | 0.1 | 恒螺旋平滑权重 |
| `--adaptive-lambda` | 开启 | 按帧质量缩放平滑权重 |
| `--save-flow` | 关闭 | 稠密场景流写入 `out/flow/*.exr` |
| `--no-motion-constraint` | 关闭 | 禁用场景流中的运动约束 |
| `--no-undistort` | 关闭 | 跳过去畸变 |

`--no-stats` 目前是**空开关**：`argparse` 里有定义，但 `args.no_stats` 从未被读取，
`compute_scene_flow(compute_stats=...)` 始终走默认的 `True`。
传不传都一样，且自适应 λ 依赖 `rigid_delta_mean`，真要接上还得先处理这个依赖。

### `eval_ate.py`

轨迹评估。

- **ATE**：首帧位姿完整锚定（旋转 + 平移），反映纯积分的累积漂移
- **RPE**：默认间隔 30 帧（约 1 秒），反映局部运动精度

输出 `ate.png`：xy 轨迹对比 + 误差随时间变化。

对齐方式的选择很关键：看局部运动精度用 RPE，看积分漂移用首帧锚定的 ATE。
若改用 Umeyama 全局对齐，ATE 会从 5.28 cm 降到 3.14 cm，但那是全局最小二乘的折衷，
不反映真实漂移。

### `plot_errors.py`

绘制逐帧误差与场景流诊断量。四个子图：

1. 平移量估计 vs 真值（cm）
2. 平移误差（cm）与旋转误差（度）
3. 有效像素比
4. 光流幅值、残差光流、流场偏离刚体的距离（px）

CSV 中的距离单位是米，绘图时换算为厘米。

### `analyze_rotation.py`

旋转误差来源分析。回答三个问题：

1. 误差是有偏还是随机？（比较各轴均值与标准差）
2. 是否系统性少转或多转？（`|est|/|gt|` 比值）
3. 误差与哪些因素相关？（角速度、有效像素比、流场质量等）

同时统计累积漂移与随机游走预期的比值——若显著大于 1，说明误差存在时间相关性。

---

## 当前性能

前 200 个关联帧对（8.07 s，真值路径长 3.80 m）：

| 指标 | 数值 |
| --- | --- |
| ATE RMSE | 4.70 cm |
| ATE 中位数 | 4.55 cm |
| ATE 最大 | 9.25 cm |
| RPE 平移 RMSE（Δ=30） | 3.53 cm |
| RPE 旋转 RMSE（Δ=30） | 3.04° |
| 单帧平移误差中位数 | 0.40 cm |
| 单帧旋转误差中位数 | 0.31° |
| RANSAC 内点率 | 94% |

相对漂移约 1.2%。

---

## 已知限制

- **困难帧未标记**。有效像素比低于 0.2 的帧（序列中存在低至 0.04 和 0.00 的情况）
  与正常帧同权进入轨迹，下游无法区分。
- **恒螺旋先验在转弯时有滞后偏置**。加大平滑权重可降低 RPE 旋转，
  但 ATE 单调恶化。自适应 λ 只是部分缓解。
- **场景流落盘只有原始格式**。`--save-flow` 逐帧写全分辨率 EXR，约 854 KB/帧，
  没有抽稀、没有时序压缩，也不与轨迹打包成单一容器。
- **数据集缺帧**。深度帧比 RGB 少 18 张，一对一关联导致 42/200 对的 Δt 翻倍。
  这是数据集本身的问题，未在算法中做适配。

---

## 环境

```bash
python3 -m venv .venv
.venv/bin/pip install -r scripts/requirements.txt
```

依赖：`opencv-python-headless`、`numpy`、`matplotlib`、`pillow`、`imageio`。

`--save-flow` 还需要 freeimage 的动态库。imageio 自带的 `fi.download()`
在本机取不到二进制，实际用的是系统包：

```bash
sudo apt install libfreeimage3     # 提供 /lib/x86_64-linux-gnu/libfreeimage.so.3
```

注意 `~/.local` 可能只读，需用项目内的 venv 而非 `pip --user`。
