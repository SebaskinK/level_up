"""Which discs paint frame-0's left band: newly born, or old discs whose colour drifted?

Loads a finished run's `model_f0.npz` (frame-0 camera coords), re-rasterises the
hard ray-disc render to get the per-pixel owning disc, then splits the left band
by disc birth frame. For old discs (birth==0) it asks whether the colour moved
away from the frame-0 image (drift = dirt) or toward it (tracking = good), and
for later-born discs it asks how far their baked colour already is from frame-0.

Run:
  python scripts/diag_left_oldnew_color.py            # latest footprint run
  python scripts/diag_left_oldnew_color.py --run output_f0_80frame_A_centeronly
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import cv2  # noqa: E402
import numpy as np

SEQ = Path(__file__).resolve().parent
sys.path.insert(0, str(SEQ))

import h_pipeline_final as H          # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402

BANDS = [(0, 64), (64, 128), (128, 192), (192, 256), (0, 128)]
DRIFT_EPS = 0.04          # |dcolour| above this counts as "colour moved"
DEPTH_TOL = 0.05          # |dz|/z above this = geometrically off frame-0 surface
BAR = 36


def caption_bar(img: np.ndarray, text: str, h_bar: int = BAR) -> np.ndarray:
    w = img.shape[1]
    bar = np.full((h_bar, w, 3), 20, np.uint8)
    cv2.putText(bar, text, (8, h_bar - 10), cv2.FONT_HERSHEY_SIMPLEX,
                0.42, (230, 230, 230), 1, cv2.LINE_AA)
    return np.vstack([img, bar])


def caption_bar_wrapped(img: np.ndarray, text: str, per_line: int = 88) -> np.ndarray:
    """Wrap the caption over several lines so nothing is cut off by the image width."""
    words = text.split(" | ")
    lines: list[str] = []
    cur = ""
    for part in words:
        cand = part if not cur else cur + " | " + part
        if len(cand) <= per_line or not cur:
            cur = cand
        else:
            lines.append(cur)
            cur = part
    if cur:
        lines.append(cur)
    h_bar = 18 * len(lines) + 14
    bar = np.full((h_bar, img.shape[1], 3), 20, np.uint8)
    for i, ln in enumerate(lines):
        cv2.putText(bar, ln, (8, 22 + 18 * i), cv2.FONT_HERSHEY_SIMPLEX,
                    0.42, (230, 230, 230), 1, cv2.LINE_AA)
    return np.vstack([img, bar])


def tangent_basis(n: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    ref = np.zeros_like(n)
    ref[:, 2] = 1.0
    flip = np.abs(n[:, 2]) > 0.9
    ref[flip] = np.array([1.0, 0.0, 0.0])
    a1 = np.cross(n, ref)
    a1 /= np.maximum(np.linalg.norm(a1, axis=1, keepdims=True), 1e-9)
    a2 = np.cross(n, a1)
    a2 /= np.maximum(np.linalg.norm(a2, axis=1, keepdims=True), 1e-9)
    return a1, a2


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", default="output_f0_80frame_relinkorder")
    ap.add_argument("--frames", type=int, default=81)
    args = ap.parse_args()
    run = SEQ.parent / args.run

    d = np.load(run / "model_f0.npz")
    mu, normal, scale = d["mu"], d["normal"], d["scale"]
    color, birth, birth_color = d["color"], d["birth"], d["birth_color"]
    a1, a2 = tangent_basis(normal)
    g = H.Gaussians(mu=mu, normal=normal, scale=scale, quat=np.zeros((len(mu), 4)),
                    color=color, alpha=np.ones(len(mu)), pixel=np.zeros((len(mu), 2)),
                    axis1=a1, axis2=a2)

    pairs = SF.associate(SF.DATA, max_dt=0.02)[: args.frames]
    sample = SF.load_rgb(pairs[0].rgb_path)
    h, w = sample.shape[:2]
    map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)
    bgr0, z0, _ = SF.load_pair(pairs, 0, map1, map2)
    gt = bgr0[..., ::-1].astype(np.float32) / 255.0

    depth, index, _ = H.rasterize_discs(g, K, (h, w))
    hit = index >= 0
    print(f"run={args.run}  N={len(mu)}  hard coverage={hit.mean():.4f}")
    print(f"birth histogram: f0={int((birth == 0).sum())} "
          f"f1-10={int(((birth >= 1) & (birth <= 10)).sum())} "
          f"f11-80={int((birth >= 11).sum())}")

    own = index[hit]
    b = birth[own]
    dc = np.linalg.norm(color - birth_color, axis=1)
    err_gt_px = np.full((h, w), np.nan)
    err_gt_px[hit] = np.linalg.norm(color[own] - gt[hit], axis=1)
    bc = birth_color[own]

    dc_birth = np.linalg.norm(bc - gt[hit], axis=1)     # baked colour vs frame-0 image
    dc_final = err_gt_px[hit]                           # current colour vs frame-0 image

    print("\nper-band, over hard-hit pixels:")
    print("  band      hit%   old(f0)%  new%   |dcol|old  |dcol|new   "
          "old: toGT now/atbirth   new: toGT")
    for x0, x1 in BANDS:
        m = np.zeros((h, w), bool)
        m[:, x0:x1] = True
        sel = m[hit]
        if sel.sum() == 0:
            continue
        bo = b[sel] == 0
        bn = ~bo
        now_o = dc_final[sel][bo].mean() if bo.any() else np.nan
        bth_o = dc_birth[sel][bo].mean() if bo.any() else np.nan
        now_n = dc_final[sel][bn].mean() if bn.any() else np.nan
        d_o = dc[own][sel][bo].mean() if bo.any() else np.nan
        d_n = dc[own][sel][bn].mean() if bn.any() else np.nan
        print(f"  x[{x0:3d},{x1:3d}) {100 * sel.mean():5.2f}  {100 * bo.mean():7.2f}  "
              f"{100 * bn.mean():5.2f}   {d_o:8.4f}  {d_n:8.4f}    "
              f"{now_o:6.4f} / {bth_o:6.4f}   {now_n:6.4f}")

    # among old-disc pixels, how many have actually moved, and does the move help?
    for x0, x1 in [(0, 128), (128, w)]:
        m = np.zeros((h, w), bool)
        m[:, x0:x1] = True
        sel = m[hit] & (b == 0)
        if sel.sum() == 0:
            continue
        moved = dc[own][sel] > DRIFT_EPS
        help_ = (dc_final[sel] < dc_birth[sel])
        print(f"\n  old discs x[{x0},{x1}): pixels={int(sel.sum())} "
              f"moved(>{DRIFT_EPS})={100 * moved.mean():.1f}%  "
              f"drift-helped={100 * float(help_.mean()):.1f}%  "
              f"drift-hurt={100 * float((~help_).mean()):.1f}%")
        if moved.any():
            print(f"    moved-subset: |final-GT|={dc_final[sel][moved].mean():.4f}  "
                  f"|birth-GT|={dc_birth[sel][moved].mean():.4f}  "
                  f"|dcol|={dc[own][sel][moved].mean():.4f}")

    # per-disc view: how many distinct discs, and who owns the band
    for x0, x1 in [(0, 128), (128, w)]:
        m = np.zeros((h, w), bool)
        m[:, x0:x1] = True
        ids, cnt = np.unique(index[m & hit], return_counts=True)
        bo = birth[ids] == 0
        area_o = cnt[bo].sum()
        area_n = cnt[~bo].sum()
        print(f"\n  band x[{x0},{x1}): discs={len(ids)} (old {int(bo.sum())} / "
              f"new {int((~bo).sum())})  area share old={100 * area_o / (area_o + area_n):.1f}%")
        band_ids = index[m & hit]
        top = np.argsort(-cnt)[:12]
        print("    top discs (id, birth, px, |dcol|, mean|final-GT| in band):")
        for t in top:
            i = ids[t]
            err_i = err_gt_px[m & hit][band_ids == i].mean()
            print(f"      {i:6d} b={birth[i]:3d} px={cnt[t]:6d} "
                  f"dc={dc[i]:.4f} toGT={err_i:.4f}")


# ---- is the owner geometrically on frame-0's surface? (colours only then comparable)
    dz = np.full((h, w), np.nan)
    dz[hit] = np.abs(depth[hit] - z0[hit]) / np.maximum(z0[hit], 1e-6)
    on_surf = dz < DEPTH_TOL
    print(f"\ndepth-consistency |dz|/z < {DEPTH_TOL}: "
          f"all hit={100 * float(np.nanmean(on_surf[hit])):.1f}%  "
          f"old={100 * float(np.nanmean(on_surf[hit][b == 0])):.1f}%  "
          f"new={100 * float(np.nanmean(on_surf[hit][b != 0])):.1f}%")
    for x0, x1 in [(0, 128), (128, w)]:
        m = np.zeros((h, w), bool)
        m[:, x0:x1] = True
        sel = m & hit & on_surf
        if sel.sum() == 0:
            continue
        bo = birth[index[sel]] == 0
        e = err_gt_px[sel]
        print(f"  x[{x0},{x1}) on-surface hit={int(sel.sum())}: "
              f"old {100 * bo.mean():.1f}% err={1000 * e[bo].mean():.1f}e-3 | "
              f"new err={1000 * e[~bo].mean():.1f}e-3")

    # ---- classification map ----
    dc_px = np.zeros((h, w), np.float64)
    dc_px[hit] = dc[own]
    b_px = np.full((h, w), -1, np.int32)
    b_px[hit] = b
    cls = np.zeros((h, w), np.uint8)
    oldm = hit & (b_px == 0)
    cls[oldm & (dc_px <= DRIFT_EPS)] = 1                         # old, colour stood still
    cls[oldm & (dc_px > DRIFT_EPS)] = 2                          # old, colour drifted
    newm = hit & (b_px >= 1)
    cls[newm & on_surf] = 3                                      # later-born, on surface
    cls[newm & ~on_surf] = 4                                     # later-born, off surface
    pal = {0: (40, 40, 40), 1: (60, 200, 60), 2: (0, 200, 255),
           3: (60, 60, 255), 4: (200, 0, 200)}
    vis = (gt * 0.30 * 255).astype(np.uint8)
    for k, c in pal.items():
        vis[cls == k] = c
    lz = cv2.resize(vis[:, :256], None, fx=2.0, fy=2.0, interpolation=cv2.INTER_NEAREST)
    n_old_still = int(((cls == 1)).sum())
    n_old_drift = int(((cls == 2)).sum())
    n_new_on = int(((cls == 3)).sum())
    n_new_off = int(((cls == 4)).sum())
    cap = (f"f0 owner map | GREEN=old disc, colour unchanged ({n_old_still}) | "
           f"YELLOW=old disc, colour drifted ({n_old_drift}) | "
           f"BLUE=born f1-80, sits on f0 surface ({n_new_on}) | "
           f"MAGENTA=born f1-80, off f0 surface ({n_new_off})")
    print("CAPTION:", cap)

    # Caption numbers are read off THIS run's model, never carried over by hand.
    n_b0 = int((birth == 0).sum())
    n_b1_10 = int(((birth >= 1) & (birth <= 10)).sum())
    n_b11 = int((birth >= 11).sum())
    onc_all = 100 * float(np.nanmean(on_surf[hit]))
    onc_old = 100 * float(np.nanmean(on_surf[hit][b == 0]))
    onc_new = 100 * float(np.nanmean(on_surf[hit][b != 0]))
    selL = np.zeros((h, w), bool)
    selL[:, :128] = True
    selL = selL[hit]
    errL = err_gt_px[hit]
    eL_old = 1000 * float(errL[selL][b[selL] == 0].mean())
    eL_new = 1000 * float(errL[selL][b[selL] != 0].mean())
    stats = {
        "run": args.run, "frames": args.frames, "n_discs": int(len(mu)),
        "coverage": float(hit.mean()),
        "birth_f0": n_b0, "birth_f1_10": n_b1_10, "birth_f11_80": n_b11,
        "depth_consistency_all": onc_all, "depth_consistency_old": onc_old,
        "depth_consistency_new": onc_new,
        "colour_err_left_old_e3": eL_old, "colour_err_left_new_e3": eL_new,
        "px_old_still": n_old_still, "px_old_drift": n_old_drift,
        "px_new_on_surface": n_new_on, "px_new_off_surface": n_new_off,
    }
    (run / "diag_owner_class_f0_stats.json").write_text(json.dumps(stats, indent=2))

    cap_full = (
        f"frame-0 HARD RENDER owner classification, FULL FRAME, {args.frames - 1}-frame "
        f"model, run={args.run}"
        f" | GREEN=old disc (born f0), colour unchanged ({n_old_still})"
        f" | YELLOW=old disc, colour drifted >{DRIFT_EPS} ({n_old_drift})"
        f" | BLUE=born f1-80, on f0 surface |dz|/z<{DEPTH_TOL} ({n_new_on})"
        f" | MAGENTA=born f1-80, off f0 surface ({n_new_off})"
        f" | depth-consistency with f0: all {onc_all:.1f}%, old {onc_old:.1f}%, "
        f"new {onc_new:.1f}%"
        f" | colour err vs f0 image, left band x<128: old {eL_old:.0f}e-3, "
        f"new {eL_new:.0f}e-3"
        f" | discs: born-f0 {n_b0} / f1-10 {n_b1_10} / f11-80 {n_b11}"
    )
    out = run / "diag_owner_class_f0.png"
    cv2.imwrite(str(out), caption_bar(lz, cap))
    cv2.imwrite(str(run / "diag_owner_class_f0_full.png"),
                caption_bar_wrapped(vis, cap_full))
    print("saved ->", out)


if __name__ == "__main__":
    main()