"""Split leftover discs into S2 (texture/footprint) vs curvature, and show why
curvature discs are SMALLER than S2 in the leftover (depth-edge margin) region.

For each covered-disc source pixel:
  r_fp   = surfel footprint radius (world, shared by both disc types)
  r_edge = max radius before hitting a depth discontinuity (world)
S2   disc radius = r_fp * sqrt(2)                      (fixed, stride-2 cover)
CURV disc radius = clip(r_k1, r_fp, max(min(r_max,r_edge), r_fp))
"""

import sys
from pathlib import Path

import numpy as np

SEQ = Path(__file__).resolve().parent
SINGLE = SEQ.parent.parent / "SINGLE FRAME" / "scripts"
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SINGLE))
sys.path.insert(0, str(SFLOW))

import h_pipeline_final as H  # noqa: E402
import incremental_hybrid as INC  # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402
from scene_flow import compute_scene_flow  # noqa: E402
from se3 import se3_exp  # noqa: E402
from tum_io import associate, load_rgb, load_depth, undistort_maps, FR1_INTRINSICS, remap_rgb, remap_depth  # noqa: E402


def main() -> None:
    pairs = associate(SF.DATA)
    h, w = load_rgb(pairs[0].rgb_path).shape[:2]
    map1, map2, K = undistort_maps((h, w), FR1_INTRINSICS)

    def lp(i):
        p = pairs[i]
        bgr = remap_rgb(load_rgb(p.rgb_path), map1, map2)
        z = remap_depth(load_depth(p.depth_path), map1, map2)
        z[z < SF.Z_MIN] = 0.0
        z[z > SF.Z_MAX] = 0.0
        return bgr, z

    bgr0, z0 = lp(0)
    g0, _, _ = H.build_hybrid(bgr0, z0, K, SF.TEX_Q)
    model = SF.Model(
        g=g0, w=np.ones(len(g0), np.float32), age=np.zeros(len(g0), np.int32),
        owner=SF.owner_from_raster(g0, K, (h, w)), birth=np.zeros(len(g0), np.int32),
        cnt=np.ones(len(g0), np.float32),
    )

    bgr1, z1 = lp(1)
    sf = compute_scene_flow(bgr0, bgr1, z0, z1, K, prev=None, dt=1.0, prev_dt=1.0)
    owner_w = SF.warp_owner(model.owner, sf.u, sf.v, sf.valid)
    owner_w = SF._fill_owner_backward(owner_w, model.owner, sf)

    valid_depth = (z1 > SF.Z_MIN) & (z1 < SF.Z_MAX)
    leftover = valid_depth & (owner_w < 0)
    g_new = INC.build_hybrid_region(bgr1, z1, K, SF.TEX_Q, leftover)

    # recompute shared geometry on frame 1 to get per-source-pixel r_fp / r_edge / tex
    geo = H.compute_scene_geometry(
        z1, K, H.GEO_CFG["eps"], H.GEO_CFG["gauss_sigma"], H.GEO_CFG["disc_rel"],
    )
    rgb = bgr1[..., ::-1].astype(np.float32) / 255.0
    tex_mask = H.texture_mask(rgb, SF.TEX_Q)

    _, idx_new, _ = H.rasterize_discs(g_new, K, (h, w))
    covered = (idx_new >= 0) & leftover
    covered_ids = np.unique(idx_new[covered])
    covered_ids = covered_ids[covered_ids >= 0]

    px = g_new.pixel[covered_ids]          # (N,2) [u, v]
    ys, xs = px[:, 1], px[:, 0]
    is_tex = tex_mask[ys, xs]              # S2 = texture footprint disc
    zc = z1[ys, xs]
    r_fp = geo.r_fp[ys, xs]
    r_edge = geo.r_edge[ys, xs]
    lim = np.minimum(H.GEO_CFG["r_max"], r_edge)
    r_s2 = r_fp * np.sqrt(2.0)              # S2 emitted radius
    r_cur = np.clip(geo.r_k1[ys, xs], r_fp, np.maximum(lim, r_fp))  # curvature short axis

    # projected px for a faithful comparison
    f_mean = 0.5 * (K[0, 0] + K[1, 1])
    def px_(r, z):
        return r * f_mean / np.maximum(z, 1e-6)

    n_s2 = int(is_tex.sum())
    n_cur = int((~is_tex).sum())
    print(f"covered discs = {covered_ids.size}  (S2/tex={n_s2}, curvature/nontex={n_cur})")
    print()
    print("S2 (texture footprint) discs:")
    print(f"  emitted radius px   med={np.median(px_(r_s2[is_tex], zc[is_tex])):.2f}  "
          f"mean={px_(r_s2[is_tex], zc[is_tex]).mean():.2f}   ( = r_fp*sqrt(2) )")
    print(f"  r_fp px             med={np.median(px_(r_fp[is_tex], zc[is_tex])):.2f}")
    print()
    print("curvature (non-texture) discs:")
    print(f"  emitted short-axis px  med={np.median(px_(r_cur[~is_tex], zc[~is_tex])):.2f}  "
          f"mean={px_(r_cur[~is_tex], zc[~is_tex]).mean():.2f}")
    print(f"  r_fp px                med={np.median(px_(r_fp[~is_tex], zc[~is_tex])):.2f}")
    print(f"  r_edge px              med={np.median(px_(r_edge[~is_tex], zc[~is_tex])):.2f}  "
          f"(clamp source; < r_fp => collapse to footprint)")
    print(f"  frac r_edge < r_fp     = {(r_edge[~is_tex] < r_fp[~is_tex]).mean():.2%}")
    print(f"  frac r_k1  <= r_fp     = {(geo.r_k1[ys, xs][~is_tex] <= r_fp[~is_tex]).mean():.2%}")


if __name__ == "__main__":
    main()