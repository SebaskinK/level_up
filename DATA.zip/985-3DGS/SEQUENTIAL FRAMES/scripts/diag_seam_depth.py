"""For the 3 seam bands, report the actual front-most rendered depth and the
covering disc's birth frame + 3D z, to distinguish (a) true hole, (b) far-surface
showing through a near-surface gap, (c) near-surface covered.
"""
from __future__ import annotations
import sys
from pathlib import Path
import numpy as np

SEQ = Path(__file__).resolve().parent
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SEQ))
sys.path.insert(0, str(SFLOW))
import h_pipeline_final as H
import sequential_fusion_flowonly as SF


def tang(n):
    n = n.astype(np.float64)
    n = n / np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-12)
    ref = np.tile(np.array([0.0, 0.0, 1.0]), (n.shape[0], 1))
    ref[np.abs(n[:, 2]) > 0.9] = [1, 0, 0]
    t1 = np.cross(ref, n)
    t1 = t1 / np.maximum(np.linalg.norm(t1, axis=1, keepdims=True), 1e-12)
    t2 = np.cross(n, t1)
    return t1, t2


d = np.load(SEQ.parent / "output_f0_ellipse_final" / "model_f0.npz")
mu = d["mu"].astype(np.float64)
normal = d["normal"].astype(np.float64)
scale = d["scale"].astype(np.float64)
color = d["color"].astype(np.float64)
birth = d["birth"].astype(np.int64)
t1, t2 = tang(normal)
g = H.Gaussians(mu=mu, normal=normal, scale=scale,
                quat=H._quat_from_frame(t1.astype(np.float32), t2.astype(np.float32), normal.astype(np.float32)),
                color=color, alpha=None, pixel=np.zeros((len(mu), 2), np.int32),
                axis1=t1.astype(np.float32), axis2=t2.astype(np.float32))

pairs = SF.associate(SF.DATA, max_dt=0.02)[:11]
sm = SF.load_rgb(pairs[0].rgb_path)
h, w = sm.shape[:2]
m1, m2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)
depth, index, _ = H.rasterize_discs(g, K, (h, w))
idx = index.astype(np.int64)
hit = np.isfinite(depth)

bands = {"B1": (600, 602), "B2": (609, 613), "B3": (630, 638)}
for name, (c0, c1) in bands.items():
    print(f"\n=== {name} cols {c0}-{c1} rows 370-399 ===")
    hole_n = 0
    dvals = []
    births = []
    for r in range(370, 400):
        for c in range(c0, c1):
            if not hit[r, c]:
                hole_n += 1
            else:
                dvals.append(depth[r, c])
                births.append(int(birth[idx[r, c]]))
    dvals = np.array(dvals)
    print(f"  total px={30*(c1-c0)}  holes={hole_n}  covered={len(dvals)}")
    if len(dvals):
        # depth clusters: near (<1.0) vs far (>1.5)
        near = dvals < 1.0
        far = dvals > 1.5
        print(f"  covered depth: near(<1m)={near.sum()} far(>1.5m)={far.sum()} other={((~near)&(~far)).sum()}")
        print(f"    near depth range {dvals[near].min():.3f}-{dvals[near].max():.3f}" if near.any() else "    no near")
        print(f"    far depth range {dvals[far].min():.3f}-{dvals[far].max():.3f}" if far.any() else "    no far")
        b = np.array(births)
        print(f"  covering disc birth hist: {np.bincount(b, minlength=11).tolist()}")
        # for far-covered px, what birth
        print(f"    far-covered birth hist: {np.bincount(b[far], minlength=11).tolist()}" if far.any() else "")