"""Summarize the colour-drift diagnostics (birth->final colour + per-frame dcol).

Two independent signals of how much a disc's tracked colour moves over the run:

  1. birth -> final colour distance per disc  (from model_f0.npz)
     ||c_final - c_birth|| : total accumulated colour change a disc's running
     average underwent. Split by birth frame to expose the monotonic exposure
     accumulation (frame-0 discs have had the most frames to drift).

  2. per-frame dcol_med / dcol_p90  (from fusion.csv, the update_hits_onepoint
     probe) : the observation-to-stored-disc colour distance over the
     point-to-plane-passing candidates. This is the tracking lag the colour
     gate actually compares against; a rising trend == discs lagging a drifting
     observation (exposure drift) rather than a static texture-to-colour gap.

Run:  python scripts/diag_color_birth_final.py --npz <dir>/model_f0.npz \
        --csv <dir>/fusion.csv [--frames 81]
"""

from __future__ import annotations

import argparse
import csv
from pathlib import Path

import numpy as np


def load_npz(path: Path) -> dict:
    d = np.load(path, allow_pickle=False)
    return {k: d[k] for k in d.files}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--npz", required=True)
    ap.add_argument("--csv", required=True)
    ap.add_argument("--frames", type=int, default=81)
    args = ap.parse_args()

    d = load_npz(Path(args.npz))
    color = d["color"]            # (N,3) final
    birth_color = d["birth_color"]  # (N,3)
    birth = d["birth"]            # (N,)
    have = np.isfinite(color).all(axis=1) & np.isfinite(birth_color).all(axis=1)
    color = color[have]
    birth_color = birth_color[have]
    birth = birth[have]

    drift = np.linalg.norm(color - birth_color, axis=1)
    gate = 2.0 * np.sqrt(4e-4)

    print(f"N discs              = {len(drift)}")
    print(f"gate threshold       = {gate:.5f}  (2 * sqrt(4e-4))")
    print()
    print("birth -> final colour distance (RGB euclidean):")
    print(f"  mean   = {drift.mean():.5f}   ({drift.mean()/gate:.2f}x gate)")
    print(f"  median = {np.median(drift):.5f}   ({np.median(drift)/gate:.2f}x gate)")
    print(f"  p90    = {np.percentile(drift, 90):.5f}")
    print(f"  p99    = {np.percentile(drift, 99):.5f}")
    print(f"  max    = {drift.max():.5f}")
    print(f"  frac > gate ({gate:.2f}) = {(drift > gate).mean():.3f}")
    print()

    # split by birth frame: do discs born early drift more? (exposure accumulates)
    print("mean drift by birth frame (discs created at frame f):")
    for f in range(0, args.frames, 5):
        sel = birth == f
        if sel.sum() == 0:
            continue
        dd = drift[sel]
        print(f"  birth={f:3d}  n={sel.sum():6d}  "
              f"mean={dd.mean():.5f}  median={np.median(dd):.5f}  "
              f"p90={np.percentile(dd, 90):.5f}")

    # per-frame dcol trend from the fusion csv
    print()
    print("per-frame dcol (observation vs stored disc colour, geometry-passing):")
    n_fail_prev = None
    with open(args.csv) as f:
        rows = list(csv.DictReader(f))
    for r in rows[1:]:
        i = r["i"]
        dmed = float(r.get("dcol_med") or "nan")
        dp90 = float(r.get("dcol_p90") or "nan")
        cfail = int(r["n_color_fail"])
        cand = int(r["n_cand"])
        rej = cfail / cand if cand else float("nan")
        print(f"  {i:>3s}  dcol_med={dmed:.4f}  dcol_p90={dp90:.4f}  "
              f"color_rej={rej:.3f}")


if __name__ == "__main__":
    main()