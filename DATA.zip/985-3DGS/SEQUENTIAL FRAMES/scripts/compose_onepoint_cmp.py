"""Compose OLD (region-weighted) vs NEW (one-point) frame-0 hard renders.

Grid: 2 rows (OLD / NEW) x 4 cols (0 / 3 / 6 / 10 frame models).
Two outputs: full-frame and a right-edge zoom (desk surface vs gray side).
"""
from pathlib import Path

import cv2
import numpy as np

ROOT = Path("/home/sti/Work/985-3DGS/SEQUENTIAL FRAMES")
OLD = "output_f0_{n}frame"
NEW = "output_onepoint_f0_{n}frame"
FRAMES = ["0", "3", "6", "10"]
LABELS = ["0帧", "3帧", "6帧", "10帧"]
ROWS = [("OLD 区域加权", OLD), ("NEW 逐盘单点", NEW)]


def load(path: Path) -> np.ndarray:
    im = cv2.imread(str(path))
    assert im is not None, path
    return im


def grid(cells, cell_h, cell_w, label_h=28, gap=6):
    nr, nc = cells.shape[:2]
    pad = 8
    out = np.full(
        (pad + nr * (cell_h + label_h + gap) + pad,
         pad + nc * (cell_w + gap) + pad, 3), 40, np.uint8)
    for r in range(nr):
        for c in range(nc):
            im = cells[r, c]
            ih, iw = im.shape[:2]
            if ih != cell_h or iw != cell_w:
                im = cv2.resize(im, (cell_w, cell_h), interpolation=cv2.INTER_AREA)
            y0 = pad + r * (cell_h + label_h + gap)
            x0 = pad + c * (cell_w + gap)
            out[y0:y0 + cell_h, x0:x0 + cell_w] = im
            cv2.putText(out, labels[c] if r == 0 else "",
                        (x0, y0 + cell_h + 18),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.55, (225, 225, 225), 1, cv2.LINE_AA)
            cv2.putText(out, ROWS[r][0],
                        (x0, y0 - 6) if y0 - 6 >= 12 else (x0, y0 + 14),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.55, (120, 210, 255), 1, cv2.LINE_AA)
    return out


labels = LABELS

# full frame
cells = np.empty((2, 4), dtype=object)
for r, (name, base) in enumerate(ROWS):
    for c, f in enumerate(FRAMES):
        cells[r, c] = load(ROOT / base.format(n=f) / "f0_hard.png")
full = grid(cells, 240, 320)
cv2.imwrite(str(ROOT / "cmp_onepoint_hard_full.png"), full)

# right-edge zoom: x[360:640], y[120:480]
def zoom(im):
    crop = im[120:480, 360:640]
    return cv2.resize(crop, None, fx=1.6, fy=1.6, interpolation=cv2.INTER_NEAREST)

cells_z = np.empty((2, 4), dtype=object)
for r, (name, base) in enumerate(ROWS):
    for c, f in enumerate(FRAMES):
        cells_z[r, c] = zoom(load(ROOT / base.format(n=f) / "f0_hard.png"))
zoom_img = grid(cells_z, cells_z[0, 0].shape[0], cells_z[0, 0].shape[1])
cv2.imwrite(str(ROOT / "cmp_onepoint_hard_rightzoom.png"), zoom_img)

print("written cmp_onepoint_hard_full.png", full.shape)
print("written cmp_onepoint_hard_rightzoom.png", zoom_img.shape)