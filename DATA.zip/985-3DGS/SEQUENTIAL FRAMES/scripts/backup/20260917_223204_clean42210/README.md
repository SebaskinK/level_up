# backup snapshot 2026-09-17 22:32（锚点：可复现 30238 → 42210）

手动快照。本目录不是 git 仓库（`/home/sti/Work/.git` 是 Trae 日志目录），
本快照作为「disc_mask 回退 + 去 cnt/recheck」全部落地后的**干净锚点**。

## 快照内容（均为当前工作区的真实状态，`cp -p` 保留 mtime）

- `h_pipeline_final.py` —— `disc_mask` 4+1 处全部回退到 `depth_discontinuity_mask`
  （`compute_scene_geometry` / `emit_footprint_discs` fallback / `emit_curvature_discs`
  fallback / `eval_setup`），`edge_distance_limit` 保持 `depth_jump_mask`。三个 mask
  函数 + `edge_distance_limit` + `CurvatureGeometry` 字段注释已同步更正。
- `incremental_hybrid.py` —— `_geometry_cropped.disc_mask` 回退到 `depth_discontinuity_mask`。
- `sequential_fusion_flowonly.py` —— 已回到 15:44 版（`update_hits_onepoint`，无 `cnt`、
  无 `recheck_owned_gate`）。与 `backup/20260917_154431/sequential_fusion_flowonly.py`
  **逐字节一致**。
- `render_f0_images.py` —— Model 构造里 `cnt` 已删。
- `DISC_MASK_REVERT_20260917.md` —— 本次改动的完整记录（结果 / 改动清单 / 根因 / 复现命令）。

## 怎么用作锚点

```bash
cd "/home/sti/Work/985-3DGS/SEQUENTIAL FRAMES/scripts"
# 之后任何改动前，先确认当前是否 = 本锚点：
for f in h_pipeline_final.py incremental_hybrid.py sequential_fusion_flowonly.py render_f0_images.py; do
  diff -q "backup/20260917_223204_clean42210/$f" "$f" || echo "DIFFERS: $f"
done

# 完整复现 30238 -> 42210（无老化、黑边填充+absorb 开）：
"/home/sti/Work/985-3DGS/SINGLE FRAME/.venv/bin/python" sequential_fusion_flowonly.py \
    --max-pairs 10 --age-max 1000000 --w-min 0 --out ../output_f0_10frame_fix
```

## 注意

- 本快照**不含** `backup/20260917_215224` 那轮「cnt + recheck_owned_gate」实验版本；
  那版已回退，仅在 215224 快照中留档，勿误当当前态。