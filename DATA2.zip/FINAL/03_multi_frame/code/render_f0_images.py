"""Run the 10-frame incremental fusion once, then render frame 0 from THAT model.

Single process so the images are guaranteed to come from the exact 3D Gaussian
set the fusion produced (aging pruning is OFF in this script: AGE_MAX=1e6, W_MIN=0.0; 986 xi).
The final model lives in the last-camera frame, so we accumulate the frame-0 ->
frame-k point motion FL_k and transform the final model back to frame 0, then:

  1. f0_ellipse.png        : disc footprint ellipses projected onto frame 0
  2. f0_hard.png           : hard ray-disc render (front-most disc colour)
  3. f0_ewa.png            : EWA normalized render
  4. f0_depth_hard.{npy,png}: back-projected depth (front-most disc plane z)

Also writes fusion.csv / summary.json / model.ply (frame-10) / model_f0.npz.
"""

from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

import cv2
import numpy as np

SEQ = Path(__file__).resolve().parent          # multi-frame H + sequential_fusion_flowonly
SINGLE = SEQ.parent.parent / "SINGLE FRAME" / "scripts"   # exp_surfel_render only
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
# SEQ last => index 0, so the multi-frame h_pipeline_final wins over SINGLE's.
sys.path.insert(0, str(SFLOW))
sys.path.insert(0, str(SINGLE))
sys.path.insert(0, str(SEQ))

import h_pipeline_final as H                           # noqa: E402  (multi-frame copy)
import sequential_fusion_flowonly as SF                # noqa: E402
from exp_surfel_render import render_ewa               # noqa: E402

OUT = SEQ.parent / "output_f0_10frame"
OUT.mkdir(parents=True, exist_ok=True)

AGE_MAX = 1000000   # aging pruning off by default (age never exceeds this)
W_MIN = 0.0
N_PTS = 40
TH = np.linspace(0.0, 2.0 * np.pi, N_PTS, endpoint=False)
COS = np.cos(TH)
SIN = np.sin(TH)


def pm_compose(a, b):
    Ra, ta = a
    Rb, tb = b
    return Rb @ Ra, Rb @ ta + tb


def pm_inv(a):
    R, t = a
    return R.T, -R.T @ t


def apply_pm(g, pm):
    return SF.transform_to_next(g, pm[0], pm[1])


def tangent_basis(n):
    n = n.astype(np.float64)
    n = n / np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-12)
    ref = np.tile(np.array([0.0, 0.0, 1.0]), (n.shape[0], 1))
    ref[np.abs(n[:, 2]) > 0.9] = np.array([1.0, 0.0, 0.0])
    t1 = np.cross(ref, n)
    t1 = t1 / np.maximum(np.linalg.norm(t1, axis=1, keepdims=True), 1e-12)
    t2 = np.cross(n, t1)
    return t1, t2


def save_depth_png(path: Path, depth: np.ndarray, caption: str | None = None) -> None:
    """Save a viewable depth preview (turbo colormap, holes black)."""
    finite = np.isfinite(depth)
    zmax = float(np.percentile(depth[finite], 99.0)) if finite.any() else 1.0
    zmin = float(depth[finite].min()) if finite.any() else 0.0
    norm = np.zeros_like(depth, dtype=np.float32)
    if zmax > zmin:
        norm[finite] = ((depth[finite] - zmin) / (zmax - zmin)).astype(np.float32)
    col = cv2.applyColorMap((norm * 255).astype(np.uint8), cv2.COLORMAP_TURBO)
    col[~finite] = 0
    if caption is not None:
        col = caption_bar(col, caption)
    cv2.imwrite(str(path), col)


def psnr_masked(img_rgb: np.ndarray, ref_rgb: np.ndarray, mask: np.ndarray) -> float:
    """PSNR (dB) over masked pixels, RGB in [0,1]."""
    if not mask.any():
        return float("nan")
    err = img_rgb[mask] - ref_rgb[mask]
    mse = float(np.mean(err * err))
    if mse <= 0:
        return float("inf")
    return float(10.0 * np.log10(1.0 / mse))


def caption_bar(img: np.ndarray, text: str, h_bar: int = 36) -> np.ndarray:
    """Stack a dark caption strip under an image for traceability."""
    w = img.shape[1]
    bar = np.full((h_bar, w, 3), 20, np.uint8)
    cv2.putText(bar, text, (8, h_bar - 10), cv2.FONT_HERSHEY_SIMPLEX,
                0.45, (230, 230, 230), 1, cv2.LINE_AA)
    return np.vstack([img, bar])


def main() -> None:
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--no-absorb", action="store_true",
                    help="disable absorb_leftover_pixels")
    ap.add_argument("--no-relink", action="store_true",
                    help="disable relink_projective (sparse disc-centre re-link)")
    ap.add_argument("--relink-no-color", action="store_true",
                    help="geometry-only relink: drop colour gate, keep point-to-plane")
    ap.add_argument("--relink-center-only", action="store_true",
                    help="A/B control: relink centre pixel only, not footprint")
    ap.add_argument("--flow-first-owner", action="store_true",
                    help="A/B control: legacy order (flow owner before relink)")
    ap.add_argument("--out", default=str(SEQ.parent / "output_f0_10frame"))
    ap.add_argument("--frames", type=int, default=11,
                    help="number of consecutive frame-0..frames-1 pairs to model")
    ap.add_argument("--color-gate-k", type=float, default=SF.COLOR_GATE_K,
                    help="colour-gate coefficient (distance <= k * local texture "
                         "sigma) for the flow-hit, footprint and absorb gates. "
                         "Does NOT touch RELINK_COLOR_GATE_K (re-link has its own).")
    ap.add_argument("--color-sample", choices=("footprint", "center"),
                    default=SF.COLOR_SAMPLE,
                    help="spatial sample of the colour observation: 'footprint' = mean "
                         "over the disc's whole written footprint (baseline), 'center' = "
                         "the disc's projected centre pixel, still weighted by the "
                         "footprint pixel count.")
    args = ap.parse_args()
    global OUT
    OUT = Path(args.out)
    OUT.mkdir(parents=True, exist_ok=True)
    SF.COLOR_GATE_K = args.color_gate_k
    SF.COLOR_SAMPLE = args.color_sample

    pairs = SF.associate(SF.DATA, max_dt=0.02)[: args.frames]
    n_frames = len(pairs)
    sample = SF.load_rgb(pairs[0].rgb_path)
    h, w = sample.shape[:2]
    map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)

    bgr0, z0, _ = SF.load_pair(pairs, 0, map1, map2)
    g0, _, _, owner0 = H.build_hybrid_with_owner(bgr0, z0, K, SF.TEX_Q)
    model = SF.Model(
        g=g0,
        w=np.ones(len(g0), dtype=np.float32),
        w_col=np.ones(len(g0), dtype=np.float32),
        age=np.zeros(len(g0), dtype=np.int32),
        owner=owner0,
        birth=np.zeros(len(g0), dtype=np.int32),
        birth_color=g0.color.astype(np.float32).copy(),
    )

    FL = [None] * n_frames
    FL[0] = (np.eye(3), np.zeros(3))
    prev_FL = FL[0]
    rows = [{"i": -1, "n": len(g0), "n_upd": 0, "n_new": len(g0),
             "n_s2": 0, "n_curv": 0, "n_absorb": 0, "n_old_drawn": 0,
             "n_leftover": 0,
             "n_relink": 0, "n_relink_plane_fail": 0, "n_relink_color_fail": 0,
             "n_gate_fail": 0, "n_color_fail": 0, "n_absorb_color_fail": 0,
             "n_cand": 0, "dcol_med": float("nan"), "dcol_p90": float("nan")}]
    print(f"[init] N={len(g0)}", flush=True)

    prev_sf = None
    prev_dt = 1.0
    bgr_a, z_a = bgr0, z0
    for i in range(len(pairs) - 1):  # frames 1..10
        bgr_b, z_b, _ = SF.load_pair(pairs, i + 1, map1, map2)
        dt = pairs[i + 1].t_rgb - pairs[i].t_rgb
        sf = SF.compute_scene_flow(
            bgr_a, bgr_b, z_a, z_b, K,
            prev=prev_sf, dt=dt, prev_dt=prev_dt,
        )
        if sf.xi is None:
            raise RuntimeError("scene flow produced no twist")
        R_10, t_10 = SF.se3_exp(sf.xi)
        FL[i + 1] = pm_compose(prev_FL, (R_10, t_10))

        rec = SF.fuse_frame(model, sf, z_a, z_b, bgr_b, K,
                            age_max=AGE_MAX, w_min=W_MIN, frame_idx=i,
                            R_10=R_10, t_10=t_10, no_absorb=args.no_absorb,
                            no_relink=args.no_relink,
                            relink_color_gate=not args.relink_no_color,
                            relink_center_only=args.relink_center_only,
                            flow_first_owner=args.flow_first_owner)
        rows.append({"i": i, "n": rec["n"], "n_upd": rec["n_upd"],
                     "n_new": rec["n_new"], "n_s2": rec["n_s2"],
                     "n_curv": rec["n_curv"], "n_absorb": rec["n_absorb"],
                     "n_old_drawn": rec.get("n_old_drawn", 0),
                     "n_leftover": rec["n_leftover"], "n_relink": rec["n_relink"],
                     "n_relink_plane_fail": rec["n_relink_plane_fail"],
                     "n_relink_color_fail": rec["n_relink_color_fail"],
                     "n_gate_fail": rec["n_gate_fail"],
                     "n_color_fail": rec["n_color_fail"],
                     "n_absorb_color_fail": rec["n_absorb_color_fail"],
                     "n_cand": rec["n_cand"],
                     "dcol_med": rec["dcol_med"], "dcol_p90": rec["dcol_p90"]})
        print(f"[{i:03d}] N={rec['n']} upd={rec['n_upd']} new={rec['n_new']} "
              f"s2={rec['n_s2']} curv={rec['n_curv']} abs={rec['n_absorb']} "
              f"relink={rec['n_relink']} "
              f"rpf={rec['n_relink_plane_fail']} rcf={rec['n_relink_color_fail']} "
              f"cfail={rec['n_color_fail']} acfail={rec['n_absorb_color_fail']} "
              f"dcol_med={rec['dcol_med']:.4f} dcol_p90={rec['dcol_p90']:.4f} "
              f"owned={rec['n_owned']}", flush=True)

        bgr_a, z_a = bgr_b, z_b
        prev_sf, prev_dt = sf, dt
        prev_FL = FL[i + 1]

    g = model.g                          # last-frame camera coords
    g0f = apply_pm(g, pm_inv(FL[n_frames - 1]))    # back to frame-0 camera coords
    print(f"final N={len(g)}", flush=True)

    summary = {
        "n_frames": n_frames,
        "n_init": rows[0]["n"],
        "n_final": len(g),
        "n_new_mean": float(np.mean([r["n_new"] for r in rows[1:]])) if len(rows) > 1 else 0.0,
        "n_s2_total": int(sum(r["n_s2"] for r in rows[1:])),
        "n_curv_total": int(sum(r["n_curv"] for r in rows[1:])),
    }
    keys = list(rows[0].keys())
    with (OUT / "fusion.csv").open("w", newline="") as f:
        wri = csv.DictWriter(f, fieldnames=keys)
        wri.writeheader()
        wri.writerows(rows)
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2))
    SF.write_ply(OUT / "model.ply", g)
    np.savez(OUT / "model_f0.npz",
             mu=g0f.mu.astype(np.float64),
             normal=g0f.normal.astype(np.float64),
             scale=g0f.scale.astype(np.float64),
             color=g0f.color.astype(np.float64),
             birth=model.birth.astype(np.int32),
             birth_color=model.birth_color.astype(np.float64),
             w_col=model.w_col.astype(np.float64),
             age=model.age.astype(np.int32))

    fx, fy, cx, cy = (float(K[0, 0]), float(K[1, 1]), float(K[0, 2]), float(K[1, 2]))

    # ---- (1) ellipse projection ----
    mu = g0f.mu.astype(np.float64)
    r1 = g0f.scale[:, 0].astype(np.float64)
    r2 = g0f.scale[:, 1].astype(np.float64)
    if g0f.axis1 is not None and g0f.axis2 is not None:
        t1 = g0f.axis1.astype(np.float64)
        t2 = g0f.axis2.astype(np.float64)
    else:
        t1, t2 = tangent_basis(g0f.normal)
    cs = COS[:, None]
    sn = SIN[:, None]
    p = (mu[None, :, :]
         + (r1 * cs)[:, :, None] * t1[None, :, :]
         + (r2 * sn)[:, :, None] * t2[None, :, :])
    zc = np.maximum(p[..., 2], 1e-6)
    u = np.clip((fx * p[..., 0] / zc + cx).astype(np.int32), 0, w - 1)
    v = np.clip((fy * p[..., 1] / zc + cy).astype(np.int32), 0, h - 1)
    epts = np.ascontiguousarray(np.stack([u, v], axis=-1).transpose(1, 0, 2))
    vis = (bgr0.astype(np.float32) * 0.5).astype(np.uint8).copy()
    for i in range(len(g0f)):
        cv2.polylines(vis, [epts[i]], True, (0, 0, 255), 1, cv2.LINE_8)
    cap = f"ELLIPSE  |  {n_frames - 1}-frame model -> frame-0  |  TEX_VAR_THR={H.TEX_VAR_THR:g}  |  N={len(g0f)}"
    cv2.imwrite(str(OUT / "f0_ellipse.png"), caption_bar(vis, cap))

    # ---- (2) hard ray-disc render + (4) back-projected depth ----
    depth_a, index_a, _ = H.rasterize_discs(g0f, K, (h, w))
    hit_a = np.isfinite(depth_a)
    hard = np.zeros((h, w, 3), np.float32)
    hard[hit_a] = g0f.color[index_a[hit_a]]
    hard_bgr = (np.clip(hard, 0, 1) * 255).astype(np.uint8)[..., ::-1].copy()
    hard_bgr[~hit_a] = 0
    cv2.imwrite(str(OUT / "f0_hard.png"),
                caption_bar(hard_bgr, cap.replace("ELLIPSE", "HARD RAY")))
    np.save(OUT / "f0_depth_hard.npy", np.where(hit_a, depth_a, 0.0).astype(np.float64))
    save_depth_png(OUT / "f0_depth_hard.png", depth_a,
                   cap.replace("ELLIPSE", "BACKPROJ DEPTH"))
    ref_rgb = bgr0[..., ::-1].astype(np.float32) / 255.0
    print(f"hard  covered={float(hit_a.mean()):.4f} hole={1 - float(hit_a.mean()):.4f} "
          f"psnr={psnr_masked(hard, ref_rgb, hit_a):.3f} dB")

    # ---- (3) EWA normalized ----
    color_b, depth_b, weight_b = render_ewa(g0f, K, (h, w),
                                            mode="normalized", cov_scale=0.33)
    hit_b = weight_b > 0
    ewa_bgr = (np.clip(color_b, 0, 1) * 255).astype(np.uint8)[..., ::-1].copy()
    ewa_bgr[~hit_b] = 0
    cv2.imwrite(str(OUT / "f0_ewa.png"),
                caption_bar(ewa_bgr, cap.replace("ELLIPSE", "EWA")))
    print(f"ewa   covered={float(hit_b.mean()):.4f} hole={1 - float(hit_b.mean()):.4f} "
          f"psnr={psnr_masked(color_b, ref_rgb, hit_b):.3f} dB")

    # reference GT (frame 0 undistorted)
    cv2.imwrite(str(OUT / "f0_gt.png"), bgr0)
    save_depth_png(OUT / "f0_depth_gt.png", z0.astype(np.float64))

    print(json.dumps(summary, indent=2))
    print(f"saved -> {OUT}")


if __name__ == "__main__":
    main()