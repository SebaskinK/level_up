"""Per-frame coverage of the FINAL model, split cov_scale 0.33 vs 1.0.

Answers: are the holes you see a MODEL/aging problem, or a RENDER problem
(cov_scale=0.33 over-shrinking each splat so neighbours no longer overlap)?

Loads the final model (output_absorb_v2/render/model_final.npz + FL9), places it
back into each GT camera (T_k = GT_k . FL9^-1), renders with EWA normalized at
cov_scale 1.0 and 0.33, and reports coverage + eval-domain coverage + PSNR.
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

SEQ = Path(__file__).resolve().parent
SINGLE = SEQ.parent.parent / "SINGLE FRAME" / "scripts"
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SINGLE))
sys.path.insert(0, str(SFLOW))

import h_pipeline_final as H  # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402
from exp_surfel_render import render_ewa  # noqa: E402

DATA = SF.DATA
RENDER_DIR = SEQ.parent / "output_absorb_v2" / "render"


def pm_compose(a, b):
    Ra, ta = a
    Rb, tb = b
    return Rb @ Ra, Rb @ ta + tb


def pm_inv(a):
    R, t = a
    return R.T, -R.T @ t


def psnr(render, ref, mask):
    if not mask.any():
        return float("nan")
    err = render[mask] - ref[mask]
    return float(-20.0 * np.log10(max(float(np.sqrt(np.mean(err ** 2))), 1e-12)))


def main() -> None:
    npz = np.load(RENDER_DIR / "model_final.npz", allow_pickle=True)
    ax1 = npz["axis1"] if npz["axis1"].shape else None
    ax2 = npz["axis2"] if npz["axis2"].shape else None
    g = H.Gaussians(
        mu=npz["mu"], normal=npz["normal"], scale=npz["scale"],
        quat=npz["quat"], color=npz["color"], alpha=npz["alpha"],
        pixel=npz["pixel"], axis1=ax1, axis2=ax2,
    )
    FL9_inv = pm_inv((npz["FL9"], npz["FL9_t"]))

    pairs = SF.associate(DATA, max_dt=0.02)[:11]
    sample = SF.load_rgb(pairs[0].rgb_path)
    h, w = sample.shape[:2]
    map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)
    gt_ts, gt_t, gt_q = SF.load_groundtruth(DATA / "groundtruth.txt")

    # GT point motion frame0 -> k
    GT = [None] * 11
    GT[0] = (np.eye(3), np.zeros(3))
    for i in range(10):
        m0 = SF.interpolate_pose(pairs[i].t_rgb, gt_ts, gt_t, gt_q)
        m1 = SF.interpolate_pose(pairs[i + 1].t_rgb, gt_ts, gt_t, gt_q)
        R_eg, t_eg = SF.relative_camera_motion(*m0, *m1)
        Rg, tg = SF.invert_point_motion(R_eg, t_eg)
        GT[i + 1] = pm_compose(GT[i], (Rg, tg))

    print(f"final N={len(g)}")
    print(f"{'f':>3} {'cov@1.0':>8} {'eval@1.0':>8} {'psnr@1.0':>8} "
          f"{'cov@0.33':>9} {'eval@0.33':>9} {'psnr@0.33':>9}")
    for k in range(10):
        bgr, z, _ = SF.load_pair(pairs, k, map1, map2)
        rgb_ref = bgr[..., ::-1].astype(np.float32) / 255.0
        normal_ref, eval_mask = H.eval_setup(z, K)
        T_k = pm_compose(FL9_inv, GT[k])
        gk = SF.transform_to_next(g, T_k[0], T_k[1])
        for cs in (1.0, 0.33):
            col, dp, wt = render_ewa(gk, K, (h, w), mode="normalized", cov_scale=cs)
            hh = wt > 0
            cov = float(hh.mean())
            ecov = float((hh & eval_mask).sum() / eval_mask.sum())
            p = psnr(col, rgb_ref, hh & eval_mask)
            if cs == 1.0:
                row = [f"{k:>3}", f"{cov:.4f}", f"{ecov:.4f}", f"{p:.2f}"]
            else:
                row += [f"{cov:.4f}", f"{ecov:.4f}", f"{p:.2f}"]
        print("  ".join(row))


if __name__ == "__main__":
    main()