"""Project the 10-frame incremental model's disc ellipses back onto frame 0.

Reproduces the claim-owner fusion loop (full-radius claim owner, age_max/w_min
chosen so nothing is pruned -- matching the n_final=41948 run), accumulates the flow point
motions FL_k (frame0 -> k), then transforms the FINAL model (which lives in the
last camera frame) back into frame 0 via FL_10^{-1} and draws each disc's emitted
footprint ellipse (in-plane r1 x r2) projected with frame 0's intrinsics.

Note on orientation: the incremental model stores `quat = _quat_from_normal(n)`
whose tangent basis (x,y) is a deterministic-but-arbitrary frame from the normal,
NOT the principal-curvature axes (axis1/axis2 are dropped by concatenation, since
S2 discs have none). So each ellipse has the correct semi-axis LENGTHS (r1,r2)
and tangent plane, but its in-plane rotation is the quaternion basis, not the true
principal direction.
"""

from __future__ import annotations

import sys
from pathlib import Path

import cv2
import numpy as np

SEQ = Path(__file__).resolve().parent
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SFLOW))
sys.path.insert(0, str(SEQ))

import h_pipeline_final as H  # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402

DATA = SF.DATA
OUT = SEQ.parent / "output_leftover_viz" / "f0_ellipse"
OUT.mkdir(parents=True, exist_ok=True)

N_PTS = 40
TH = np.linspace(0.0, 2.0 * np.pi, N_PTS, endpoint=False)
COS = np.cos(TH)
SIN = np.sin(TH)


def pm_compose(a, b):
    """Point-motion compose: X_out = Rb (Ra X + ta) + tb."""
    Ra, ta = a
    Rb, tb = b
    return Rb @ Ra, Rb @ ta + tb


def pm_inv(a):
    R, t = a
    return R.T, -R.T @ t


def apply_pm(g, pm):
    return SF.transform_to_next(g, pm[0], pm[1])


def tangent_basis(n):
    """Same Gram-Schmidt as _quat_from_normal: (t1,t2,n) orthonormal, z->n."""
    n = n.astype(np.float64)
    n = n / np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-12)
    ref = np.tile(np.array([0.0, 0.0, 1.0]), (n.shape[0], 1))
    ref[np.abs(n[:, 2]) > 0.9] = np.array([1.0, 0.0, 0.0])
    t1 = np.cross(ref, n)
    t1 = t1 / np.maximum(np.linalg.norm(t1, axis=1, keepdims=True), 1e-12)
    t2 = np.cross(n, t1)
    return t1, t2


def main() -> None:
    pairs = SF.associate(DATA, max_dt=0.02)[: 11]
    sample = SF.load_rgb(pairs[0].rgb_path)
    h, w = sample.shape[:2]
    map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)

    bgr0, z0, _ = SF.load_pair(pairs, 0, map1, map2)
    g0, _, _, owner0 = H.build_hybrid_with_owner(bgr0, z0, K, SF.TEX_Q)
    model = SF.Model(
        g=g0,
        w=np.ones(len(g0), dtype=np.float32),
        age=np.zeros(len(g0), dtype=np.int32),
        owner=owner0,
        birth=np.zeros(len(g0), dtype=np.int32),
        cnt=np.ones(len(g0), dtype=np.float32),
    )

    FL = [None] * 11
    FL[0] = (np.eye(3), np.zeros(3))
    prev_FL = FL[0]

    prev_sf = None
    prev_dt = 1.0
    bgr_a, z_a = bgr0, z0
    for i in range(len(pairs) - 1):  # 10 incremental steps -> frame 0..10
        bgr_b, z_b, _ = SF.load_pair(pairs, i + 1, map1, map2)
        dt = pairs[i + 1].t_rgb - pairs[i].t_rgb
        sf = SF.compute_scene_flow(
            bgr_a, bgr_b, z_a, z_b, K,
            prev=prev_sf, dt=dt, prev_dt=prev_dt,
        )
        if sf.xi is None:
            raise RuntimeError("scene flow produced no twist")
        R_10, t_10 = SF.se3_exp(sf.xi)
        FL[i + 1] = pm_compose(prev_FL, (R_10, t_10))

        rec = SF.fuse_frame(model, sf, z_a, z_b, bgr_b, K,
                            age_max=1000000, w_min=0.0, frame_idx=i,
                            R_10=R_10, t_10=t_10)
        print(f"[f0-ellipse] step {i} N={rec['n']}", flush=True)

        bgr_a, z_a = bgr_b, z_b
        prev_sf, prev_dt = sf, dt
        prev_FL = FL[i + 1]

    g = model.g                      # in frame-10 camera coords
    g0f = apply_pm(g, pm_inv(FL[10]))  # back to frame-0 camera coords
    print(f"final N={len(g)}", flush=True)
    cache = OUT / "model_f0.npz"
    np.savez(cache, mu=g0f.mu.astype(np.float64),
             normal=g0f.normal.astype(np.float64),
             scale=g0f.scale.astype(np.float64))
    print(f"cached -> {cache}", flush=True)

    fx, fy, cx, cy = (float(K[0, 0]), float(K[1, 1]), float(K[0, 2]), float(K[1, 2]))

    mu = g0f.mu.astype(np.float64)
    r1 = g0f.scale[:, 0].astype(np.float64)
    r2 = g0f.scale[:, 1].astype(np.float64)
    t1, t2 = tangent_basis(g0f.normal)

    # 3D ellipse boundary for every disc, then project (vectorised).
    cs = COS[:, None]
    sn = SIN[:, None]
    p = (mu[None, :, :]
         + (r1 * cs)[:, :, None] * t1[None, :, :]
         + (r2 * sn)[:, :, None] * t2[None, :, :])       # (N_PTS, N, 3)
    zc = np.maximum(p[..., 2], 1e-6)
    u = (fx * p[..., 0] / zc + cx).astype(np.int32)      # (N_PTS, N)
    v = (fy * p[..., 1] / zc + cy).astype(np.int32)
    u = np.clip(u, 0, w - 1)
    v = np.clip(v, 0, h - 1)
    epts = np.stack([u, v], axis=-1)                     # (N_PTS, N, 2)

    vis = (bgr0.astype(np.float32) * 0.5).astype(np.uint8).copy()
    epts = np.ascontiguousarray(epts.transpose(1, 0, 2))  # (N, N_PTS, 2) contiguous
    for i in range(len(g)):
        cv2.polylines(vis, [epts[i]], True, (0, 0, 255), 1, cv2.LINE_8)

    bar = np.full((40, w, 3), 25, np.uint8)
    cv2.putText(
        bar,
        f"frame-0 projection of 10-frame model: {len(g)} disc footprint ellipses "
        f"(red; orientation = quaternion tangent basis, not principal axes)",
        (8, 26), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (225, 225, 225), 1, cv2.LINE_AA,
    )
    out_img = np.vstack([vis, bar])
    cv2.imwrite(str(OUT / "f0_ellipse.png"), out_img)
    print(f"saved -> {OUT / 'f0_ellipse.png'}")


if __name__ == "__main__":
    main()