"""Render comparison panel for experiment H (S2-fallback hybrid).

Current algorithm: texture mask -> S2 (stride 2, x√2 radius) inside, curvature
outside with tex_boundary_limit clamping. Baselines: full S2, full curvature.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from exp_h_s2 import build_s2_fallback  # noqa: E402
from exp_g_aniso_real import CFG as GEO_CFG, eval_setup  # noqa: E402
from exp_e_curvature_sample import curvature_mask  # noqa: E402
from gaussian_build import build_gaussians, build_gaussians_curvature  # noqa: E402
from metrics import rasterize_discs  # noqa: E402
from rgbd_io import (  # noqa: E402
    FR1_INTRINSICS,
    associate,
    load_depth,
    load_rgb,
    remap_depth,
    remap_rgb,
    undistort_maps,
)


def label(img, text):
    out = img.copy()
    cv2.rectangle(out, (0, 0), (out.shape[1], 34), (0, 0, 0), -1)
    cv2.putText(out, text, (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
    return out


def render_psnr(g, bgr, shape, K, eval_mask):
    depth, index, _ = rasterize_discs(g, K, shape)
    hit = index >= 0
    render = np.zeros((*shape, 3), dtype=np.uint8)
    rgb = np.clip(g.color[index[hit]], 0.0, 1.0)
    render[hit] = (rgb[:, ::-1] * 255.0).astype(np.uint8)
    m = hit & eval_mask
    if m.any():
        err = g.color[index[m]] - (bgr[..., ::-1].astype(np.float32) / 255.0)[m]
        psnr = -20.0 * np.log10(max(float(np.sqrt(np.mean(err ** 2))), 1e-12))
    else:
        psnr = 0.0
    return render, psnr


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--data", default=str(
        ROOT.parent.parent / "986-SceneFlow" / "rgbd_dataset_freiburg1_desk"))
    p.add_argument("--out", default=str(ROOT.parent / "output_H"))
    p.add_argument("--frame", type=int, default=0)
    args = p.parse_args()

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    pairs = associate(Path(args.data))
    fr = pairs[args.frame]
    sample = load_rgb(pairs[0].rgb_path)
    map1, map2, K = undistort_maps(sample.shape[:2], FR1_INTRINSICS)
    bgr = remap_rgb(load_rgb(fr.rgb_path), map1, map2)
    z = remap_depth(load_depth(fr.depth_path), map1, map2)
    normal_ref, eval_mask = eval_setup(z, K)

    cells = [label(bgr, "original RGB")]

    g_s2 = build_gaussians(
        bgr, z, K, z_min=GEO_CFG["z_min"], z_max=GEO_CFG["z_max"],
        disc_rel=GEO_CFG["disc_rel"], stride=2,
        prefilter="gauss", prefilter_size=int(GEO_CFG["gauss_sigma"]),
    )
    r, psnr = render_psnr(g_s2, bgr, z.shape, K, eval_mask)
    cells.append(label(r, f"S2  N={len(g_s2)}  PSNR={psnr:.1f}"))

    # footprint-only (curvature path at footprint radius)
    keep_fp = curvature_mask(
        z, K, GEO_CFG["eps"], GEO_CFG["gauss_sigma"], GEO_CFG["z_min"],
        GEO_CFG["z_max"], GEO_CFG["disc_rel"], GEO_CFG["overlap"], GEO_CFG["r_max"],
        foreshorten=False, aniso_claim=True, edge_fallback_fp=True,
        texture_mask=np.ones(z.shape, dtype=bool),
    )
    g_fp = build_gaussians_curvature(
        bgr, z, K, eps=GEO_CFG["eps"], gauss_sigma=GEO_CFG["gauss_sigma"],
        r_max=GEO_CFG["r_max"], shrink=GEO_CFG["shrink"],
        normal_mode="disc_inliers", z_min=GEO_CFG["z_min"], z_max=GEO_CFG["z_max"],
        disc_rel=GEO_CFG["disc_rel"], mask=keep_fp, prefilter="gauss",
        prefilter_size=int(GEO_CFG["gauss_sigma"]),
    )
    r, psnr = render_psnr(g_fp, bgr, z.shape, K, eval_mask)
    cells.append(label(r, f"footprint  N={len(g_fp)}  PSNR={psnr:.1f}"))

    # curv (full curvature, no texture mask)
    keep_curv = curvature_mask(
        z, K, GEO_CFG["eps"], GEO_CFG["gauss_sigma"], GEO_CFG["z_min"],
        GEO_CFG["z_max"], GEO_CFG["disc_rel"], GEO_CFG["overlap"], GEO_CFG["r_max"],
        foreshorten=False, aniso_claim=True, edge_fallback_fp=True,
    )
    g_cur = build_gaussians_curvature(
        bgr, z, K, eps=GEO_CFG["eps"], gauss_sigma=GEO_CFG["gauss_sigma"],
        r_max=GEO_CFG["r_max"], shrink=GEO_CFG["shrink"],
        normal_mode="disc_inliers", z_min=GEO_CFG["z_min"], z_max=GEO_CFG["z_max"],
        disc_rel=GEO_CFG["disc_rel"], mask=keep_curv, prefilter="gauss",
        prefilter_size=int(GEO_CFG["gauss_sigma"]),
    )
    r, psnr = render_psnr(g_cur, bgr, z.shape, K, eval_mask)
    cells.append(label(r, f"curv  N={len(g_cur)}  PSNR={psnr:.1f}"))

    # S2-fallback hybrid (current algorithm) at a few quantiles
    for q in (0.6, 0.75, 0.9):
        g_h, _, _ = build_s2_fallback(bgr, z, K, q)
        r, psnr = render_psnr(g_h, bgr, z.shape, K, eval_mask)
        cells.append(label(r, f"s2-fallback q{q:g}  N={len(g_h)}  PSNR={psnr:.1f}"))

    # Arrange into a 2x4 grid (pad to multiple of 4)
    while len(cells) % 4 != 0:
        cells.append(np.zeros_like(bgr))
    rows = []
    for i in range(0, len(cells), 4):
        rows.append(np.hstack(cells[i:i + 4]))
    panel = np.vstack(rows)

    out = out_dir / f"render_panel_f{args.frame:02d}.png"
    cv2.imwrite(str(out), panel)
    print(f"wrote {out}")


if __name__ == "__main__":
    main()