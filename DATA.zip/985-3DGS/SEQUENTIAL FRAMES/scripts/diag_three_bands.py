"""Root-cause the 3 vertical crack bands at cols ~601 / ~610-612 / ~631-637
(rows 370-400) in the progressively-filled border region.

For each hole pixel: nearest disc birth frame, grazing angle, and whether a
7x7 sub-pixel sweep hits any local disc (=> renderer undersampling) or not
(=> true 3D tiling gap). Also reports the birth-frame mix of discs covering
the covered columns beside each band, to see if the bands are seams between
different frames' discs.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

SEQ = Path(__file__).resolve().parent
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SEQ))
sys.path.insert(0, str(SFLOW))

import h_pipeline_final as H            # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402

FINAL = SEQ.parent / "output_f0_ellipse_final" / "model_f0.npz"
Z_MIN, Z_MAX = 0.4, 4.0


def tangent_basis(n):
    n = n.astype(np.float64)
    n = n / np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-12)
    ref = np.tile(np.array([0.0, 0.0, 1.0]), (n.shape[0], 1))
    ref[np.abs(n[:, 2]) > 0.9] = np.array([1.0, 0.0, 0.0])
    t1 = np.cross(ref, n)
    t1 = t1 / np.maximum(np.linalg.norm(t1, axis=1, keepdims=True), 1e-12)
    t2 = np.cross(n, t1)
    return t1, t2


def load_g(path: Path):
    d = np.load(path)
    mu = d["mu"].astype(np.float64)
    normal = d["normal"].astype(np.float64)
    scale = d["scale"].astype(np.float64)
    color = d["color"].astype(np.float64)
    birth = d["birth"].astype(np.int64)
    t1, t2 = tangent_basis(normal)
    g = H.Gaussians(
        mu=mu, normal=normal, scale=scale,
        quat=H._quat_from_frame(t1.astype(np.float32), t2.astype(np.float32), normal.astype(np.float32)),
        color=color, alpha=None,
        pixel=np.zeros((len(mu), 2), np.int32),
        axis1=t1.astype(np.float32), axis2=t2.astype(np.float32))
    return g, birth


def main() -> None:
    pairs = SF.associate(SF.DATA, max_dt=0.02)[: 11]
    sm = SF.load_rgb(pairs[0].rgb_path)
    h, w = sm.shape[:2]
    m1, m2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)
    bgr0, z0, _ = SF.load_pair(pairs, 0, m1, m2)
    valid = (z0 > Z_MIN) & (z0 < Z_MAX)
    fx, fy, cx, cy = (float(K[0,0]), float(K[1,1]), float(K[0,2]), float(K[1,2]))

    g, birth = load_g(FINAL)
    depth, index, _ = H.rasterize_discs(g, K, (h, w))
    idx = index.astype(np.int64)
    hit = np.isfinite(depth)
    pix_birth = np.full((h, w), -1, np.int32)
    pix_birth[hit] = birth[idx[hit]]

    # bands
    bands = {"B1_col601": (600, 602), "B2_col610-612": (609, 613), "B3_col631-637": (630, 638)}
    # precompute disc projections
    zc = np.maximum(g.mu[:, 2], 1e-6)
    uc = (fx * g.mu[:, 0] / zc + cx)
    vc = (fy * g.mu[:, 1] / zc + cy)
    nrm = g.normal.astype(np.float64)
    mu = g.mu.astype(np.float64)
    r1 = g.scale[:, 0]
    r2 = g.scale[:, 1]
    ax1 = g.axis1.astype(np.float64)
    ax2 = g.axis2.astype(np.float64)
    n_dot_mu = np.einsum("ij,ij->i", nrm, mu)

    grid = [(i/7.0 + 1/14.0, j/7.0 + 1/14.0) for i in range(7) for j in range(7)]

    print("=== row 370-399 === each band ===")
    for name, (cb0, cb1) in bands.items():
        sub = slice(370, 400), slice(cb0, cb1)
        hole_mask = ~hit[370:400, cb0:cb1]
        cov_mask = hit[370:400, cb0:cb1]
        n_hole = hole_mask.sum()
        # birth of covering discs in the band (covered cols)
        cov_birth = pix_birth[370:400, cb0:cb1][cov_mask]
        # birth of discs in 3px to LEFT and RIGHT of band
        left_b = pix_birth[370:400, max(cb0-4,0):cb0][hit[370:400, max(cb0-4,0):cb0]]
        right_b = pix_birth[370:400, cb1:cb1+4][hit[370:400, cb1:cb1+4]]
        print(f"\n{name}: holes={n_hole}")
        print(f"  covered-in-band birth hist: {np.bincount(cov_birth, minlength=11).tolist()}")
        print(f"  left-adjacent birth hist:   {np.bincount(left_b, minlength=11).tolist()}")
        print(f"  right-adjacent birth hist:  {np.bincount(right_b, minlength=11).tolist()}")

        # hole pixel sub-pixel test
        yy, xx = np.nonzero(hole_mask)
        hy = yy + 370
        hx = xx + cb0
        covered = np.zeros(hy.size, bool)
        graze_min = np.full(hy.size, np.inf)
        for du, dv in grid:
            uu = (hx + du - cx) / fx
            vv = (hy + dv - cy) / fy
            dvec = np.stack([uu, vv, np.ones_like(uu)], axis=1)
            dist2 = (uc[None, :] - (hx + du)[:, None])**2 + (vc[None, :] - (hy + dv)[:, None])**2
            order = np.argsort(dist2, axis=1)[:, :200]
            for k in range(hy.size):
                cd = order[k]
                P = dvec[k]
                nm = nrm[cd]; mux = mu[cd]
                denom = np.einsum("ij,j->i", nm, P)
                live = np.abs(denom) > 1e-9
                t = np.full(cd.shape, np.nan)
                t[live] = n_dot_mu[cd][live] / denom[live]
                ok = live & (t > 0)
                if not ok.any():
                    continue
                Q = P[None, :] * t[:, None]
                off = Q - mux
                pa = np.einsum("ij,ij->i", off, ax1[cd]) / np.maximum(r1[cd], 1e-9)
                pb = np.einsum("ij,ij->i", off, ax2[cd]) / np.maximum(r2[cd], 1e-9)
                inside = (pa*pa + pb*pb) <= 1.0
                if inside.any():
                    covered[k] = True
        nbr = idx[hy, hx]  # -1 for hole
        # grazing angle of nearest disc (nearest by image dist)
        nearest_d = np.full(hy.size, np.inf)
        nearest_i = np.full(hy.size, -1, np.int32)
        for s in range(0, hy.size, 256):
            e = min(s+256, hy.size)
            dd = (uc[None, :] - hx[s:e, None])**2 + (vc[None, :] - hy[s:e, None])**2
            bi = dd.argmin(axis=1)
            nearest_i[s:e] = bi
        nn = g.normal[nearest_i]
        nmu = g.mu[nearest_i]
        view = -nmu / np.maximum(np.linalg.norm(nmu, axis=1, keepdims=True), 1e-12)
        cosg = np.abs(np.einsum("ij,ij->i", nn, view))
        graze = np.degrees(np.arccos(np.clip(cosg, 0, 1)))
        print(f"  hole sub-pixel(7x7) coverage: {covered.sum()}/{hy.size} = {covered.mean():.3f}")
        print(f"  nearest-disc birth hist: {np.bincount(birth[nearest_i], minlength=11).tolist()}")
        print(f"  nearest-disc graze deg: min={graze.min():.1f} med={np.median(graze):.1f} max={graze.max():.1f}")


if __name__ == "__main__":
    main()