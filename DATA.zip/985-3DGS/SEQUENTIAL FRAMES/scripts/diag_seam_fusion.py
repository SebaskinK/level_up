"""Instrumented re-run of frames 0..3 to find WHY the frame-2<->frame-3 seam
(B3, cols 630-638) and frame-0<->frame-1 seam (B2) leave real tiling gaps.

At each frame we record the depth-valid, owned, leftover masks plus where the
leftover pixels went (S2 / absorb / curvature / unhandled), and dump ASCII for
the right-edge strip so we can see the seam classification in that frame's own
coordinates.
"""
from __future__ import annotations
import sys
from pathlib import Path
import numpy as np

SEQ = Path(__file__).resolve().parent
SINGLE = SEQ.parent.parent / "SINGLE FRAME" / "scripts"
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SFLOW))
sys.path.insert(0, str(SINGLE))
sys.path.insert(0, str(SEQ))

import h_pipeline_final as H
import incremental_hybrid as INC
import sequential_fusion_flowonly as SF

AGE_MAX = 1000000
W_MIN = 0.0
Z_MIN, Z_MAX = 0.4, 4.0

# monkeypatch absorb to return also the spatial 'absorbed' mask (it already does)


def ascii_map(mask, r0, r1, c0, c1, ch):
    print("     " + "".join(str((c // 10) % 10) for c in range(c0, c1)))
    print("     " + "".join(str(c % 10) for c in range(c0, c1)))
    for r in range(r0, r1):
        print(f"{r:3d} " + "".join(ch[mask[r, c]] for c in range(c0, c1)))


def main():
    pairs = SF.associate(SF.DATA, max_dt=0.02)[:4]  # frames 0..3
    sample = SF.load_rgb(pairs[0].rgb_path)
    h, w = sample.shape[:2]
    m1, m2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)

    bgr0, z0, _ = SF.load_pair(pairs, 0, m1, m2)
    g0, _, _, owner0 = H.build_hybrid_with_owner(bgr0, z0, K, SF.TEX_Q)
    model = SF.Model(g=g0, w=np.ones(len(g0), np.float32),
                     age=np.zeros(len(g0), np.int32), owner=owner0,
                     birth=np.zeros(len(g0), np.int32))

    prev_sf = None
    prev_dt = 1.0
    bgr_a, z_a = bgr0, z0
    for i in range(len(pairs) - 1):  # i = 0,1,2 -> process frame i+1 = 1,2,3
        bgr_b, z_b, _ = SF.load_pair(pairs, i + 1, m1, m2)
        dt = pairs[i + 1].t_rgb - pairs[i].t_rgb
        sf = SF.compute_scene_flow(bgr_a, bgr_b, z_a, z_b, K,
                                   prev=prev_sf, dt=dt, prev_dt=prev_dt)
        R_10, t_10 = SF.se3_exp(sf.xi)

        g = SF.transform_to_next(model.g, R_10, t_10)
        owner_w = SF.warp_owner(model.owner, sf.u, sf.v, sf.valid)
        owner_w = SF._fill_owner_backward(owner_w, model.owner, sf)
        geo = H.compute_scene_geometry(z_b, K, H.GEO_CFG["eps"], H.GEO_CFG["gauss_sigma"], H.GEO_CFG["disc_rel"])
        owned = owner_w >= 0
        leftover = (z_b > Z_MIN) & (z_b < Z_MAX) & ~owned
        valid = (z_b > Z_MIN) & (z_b < Z_MAX)

        # render the PRE-emission model (old discs) to this frame to see coverage
        depth_pre, _, _ = H.rasterize_discs(g, K, (h, w))
        pre_hit = np.isfinite(depth_pre)

        # run the actual fusion to get the emission classification
        rec = SF.fuse_frame(model, sf, z_a, z_b, bgr_b, K,
                            age_max=AGE_MAX, w_min=W_MIN, frame_idx=i,
                            R_10=R_10, t_10=t_10, no_absorb=False)

        print(f"\n================ FRAME {i+1} (birth {i+1}) ================")
        print(f"N={rec['n']} upd={rec['n_upd']} new={rec['n_new']} abs={rec['n_absorb']} left={rec['n_leftover']}")
        print(f"valid px={valid.sum()}  owned={owned.sum()}  leftover={leftover.sum()}")
        # right-edge strip where new surface may appear: find valid right boundary
        # classify the leftover-adjacent region
        # Focus: for each column in the right strip, count valid/owned/leftover/pre-hit
        print("\ncol : valid | owned | leftover | preHit(old discs cover) | preHole")
        for c in range(560, w, 4):
            rowband = slice(300, 420)
            print(f"{c:3d}: {valid[rowband, c].sum():4d} | {owned[rowband, c].sum():4d} | "
                  f"{leftover[rowband, c].sum():4d} | {pre_hit[rowband, c].sum():4d} | "
                  f"{(valid[rowband, c] & ~pre_hit[rowband, c]).sum():4d}")

        # ASCII of leftover in the right strip rows 300-420 cols 560-639
        print("\nleftover map (rows 300-419, cols 560-639): L=leftover .=owned .'=invalid")
        ascii_map(np.where(valid, np.where(owned, 0, 1), 2), 300, 420, 560, 640,
                  {0: '.', 1: 'L', 2: ' '})

        bgr_a, z_a = bgr_b, z_b
        prev_sf, prev_dt = sf, dt


if __name__ == "__main__":
    main()