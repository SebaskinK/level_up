"""Novel-view render over consecutive frame pairs: build gaussians from frame n,
render from frame n+1's pose, compare to frame n+1 rgb.

Per pair, Mrel = inv(M_{n+1}) @ M_n (TUM camera-to-world trajectory). The disc
primitives are rigidly transformed (mu/normal/axes rotate + mu translates; scale
and Lambertian colour are invariant) and re-rasterized with the same intrinsics.

Output: a 4-row x N-col panel —
  row 0: frame n     (source)
  row 1: frame n+1   (target)
  row 2: novel-view render
  row 3: |render - target| diff
"""

import sys
from pathlib import Path

import cv2
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import h_pipeline_final as H


def q_to_R(qx, qy, qz, qw):
    return np.array([
        [1 - 2 * (qy * qy + qz * qz), 2 * (qx * qy - qz * qw), 2 * (qx * qz + qy * qw)],
        [2 * (qx * qy + qz * qw), 1 - 2 * (qx * qx + qz * qz), 2 * (qy * qz - qx * qw)],
        [2 * (qx * qz - qy * qw), 2 * (qy * qz + qx * qw), 1 - 2 * (qx * qx + qy * qy)],
    ])


def parse_tum(path):
    poses = []
    for line in Path(path).read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        p = line.split()
        t = np.array(list(map(float, p[1:4])))
        T = np.eye(4)
        T[:3, :3] = q_to_R(*map(float, p[4:8]))
        T[:3, 3] = t
        poses.append((float(p[0]), T))
    return poses


def transform_gaussians(g, Mrel):
    R = Mrel[:3, :3].astype(np.float32)
    t = Mrel[:3, 3].astype(np.float32)
    mu = g.mu @ R.T + t
    normal = g.normal @ R.T
    axis1 = g.axis1 @ R.T if g.axis1 is not None else None
    axis2 = g.axis2 @ R.T if g.axis2 is not None else None
    return H.Gaussians(
        mu=mu.astype(np.float32), normal=normal.astype(np.float32),
        scale=g.scale, quat=H._quat_from_normal(normal),
        color=g.color, alpha=g.alpha, pixel=g.pixel,
        axis1=axis1.astype(np.float32) if axis1 is not None else None,
        axis2=axis2.astype(np.float32) if axis2 is not None else None,
    )


def load_frame(i):
    pairs = H.associate(Path(H.ROOT.parent.parent / "986-SceneFlow" /
                            "rgbd_dataset_freiburg1_desk"))
    fr = pairs[i]
    map1, map2, K = H.undistort_maps((480, 640), H.FR1_INTRINSICS)
    bgr = H.remap_rgb(H.load_rgb(fr.rgb_path), map1, map2)
    z = H.remap_depth(H.load_depth(fr.depth_path), map1, map2)
    return bgr, z, K


def label(img, s):
    o = img.copy()
    cv2.rectangle(o, (0, 0), (o.shape[1], 34), (0, 0, 0), -1)
    cv2.putText(o, s, (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
    return o


def main():
    import time
    pairs = H.associate(Path(H.ROOT.parent.parent / "986-SceneFlow" /
                            "rgbd_dataset_freiburg1_desk"))
    poses = parse_tum(Path(H.ROOT.parent.parent) / "986-SceneFlow" /
                      "output_final" / "trajectory.txt")
    N = 10
    map1, map2, K = H.undistort_maps((480, 640), H.FR1_INTRINSICS)

    rows = [[], [], [], []]
    print(f"{'pair':>6}{'N':>8}{'hit_frac':>10}{'psnr_db':>9}", flush=True)
    for n in range(N):
        fr0 = pairs[n]
        fr1 = pairs[n + 1]
        bgr0 = H.remap_rgb(H.load_rgb(fr0.rgb_path), map1, map2)
        z0 = H.remap_depth(H.load_depth(fr0.depth_path), map1, map2)
        bgr1 = H.remap_rgb(H.load_rgb(fr1.rgb_path), map1, map2)

        t0 = time.perf_counter()
        g, _, _ = H.build_hybrid(bgr0, z0, K, 0.6)
        dt = time.perf_counter() - t0

        Mrel = np.linalg.inv(poses[n + 1][1]) @ poses[n][1]
        gt = transform_gaussians(g, Mrel)
        depth, index, _ = H.rasterize_discs(gt, K, (480, 640))
        hit = index >= 0
        render = np.zeros((480, 640, 3), dtype=np.uint8)
        rgb = np.clip(gt.color[index[hit]], 0.0, 1.0)
        render[hit] = (rgb[:, ::-1] * 255.0).astype(np.uint8)

        err = render.astype(np.float32) / 255.0 - (bgr1.astype(np.float32) / 255.0)[:, :, ::-1]
        psnr = -20.0 * np.log10(np.sqrt(np.mean(err[hit] ** 2)) + 1e-12)
        print(f"{n:>4}{len(g):>8}{hit.mean():>10.3f}{psnr:>9.2f}  ({dt:.1f}s)", flush=True)

        rows[0].append(label(bgr0, f"frame {n} rgb"))
        rows[1].append(label(bgr1, f"frame {n+1} rgb"))
        rows[2].append(label(render, f"novel f{n}->f{n+1}"))
        rows[3].append(label(cv2.absdiff(render, bgr1), f"diff  PSNR={psnr:.1f} dB"))

    panel = np.vstack([np.hstack(r) for r in rows])
    out = H.ROOT.parent / "output_H" / "novelview_recursive_10.png"
    out.parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(out), panel)
    print(f"wrote {out}  shape={panel.shape}")


if __name__ == "__main__":
    main()