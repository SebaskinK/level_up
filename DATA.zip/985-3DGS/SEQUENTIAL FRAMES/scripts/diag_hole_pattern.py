"""Characterise the ray-coverage hole spatial pattern and correlate with drift.

Loads the cached final model (output_discmask_align) and reports, for holes in
the valid-depth region: column/row histograms (the user sees a *periodic* row of
holes at the right edge of the gray strip), and the drift of the disc nearest
each hole in frame-0 projection (birth + type + centre drift from its own birth).
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

SEQ = Path(__file__).resolve().parent
SINGLE = SEQ.parent.parent / "SINGLE FRAME" / "scripts"
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SFLOW))
sys.path.insert(0, str(SINGLE))
sys.path.insert(0, str(SEQ))

import h_pipeline_final as H            # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402

NPZ = SEQ.parent / "output_discmask_align" / "model_f0.npz"
DEPTH_NPY = SEQ.parent / "output_discmask_align" / "f0_depth_hard.npy"


def main() -> None:
    d = np.load(NPZ)
    mu_f = d["mu"].astype(np.float64)
    scale_f = d["scale"].astype(np.float64)
    birth_f = d["birth"]

    pairs = SF.associate(SF.DATA, max_dt=0.02)[: 11]
    sample = SF.load_rgb(pairs[0].rgb_path)
    h, w = sample.shape[:2]
    map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)
    bgr0, z0, _ = SF.load_pair(pairs, 0, map1, map2)

    depth_h = np.load(DEPTH_NPY)
    valid = (z0 > SF.Z_MIN) & (z0 < SF.Z_MAX)
    hole = (depth_h == 0) & valid
    hy, hx = np.nonzero(hole)
    print(f"image {w}x{h}  valid={valid.sum()}  holes={hy.size} "
          f"({100.0*hy.size/valid.sum():.3f}% of valid)")

    if hy.size == 0:
        return

    # --- spatial pattern ---
    colhist = np.bincount(hx, minlength=w)
    nz_cols = np.flatnonzero(colhist > 0)
    print(f"\nhole columns: min={nz_cols.min()} max={nz_cols.max()}  "
          f"count(nonzero cols)={nz_cols.size}")
    # periodic spacing in columns?
    if nz_cols.size >= 3:
        gaps = np.diff(nz_cols)
        print(f"column gap: median={np.median(gaps):.0f}  mode={np.bincount(gaps).argmax():.0f}  "
              f"unique gaps={np.unique(gaps)[:20].tolist()}")

    rowhist = np.bincount(hy, minlength=h)
    nz_rows = np.flatnonzero(rowhist > 0)
    print(f"hole rows: min={nz_rows.min()} max={nz_rows.max()}  count={nz_rows.size}")

    # print the hole columns with counts (right half only, condensed)
    print("\nright-half column histogram (nonzero):")
    for c in nz_cols:
        if c >= w // 2:
            print(f"  col {c}: {colhist[c]}")
    print("\nrow histogram (nonzero, top 40):")
    for r in nz_rows[:40]:
        print(f"  row {r}: {rowhist[r]}")

    # --- gray strip location: right-half valid pixels, low-saturation gray ---
    rgb = bgr0[..., ::-1].astype(np.float32) / 255.0
    mx = rgb.max(axis=2)
    mn = rgb.min(axis=2)
    sat = (mx - mn) / np.maximum(mx, 1e-6)
    gray_ish = valid & (sat < 0.15) & (mx > 0.1) & (mx < 0.85)
    gy, gx = np.nonzero(gray_ish & (np.arange(w)[None, :] >= w // 2))
    if gx.size:
        print(f"\ngray-ish strip (right half): cols [{gx.min()},{gx.max()}] "
              f"rows [{gy.min()},{gy.max()}]  n={gx.size}")

    # --- nearest final disc to each hole ---
    fx, fy, cx, cy = (float(K[0, 0]), float(K[1, 1]), float(K[0, 2]), float(K[1, 2]))
    zc = np.maximum(mu_f[:, 2], 1e-6)
    uc = (fx * mu_f[:, 0] / zc + cx)
    vc = (fy * mu_f[:, 1] / zc + cy)
    r_px = np.maximum(scale_f[:, 0], scale_f[:, 1]) * 0.5 * (fx + fy) / zc
    iso = np.abs(scale_f[:, 0] - scale_f[:, 1]) < 1e-6 * np.maximum(scale_f[:, 0], 1e-9)

    best_d = np.full(hy.size, np.inf)
    best_i = np.zeros(hy.size, dtype=np.int32)
    CH = 200
    for s in range(0, hy.size, CH):
        e = min(s + CH, hy.size)
        du = hx[s:e, None] - uc[None, :]
        dv = hy[s:e, None] - vc[None, :]
        dd = du * du + dv * dv
        bi = dd.argmin(axis=1)
        best_i[s:e] = bi
        best_d[s:e] = dd[np.arange(e - s), bi]
    best_d = np.sqrt(best_d)

    reach = r_px[best_i] >= best_d
    print(f"\nnearest-disc analysis over {hy.size} holes:")
    print(f"  nearest centre distance: med={np.median(best_d):.2f}px "
          f"p90={np.percentile(best_d, 90):.2f}")
    print(f"  nearest disc REACHES the hole centre (r>=d): {reach.mean():.3f}")
    print(f"  nearest disc birth hist: {np.bincount(birth_f[best_i], minlength=12).tolist()}")
    print(f"  nearest disc iso(frac): {iso[best_i].mean():.3f}")
    # where the nearest disc centre sits relative to the hole (left/right/up/down)
    duc = hx - uc[best_i]
    dvc = hy - vc[best_i]
    print(f"  disc-centre rel. to hole: dx med={np.median(duc):+.2f} dy med={np.median(dvc):+.2f}"
          f"  (disc-centre left-of-hole frac={(duc < 0).mean():.3f})")

    print("\nDone.")


if __name__ == "__main__":
    main()