"""A/B age (staleness) probe for the relink-order ablation.

`age` is the per-disc "frames since the stored COLOUR was last written" counter:
+1 for every disc every frame, reset to 0 only where the colour is actually
written (footprint colour write, or absorb merge). The centre geometry gate does
NOT reset it. It widens the colour gate through the temporal term
`min(0.013*age, 0.27)`. This script asks which order leaves the discs staler, and
whether that lines up with the screen-region colour difference.

Run (after both 81-frame runs have written `age` into model_f0.npz):
  python scripts/diag_age_ab.py
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

SEQ = Path(__file__).resolve().parent
sys.path.insert(0, str(SEQ))

import h_pipeline_final as H          # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402

A = SEQ.parent / "output_f0_80frame_olddraw"
B = SEQ.parent / "output_f0_80frame_flowfirst"
REGIONS = {
    "screen  r10-120 c0-220":  (10, 120, 0, 220),
    "left    r120-320 c0-160": (120, 320, 0, 160),
    "mid     r200-320 c160-480": (200, 320, 160, 480),
    "right   r10-120 c420-640": (10, 120, 420, 640),
    "whole frame":             (0, 480, 0, 640),
}


def tangent_basis(n):
    ref = np.zeros_like(n)
    ref[:, 2] = 1.0
    ref[np.abs(n[:, 2]) > 0.9] = np.array([1.0, 0.0, 0.0])
    a1 = np.cross(n, ref)
    a1 /= np.maximum(np.linalg.norm(a1, axis=1, keepdims=True), 1e-9)
    a2 = np.cross(n, a1)
    a2 /= np.maximum(np.linalg.norm(a2, axis=1, keepdims=True), 1e-9)
    return a1, a2


def main():
    pairs = SF.associate(SF.DATA, max_dt=0.02)[:81]
    hw = SF.load_rgb(pairs[0].rgb_path).shape[:2]
    map1, map2, K = SF.undistort_maps(hw, SF.FR1_INTRINSICS)
    _, z0, _ = SF.load_pair(pairs, 0, map1, map2)
    zv = (z0 >= SF.Z_MIN) & (z0 <= SF.Z_MAX)

    res = {}
    for tag, run in (("A relink-first", A), ("B flow-first", B)):
        d = np.load(run / "model_f0.npz")
        if "age" not in d.files:
            raise SystemExit(f"{run}/model_f0.npz has no age field -- re-run the pipeline")
        mu, nm, sc, bt = d["mu"], d["normal"], d["scale"], d["birth"]
        age, wc, col, bcol = d["age"], d["w_col"], d["color"], d["birth_color"]
        a1, a2 = tangent_basis(nm)
        g = H.Gaussians(mu=mu, normal=nm, scale=sc, quat=np.zeros((len(mu), 4)),
                        color=col, alpha=np.ones(len(mu)), pixel=np.zeros((len(mu), 2)),
                        axis1=a1, axis2=a2)
        _, index, _ = H.rasterize_discs(g, K, hw)
        hit = index >= 0
        drift = np.linalg.norm(col - bcol, axis=1)
        print(f"\n===== {tag} =====  N={len(mu)}")
        print(f"  ALL discs      age: median={np.median(age):.0f} mean={age.mean():.1f} "
              f"age==0 {100*(age == 0).mean():4.1f}%  age>=21(term saturated) {100*(age >= 21).mean():4.1f}%")
        print(f"                 w_col median={np.median(wc):.1f}  drift median={np.median(drift):.4f}")
        tab = {}
        for nm2, (y0, y1, x0, x1) in REGIONS.items():
            reg = np.zeros(hw, bool)
            reg[y0:y1, x0:x1] = True
            m = hit & reg & zv
            if not m.any():
                continue
            own = index[m]
            # pixel-weighted age of the disc that draws each pixel
            pa = np.median(age[own])
            p0 = 100 * (age[own] == 0).mean()
            psat = 100 * (age[own] >= 21).mean()
            # implied colour-gate temporal budget, spatially only (sigma floored 0.02)
            light = np.minimum(SF.COLOR_LIGHT_RATE * age[own], SF.COLOR_LIGHT_MAX)
            budget = np.sqrt((SF.COLOR_GATE_K * 0.02) ** 2 + light ** 2)
            print(f"  {nm2:26s} px={int(m.sum()):6d}  age(px-wtd) med={pa:5.0f}  "
                  f"age==0 {p0:5.1f}%  sat {psat:5.1f}%  "
                  f"w_col med={np.median(wc[own]):5.1f}  drift med={np.median(drift[own]):.4f}  "
                  f"gate budget med={np.median(budget):.3f}")
            tab[nm2] = dict(age_med=float(pa), age0=float(p0), sat=float(psat),
                            wcol=float(np.median(wc[own])),
                            drift=float(np.median(drift[own])),
                            budget=float(np.median(budget)))
        # does age correlate with drift, disc-wise?
        for lo, hi, nm3 in ((0, 0, "age==0"), (1, 10, "1-10"), (11, 20, "11-20"), (21, 10 ** 9, "21+")):
            s = (age >= lo) & (age <= hi)
            if s.sum() > 5:
                print(f"  disc-age bucket {nm3:6s}: n={int(s.sum()):6d}  "
                      f"w_col med={np.median(wc[s]):5.1f}  drift med={np.median(drift[s]):.4f}  "
                      f"birth==0 {100*(bt[s] == 0).mean():4.0f}%")
        res[tag] = tab

    Path(SEQ / "diag_age_ab_stats.json").write_text(json.dumps(res, indent=2))


if __name__ == "__main__":
    main()