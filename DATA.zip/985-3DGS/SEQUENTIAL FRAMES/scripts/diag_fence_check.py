"""At the birth-0 culprit pixels (white desk covering gray side), compare the
two radius fences: sequential r_edge (depth_jump_mask, void-adjacency ignored)
vs single-frame r_edge (depth_discontinuity_mask, void-adjacency is an edge),
plus r_cap (tex_boundary_limit). Determines which fence should have clamped
the white desk discs and whether the FOV change is what removed it."""
import sys
from pathlib import Path

import numpy as np
import cv2

SEQ = Path(__file__).resolve().parent
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SEQ))
sys.path.insert(0, str(SFLOW))

import h_pipeline_final as H  # noqa: E402  (sequential copy, FOV variant)
import sequential_fusion_flowonly as SF  # noqa: E402


def depth_discontinuity_mask_single(z, rel_thresh=0.02, valid=None):
    """Single-frame version: adjacency to invalid depth counts as a seam."""
    if valid is None:
        valid = H.depth_valid(z)
    step = np.full(z.shape, -1.0, dtype=np.float32)
    for dy, dx in ((0, 1), (0, -1), (1, 0), (-1, 0)):
        shifted = np.roll(np.roll(z, dy, axis=0), dx, axis=1)
        nbr = np.where(np.roll(np.roll(valid, dy, axis=0), dx, axis=1), shifted, 0.0)
        step = np.maximum(step, np.abs(z - nbr))
    edge = step > rel_thresh * np.maximum(z, 1e-6)
    return edge & valid


def edge_distance_limit_single(z, K, disc_rel=0.02, valid=None):
    edge = depth_discontinuity_mask_single(z, disc_rel, valid=valid)
    free = (~edge).astype(np.uint8)
    dist_px = cv2.distanceTransform(free, cv2.DIST_L2, 3)
    return (dist_px * z / (0.5 * (K[0, 0] + K[1, 1]))).astype(np.float32)


pairs = SF.associate(SF.DATA, max_dt=0.02)[:1]
h, w = SF.load_rgb(pairs[0].rgb_path).shape[:2]
map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)
bgr0, z0, _ = SF.load_pair(pairs, 0, map1, map2)
rgb = bgr0[..., ::-1].astype(np.float32) / 255.0

geo = H.compute_scene_geometry(
    z0, K, H.GEO_CFG["eps"], H.GEO_CFG["gauss_sigma"], H.GEO_CFG["disc_rel"],
)
tex_mask = H.texture_mask(rgb, SF.TEX_Q)
r_cap = H.tex_boundary_limit(z0, K, tex_mask, tol_px=4.5)
r_edge_single = edge_distance_limit_single(z0, K, H.GEO_CFG["disc_rel"])

g0, keep_geo, tex_mask2, owner0 = H.build_hybrid_with_owner(bgr0, z0, K, SF.TEX_Q)

px = [(588, 350), (602, 360), (597, 363)]
print("pixel | r_k1 r_k2 | r_fp | r_edge_seq | r_edge_single | r_cap | tex | disc | nz | z")
for (u, v) in px:
    rk1 = geo.r_k1[v, u]; rk2 = geo.r_k2[v, u]; rfp = geo.r_fp[v, u]
    re_seq = geo.r_edge[v, u]
    re_sgl = r_edge_single[v, u]
    rc = r_cap[v, u]
    tm = int(tex_mask[v, u]); dm = int(geo.disc_mask[v, u])
    # emitted disc whose source pixel == this pixel
    ii = np.where((g0.pixel[:, 0] == u) & (g0.pixel[:, 1] == v))[0]
    r_emit = (f"{g0.scale[ii[0], 0]:.4f},{g0.scale[ii[0], 1]:.4f}") if ii.size else "-"
    print(f"({u},{v}) | {rk1:.4f},{rk2:.4f} | {rfp:.4f} | {re_seq:.4f} | "
          f"{re_sgl:.4f} | {rc:.4f} | {tm} | {dm} | emit_r=({r_emit}) | z={z0[v, u]:.2f}")

# how far from the FOV/void is the desk side? report invalid-depth counts near the boundary
print("\ninvalid-depth pixel counts in right strip rows 340-400:")
strip = z0[340:400, 560:640]
valid = H.depth_valid(z0)[340:400, 560:640]
print("  rows 340-400, cols 560-640: valid=", int(valid.sum()), "/", valid.size)