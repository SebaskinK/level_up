"""Diff the frame-0 hard ray-disc render: footprint relink (A) vs centre-only.

The two 81-frame runs differ only by `--relink-center-only`. Strips the 36px
caption bar, diffs, reports per-band stats and saves a full montage plus a
left-edge zoom (where the redundant overdraw was visible).

Run:  python scripts/cmp_relink_f0.py
"""

from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np

SEQ = Path(__file__).resolve().parent
A_PATH = SEQ.parent / "output_f0_80frame_A_centeronly" / "f0_hard.png"
B_PATH = SEQ.parent / "output_f0_80frame_A_footprint" / "f0_hard.png"
OUT_DIR = SEQ.parent / "output_f0_80frame_A_footprint"
BAR = 36


def caption_bar(img: np.ndarray, text: str, h_bar: int = 36) -> np.ndarray:
    w = img.shape[1]
    bar = np.full((h_bar, w, 3), 20, np.uint8)
    cv2.putText(bar, text, (8, h_bar - 10), cv2.FONT_HERSHEY_SIMPLEX,
                0.45, (230, 230, 230), 1, cv2.LINE_AA)
    return np.vstack([img, bar])


def load(p: Path) -> np.ndarray:
    im = cv2.imread(str(p))
    if im is None:
        raise FileNotFoundError(p)
    return im[:-BAR] if im.shape[0] > BAR else im


def band_stats(d: np.ndarray, x0: int, x1: int) -> str:
    s = d[:, x0:x1]
    return (f"x[{x0:3d},{x1:3d})  mean={s.mean():6.2f}  "
            f"px>10={100 * float((s > 10).mean()):5.2f}%  "
            f"px>30={100 * float((s > 30).mean()):5.2f}%  "
            f"px>60={100 * float((s > 60).mean()):5.2f}%")


def main() -> None:
    a = load(A_PATH)
    b = load(B_PATH)
    h = min(a.shape[0], b.shape[0])
    w = min(a.shape[1], b.shape[1])
    a, b = a[:h, :w], b[:h, :w]
    d = np.abs(a.astype(np.int16) - b.astype(np.int16)).max(axis=2).astype(np.uint8)

    lines = [band_stats(d, 0, 64), band_stats(d, 64, 128),
             band_stats(d, 0, 128), band_stats(d, 128, 256),
             band_stats(d, 256, w)]
    print("HARD RAY f0 diff (centre-only vs footprint), per-pixel max |dchannel|:")
    print("\n".join("  " + s for s in lines))

    heat = cv2.applyColorMap(d, cv2.COLORMAP_JET)
    heat[d < 8] = (18, 18, 18)
    mont = np.hstack([a, b, heat])
    cv2.imwrite(str(OUT_DIR / "cmp_relink_f0.png"), caption_bar(
        mont,
        "HARD RAY f0 | LEFT: centre-only relink (old) | MID: footprint relink (A) | "
        "RIGHT: |diff| jet (dark=<8) | "
        f"x<128 mean {d[:, :128].mean():.1f}, px>30 {100 * float((d[:, :128] > 30).mean()):.2f}%"))

    lz = np.vstack([a[:, :192], np.full((4, 192, 3), 200, np.uint8),
                    b[:, :192], np.full((4, 192, 3), 200, np.uint8), heat[:, :192]])
    lz = cv2.resize(lz, None, fx=2.0, fy=2.0, interpolation=cv2.INTER_NEAREST)
    cv2.imwrite(str(OUT_DIR / "cmp_relink_f0_leftzoom.png"), caption_bar(
        lz, "LEFT x<192 zoom 2x | TOP: centre-only | MID: footprint (A) | "
            "BOTTOM: |diff|", h_bar=30))

    # coverage / hole split from the saved depth maps (0 == hole)
    for name, p in [("centre-only", A_PATH.parent / "f0_depth_hard.npy"),
                    ("footprint  ", B_PATH.parent / "f0_depth_hard.npy")]:
        dp = np.load(p)
        hit = dp > 0
        print(f"  hole {name}: all={1 - hit.mean():.4f} "
              f"x<64={1 - hit[:, :64].mean():.4f} x<128={1 - hit[:, :128].mean():.4f}")
    print("saved ->", OUT_DIR / "cmp_relink_f0.png")


if __name__ == "__main__":
    main()