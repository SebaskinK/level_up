"""ATE / RPE evaluation against TUM ground truth (Horn alignment)."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from rigid_motion import rot_angle_deg  # noqa: E402
from tum_io import interpolate_pose, load_groundtruth, quat_xyzw_to_R  # noqa: E402


def load_trajectory(path: Path):
    ts, txyz, quat = [], [], []
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        v = line.split()
        ts.append(float(v[0]))
        txyz.append([float(v[1]), float(v[2]), float(v[3])])
        quat.append([float(v[4]), float(v[5]), float(v[6]), float(v[7])])
    return np.array(ts), np.array(txyz), np.array(quat)


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--traj", required=True)
    p.add_argument("--gt", default=str(ROOT.parent / "rgbd_dataset_freiburg1_desk" / "groundtruth.txt"))
    p.add_argument("--out", default=None)
    p.add_argument("--rpe-delta", type=int, default=30, help="frames between RPE poses")
    args = p.parse_args()

    traj_path = Path(args.traj)
    est_ts, est_t, est_q = load_trajectory(traj_path)
    gt_ts, gt_t, gt_q = load_groundtruth(Path(args.gt))

    gt_matched_t, gt_matched_R, est_idx = [], [], []
    for i, t in enumerate(est_ts):
        pose = interpolate_pose(t, gt_ts, gt_t, gt_q)
        if pose is None:
            continue
        R, tr = pose
        gt_matched_R.append(R)
        gt_matched_t.append(tr)
        est_idx.append(i)
    est_idx = np.array(est_idx)
    gt_pos = np.array(gt_matched_t)
    est_pos = est_t[est_idx]

    R_align = gt_matched_R[0] @ quat_xyzw_to_R(est_q[est_idx[0]]).T
    t_align = gt_pos[0] - R_align @ est_pos[0]
    aligned = est_pos @ R_align.T + t_align
    err = np.linalg.norm(aligned - gt_pos, axis=1)

    print(f"trajectory: {traj_path}")
    print(f"  poses evaluated : {len(err)}")
    print(f"  duration        : {est_ts[est_idx][-1] - est_ts[est_idx][0]:.2f} s")
    print(f"  path length gt  : {np.linalg.norm(np.diff(gt_pos, axis=0), axis=1).sum():.3f} m")
    print("--- ATE (first pose anchored) ---")
    print(f"  RMSE   : {np.sqrt((err ** 2).mean()) * 100:.2f} cm")
    print(f"  mean   : {err.mean() * 100:.2f} cm")
    print(f"  median : {np.median(err) * 100:.2f} cm")
    print(f"  std    : {err.std() * 100:.2f} cm")
    print(f"  max    : {err.max() * 100:.2f} cm")

    delta = args.rpe_delta
    rpe_t, rpe_r = [], []
    est_R = [quat_xyzw_to_R(est_q[i]) for i in est_idx]
    for i in range(len(est_idx) - delta):
        j = i + delta
        rel_est_t = est_R[i].T @ (est_pos[j] - est_pos[i])
        rel_est_R = est_R[i].T @ est_R[j]
        rel_gt_t = gt_matched_R[i].T @ (gt_pos[j] - gt_pos[i])
        rel_gt_R = gt_matched_R[i].T @ gt_matched_R[j]
        rpe_t.append(np.linalg.norm(rel_est_t - rel_gt_t))
        rpe_r.append(rot_angle_deg(rel_est_R.T @ rel_gt_R))
    rpe_t = np.array(rpe_t)
    rpe_r = np.array(rpe_r)
    print(f"--- RPE (delta = {delta} frames) ---")
    print(f"  trans RMSE : {np.sqrt((rpe_t ** 2).mean()) * 100:.2f} cm")
    print(f"  rot   RMSE : {np.sqrt((rpe_r ** 2).mean()):.2f} deg")

    out = Path(args.out) if args.out else traj_path.parent / "ate.png"
    fig = plt.figure(figsize=(12, 5))
    ax = fig.add_subplot(1, 2, 1)
    ax.plot(gt_pos[:, 0], gt_pos[:, 1], label="ground truth", lw=2)
    ax.plot(aligned[:, 0], aligned[:, 1], label="estimated", lw=1.5)
    for k in range(0, len(err), max(1, len(err) // 40)):
        ax.plot(
            [gt_pos[k, 0], aligned[k, 0]],
            [gt_pos[k, 1], aligned[k, 1]],
            color="red",
            lw=0.6,
            alpha=0.5,
        )
    ax.set_aspect("equal")
    ax.set_xlabel("x (m)")
    ax.set_ylabel("y (m)")
    ax.set_title(f"xy trajectory  (ATE RMSE {np.sqrt((err**2).mean())*100:.2f} cm)")
    ax.legend()
    ax.grid(True, alpha=0.3)

    ax2 = fig.add_subplot(1, 2, 2)
    ax2.plot(est_ts[est_idx] - est_ts[est_idx][0], err * 100)
    ax2.set_xlabel("time (s)")
    ax2.set_ylabel("ATE (cm)")
    ax2.set_title("absolute trajectory error")
    ax2.grid(True, alpha=0.3)

    fig.tight_layout()
    fig.savefig(out, dpi=140)
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
