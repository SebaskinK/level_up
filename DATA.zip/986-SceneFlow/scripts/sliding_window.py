"""3-frame sliding window over relative twists.

Data term  : weighted 3D correspondence residual per frame pair
Smooth term: constant twist, xi_k/dt_k ~= xi_{k+1}/dt_{k+1}  (no IMU)
Solved by Gauss-Newton on se(3) increments.
"""

from __future__ import annotations

import numpy as np

from rigid_motion import depth_sigma
from se3 import hat, se3_exp, se3_log


def _left_jacobian_inv_approx(xi: np.ndarray) -> np.ndarray:
    return np.eye(6)


def _residual_and_jac(xi: np.ndarray, X0: np.ndarray, X1: np.ndarray, w: np.ndarray):
    """r = exp(xi) X0 - X1, J = d r / d delta with left perturbation."""
    R, t = se3_exp(xi)
    P = X0 @ R.T + t
    r = P - X1
    n = X0.shape[0]
    J = np.zeros((n, 3, 6))
    J[:, :, 3:] = np.eye(3)
    J[:, 0, 1] = P[:, 2]
    J[:, 0, 2] = -P[:, 1]
    J[:, 1, 0] = -P[:, 2]
    J[:, 1, 2] = P[:, 0]
    J[:, 2, 0] = P[:, 1]
    J[:, 2, 1] = -P[:, 0]
    sw = np.sqrt(w)[:, None]
    return (r * sw).reshape(-1), (J * sw[:, :, None]).reshape(-1, 6)


def quality_scale(rigid_delta: float, valid_frac: float) -> float:
    """0 for a clean pair, growing as the flow departs from a rigid field.

    Rotation error correlates with rigid_delta (+0.72) and valid_frac (-0.57),
    so poor pairs lean on the constant-twist prior while clean ones stay
    unbiased.
    """
    a = max(0.0, rigid_delta - 0.8) / 1.5
    b = max(0.0, 0.55 - valid_frac) / 0.35
    return float(min(4.0, a + b))


def optimize_window(
    twists: list[np.ndarray],
    corrs: list[tuple[np.ndarray, np.ndarray]],
    dts: list[float],
    lam: float,
    iters: int = 5,
    quality: list[float] | None = None,
) -> list[np.ndarray]:
    """Refine a list of relative twists jointly. corrs[k] = (X0, X1) inliers.

    lam is relative to the data-term scale, so it stays meaningful across
    frames with wildly different inlier counts.
    """
    m = len(twists)
    xi = [x.copy() for x in twists]
    weights = [1.0 / depth_sigma(X0[:, 2]) ** 2 for X0, _ in corrs]
    q = quality if quality is not None else [1.0] * m

    for _ in range(iters):
        H = np.zeros((6 * m, 6 * m))
        b = np.zeros(6 * m)

        data_scale = 0.0
        for k in range(m):
            X0, X1 = corrs[k]
            r, J = _residual_and_jac(xi[k], X0, X1, weights[k])
            Hk = J.T @ J
            s = slice(6 * k, 6 * k + 6)
            H[s, s] += Hk
            b[s] -= J.T @ r
            data_scale += np.trace(Hk) / 6.0
        data_scale /= m

        for k in range(m - 1):
            a, c = 1.0 / dts[k], 1.0 / dts[k + 1]
            g = lam * max(q[k], q[k + 1]) * data_scale / (a * a)
            if g <= 0.0:
                continue
            r = a * xi[k] - c * xi[k + 1]
            Ja = a * np.eye(6)
            Jc = -c * np.eye(6)
            sa = slice(6 * k, 6 * k + 6)
            sc = slice(6 * (k + 1), 6 * (k + 1) + 6)
            H[sa, sa] += g * Ja.T @ Ja
            H[sc, sc] += g * Jc.T @ Jc
            H[sa, sc] += g * Ja.T @ Jc
            H[sc, sa] += g * Jc.T @ Ja
            b[sa] -= g * Ja.T @ r
            b[sc] -= g * Jc.T @ r

        H += np.eye(6 * m) * 1e-9
        try:
            delta = np.linalg.solve(H, b)
        except np.linalg.LinAlgError:
            break

        for k in range(m):
            d = delta[6 * k : 6 * k + 6]
            Rd, td = se3_exp(d)
            Rk, tk = se3_exp(xi[k])
            xi[k] = se3_log(Rd @ Rk, Rd @ tk + td)

        if np.linalg.norm(delta) < 1e-8:
            break

    return xi
