"""Diagnose the 3 vertical stripes the user sees at the white/gray junction.

Re-rasterizes the final frame-0 model (output_discmask_align/model_f0.npz),
locates the white->gray depth discontinuity (depth_jump_mask == the "cyan"
line in the curv-ellipse viz), and reports:

  1. contiguous vertical RUNS of ray-coverage holes near the junction, and
  2. per-column render-vs-GT luminance where the white top meets the gray side.

Both hole-definitions (coverage gap and dark-disc) are checked so we can tell
which one actually forms the "3 vertical stripes".
"""
from __future__ import annotations

import sys
from pathlib import Path

import cv2
import numpy as np

SEQ = Path(__file__).resolve().parent
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SFLOW))
sys.path.insert(0, str(SEQ))

import h_pipeline_final as H            # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402

OUT = SEQ.parent / "output_discmask_align"


def tangent_basis(n):
    n = n.astype(np.float64)
    n = n / np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-12)
    ref = np.tile(np.array([0.0, 0.0, 1.0]), (n.shape[0], 1))
    ref[np.abs(n[:, 2]) > 0.9] = np.array([1.0, 0.0, 0.0])
    t1 = np.cross(ref, n)
    t1 = t1 / np.maximum(np.linalg.norm(t1, axis=1, keepdims=True), 1e-12)
    t2 = np.cross(n, t1)
    return t1.astype(np.float32), t2.astype(np.float32)


def main() -> None:
    d = np.load(OUT / "model_f0.npz")
    mu = d["mu"].astype(np.float32)
    normal = d["normal"].astype(np.float32)
    scale = d["scale"].astype(np.float32)
    color = d["color"].astype(np.float32)
    birth = d["birth"].astype(np.int32)
    t1, t2 = tangent_basis(normal)
    g = H.Gaussians(
        mu=mu, normal=normal, scale=scale,
        quat=H._quat_from_frame(t1, t2, normal), color=color, alpha=None,
        pixel=np.zeros((len(mu), 2), np.int32), axis1=t1, axis2=t2)

    pairs = SF.associate(SF.DATA, max_dt=0.02)[: 11]
    sm = SF.load_rgb(pairs[0].rgb_path)
    h, w = sm.shape[:2]
    m1, m2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)
    bgr0, z0, _ = SF.load_pair(pairs, 0, m1, m2)
    valid = (z0 > SF.Z_MIN) & (z0 < SF.Z_MAX)

    depth, index, _ = H.rasterize_discs(g, K, (h, w))
    idx = index.astype(np.int64)
    cov = np.isfinite(depth) & valid
    hole = valid & ~cov
    iso = np.abs(scale[:, 0] - scale[:, 1]) < 1e-6 * np.maximum(scale[:, 0], 1e-9)

    render = np.zeros((h, w, 3), np.float32)
    render[cov] = color[idx[cov]]
    rlum = render.mean(axis=2)
    gt = bgr0[..., ::-1].astype(np.float32) / 255.0
    glum = gt.mean(axis=2)

    jump = H.depth_jump_mask(z0, H.GEO_CFG["disc_rel"], valid=valid)

    # ---- (1) contiguous vertical runs of coverage holes in the right half ----
    hy, hx = np.nonzero(hole & (np.arange(w)[None, :] >= w // 2))
    runs_by_col = {}
    for y, x in zip(hy, hx):
        runs_by_col.setdefault(int(x), []).append(int(y))
    print("contiguous vertical RUNS (len>=3) of ray-coverage holes, right half:")
    n_runs = 0
    for c in sorted(runs_by_col):
        ys = sorted(runs_by_col[c])
        run = []
        for y in ys:
            if run and y == run[-1] + 1:
                run.append(y)
            else:
                if len(run) >= 3:
                    n_runs += 1
                    print(f"  col {c}: rows {run} (len {len(run)})")
                run = [y]
        if len(run) >= 3:
            n_runs += 1
            print(f"  col {c}: rows {run} (len {len(run)})")
    print(f"  -> {n_runs} vertical runs (len>=3) total; right-half holes={hy.size}\n")

    # ---- (2) holes near the junction line, per column ----
    jy, jx = np.nonzero(jump)
    jr = np.stack([jy, jx], axis=1)
    print("coverage holes within 4px of the depth-jump line, grouped by column:")
    near = []
    for i in range(0, hy.size, 512):
        e = min(i + 512, hy.size)
        dd = np.abs(hx[i:e, None] - jr[None, :, 1]) + np.abs(hy[i:e, None] - jr[None, :, 0])
        m = dd.min(axis=1) <= 4
        near.append(m)
    near = np.concatenate(near)
    hn_y, hn_x = hy[near], hx[near]
    ch = np.bincount(hn_x, minlength=w)
    for c in range(w // 2, w):
        if ch[c] > 0:
            print(f"  col {c}: {ch[c]}  rows {sorted(set(hn_y[hn_x == c].tolist()))}")

    # ---- (3) dark (near-black) covering discs vs GT-dark at the junction ----
    print("\nper-column at the right junction band (rows 360..400, cols 560..612):")
    print(" col | gt_lum  render_lum  holes  dark_disc  mean_birth  iso_frac")
    for c in range(560, 612, 2):
        rows = np.arange(360, 400)
        m = valid[rows, c]
        if m.sum() < 10:
            continue
        gl = glum[rows, c][m].mean()
        av = cov[rows, c] & valid[rows, c]
        rl = rlum[rows, c][av].mean() if av.any() else float("nan")
        hh = int((valid[rows, c] & ~cov[rows, c]).sum())
        dk = int((rlum[rows, c] < 0.05).sum())
        cc = cov[rows, c] & valid[rows, c]
        mb = birth[idx[rows, c][cc]].mean() if cc.any() else -1
        iof = iso[idx[rows, c][cc]].mean() if cc.any() else -1
        print(f" {c:3d} | {gl:6.3f}  {rl:8.3f}  {hh:4d}  {dk:8d}  {mb:10.2f}  {iof:7.2f}")

    # ---- (4) visualize: cyan depth-jump + magenta coverage holes, junction zoom ----
    vis = (bgr0.astype(np.float32) * 0.55).astype(np.uint8).copy()
    vis[jump] = (255, 255, 0)          # cyan = depth-jump (white/gray junction)
    vis[hole] = (255, 0, 255)          # magenta = ray-coverage hole
    # invalid depth -> blue tint (so context matches prior figures)
    void = ~valid
    vis[void] = (vis[void].astype(np.float32) * 0.4 + np.array([120, 60, 20], np.float32)).astype(np.uint8)

    # junction band around the found stripes: cols 565..612, rows 355..400
    x0, x1, y0, y1 = 565, 612, 355, 400
    crop = vis[y0:y1, x0:x1]
    zoom = cv2.resize(crop, ((x1 - x0) * 6, (y1 - y0) * 6), interpolation=cv2.INTER_NEAREST)
    out = OUT / "_diag_junction_stripes.png"
    cv2.imwrite(str(out), zoom)
    print(f"\nsaved -> {out}")

    # a focused view of ONLY the 3 vertical runs (bright white) so they are
    # unambiguous against the cyan junction line.
    vis2 = (bgr0.astype(np.float32) * 0.55).astype(np.uint8).copy()
    vis2[jump] = (255, 255, 0)         # cyan junction
    vis2[void] = (vis2[void].astype(np.float32) * 0.4 + np.array([120, 60, 20], np.float32)).astype(np.uint8)
    stripes = np.zeros((h, w), bool)
    for c, rs in [(594, (379, 381)), (597, (381, 383)), (599, (381, 384))]:
        stripes[rs[0]:rs[1] + 1, c] = True
    vis2[stripes] = (255, 255, 255)    # white = the 3 vertical stripe holes
    crop2 = vis2[y0:y1, x0:x1]
    zoom2 = cv2.resize(crop2, ((x1 - x0) * 6, (y1 - y0) * 6), interpolation=cv2.INTER_NEAREST)
    out2 = OUT / "_diag_junction_stripes_focus.png"
    cv2.imwrite(str(out2), zoom2)
    print(f"saved -> {out2}")

    # also a right-half full-band context crop
    ctx = vis[300:450, 500:w]
    cz = cv2.resize(ctx, ((w - 500) * 3, 150 * 3), interpolation=cv2.INTER_NEAREST)
    ctx_out = OUT / "_diag_junction_context.png"
    cv2.imwrite(str(ctx_out), cz)
    print(f"saved -> {ctx_out}")


if __name__ == "__main__":
    main()