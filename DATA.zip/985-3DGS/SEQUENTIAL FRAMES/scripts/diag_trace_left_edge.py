"""Trace the left-edge discs: is the 80-frame vs 0-frame appearance change on the
left border caused by (a) the SAME original disc front-most but recolored /
shifted, (b) a NEWLY born disc now in front, or (c) a DIFFERENT original disc
becoming front-most.

Runs the same 80-frame fusion as export_f0_model_timed.py (aging off), rasterizes
both the frame-0 model and the frame-0-transformed 80-frame model, and dumps the
per-pixel front-most disc index + per-disc mu/color/scale/birth so the caller can
attribute every changed left-edge pixel to one of the cases above.

Because aging pruning is off, the fusion only ever APPENDS discs: final-model
indices 0..n_init-1 are EXACTLY the original frame-0 discs (lineage preserved),
and indices n_init.. are newly born discs. birth alone is NOT a reliable lineage
marker (the first transition is labelled frame_idx=0, same as the originals), so
we key on the array index instead.
"""

from __future__ import annotations

import time
from pathlib import Path

import numpy as np

import h_pipeline_final as H
import sequential_fusion_flowonly as SF


def pm_compose(a, b):
    Ra, ta = a
    Rb, tb = b
    return Rb @ Ra, Rb @ ta + tb


def pm_inv(a):
    R, t = a
    return R.T, -R.T @ t


def main() -> None:
    OUT = SF.SEQ.parent / "output_trace_left"
    OUT.mkdir(parents=True, exist_ok=True)

    NPAIR = 81
    AGE_MAX = 1000000
    W_MIN = 0.0
    pairs = SF.associate(SF.DATA, max_dt=0.02)[:NPAIR]
    sample = SF.load_rgb(pairs[0].rgb_path)
    h, w = sample.shape[:2]
    map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)

    print("building frame-0 model ...", flush=True)
    bgr0, z0, _ = SF.load_pair(pairs, 0, map1, map2)
    g0, _, _, owner0 = H.build_hybrid_with_owner(bgr0, z0, K, SF.TEX_Q)
    n_init = len(g0)
    print(f"n_init={n_init}", flush=True)

    depth0, index0, _ = H.rasterize_discs(g0, K, (h, w))
    np.save(OUT / "index0.npy", index0.astype(np.int32))
    np.save(OUT / "depth0.npy", depth0.astype(np.float32))
    np.savez(OUT / "g0.npz", mu=g0.mu.astype(np.float64),
             color=g0.color.astype(np.float64), scale=g0.scale.astype(np.float64),
             normal=g0.normal.astype(np.float64))

    model = SF.Model(
        g=g0,
        w=np.ones(n_init, dtype=np.float32),
        age=np.zeros(n_init, dtype=np.int32),
        owner=owner0,
        birth=np.zeros(n_init, dtype=np.int32),
    )
    FL = [None] * NPAIR
    FL[0] = (np.eye(3), np.zeros(3))
    prev_FL = FL[0]
    prev_sf, prev_dt = None, 1.0
    bgr_a, z_a = bgr0, z0

    t0 = time.perf_counter()
    for i in range(NPAIR - 1):
        bgr_b, z_b, _ = SF.load_pair(pairs, i + 1, map1, map2)
        dt = pairs[i + 1].t_rgb - pairs[i].t_rgb
        sf = SF.compute_scene_flow(bgr_a, bgr_b, z_a, z_b, K,
                                   prev=prev_sf, dt=dt, prev_dt=prev_dt)
        R_10, t_10 = SF.se3_exp(sf.xi)
        FL[i + 1] = pm_compose(prev_FL, (R_10, t_10))
        SF.fuse_frame(model, sf, z_a, z_b, bgr_b, K,
                      age_max=AGE_MAX, w_min=W_MIN, frame_idx=i,
                      R_10=R_10, t_10=t_10)
        if (i + 1) % 10 == 0:
            print(f"[{i+1:03d}] N={len(model.g)} cum={time.perf_counter()-t0:.1f}s",
                  flush=True)
        bgr_a, z_a = bgr_b, z_b
        prev_sf, prev_dt = sf, dt
        prev_FL = FL[i + 1]

    g = model.g
    print(f"final N={len(g)}  transforming to frame 0 ...", flush=True)
    g0f = SF.transform_to_next(g, *pm_inv(FL[NPAIR - 1]))
    if g0f.axis1 is not None and g0f.axis2 is not None:
        g0f.quat = H._quat_from_frame(g0f.axis1, g0f.axis2, g0f.normal)

    print("rasterizing 80-frame model ...", flush=True)
    depth80, index80, _ = H.rasterize_discs(g0f, K, (h, w))
    np.save(OUT / "index80.npy", index80.astype(np.int32))
    np.save(OUT / "depth80.npy", depth80.astype(np.float32))
    np.savez(OUT / "g80f.npz", mu=g0f.mu.astype(np.float64),
             color=g0f.color.astype(np.float64), scale=g0f.scale.astype(np.float64),
             normal=g0f.normal.astype(np.float64), birth=model.birth.astype(np.int32))

    print("done", flush=True)


if __name__ == "__main__":
    main()