"""Scene flow export as multi-channel EXR (VX, VY, VZ in metres, NaN = invalid)."""

from __future__ import annotations

from pathlib import Path

import imageio.v3 as iio
import numpy as np


def write_scene_flow(path: Path, V: np.ndarray, valid: np.ndarray) -> None:
    """V: (H, W, 3) camera-frame displacement in metres. Invalid pixels become NaN."""
    out = np.asarray(V, dtype=np.float32).copy()
    out[~valid] = np.nan
    iio.imwrite(Path(path), out)


def read_scene_flow(path: Path) -> tuple[np.ndarray, np.ndarray]:
    V = np.asarray(iio.imread(Path(path)), dtype=np.float32)
    valid = np.isfinite(V).all(axis=-1)
    return V, valid
