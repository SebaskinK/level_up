"""PREV vs CURRENT breakdown of the frame-0 BLUE pixels, by the gate that rejected
the nearest old disc.

PREV    = original leftover order (S2 claims before absorb), N=86203.
CURRENT = absorb-first order, N=81349.
Both numbers are read from the blue-attribution runs' own output (never typed in
by hand): PREV from `output_blue_reason_run.log`, CURRENT from
`output_blue_reason_a2/report.txt`.

Run:
  python scripts/cmp_blue_reason_prev_new.py
"""

from __future__ import annotations

import re
from pathlib import Path

import cv2
import matplotlib
import numpy as np

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

SEQ = Path(__file__).resolve().parent
ROOT = SEQ.parent
PREV_LOG = ROOT / "output_blue_reason_run.log"
NEW_REPORT = ROOT / "output_blue_reason_a2" / "report.txt"
NEW_MAP = ROOT / "output_blue_reason_a2" / "blue_reason.png"
OUT = ROOT / "output_blue_reason_a2" / "cmp_blue_source_prev_new.png"

GATES = ["NO_NBR", "PLANE_FAIL", "RADIUS_FAIL", "COLOUR_FAIL", "WOULD_ABSORB"]
GATE_COLORS = ["#6e6e6e", "#e04b4b", "#e8c33a", "#f08a2a", "#3ec03e"]
BAR = 20


def parse_block(text: str, header: str) -> dict:
    """Read one attribution block: total line + the per-gate px counts."""
    m = re.search(re.escape(header), text)
    if not m:
        raise SystemExit(f"header not found: {header}")
    tail = text[m.end():]
    out = {}
    tm = re.search(r":\s*(\d+) px", tail)
    out["total"] = int(tm.group(1))
    out["f0_footprint_pct"] = parse_f0_footprint(text)
    for g in GATES:
        gm = re.search(rf"^\s+{g}\s+:\s*px=\s*(\d+)", tail, re.M)
        out[g] = int(gm.group(1)) if gm else 0
    return out


def parse_f0_footprint(text: str) -> float:
    fm = re.search(r"inside an f0-born disc footprint = ([\d.]+)%", text)
    if fm is None:
        raise SystemExit("f0-footprint line not found")
    return float(fm.group(1))


def caption(img: np.ndarray, lines: list[str]) -> np.ndarray:
    bar = np.full((BAR * len(lines) + 12, img.shape[1], 3), 20, np.uint8)
    for i, ln in enumerate(lines):
        cv2.putText(bar, ln, (8, 16 + BAR * i), cv2.FONT_HERSHEY_SIMPLEX,
                    0.44, (232, 232, 232), 1, cv2.LINE_AA)
    return np.vstack([img, bar])


def main() -> None:
    prev = parse_block(PREV_LOG.read_text(), "BLUE & f0-measured (redundant overdraw)")
    new = parse_block(NEW_REPORT.read_text(), "BLUE & f0-measured (redundant overdraw)")
    prev_l = parse_block(PREV_LOG.read_text(), "BLUE & f0-measured, LEFT x<128")
    new_l = parse_block(NEW_REPORT.read_text(), "BLUE & f0-measured, LEFT x<128")

    fig, axes = plt.subplots(1, 2, figsize=(15.5, 5.4), dpi=105)
    for ax, p, n, tag in [(axes[0], prev, new, "ALL blue"),
                          (axes[1], prev_l, new_l, "LEFT band x<128")]:
        x = np.arange(len(GATES))
        pv = [p[g] for g in GATES]
        nv = [n[g] for g in GATES]
        ax.bar(x - 0.2, pv, 0.4, label=f"PREV  (N=86203, blue={p['total']} px)",
               color=GATE_COLORS, alpha=0.45, edgecolor="k", linewidth=0.6)
        ax.bar(x + 0.2, nv, 0.4, label=f"CURRENT absorb-first (N=81349, blue={n['total']} px)",
               color=GATE_COLORS, edgecolor="k", linewidth=0.6)
        for xi, (a, b) in enumerate(zip(pv, nv)):
            ax.text(xi - 0.2, a, str(a), ha="center", va="bottom", fontsize=8)
            ax.text(xi + 0.2, b, str(b), ha="center", va="bottom", fontsize=8,
                    fontweight="bold")
        ax.set_xticks(x)
        ax.set_xticklabels([g.replace("_", "\n") for g in GATES], fontsize=9)
        ax.set_title(f"{tag}: blue px by rejecting gate of the nearest old disc",
                     fontsize=10)
        ax.set_ylabel("blue pixels", fontsize=9)
        ax.grid(axis="y", alpha=0.25)
        ax.legend(fontsize=8, loc="upper right")
    fig.tight_layout()

    fig.canvas.draw()
    chart = cv2.cvtColor(np.asarray(fig.canvas.buffer_rgba()), cv2.COLOR_RGBA2BGR)
    plt.close(fig)

    mp = cv2.imread(str(NEW_MAP))
    if mp is None:
        raise SystemExit(f"missing {NEW_MAP}")
    mp = mp[:480]
    scale = chart.shape[1] / mp.shape[1]
    mp = cv2.resize(mp, (chart.shape[1], int(mp.shape[0] * scale)),
                    interpolation=cv2.INTER_NEAREST)
    body = np.vstack([chart, np.full((6, chart.shape[1], 3), 255, np.uint8), mp])

    lines = [
        "FRAME-0 BLUE PIXEL SOURCE  (blue = front-most disc born f1-80 while f0 had measured depth there, |dz|/z<0.05)",
        f"Bar colours = the gate that rejected the nearest OLD disc at that pixel.  ALL-blue: PREV {prev['total']} px -> CURRENT {new['total']} px "
        f"({100*(new['total']-prev['total'])/prev['total']:+.1f}%).  LEFT x<128: PREV {prev_l['total']} -> CURRENT {new_l['total']} px "
        f"({100*(new_l['total']-prev_l['total'])/max(prev_l['total'],1):+.1f}%).",
        f"PREV: f0-MEASURED depth at 100% of blue, inside an f0-born disc footprint {prev['f0_footprint_pct']:.1f}% "
        f"-> pure redundant overdraw, zero genuinely-new region.  CURRENT: measured 100%, inside f0 footprint {new['f0_footprint_pct']:.1f}%.",
        f"CURRENT left band: WOULD_ABSORB {new_l['WOULD_ABSORB']} + RADIUS_FAIL {new_l['RADIUS_FAIL']} = "
        f"{100*(new_l['WOULD_ABSORB']+new_l['RADIUS_FAIL'])/new_l['total']:.1f}%  ->  cause is the old disc NOT RENDERING the pixel "
        f"(its frozen radius does not reach it), not the colour gate.",
        "COLOUR_FAIL (B, untouched) is only 8.5% of blue and 72% of its pixels are ALREADY inside the neighbour's own ellipse -> a real colour seam, not a geometry gap.",
        "BOTTOM: frame-0 hard ray render, blue pixels painted by rejecting gate.  gray=NO_NBR red=PLANE yellow=RADIUS orange=COLOUR green=WOULD_ABSORB.",
    ]
    out = caption(body, lines)
    cv2.imwrite(str(OUT), out)
    print("saved ->", OUT)
    for tag, blk in [("ALL ", new), ("LEFT", new_l)]:
        print(tag, {g: blk[g] for g in GATES}, "total", blk["total"])


if __name__ == "__main__":
    main()