S2 4-neighborhood experiment
