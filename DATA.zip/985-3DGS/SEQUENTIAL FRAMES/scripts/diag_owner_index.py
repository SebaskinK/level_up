"""Per-pixel owner index map (claim-based, first-order Jacobian) vs the exact
disc footprint (ray-plane intersection), both from the same frame-0 model.

Owner is the `claim_owner` full-footprint ellipse: image-space semi-axis vectors
from `project_tangent` (first-order perspective Jacobian), resolved largest-
footprint-first with no overwrite. The exact footprint is `rasterize_discs`
(ray-plane intersection, front-most), with the in-plane axes reconstructed from
the normal via the same tangent frame, so the only differences are (a) the
Jacobian linearisation and (b) resolution order (largest-first vs front-most).

Loads model_f0.npz (a cached 10-frame model already transformed back to frame 0),
so this does NOT re-run scene flow.
"""

from __future__ import annotations

import sys
from pathlib import Path

import cv2
import numpy as np

SEQ = Path(__file__).resolve().parent
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SFLOW))
sys.path.insert(0, str(SEQ))

import h_pipeline_final as H  # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402

BASE = SEQ.parent
N_PTS = 48
TH = np.linspace(0.0, 2.0 * np.pi, N_PTS, endpoint=False)
COS = np.cos(TH)
SIN = np.sin(TH)


def tangent_basis(n: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Same Gram-Schmidt as _quat_from_normal: (t1, t2, n) orthonormal."""
    n = n.astype(np.float64)
    n = n / np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-12)
    ref = np.tile(np.array([0.0, 0.0, 1.0]), (n.shape[0], 1))
    ref[np.abs(n[:, 2]) > 0.9] = np.array([1.0, 0.0, 0.0])
    t1 = np.cross(ref, n)
    t1 = t1 / np.maximum(np.linalg.norm(t1, axis=1, keepdims=True), 1e-12)
    t2 = np.cross(n, t1)
    return t1, t2


def owner_index_map(mu, normal, scale, K, shape):
    """Claim-based per-pixel owner (linearised full footprint).

    Ids are the ACTUAL disc index into `mu` (position in the model array), so the
    map is directly comparable to `rasterize_discs`' returned index. `H.claim_owner`
    re-labels by row-major rank (which only coincides with the emission order in a
    fresh single-frame build), so it cannot be reused for an arbitrary accumulated
    ordering.
    """
    h, w = shape
    fx, fy, cx, cy = (float(K[0, 0]), float(K[1, 1]), float(K[0, 2]), float(K[1, 2]))
    zc = np.maximum(mu[:, 2], 1e-6)
    ys = np.clip(np.rint(fy * mu[:, 1] / zc + cy).astype(np.int32), 0, h - 1)
    xs = np.clip(np.rint(fx * mu[:, 0] / zc + cx).astype(np.int32), 0, w - 1)
    r1 = scale[:, 0].astype(np.float64)
    r2 = scale[:, 1].astype(np.float64)
    t1, t2 = tangent_basis(normal)
    e1 = H.project_tangent(t1 * r1[:, None], mu.astype(np.float64), K)
    e2 = H.project_tangent(t2 * r2[:, None], mu.astype(np.float64), K)
    return claim_owner_actual_ids(ys, xs, e1, e2, shape)


def claim_owner_actual_ids(ys, xs, e1, e2, shape):
    """Same greedy (largest |det| first, no overwrite) but id = array position."""
    h, w = shape
    owner = np.full((h, w), -1, dtype=np.int32)
    n = ys.size
    if n == 0:
        return owner
    det = e1[:, 0] * e2[:, 1] - e2[:, 0] * e1[:, 1]
    order = np.argsort(-np.abs(det), kind="stable")
    YY, XX = np.meshgrid(np.arange(h), np.arange(w), indexing="ij")
    for i in order:
        y, x = ys[i], xs[i]
        if abs(det[i]) < 1e-12:
            if owner[y, x] < 0:
                owner[y, x] = i
            continue
        bx = max(int(np.ceil(np.hypot(e1[i, 0], e2[i, 0]))), 0)
        by = max(int(np.ceil(np.hypot(e1[i, 1], e2[i, 1]))), 0)
        y0, y1 = max(y - by, 0), min(y + by + 1, h)
        x0, x1 = max(x - bx, 0), min(x + bx + 1, w)
        if x0 >= x1 or y0 >= y1:
            continue
        px = XX[y0:y1, x0:x1] - x
        py = YY[y0:y1, x0:x1] - y
        c0 = (e2[i, 1] * px - e2[i, 0] * py) / det[i]
        c1 = (-e1[i, 1] * px + e1[i, 0] * py) / det[i]
        ellipse = (c0 * c0 + c1 * c1) <= 1.0
        sub = owner[y0:y1, x0:x1]
        sub[ellipse & (sub < 0)] = i
    return owner


def owner_to_color(owner: np.ndarray) -> np.ndarray:
    """Golden-angle hue per owner id; unowned -> dark grey."""
    out = np.full((*owner.shape, 3), 45, np.uint8)
    uid = owner >= 0
    if uid.any():
        hid = owner[uid].astype(np.float64)
        hue = np.mod(hid * 0.6180339887498949, 1.0)
        hsv = np.zeros((int(uid.sum()), 1, 3), np.uint8)
        hsv[:, 0, 0] = (hue * 179).astype(np.uint8)
        hsv[:, 0, 1] = 190
        hsv[:, 0, 2] = 255
        out[uid] = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)[:, 0]
    return out


def draw_exact_ellipses(img, mu, normal, scale, K, color=(255, 255, 255)):
    """Exact perspective projection of each 3D footprint ellipse (tangent frame)."""
    h, w = img.shape[:2]
    fx, fy, cx, cy = (float(K[0, 0]), float(K[1, 1]), float(K[0, 2]), float(K[1, 2]))
    mu = mu.astype(np.float64)
    r1 = scale[:, 0].astype(np.float64)
    r2 = scale[:, 1].astype(np.float64)
    t1, t2 = tangent_basis(normal)
    cs = COS[:, None]
    sn = SIN[:, None]
    p = (mu[None, :, :]
         + (r1 * cs)[:, :, None] * t1[None, :, :]
         + (r2 * sn)[:, :, None] * t2[None, :, :])
    zc = np.maximum(p[..., 2], 1e-6)
    u = np.clip((fx * p[..., 0] / zc + cx).astype(np.int32), 0, w - 1)
    v = np.clip((fy * p[..., 1] / zc + cy).astype(np.int32), 0, h - 1)
    epts = np.ascontiguousarray(np.stack([u, v], axis=-1).transpose(1, 0, 2))
    for i in range(len(mu)):
        cv2.polylines(img, [epts[i]], True, color, 1, cv2.LINE_8)
    return img


def bar(text, w):
    b = np.full((40, w, 3), 25, np.uint8)
    cv2.putText(b, text, (8, 26), cv2.FONT_HERSHEY_SIMPLEX, 0.45,
                (225, 225, 225), 1, cv2.LINE_AA)
    return b


def main() -> None:
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--npz", default=str(BASE / "output_f0_10frame" / "model_f0.npz"))
    ap.add_argument("--gt", default=str(BASE / "output_f0_10frame" / "f0_gt.png"))
    ap.add_argument("--out", default=str(BASE / "output_owner_index"))
    args = ap.parse_args()

    data = np.load(args.npz)
    mu = data["mu"].astype(np.float64)
    normal = data["normal"].astype(np.float64)
    scale = data["scale"].astype(np.float64)
    bgr0 = cv2.imread(args.gt)
    if bgr0 is None:
        raise FileNotFoundError(args.gt)
    h, w = bgr0.shape[:2]

    # intrinsics from the same undistort path the fusion uses (K only).
    _, _, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    print(f"N={len(mu)} shape=({h},{w})")

    owner = owner_index_map(mu, normal, scale, K, (h, w))
    n_owned = int((owner >= 0).sum())

    # exact front-most ray-disc footprint (same tangent frame via reconstructed axes)
    t1, t2 = tangent_basis(normal)
    g = H.Gaussians(
        mu=mu.astype(np.float32),
        normal=normal.astype(np.float32),
        scale=scale.astype(np.float32),
        quat=H._quat_from_frame(t1.astype(np.float32), t2.astype(np.float32),
                                normal.astype(np.float32)),
        color=np.zeros((len(mu), 3), np.float32),
        alpha=np.full(len(mu), H.OPAQUE_ALPHA, np.float32),
        pixel=np.zeros((len(mu), 2), np.int32),
        axis1=t1.astype(np.float32),
        axis2=t2.astype(np.float32),
    )
    depth, idx, _ = H.rasterize_discs(g, K, (h, w))
    hit = np.isfinite(depth)

    # --- (A) exact ellipse outline on dimmed GT (self-consistent with owner axes)
    vis_a = (bgr0.astype(np.float32) * 0.5).astype(np.uint8).copy()
    draw_exact_ellipses(vis_a, mu, normal, scale, K, color=(0, 0, 255))

    # --- (B) owner index map, exact outlines overlaid in white
    vis_b = owner_to_color(owner)
    draw_exact_ellipses(vis_b, mu, normal, scale, K, color=(255, 255, 255))

    # --- (C) mismatch: where owner id vs ray-disc id disagree (among both-covered)
    both = (owner >= 0) & hit
    agree = both & (owner == idx)
    owner_only = (owner >= 0) & ~hit
    raydisc_only = hit & (owner < 0)
    mismatch = both & (owner != idx)

    # agreement metrics (fractions of the full image)
    tot = h * w
    union = (owner >= 0) | hit
    stats = {
        "owner_cov": (owner >= 0).sum() / tot,
        "raydisc_cov": hit.sum() / tot,
        "agree": agree.sum() / tot,
        "id_mismatch": mismatch.sum() / tot,
        "owner_only": owner_only.sum() / tot,
        "raydisc_only": raydisc_only.sum() / tot,
        "union": union.sum() / tot,
    }
    agree_union = agree.sum() / max(union.sum(), 1) if union.any() else 0.0
    print(json_str := ", ".join(f"{k}={v:.4f}" for k, v in stats.items()))
    print(f"agree/union={agree_union:.4f}")
    print(f"n_owned={n_owned} n_hit={int(hit.sum())}")

    cv2.imwrite(str(out / "owner_index.png"),
                np.vstack([vis_b, bar(f"owner index (golden-angle hue by disc id; "
                                      f"white = exact ellipse outline; N={len(mu)})", w)]))
    cv2.imwrite(str(out / "ellipse_exact.png"),
                np.vstack([vis_a, bar("exact frame-0 ellipse projection (red)", w)]))

    # side-by-side comparison
    lab = bar(f"exact ellipse (ray-plane)  |  owner index (linearised claim)  "
              f"owner_cov={stats['owner_cov']:.3f} raydisc_cov={stats['raydisc_cov']:.3f} "
              f"id_mismatch={stats['id_mismatch']:.4f} agree/union={agree_union:.3f}",
              w * 2)
    cmp = np.vstack([lab, np.hstack([vis_a, vis_b])])
    cv2.imwrite(str(out / "cmp_owner_vs_ellipse.png"), cmp)

    # mismatch heat: white where owner->ray-disc ids disagree (both covered)
    vis_m = (bgr0.astype(np.float32) * 0.35).astype(np.uint8).copy()
    vis_m[owner_only] = (0, 200, 255)      # yellow: owner covers, ray-disc misses
    vis_m[raydisc_only] = (0, 0, 255)      # red: ray-disc hits, owner missed
    vis_m[mismatch] = (255, 255, 255)      # white: both cover but different disc
    mb = bar(f"owner_only={stats['owner_only']:.4f} (yellow)  "
             f"raydisc_only={stats['raydisc_only']:.4f} (red)  "
             f"id_mismatch={stats['id_mismatch']:.4f} (white)", w)
    cv2.imwrite(str(out / "owner_raydisc_mismatch.png"), np.vstack([vis_m, mb]))

    print(f"saved -> {out}")
    print(json_str)


if __name__ == "__main__":
    main()