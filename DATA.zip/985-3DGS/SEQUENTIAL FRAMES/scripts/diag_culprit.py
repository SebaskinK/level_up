"""Pinpoint white-over-gray culprit discs with color + birth from the re-run."""
import sys
from pathlib import Path

import numpy as np

SEQ = Path(__file__).resolve().parent
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SEQ))
sys.path.insert(0, str(SFLOW))

import h_pipeline_final as H  # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402

OUT = SEQ.parent / "output_f0_10frame"
d = np.load(OUT / "model_f0.npz")
mu = d["mu"].astype(np.float32)
normal = d["normal"].astype(np.float32)
scale = d["scale"].astype(np.float32)
col = d["color"].astype(np.float32)
birth = d["birth"]
print("n_final", len(mu), "birth range", birth.min(), birth.max())

pairs = SF.associate(SF.DATA, max_dt=0.02)[:1]
h, w = SF.load_rgb(pairs[0].rgb_path).shape[:2]
map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)
bgr0, z0, _ = SF.load_pair(pairs, 0, map1, map2)
gt = bgr0.astype(np.float32)[..., ::-1] / 255.0  # RGB

# rebuild axis1/axis2 from quat in ply (for accurate rasterize)
raw = (OUT / "model.ply").read_bytes()
arr = np.frombuffer(raw[raw.index(b"end_header\n") + len(b"end_header\n"):],
                    dtype=np.float32).reshape(-1, 17)
rot = arr[:, 13:17].astype(np.float32)
q = rot / np.maximum(np.linalg.norm(rot, axis=1, keepdims=True), 1e-12)
x, y, z, wq = q[:, 0], q[:, 1], q[:, 2], q[:, 3]
axis1 = np.stack([1 - 2*(y*y+z*z), 2*(x*y - z*wq), 2*(x*z + y*wq)], 1)
axis2 = np.stack([2*(x*y + z*wq), 1 - 2*(x*x+z*z), 2*(y*z - x*wq)], 1)

g = H.Gaussians(mu=mu, normal=normal, scale=scale, quat=q,
                color=col, alpha=np.ones(len(mu), np.float32),
                pixel=np.zeros((len(mu), 2), np.int32), axis1=axis1, axis2=axis2)
depth, index, _ = H.rasterize_discs(g, K, (h, w))

# white-over-gray (RGB): render white, GT gray
render = np.zeros((h, w, 3), np.float32)
hit = np.isfinite(depth)
render[hit] = col[index[hit]]
hw = render.min(axis=2) > 0.68
gs = (gt.mean(axis=2) > 0.15) & (gt.mean(axis=2) < 0.6)
mask = hw & gs & hit
ys, xs = np.where(mask)
print("white-over-gray pixels:", xs.size)

# for a sample of culprit pixels, report disc idx + birth + color + r + normal + GT
print("\nsample culprit discs (pixel -> disc):")
seen = set()
for py, px in list(zip(ys, xs))[:: max(1, xs.size // 20)]:
    i = index[py, px]
    if i in seen:
        continue
    seen.add(int(i))
    print(f"  px({px},{py}) gt=({gt[py,px,0]:.2f},{gt[py,px,1]:.2f},{gt[py,px,2]:.2f}) "
          f"-> disc{i} birth={birth[i]} col=({col[i,0]:.2f},{col[i,1]:.2f},{col[i,2]:.2f}) "
          f"r=({scale[i,0]:.4f},{scale[i,1]:.4f}) nz={normal[i,2]:.2f} "
          f"mu=({mu[i,0]:.3f},{mu[i,1]:.3f},{mu[i,2]:.3f})")

# aggregate: birth histogram of culprit discs, and color stats
culp = np.unique(index[mask])
print("\nculprit discs:", len(culp))
for b in range(0, 11):
    sel = culp[birth[culp] == b]
    if sel.size:
        print(f"  birth={b}: {sel.size} discs, mean r=({scale[sel,0].mean():.4f},{scale[sel,1].mean():.4f}) "
              f"mean col=({col[sel,0].mean():.2f},{col[sel,1].mean():.2f},{col[sel,2].mean():.2f}) "
              f"mean nz={normal[sel,2].mean():.2f}")