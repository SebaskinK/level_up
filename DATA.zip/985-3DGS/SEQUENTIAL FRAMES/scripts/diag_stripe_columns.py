"""Tie the right-edge dark vertical stripes to disc birth frame / type / colour.

Re-rasterizes the final frame-0 model, locates the gray table strip (low-saturation
mid-brightness GT), and for the right-half strip prints a per-column profile of
rendered-vs-GT brightness plus the covering disc's birth frame, S2/curvature class
and colour luminance. The goal: prove the stripes are near-black birth-0 discs and
not coverage holes, and localise which columns they land on.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

SEQ = Path(__file__).resolve().parent
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SEQ))
sys.path.insert(0, str(SFLOW))

import h_pipeline_final as H            # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402

OUT = SEQ.parent / "output_discmask_align"


def tangent_basis(n):
    n = n.astype(np.float64)
    n = n / np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-12)
    ref = np.tile(np.array([0.0, 0.0, 1.0]), (n.shape[0], 1))
    ref[np.abs(n[:, 2]) > 0.9] = np.array([1.0, 0.0, 0.0])
    t1 = np.cross(ref, n)
    t1 = t1 / np.maximum(np.linalg.norm(t1, axis=1, keepdims=True), 1e-12)
    t2 = np.cross(n, t1)
    return t1, t2


def main() -> None:
    d = np.load(OUT / "model_f0.npz")
    mu = d["mu"].astype(np.float32)
    normal = d["normal"].astype(np.float32)
    scale = d["scale"].astype(np.float32)
    color = d["color"].astype(np.float32)
    birth = d["birth"].astype(np.int32)
    t1, t2 = tangent_basis(normal)
    g = H.Gaussians(
        mu=mu, normal=normal, scale=scale,
        quat=H._quat_from_frame(t1.astype(np.float32), t2.astype(np.float32), normal),
        color=color, alpha=None,
        pixel=np.zeros((len(mu), 2), np.int32),
        axis1=t1.astype(np.float32), axis2=t2.astype(np.float32))

    pairs = SF.associate(SF.DATA, max_dt=0.02)[: 11]
    sm = SF.load_rgb(pairs[0].rgb_path)
    h, w = sm.shape[:2]
    m1, m2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)
    bgr0, z0, _ = SF.load_pair(pairs, 0, m1, m2)
    valid = (z0 > SF.Z_MIN) & (z0 < SF.Z_MAX)

    depth, index, _ = H.rasterize_discs(g, K, (h, w))
    cov = np.isfinite(depth) & valid
    idx = index.astype(np.int64)

    # per-pixel covering disc colour luminance (RGB mean)
    lum_disc = color.mean(axis=1)
    pix_lum = np.zeros((h, w), np.float32)
    pix_lum[cov] = lum_disc[idx[cov]]
    pix_birth = np.full((h, w), -1, np.int32)
    pix_birth[cov] = birth[idx[cov]]
    iso = np.abs(scale[:, 0] - scale[:, 1]) < 1e-6 * np.maximum(scale[:, 0], 1e-9)

    # GT gray strip: low saturation, mid brightness (table side)
    rgb = bgr0[..., ::-1].astype(np.float32) / 255.0
    mx = rgb.max(axis=2); mn = rgb.min(axis=2)
    sat = (mx - mn) / np.maximum(mx, 1e-6)
    gt_lum = rgb.mean(axis=2)
    gray = valid & (sat < 0.15) & (gt_lum > 0.1) & (gt_lum < 0.85)

    # render-lum vs GT-lum on the gray strip, right half
    half = w // 2
    strip = gray & (np.arange(w)[None, :] >= half)
    ys, xs = np.nonzero(strip)
    if xs.size == 0:
        print("no gray strip found in right half"); return
    print(f"gray strip (right half): cols [{xs.min()},{xs.max()}] rows [{ys.min()},{ys.max()}] n={xs.size}")

    # column profile every ~2 px over the strip columns
    cols = np.arange(xs.min(), xs.max() + 1, 2)
    print("\ncol : rend_lum | gt_lum | dRendLum | dark% | meanbirth | iso% | ncover")
    for c in cols:
        m = strip[:, c]
        if m.sum() < 5:
            continue
        rl = pix_lum[:, c][m].mean() if cov[:, c][m].any() else 0.0
        gl = gt_lum[:, c][m].mean()
        dark = m & cov[:, c] & (pix_lum[:, c] < 0.05)
        dfrac = dark.sum() / max(m.sum(), 1)
        mb = pix_birth[:, c][m & cov[:, c]].mean() if cov[:, c][m].any() else -1
        isof = iso[idx[:, c][m & cov[:, c]]].mean() if cov[:, c][m].any() else -1
        nc = len(np.unique(idx[:, c][m & cov[:, c]])) if cov[:, c][m].any() else 0
        print(f"{c:4d}: {rl:8.3f} | {gl:6.3f} | {rl-gl:+8.3f} | {dfrac:5.2f} | {mb:9.2f} | {isof:4.2f} | {nc:5d}")

    # distinct dark discs covering the strip, with birth / iso / colour / depth
    sel = strip & cov & (pix_lum < 0.05)
    dids = np.unique(idx[sel])
    print(f"\n{dids.size} distinct dark discs on strip; birth hist: {np.bincount(birth[dids], minlength=12).tolist()}")
    print(f"iso(S2) frac: {iso[dids].mean():.3f}")
    print(f"colour lum: min={lum_disc[dids].min():.3f} med={np.median(lum_disc[dids]):.3f} max={lum_disc[dids].max():.3f}")
    # depth of dark discs vs depth of the *bright* discs in the same columns
    zc = depth[sel].mean()
    bright = strip & cov & (pix_lum > 0.2)
    zb = depth[bright].mean() if bright.any() else np.nan
    print(f"mean depth: dark discs={zc:.4f}  bright discs={zb:.4f}  (dark is {'CLOSER' if zc < zb else 'FARTHER'})")
    # 3D radius of dark discs
    rd = scale[dids].max(axis=1).mean()
    rb = scale[idx[bright]].max(axis=1).mean() if bright.any() else np.nan
    print(f"mean max-scale (m): dark={rd:.4f} bright={rb:.4f}")


if __name__ == "__main__":
    main()