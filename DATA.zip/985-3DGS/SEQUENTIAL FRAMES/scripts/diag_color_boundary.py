"""Why do white desk discs cover the gray side? Check which fence (r_edge / r_cap)
should have clamped them, for the frame-0 build (not the incremental model)."""
import sys
from pathlib import Path

import numpy as np

SEQ = Path(__file__).resolve().parent
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SEQ))
sys.path.insert(0, str(SFLOW))

import h_pipeline_final as H  # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402

pairs = SF.associate(SF.DATA, max_dt=0.02)[:1]
h, w = SF.load_rgb(pairs[0].rgb_path).shape[:2]
map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)
bgr0, z0, _ = SF.load_pair(pairs, 0, map1, map2)

g0, keep_geo, tex_mask, owner0 = H.build_hybrid_with_owner(bgr0, z0, K, SF.TEX_Q)
print("frame0 N =", len(g0))

geo = H.compute_scene_geometry(
    z0, K, H.GEO_CFG["eps"], H.GEO_CFG["gauss_sigma"], H.GEO_CFG["disc_rel"],
)
rgb = bgr0[..., ::-1].astype(np.float32) / 255.0
r_cap = H.tex_boundary_limit(z0, K, tex_mask, tol_px=4.5)

depth, index, _ = H.rasterize_discs(g0, K, (h, w))
render = np.zeros((h, w, 3), np.float32)
hit = np.isfinite(depth)
render[hit] = g0.color[index[hit]]

gt = rgb
hw = render.min(axis=2) > 0.68          # rendered white
gs = (gt.mean(axis=2) > 0.15) & (gt.mean(axis=2) < 0.6)  # GT gray
mask = hw & gs & hit

ys, xs = np.where(mask)
culp = np.unique(index[mask])
print(f"white-over-gray pixels={xs.size} culprit discs={len(culp)}")

# per-disc source pixel: project mu back to image
mu = g0.mu.astype(np.float64)
fx, fy, cx, cy = (float(K[0, 0]), float(K[1, 1]), float(K[0, 2]), float(K[1, 2]))
u = fx * mu[:, 0] / np.maximum(mu[:, 2], 1e-6) + cx
v = fy * mu[:, 1] / np.maximum(mu[:, 2], 1e-6) + cy
ui = np.clip(u.astype(int), 0, w - 1)
vi = np.clip(v.astype(int), 0, h - 1)

r1 = g0.scale[:, 0]
r2 = g0.scale[:, 1]

print("\nculprit discs (sorted by radius r1):")
order = np.argsort(-r1[culp])
for o in order[:30]:
    i = culp[o]
    src_tex = bool(tex_mask[vi[i], ui[i]])
    src_disc = bool(geo.disc_mask[vi[i], ui[i]])
    print(f"  idx{i:5d} r=({r1[i]:.4f},{r2[i]:.4f}) "
          f"src=({ui[i]},{vi[i]}) src_tex={int(src_tex)} "
          f"r_edge={geo.r_edge[vi[i], ui[i]]:.4f} "
          f"r_cap={r_cap[vi[i], ui[i]]:.4f} "
          f"z={z0[vi[i], ui[i]]:.2f} nz={g0.normal[i, 2]:.2f} "
          f"col=({g0.color[i,0]:.2f},{g0.color[i,1]:.2f},{g0.color[i,2]:.2f})")