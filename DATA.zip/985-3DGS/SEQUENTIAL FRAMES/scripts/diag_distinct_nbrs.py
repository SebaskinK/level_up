"""Count distinct neighbour discs around un-owned (leftover/hole) pixels.

Decisive check for the "collapse signal is being dropped" hypothesis.

For each of the first few frames, after fusion, take every valid-depth pixel
that has NO owner (owner<0 -- these are next frame's leftover), and count how
many DISTINCT old discs sit in its 9x9 window (Chebyshev radius 4, matching the
absorb search). If many pixels have 2..5 distinct neighbours, then the current
"nearest-neighbour-only" absorb is ignoring a multi-disc collapse opportunity.
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

SEQ = Path(__file__).resolve().parent
SINGLE = SEQ.parent.parent / "SINGLE FRAME" / "scripts"
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SINGLE))
sys.path.insert(0, str(SFLOW))

import h_pipeline_final as H  # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402


def distinct_nbrs(owner, ys, xs, R=4):
    """Per pixel, count distinct owner ids (>=0) in a (2R+1)^2 Chebyshev window."""
    h, w = owner.shape
    seen = {}
    out = np.zeros(xs.shape[0], dtype=np.int32)
    # accumulate distinct ids via per-pixel bitset on the fly is heavy; use
    # small window so collect per-pixel sets only for the queried pixels.
    for k, (y, x) in enumerate(zip(ys, xs)):
        s = set()
        for dy in range(-R, R + 1):
            for dx in range(-R, R + 1):
                if max(abs(dy), abs(dx)) > R:
                    continue
                yy, xx = y + dy, x + dx
                if 0 <= yy < h and 0 <= xx < w:
                    o = owner[yy, xx]
                    if o >= 0:
                        s.add(int(o))
        out[k] = len(s)
    return out


def main() -> None:
    pairs = SF.associate(SF.DATA, max_dt=0.02)[:4]  # frames 0..3
    sample = SF.load_rgb(pairs[0].rgb_path)
    h, w = sample.shape[:2]
    map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)

    bgr0, z0, _ = SF.load_pair(pairs, 0, map1, map2)
    g0, _, _ = H.build_hybrid(bgr0, z0, K, SF.TEX_Q)
    model = SF.Model(
        g=g0, w=np.ones(len(g0), dtype=np.float32),
        age=np.zeros(len(g0), dtype=np.int32),
        owner=SF.owner_from_raster(g0, K, (h, w)),
        birth=np.zeros(len(g0), dtype=np.int32),
        cnt=np.ones(len(g0), dtype=np.float32),
    )

    prev_sf = None
    prev_dt = 1.0
    bgr_a, z_a = bgr0, z0
    for i in range(len(pairs) - 1):
        bgr_b, z_b, _ = SF.load_pair(pairs, i + 1, map1, map2)
        dt = pairs[i + 1].t_rgb - pairs[i].t_rgb
        sf = SF.compute_scene_flow(bgr_a, bgr_b, z_a, z_b, K,
                                   prev=prev_sf, dt=dt, prev_dt=prev_dt)
        R_10, t_10 = SF.se3_exp(sf.xi)
        rec = SF.fuse_frame(model, sf, z_a, z_b, bgr_b, K,
                            age_max=10**6, w_min=2.0, frame_idx=i,
                            R_10=R_10, t_10=t_10)
        z1 = rec["z1"]
        valid = (z1 > SF.Z_MIN) & (z1 < SF.Z_MAX)
        owner = model.owner
        ys, xs = np.where(valid & (owner < 0))
        cnt = distinct_nbrs(owner, ys, xs, R=4)
        total = int(xs.size)
        hist = np.bincount(cnt, minlength=8)
        print(f"[f{i}] owner<0 valid px={total:6d}  distinct-9x9-nbr hist "
              f"(0..7): {hist[:8].tolist()}", flush=True)
        if total:
            frac_ge2 = float((cnt >= 2).mean())
            print(f"        >=2 distinct neighbours: {frac_ge2*100:.1f}%  "
                  f"mean={cnt.mean():.2f}  max={cnt.max()}", flush=True)
        bgr_a, z_a = bgr_b, z_b
        prev_sf, prev_dt = sf, dt


if __name__ == "__main__":
    main()