"""Render frame 0 using the INCREMENTAL pipeline's h_pipeline_final (multi-frame copy).

The incremental driver builds frame 0 via `H.build_hybrid(bgr0, z0, K, TEX_Q)`
where `H` is SEQUENTIAL FRAMES/scripts/h_pipeline_final.py -- the copy whose
`edge_distance_limit` now treats FOV-border void as non-seam. This script renders
THAT build with both renderers (hard ray-disc + EWA) and saves the three images.

Deliberately does NOT import the single-frame copy; sys.path puts the multi-frame
scripts dir FIRST so `import h_pipeline_final as H` (also inside exp_surfel_render)
resolves to the same multi-frame module.
"""

from __future__ import annotations

import sys
from pathlib import Path

import cv2
import numpy as np

SEQ = Path(__file__).resolve().parent          # SEQUENTIAL FRAMES/scripts (multi-frame H)
SINGLE = SEQ.parent.parent / "SINGLE FRAME" / "scripts"   # for exp_surfel_render only
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
# `sys.path.insert(0, ...)` puts the LAST inserted at index 0. So insert SEQ last
# among those that define h_pipeline_final, so the multi-frame copy wins; SINGLE is
# inserted only to provide exp_surfel_render (which then re-imports the same
# already-registered multi-frame `h_pipeline_final` from sys.modules).
sys.path.insert(0, str(SFLOW))
sys.path.insert(0, str(SINGLE))
sys.path.insert(0, str(SEQ))       # multi-frame h_pipeline_final wins

import h_pipeline_final as H  # noqa: E402  (multi-frame copy)
from exp_surfel_render import render_ewa  # noqa: E402
from tum_io import (  # noqa: E402
    FR1_INTRINSICS, associate, load_depth, load_rgb,
    remap_depth, remap_rgb, undistort_maps,
)

DATA = Path("/home/sti/Work/986-SceneFlow/rgbd_dataset_freiburg1_desk")
OUT = SEQ.parent / "output_absorb_v2" / "render_inc0"
OUT.mkdir(parents=True, exist_ok=True)


def main() -> None:
    pairs = associate(DATA)
    fr = pairs[0]
    sample = load_rgb(fr.rgb_path)
    h, w = sample.shape[:2]
    map1, map2, K = undistort_maps((h, w), FR1_INTRINSICS)
    bgr = remap_rgb(load_rgb(fr.rgb_path), map1, map2)
    z = remap_depth(load_depth(fr.depth_path), map1, map2)
    z[(z < H.GEO_CFG["z_min"]) | (z > H.GEO_CFG["z_max"])] = 0.0

    g, keep_geo, tex_mask = H.build_hybrid(bgr, z, K, 0.6)
    print(f"[incremental H] N={len(g)} geo={int(keep_geo.sum())} "
          f"tex={int(tex_mask.sum())}")

    # hard ray-disc
    depth_a, index_a, _ = H.rasterize_discs(g, K, (h, w))
    hit_a = np.isfinite(depth_a)
    hard = np.zeros((h, w, 3), np.float32)
    hard[hit_a] = g.color[index_a[hit_a]]
    print(f"hard  covered={float(hit_a.mean()):.4f} hole={1-float(hit_a.mean()):.4f}")

    # EWA normalized (matches the fusion render path cov_scale=0.33)
    color_b, depth_b, weight_b = render_ewa(g, K, (h, w),
                                            mode="normalized", cov_scale=0.33)
    hit_b = weight_b > 0
    print(f"ewa   covered={float(hit_b.mean()):.4f} hole={1-float(hit_b.mean()):.4f}")

    gt = bgr
    hard_bgr = (np.clip(hard, 0, 1) * 255).astype(np.uint8)[..., ::-1].copy()
    hard_bgr[~hit_a] = 0
    ewa_bgr = (np.clip(color_b, 0, 1) * 255).astype(np.uint8)[..., ::-1].copy()
    ewa_bgr[~hit_b] = 0

    cv2.imwrite(str(OUT / "f0_gt.png"), gt)
    cv2.imwrite(str(OUT / "f0_hard.png"), hard_bgr)
    cv2.imwrite(str(OUT / "f0_ewa.png"), ewa_bgr)
    print(f"saved -> {OUT}")


if __name__ == "__main__":
    main()