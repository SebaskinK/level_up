# FINAL —— 场景流 / 视觉里程计 / 单帧建模 / 多帧建模：定稿交付

本目录是四条线的**代码 + 文档 + 最终结果**汇总（2026-09-23 打包）。
目的：一个目录看懂"我们做了什么、最后是怎么做的、结果是什么、还剩什么没做"。

| 目录 | 覆盖范围 | 原路径 |
|---|---|---|
| `01_scene_flow_vo/` | **场景流 + 视觉里程计**（同一套管线：DIS 稠密流 → 刚体 SE(3) 拟合 → 滑窗轨迹） | `/home/sti/Work/986-SceneFlow/` |
| `02_single_frame/` | **单帧建模**（单帧解析构造 hybrid surfel，已定稿为单文件） | `/home/sti/Work/985-3DGS/SINGLE FRAME/` |
| `03_multi_frame/` | **多帧建模**（逐帧增量融合 / 身份链 / 写色 / 足迹统一） | `/home/sti/Work/985-3DGS/SEQUENTIAL FRAMES/` |

每个目录下统一分三层：`code/`（可复现的代码）、`docs/`（权威文档）、`results/`（最终结果）。

---

## 1. 场景流 + 视觉里程计（`01_scene_flow_vo/`）

**是什么**：RGB-D 稠密场景流驱动相机运动估计。两步结构：① 受运动约束的 DIS 残差流（深度对齐位姿，
不是 Range Flow）；② 把流压到刚体上拟合 SE(3)，三帧滑窗积分成轨迹。稠密流是**第一输出**，
位姿是副产物——这是产品定义，文档里对"为什么不把 Range Flow 塞进匹配"有完整实验与结论。

- `code/`：12 个模块（`scene_flow.py` / `variational_flow.py` / `flow_io.py` = 流；
  `rigid_motion.py` / `expand_rigid_inliers.py` / `se3.py` / `sliding_window.py` / `tum_io.py` = 位姿与轨迹；
  `run_pipeline.py` / `eval_ate.py` / `plot_errors.py` / `analyze_rotation.py` = 驱动与评测）+ `requirements.txt`
- `docs/`：`README.md`（用法与模块说明）、`TECHNICAL_REPORT.md`（36 KB 技术报告：方法 / 消融 / 踩坑 / 讨论 / 展望）
- `results/output_final/`：200 帧（评测 199 对）的最终结果 —— `summary.json`、`trajectory.txt`、
  `frame_errors.csv`、`ate.png`、`vis/`

**最终数字（`results/output_final/summary.json`）**：平移误差中位 **3.99 mm** / 均值 5.40 mm；
旋转误差中位 **0.31°** / 均值 0.36°；内点率均值 **94.3%**；有效对应像素占比均值 55.9%。
（GT 本身的中位运动量：平移 16.4 mm、旋转 1.34°，可作尺度参照。）

**入口**：`docs/README.md` 的"快速开始"（`python run_pipeline.py` → `eval_ate.py` → `plot_errors.py`）。

---

## 2. 单帧建模（`02_single_frame/`）

**是什么**：从一帧 RGB-D 解析构造 hybrid surfel 模型（S2 均匀铺 + 曲率盘补结构），
**已定稿为单文件** `h_pipeline_final.py`（自包含、纯 Python/numpy，无 numba，~0.7 s/帧）。
不做训练、不做优化：位置/法线/半径都由几何推导，颜色取观测。

- `code/`：`h_pipeline_final.py`（**定稿**：唯一活动路径，自包含）、`rgbd_io.py`（数据 IO）、
  `metrics.py`（评测）、`exp_surfel_render.py`（EWA 表面溅射渲染器；名字带 `exp_` 但它被结果渲染调用，
  是交付用渲染器不是实验脚本）、`render_single_frame_frames.py`（**结果生成器**：对每一帧**独立**
  跑定稿管线（无跨帧状态），输出四张面板 + 合成图 + 逐帧 metrics）
- `docs/`：`RESEARCH.md`（41 KB：调研 + 推导 + 权威实验，**§4.5.2 是权威结果**）、
  `OPEN_ITEMS.md`（28 KB：缺口清单与决策记录）
- `results/`：**偶数帧 0,2,4,…,80（41 帧）的最终结果**，每帧一套
  `f{kk}_{ellipse,hard,ewa,depth_hard}.png` + `frame_{kk}_quad.png`，加一个 `metrics.json`
  （41 帧逐帧数字 + summary 的 mean/median/min/max）。生成命令：
  ```bash
  python code/render_single_frame_frames.py                    # = 前 81 帧（0–80）
  python code/render_single_frame_frames.py --frames 0,2,4,6   # 指定帧号子集（本目录即 0,2,…,80）
  ```
  **帧 0 复现 N=31,372，与文档 §C1 的定稿数字一致**；`metrics.json` 里的覆盖/空洞/RMSE/PSNR 是
  `H.evaluate` 口径，与文档 §C1 的 4.01 mm / 26.19 dB / 0.63% **有差**（N 相同 → 模型一致，
  差异在评测口径定义，见 `TODO.md` 跨线第 4 条）。

  41 帧的 summary（`metrics.json`）：覆盖 0.9743（0.9641–0.9843）、空洞 0.0257（0.0157–0.0359）、
  深度 RMSE 8.11 mm（5.08–14.25）、法线中位 4.66°（3.85–5.37）、颜色 PSNR 25.33 dB（23.22–27.50）、
  **N 32,693（30,717–34,454）**。注意这是**逐帧独立建模**（无跨帧），故指标随帧波动，
  不能与多帧线（有融合）的模型规模直接横比。

  规模：41 帧 = **80 MB**（每帧四张 PNG 面板 + 合成图）。想瘦身可只保留合成图（约减半）或改 JPG。

> 原 `SINGLE FRAME/output_*`（14 个实验臂目录）**未收录**：它们是实验/中间过程（本目录曾误收，已清掉），
> 留在原路径。定稿配置的权威数字以 `docs/RESEARCH.md` §4.5.2 / `docs/OPEN_ITEMS.md` §C1 为准。

---

## 3. 多帧建模（`03_multi_frame/`）

**是什么**：在单帧 hybrid 的基础上做**逐帧增量融合**——身份链（几何重投影 relink + 生产者/吸收）、
写色（center 采样 + 封顶 cap=200 + 颜色门 K=3）、足迹（**统一为精确解析椭圆**）、
以及本轮定稿的取舍。**不做全局优化、不做老化/删除**（老化是记录类待办）。

- `code/`：`h_pipeline_final.py`（单帧 builder，本线的副本）、`sequential_fusion_flowonly.py`
  （**多帧主循环**：`fuse_frame` = 身份链 / 吸收 / old-draw / S2 / 曲率 / 写色 / 几何更新）、
  `incremental_hybrid.py`（S2 与曲率分段构建）、`scene_flow_gated.py`（**采纳版场景流**：
  seed+扩张双几何门，夹角门 θ(kc)=max(16°, floor(kc)+57.2958·kc·10mm)）、
  `render_f0_images.py`（渲染驱动）、`exp_surfel_render.py`（EWA，与 02 同一份）
- `docs/`：`OPEN_ITEMS.md`（**174 KB 主记录**：§11 写色溯源、§13 flow 线、§14 overclaim 归因、
  §15 已改流水线、§16 待办盘点）、`RESEARCH.md`、`ARCHIVE_2026091{8,9}.md`、
  `DISC_MASK_REVERT_20260917.md`
- `results/output_frames_baseline_new/`：**新默认**在 9 个视角（0,10,…,80）的四张面板
  （ellipse / hard / EWA / depth）+ 2×2 合成图 + `frame_metrics.json` + `render_config.json`

**本线 2026-09-23 的定稿改动（已在代码里，非脚本 patch）**：

| 改动 | 效果（f80，同相机口径） |
|---|---|
| **统一足迹**：`rasterize_discs` = 分环批处理精确椭圆；relink 认领、S2/曲率新生认领全用它 | relink 认领"claimed, NOT drawn" 4.222% → **0.000%**；光栅器 **7.3 s → 0.64 s（11.9×）**，81 帧端到端 ~15 min → **~2.5 min** |
| **flow 继承（warp）关闭** | 它补的像素 80% 无根据；关闭后 overclaim 大幅下降 |
| **吸收1 不再登记 claim**（`register_owner=False`） | 纯记账（N/覆盖/PSNR 逐位不变），overclaim **1.234% → 0.307%** |
| **第二次吸收从代码删除** | overclaim −10%，N +2.0% |

**最终数字（新默认）**：模型 **N = 94,956**；f80 **overclaim 0.307% of valid**（旧默认 6.005%）；
f80 孔洞 3.803%（其中 **70% 是无深度支撑**）；f80 覆盖：模型自身相机 **96.197%**、
GT 位姿摆放 0.926。9 帧指标见 `results/.../frame_metrics.json`。

---

## 4. 未收录（按约定剔除）

1. **原始数据集**：`rgbd_dataset_freiburg1_desk/`（TUM fr1_desk）及其 `.tgz` —— 不复制。
2. **实验 / 诊断 / 原型脚本**：`exp_*`、`diag_*`、`proto_*` 等一次性脚本与它们的中间输出
   （`output_*` 里的 `.npy/.npz`、逐帧 scratch、逐臂对照目录）。例外：`exp_surfel_render.py`
   是交付用 EWA 渲染器（见 §2/§3），故收录。
3. **历史快照**：`scripts/backup/**`（含本轮所有改动的 `.PRE` 回滚点）——留在原路径，不复制。
   （回滚点位置见 `03_multi_frame/docs/OPEN_ITEMS.md` §15.1/§15.2。）
4. **中间产物**：`.npy` / `.npz` 一律不复制（结果目录里的深度图已保存为 `.png`）。

**运行依赖（重要）**：`03_multi_frame/code` 的多帧主循环会 `import` 986 的模块
（`scene_flow` / `rigid_motion` / `se3` / `tum_io` / `variational_flow` / `expand_rigid_inliers` 等），
它们是 `01_scene_flow_vo/code/` 的那一份（未在 03 里重复，避免两份漂移）。
跑 03 时把 `01_scene_flow_vo/code` 与本目录的 `03_multi_frame/code` 一起放进 `sys.path` 即可。

---

## 5. 三条评测口径（避免误读）

1. **多帧的 quad 用 GT 位姿摆放**，而模型建在 flow 轨迹上 → f80 两者差 1.858° / 8.17 cm
   （图上 7–33 px），使**覆盖被低估约 3.6 pp**。判"关联质量"应看 **overclaim / 画出覆盖率**，
   或用"flow 轨迹自洽摆放"的渲染。
2. **渲染 PSNR 被位姿漂移主导**（同一渲染从 21 dB 掉到 13 dB 量级），**不适合**作为关联质量的判据。
3. 单帧与多帧的模型**定义不同**（单帧 = 解析构造的 hybrid；多帧 = 逐帧增量融合后的结果），
   两边的 N / PSNR **不可直接横比**。

---

## 6. 待办

见同目录 **`TODO.md`**（四条线的待办汇总，按优先级排列）。