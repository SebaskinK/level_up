absorb merge rewrite (pre-change snapshot)

即将把 absorb_leftover_pixels 的合并段改写为与 update_hits_onepoint 一致的
批量合并：mu/normal/color 运行平均，scale 冻结。
