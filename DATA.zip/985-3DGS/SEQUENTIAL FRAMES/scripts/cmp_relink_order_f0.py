"""Diff the frame-0 hard ray-disc render across owner-association orders.

  NEW    : relink (whole footprint) runs FIRST on an empty owner map, then the
           flow chain fills what no disc projects onto.
  LEGACY : flow chain first, relink only tops up the pixels flow left empty.
  PREV   : the K6-default baseline from before the reorder.

Run:  python scripts/cmp_relink_order_f0.py
"""

from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np

SEQ = Path(__file__).resolve().parent
ROOT = SEQ.parent
NEW_DIR = ROOT / "output_f0_80frame_relinkorder"
LEG_DIR = ROOT / "output_f0_80frame_relinkorder_ab_flowfirst"
PREV_DIR = ROOT / "output_f0_80frame_K6_default"
BAR = 36


def caption_bar(img: np.ndarray, text: str, h_bar: int = 36) -> np.ndarray:
    w = img.shape[1]
    bar = np.full((h_bar, w, 3), 20, np.uint8)
    cv2.putText(bar, text, (8, h_bar - 10), cv2.FONT_HERSHEY_SIMPLEX,
                0.42, (235, 235, 235), 1, cv2.LINE_AA)
    return np.vstack([img, bar])


def load(p: Path) -> np.ndarray:
    im = cv2.imread(str(p))
    if im is None:
        raise FileNotFoundError(p)
    return im[:-BAR] if im.shape[0] > BAR else im


def band_stats(d: np.ndarray, x0: int, x1: int) -> str:
    s = d[:, x0:x1]
    return (f"x[{x0:3d},{x1:3d})  mean={s.mean():6.2f}  "
            f"px>10={100 * float((s > 10).mean()):5.2f}%  "
            f"px>30={100 * float((s > 30).mean()):5.2f}%  "
            f"px>60={100 * float((s > 60).mean()):5.2f}%")


def diff_heat(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    d = np.abs(a.astype(np.int16) - b.astype(np.int16)).max(axis=2).astype(np.uint8)
    heat = cv2.applyColorMap(d, cv2.COLORMAP_JET)
    heat[d < 8] = (18, 18, 18)
    return d, heat


def one(a_path, b_path, a_lbl, b_lbl, out_stem, title):
    a, b = load(a_path), load(b_path)
    h = min(a.shape[0], b.shape[0])
    w = min(a.shape[1], b.shape[1])
    a, b = a[:h, :w], b[:h, :w]
    d, heat = diff_heat(a, b)
    print(f"--- {title}")
    for x0, x1 in [(0, 64), (64, 128), (0, 128), (128, 256), (256, w)]:
        print("  " + band_stats(d, x0, x1))
    mont = np.hstack([a, b, heat])
    cap = (f"HARD RAY f0 | LEFT: {a_lbl} | MID: {b_lbl} | RIGHT: |diff| jet (dark<8) | "
           f"x<128 mean {d[:, :128].mean():.1f}, px>30 {100 * float((d[:, :128] > 30).mean()):.2f}%")
    cv2.imwrite(str(NEW_DIR / f"{out_stem}.png"), caption_bar(mont, cap))
    lz = np.vstack([a[:, :192], np.full((4, 192, 3), 200, np.uint8),
                    b[:, :192], np.full((4, 192, 3), 200, np.uint8), heat[:, :192]])
    lz = cv2.resize(lz, None, fx=2.0, fy=2.0, interpolation=cv2.INTER_NEAREST)
    cv2.imwrite(str(NEW_DIR / f"{out_stem}_leftzoom.png"), caption_bar(
        lz, f"LEFT x<192 zoom2x | TOP: {a_lbl} | MID: {b_lbl} | BOTTOM: |diff|", h_bar=30))
    for name, p in [(a_lbl, Path(a_path).parent / "f0_depth_hard.npy"),
                    (b_lbl, Path(b_path).parent / "f0_depth_hard.npy")]:
        dp = np.load(p)
        hit = dp > 0
        print(f"  hole {name}: all={1 - hit.mean():.4f} x<64={1 - hit[:, :64].mean():.4f} "
              f"x<128={1 - hit[:, :128].mean():.4f}")


def four_panel():
    names = [("f0_ellipse.png", "ELLIPSE", (0, 0, 255)),
             ("f0_hard.png", "HARD RAY", (0, 255, 0)),
             ("f0_ewa.png", "EWA", (255, 160, 0)),
             ("f0_depth_hard.png", "BACKPROJ DEPTH", (0, 255, 255))]
    ims = []
    for fn, lbl, col in names:
        im = load(NEW_DIR / fn)
        im = caption_bar(im, f"{lbl}  |  relink-first | 81-frame model -> frame-0")
        cv2.putText(im, "  ", (4, im.shape[0] - 8), cv2.FONT_HERSHEY_SIMPLEX, 0.5, col, 8)
        ims.append(im)
    top = np.hstack(ims[:2])
    bot = np.hstack(ims[2:])
    cv2.imwrite(str(NEW_DIR / "f0_four_panel.png"), np.vstack([top, bot]))
    print("saved ->", NEW_DIR / "f0_four_panel.png")


if __name__ == "__main__":
    one(NEW_DIR / "f0_hard.png", LEG_DIR / "f0_hard.png",
        "relink-first (NEW)", "flow-first (LEGACY)",
        "cmp_order_f0", "NEW vs LEGACY")
    one(NEW_DIR / "f0_hard.png", PREV_DIR / "f0_hard.png",
        "relink-first (NEW)", "K6 default (PREV)",
        "cmp_vs_prev_f0", "NEW vs PREV baseline")
    four_panel()