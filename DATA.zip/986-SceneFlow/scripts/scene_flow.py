"""Scene flow from RGB-D.

Motion constraints live here, not in the later pose-fit:
  * spatial: static scene ⇒ V is induced by one rigid twist ξ
  * temporal: constant twist (no IMU) ⇒ ξ_k / Δt_k ≈ ξ_{k-1} / Δt_{k-1}

DIS estimates residual flow around that prediction, not a free dense field.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import cv2
import numpy as np

from se3 import apply_point_motion, scale_twist, se3_exp, se3_log
from variational_flow import variational_flow_bidirectional


@dataclass
class SceneFlow:
    u: np.ndarray
    v: np.ndarray
    vz: np.ndarray
    X0: np.ndarray
    X1: np.ndarray
    valid: np.ndarray
    gray0: np.ndarray
    gray1: np.ndarray
    xi: np.ndarray | None = None  # point-motion twist, X1 = exp(ξ) X0
    expanded: np.ndarray | None = None  # geometrically filled, not FB-valid
    pred_u: np.ndarray | None = None
    pred_v: np.ndarray | None = None
    res_u: np.ndarray | None = None
    res_v: np.ndarray | None = None
    bw_u: np.ndarray | None = None
    bw_v: np.ndarray | None = None
    stats: dict = field(default_factory=dict)


_DIS_CACHE: cv2.DISOpticalFlow | None = None


def _dis() -> cv2.DISOpticalFlow:
    global _DIS_CACHE
    if _DIS_CACHE is None:
        of = cv2.DISOpticalFlow_create(cv2.DISOPTICAL_FLOW_PRESET_MEDIUM)
        of.setFinestScale(0)
        of.setUseMeanNormalization(True)
        of.setUseSpatialPropagation(True)
        _DIS_CACHE = of
    return _DIS_CACHE


def dense_flow(
    gray0: np.ndarray,
    gray1: np.ndarray,
    init: np.ndarray | None = None,
) -> np.ndarray:
    return _dis().calc(gray0, gray1, None if init is None else init.copy())


def dense_var_bidirectional(
    gray0: np.ndarray,
    gray1: np.ndarray,
    z0: np.ndarray,
    z1: np.ndarray,
    K: np.ndarray,
    lambda_depth: float = 5.0,
    lambda_sym: float = 0.5,
    init_fw: np.ndarray | None = None,
    init_bw: np.ndarray | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    """Spies Range Flow + brightness, forward and backward solved together."""
    fw, bw = variational_flow_bidirectional(
        gray0, gray1, z0, z1, K,
        lambda_depth=lambda_depth,
        lambda_sym=lambda_sym,
        levels=4,
        warp_iters=6,
        jacobi_iters=20,
        init_fw=init_fw,
        init_bw=init_bw,
    )
    return (
        np.stack([fw["u"], fw["v"]], axis=-1),
        np.stack([bw["u"], bw["v"]], axis=-1),
    )


def _grid(h: int, w: int) -> tuple[np.ndarray, np.ndarray]:
    return np.meshgrid(np.arange(w, dtype=np.float32), np.arange(h, dtype=np.float32))


def warp(img: np.ndarray, flow: np.ndarray, interpolation: int = cv2.INTER_LINEAR) -> np.ndarray:
    h, w = flow.shape[:2]
    xs, ys = _grid(h, w)
    return cv2.remap(
        img,
        xs + flow[..., 0],
        ys + flow[..., 1],
        interpolation=interpolation,
        borderMode=cv2.BORDER_CONSTANT,
        borderValue=0,
    )


def forward_backward_mask(
    flow_fw: np.ndarray,
    flow_bw: np.ndarray,
    thresh_px: float = 1.5,
) -> np.ndarray:
    h, w = flow_fw.shape[:2]
    xs, ys = _grid(h, w)
    x1 = xs + flow_fw[..., 0]
    y1 = ys + flow_fw[..., 1]
    bw = cv2.remap(flow_bw, x1, y1, interpolation=cv2.INTER_LINEAR, borderValue=0)
    cycle = np.sqrt((flow_fw[..., 0] + bw[..., 0]) ** 2 + (flow_fw[..., 1] + bw[..., 1]) ** 2)
    in_bounds = (x1 >= 0) & (x1 <= w - 1) & (y1 >= 0) & (y1 <= h - 1)
    return in_bounds & (cycle < thresh_px)


def backproject(z: np.ndarray, K: np.ndarray) -> np.ndarray:
    h, w = z.shape
    fx, fy, cx, cy = K[0, 0], K[1, 1], K[0, 2], K[1, 2]
    xs, ys = _grid(h, w)
    X = (xs - cx) * z / fx
    Y = (ys - cy) * z / fy
    return np.stack([X, Y, z], axis=-1)


def project_points(X: np.ndarray, K: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    fx, fy, cx, cy = K[0, 0], K[1, 1], K[0, 2], K[1, 2]
    z = np.clip(X[..., 2], 1e-6, None)
    x = fx * X[..., 0] / z + cx
    y = fy * X[..., 1] / z + cy
    return x.astype(np.float32), y.astype(np.float32)


def flow_from_twist(
    X0: np.ndarray,
    z0: np.ndarray,
    K: np.ndarray,
    xi: np.ndarray,
    z_min: float = 0.4,
) -> np.ndarray:
    h, w = z0.shape
    R, t = se3_exp(xi)
    X1 = apply_point_motion(X0, R, t)
    xs, ys = _grid(h, w)
    x1, y1 = project_points(X1, K)
    flow = np.stack([x1 - xs, y1 - ys], axis=-1)
    bad = (z0 < z_min) | (X1[..., 2] < z_min) | ~np.isfinite(flow).all(axis=-1)
    flow[bad] = 0.0
    return flow.astype(np.float32)


def warp_flow_forward(flow_prev: np.ndarray) -> np.ndarray:
    """Constant image-velocity: u_k(x+u_{k-1}) ≈ u_{k-1}(x)."""
    pred = np.zeros_like(flow_prev)
    pred[..., 0] = warp(flow_prev[..., 0], flow_prev)
    pred[..., 1] = warp(flow_prev[..., 1], flow_prev)
    return pred


def invert_twist(xi: np.ndarray) -> np.ndarray:
    R, t = se3_exp(xi)
    return se3_log(R.T, -R.T @ t)


def estimate_twist(
    X0: np.ndarray,
    X1: np.ndarray,
    xi_prior: np.ndarray | None = None,
    prior_w: float = 80.0,
) -> np.ndarray | None:
    if X0.shape[0] < 32:
        return None
    mu0 = X0.mean(axis=0)
    mu1 = X1.mean(axis=0)
    A = ((X1 - mu1).T @ (X0 - mu0)) / X0.shape[0]
    U, _, Vt = np.linalg.svd(A)
    S = np.eye(3)
    if np.linalg.det(U) * np.linalg.det(Vt) < 0:
        S[2, 2] = -1
    R = U @ S @ Vt
    t = mu1 - R @ mu0
    xi = se3_log(R, t)
    if xi_prior is not None:
        # prior_w is in "virtual point" units; keep it from vanishing on dense sets
        n = min(X0.shape[0], 400.0)
        w = prior_w / (n + prior_w)
        xi = (1.0 - w) * xi + w * xi_prior
    return xi


def rigid_projection_flow(
    X0_full: np.ndarray,
    z0: np.ndarray,
    X1_dis: np.ndarray,
    K: np.ndarray,
    valid: np.ndarray,
    xi_prior: np.ndarray | None = None,
    z_min: float = 0.4,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray] | None:
    """Project dense 3D correspondences onto SE(3), then regenerate the field.

    Clean counterpart to the DIS/model blend: fit one twist from the (already
    valid) 3D correspondences, then rebuild the whole flow field from that twist.
    The result is fully rigid-self-consistent (no per-pixel 0.55/0.08 mixing).
    Returns (u, v, X1, xi) or None when too few correspondences survive.
    """
    ys_i, xs_i = np.where(valid)
    if xs_i.size < 32:
        return None
    keep = (xs_i % 4 == 0) & (ys_i % 4 == 0)
    xi = estimate_twist(
        X0_full[ys_i[keep], xs_i[keep]],
        X1_dis[ys_i[keep], xs_i[keep]],
        xi_prior=xi_prior,
    )
    if xi is None:
        return None
    flow = flow_from_twist(X0_full, z0, K, xi, z_min=z_min)
    X1_model = apply_point_motion(X0_full, *se3_exp(xi))
    return flow[..., 0], flow[..., 1], X1_model, xi


def _points_from_flow(z0: np.ndarray, z1: np.ndarray, flow: np.ndarray, K: np.ndarray):
    z1w = warp(z1, flow, interpolation=cv2.INTER_NEAREST)
    X0 = backproject(z0, K)
    h, w = z0.shape
    xs, ys = _grid(h, w)
    fx, fy, cx, cy = K[0, 0], K[1, 1], K[0, 2], K[1, 2]
    x1 = xs + flow[..., 0]
    y1 = ys + flow[..., 1]
    X1 = np.stack(
        [(x1 - cx) * z1w / fx, (y1 - cy) * z1w / fy, z1w],
        axis=-1,
    )
    return X0, X1, z1w


def compute_scene_flow(
    bgr0: np.ndarray,
    bgr1: np.ndarray,
    z0: np.ndarray,
    z1: np.ndarray,
    K: np.ndarray,
    fb_thresh: float = 1.5,
    z_min: float = 0.4,
    z_max: float = 4.0,
    prev: SceneFlow | None = None,
    dt: float = 1.0,
    prev_dt: float = 1.0,
    motion_constraint: bool = True,
    compute_stats: bool = True,
    project_mode: bool = False,
    flow_backend: str = "dis",
    var_lambda: float = 5.0,
    var_sym: float = 0.5,
    expand_inliers: bool = True,
) -> SceneFlow:
    gray0 = cv2.cvtColor(bgr0, cv2.COLOR_BGR2GRAY)
    gray1 = cv2.cvtColor(bgr1, cv2.COLOR_BGR2GRAY)
    X0_full = backproject(z0, K)
    h, w = z0.shape
    zeros = np.zeros((h, w), dtype=np.float32)

    xi_prior = None
    pred = None
    if motion_constraint and prev is not None:
        if prev.xi is not None and prev_dt > 1e-6:
            xi_prior = scale_twist(prev.xi, dt / prev_dt)
            pred = flow_from_twist(X0_full, z0, K, xi_prior, z_min=z_min)
        else:
            pred = warp_flow_forward(np.stack([prev.u, prev.v], axis=-1))

    residual = None
    use_var = flow_backend == "var"

    if use_var:
        # DIS difference folded in: one joint (fw, bw) solve with invertibility.
        # Residual-add is a DIS trick (match leftover on a warped pair). Doing that
        # here puts residual_bw on the wrong grid and empties the FB gate.
        # SE(3) pred seeds the joint solve; the fields are the full flow.
        pred_bw = None
        if pred is not None:
            if xi_prior is not None:
                X1_prior = apply_point_motion(X0_full, *se3_exp(xi_prior))
                z1_pred = X1_prior[..., 2].astype(np.float32)
                pred_bw = flow_from_twist(
                    X1_prior, z1_pred, K, invert_twist(xi_prior), z_min=z_min
                )
            else:
                pred_bw = -pred
        flow_fw, flow_bw = dense_var_bidirectional(
            gray0, gray1, z0, z1, K,
            lambda_depth=var_lambda, lambda_sym=var_sym,
            init_fw=pred, init_bw=pred_bw,
        )
        residual = flow_fw - pred if pred is not None else np.zeros_like(flow_fw)
    elif pred is not None:
        gray1_w = warp(gray1, pred)
        z1_w = warp(z1, pred, interpolation=cv2.INTER_NEAREST)
        residual = dense_flow(gray0, gray1_w)
        flow_fw = pred + residual
        pred_bw = None
        if xi_prior is not None:
            X1_prior = apply_point_motion(X0_full, *se3_exp(xi_prior))
            z1_pred = X1_prior[..., 2].astype(np.float32)
            pred_bw = flow_from_twist(X1_prior, z1_pred, K, invert_twist(xi_prior), z_min=z_min)
        if pred_bw is None:
            pred_bw = -pred
        gray0_w = warp(gray0, pred_bw)
        z0_w = warp(z0, pred_bw, interpolation=cv2.INTER_NEAREST)
        residual_bw = dense_flow(gray1, gray0_w)
        flow_bw = pred_bw + residual_bw
    else:
        flow_fw = dense_flow(gray0, gray1)
        flow_bw = dense_flow(gray1, gray0)
        residual = np.zeros_like(flow_fw)

    fb = forward_backward_mask(flow_fw, flow_bw, thresh_px=fb_thresh)
    z1w = warp(z1, flow_fw, interpolation=cv2.INTER_NEAREST)
    xs, ys = _grid(h, w)
    fx, fy, cx, cy = K[0, 0], K[1, 1], K[0, 2], K[1, 2]
    x1 = xs + flow_fw[..., 0]
    y1 = ys + flow_fw[..., 1]
    X1_dis = np.stack(
        [(x1 - cx) * z1w / fx, (y1 - cy) * z1w / fy, z1w],
        axis=-1,
    )
    valid = (
        fb
        & (z0 > z_min)
        & (z0 < z_max)
        & (z1w > z_min)
        & (z1w < z_max)
    )

    xi = None
    ys_i, xs_i = np.where(valid)
    if xs_i.size > 0:
        keep = (xs_i % 4 == 0) & (ys_i % 4 == 0)
        xi = estimate_twist(
            X0_full[ys_i[keep], xs_i[keep]],
            X1_dis[ys_i[keep], xs_i[keep]],
            xi_prior=xi_prior if motion_constraint else None,
        )

    # Refine dense field with the updated rigid model (still inside scene flow).
    u = flow_fw[..., 0]
    v = flow_fw[..., 1]
    X1 = X1_dis
    flow_model = None
    if project_mode:
        # Clean projection: fit one twist, regenerate the whole field from it.
        # No per-pixel DIS/model blend; the field is rigid-self-consistent.
        proj = rigid_projection_flow(
            X0_full, z0, X1_dis, K, valid,
            xi_prior=xi_prior if motion_constraint else None,
            z_min=z_min,
        )
        if proj is not None:
            u, v, X1, xi = proj
            z1w = X1[..., 2]
            flow_model = np.stack([u, v], axis=-1)
            valid = (
                fb
                & (z0 > z_min)
                & (z0 < z_max)
                & (z1w > z_min)
                & (z1w < z_max)
            )
        else:
            # Too few correspondences: leave as DIS, no model.
            xi = None
    elif motion_constraint and xi is not None:
        flow_model = flow_from_twist(X0_full, z0, K, xi, z_min=z_min)
        X1_model = apply_point_motion(X0_full, *se3_exp(xi))
        delta = np.linalg.norm(flow_fw - flow_model, axis=-1)
        agree = valid & (delta < 3.0)
        alpha = np.where(agree, 0.55, 0.08).astype(np.float32)
        u = (1.0 - alpha) * flow_fw[..., 0] + alpha * flow_model[..., 0]
        v = (1.0 - alpha) * flow_fw[..., 1] + alpha * flow_model[..., 1]
        a3 = alpha[..., None]
        X1 = (1.0 - a3) * X1_dis + a3 * X1_model
        z1w = X1[..., 2]
        valid = (
            fb
            & (z0 > z_min)
            & (z0 < z_max)
            & (z1w > z_min)
            & (z1w < z_max)
        )

    uz = np.where(valid, X1[..., 2] - z0, 0.0)

    stats = {}
    if compute_stats:
        res_mag = np.linalg.norm(residual, axis=-1) if residual is not None else zeros
        flow_mag = np.sqrt(u * u + v * v)
        pred_mag = np.linalg.norm(pred, axis=-1) if pred is not None else zeros
        rigid_delta = zeros
        if flow_model is not None:
            rigid_delta = np.sqrt((u - flow_model[..., 0]) ** 2 + (v - flow_model[..., 1]) ** 2)
        photo = np.abs(
            gray0.astype(np.float32)
            - warp(gray1, np.stack([u, v], axis=-1)).astype(np.float32)
        )
        stats = {
            "flow_mag_mean": float(flow_mag[valid].mean()) if valid.any() else 0.0,
            "res_mag_mean": float(res_mag[valid].mean()) if valid.any() else 0.0,
            "pred_mag_mean": float(pred_mag[valid].mean()) if valid.any() and pred is not None else 0.0,
            "rigid_delta_mean": float(rigid_delta[valid].mean()) if valid.any() else 0.0,
            "photo_mean": float(photo[valid].mean()) if valid.any() else 0.0,
            "used_pred": int(pred is not None),
            "seed_frac": float(valid.mean()),
            "expanded_frac": 0.0,
        }

    sf = SceneFlow(
        u=u.astype(np.float32),
        v=v.astype(np.float32),
        vz=uz.astype(np.float32),
        X0=X0_full,
        X1=X1,
        valid=valid,
        gray0=gray0,
        gray1=gray1,
        xi=xi,
        pred_u=None if pred is None else pred[..., 0],
        pred_v=None if pred is None else pred[..., 1],
        res_u=None if residual is None else residual[..., 0],
        res_v=None if residual is None else residual[..., 1],
        bw_u=flow_bw[..., 0].astype(np.float32),
        bw_v=flow_bw[..., 1].astype(np.float32),
        stats=stats,
    )

    if expand_inliers and flow_backend != "var":
        from expand_rigid_inliers import expand_rigid_inliers
        ex = expand_rigid_inliers(sf, z0, z1, K, z_min=z_min, z_max=z_max)
        sf.u = ex.u
        sf.v = ex.v
        sf.X1 = ex.X1
        sf.valid = ex.valid
        sf.expanded = ex.expanded
        if ex.xi is not None:
            sf.xi = ex.xi
        sf.vz = np.where(ex.valid, ex.X1[..., 2] - z0, 0.0).astype(np.float32)
        if compute_stats:
            sf.stats["seed_frac"] = ex.n_seed / float(z0.size)
            sf.stats["expanded_frac"] = ex.n_added / float(z0.size)
            mag = np.sqrt(sf.u * sf.u + sf.v * sf.v)
            sf.stats["flow_mag_mean"] = float(mag[ex.valid].mean()) if ex.valid.any() else 0.0

    return sf
