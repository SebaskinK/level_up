"""Pure-GT control-variable fusion (A1): no 986 scene flow anywhere in identity.

Only build_hybrid (frame-0 geometry) and GT poses drive everything:
  * point motion X1 = R_10 X0 + t_10 comes from TUM ground truth
  * per-pixel flow (u,v) is the rigid flow regenerated from that GT twist
  * owner identity warps by that GT flow (forward + backward fill)
  * point-to-plane gate uses the GT-transformed model
  * colour frozen (pure GT tracks have no appearance guarantee, like 986 expanded)

Purpose: isolate whether the disc-count growth in output_N is pose drift or a
mechanism (frame-to-frame identity chain breaks on revisit -> re-layer).
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np

SEQ = Path(__file__).resolve().parent
SINGLE = SEQ.parent.parent / "SINGLE FRAME" / "scripts"
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SEQ))
sys.path.insert(0, str(SINGLE))
sys.path.insert(0, str(SFLOW))

import h_pipeline_final as H  # noqa: E402
from rigid_motion import depth_sigma, invert_point_motion  # noqa: E402
from scene_flow import flow_from_twist  # noqa: E402
from se3 import se3_log  # noqa: E402
from tum_io import (  # noqa: E402
    FR1_INTRINSICS,
    associate,
    interpolate_pose,
    load_groundtruth,
    relative_camera_motion,
    undistort_maps,
)

import sequential_fusion as SF  # noqa: E402
from sequential_fusion import Model, _subset, transform_to_next, owner_from_raster, point_to_plane, write_ply, load_pair, _draw_new  # noqa: E402

DATA = Path("/home/sti/Work/986-SceneFlow/rgbd_dataset_freiburg1_desk")
Z_MIN, Z_MAX = SF.Z_MIN, SF.Z_MAX
K_SIGMA = 3.0


def _fill_owner_backward_flow(owner_w, owner_src, bw_u, bw_v, valid_src):
    """Fill forward-miss cells from the rigid backward flow."""
    if bw_u is None:
        return owner_w
    h, w = owner_w.shape
    xs_g, ys_g = np.meshgrid(np.arange(w, dtype=np.float32), np.arange(h, dtype=np.float32))
    x0 = xs_g + bw_u
    y0 = ys_g + bw_v
    inb = (x0 >= 0) & (x0 <= w - 1) & (y0 >= 0) & (y0 <= h - 1)
    x0i = np.clip(np.rint(x0).astype(np.int32), 0, w - 1)
    y0i = np.clip(np.rint(y0).astype(np.int32), 0, h - 1)
    src_id = owner_src[y0i, x0i]
    src_ok = inb & (src_id >= 0) & valid_src[y0i, x0i]
    take = (owner_w < 0) & src_ok
    owner_w = owner_w.copy()
    owner_w[take] = src_id[take]
    return owner_w


def fuse_frame_gt(model, z0, z1, bgr1, K, R_10, t_10, age_max, w_min):
    h, w = z0.shape
    g = transform_to_next(model.g, R_10, t_10)
    n_old = len(g)
    w_conf = model.w.copy()
    age = model.age.copy() + 1

    X0 = H.backproject(z0, K)
    flow = flow_from_twist(X0, z0, K, se3_log(R_10, t_10), z_min=Z_MIN)
    u, v = flow[..., 0], flow[..., 1]
    valid0 = (z0 > Z_MIN) & (z0 < Z_MAX)

    # backward rigid flow (frame n+1 -> n) for the fill
    R_01, t_01 = invert_point_motion(R_10, t_10)
    X1_full = H.backproject(z1, K)
    flow_bw = flow_from_twist(X1_full, z1, K, se3_log(R_01, t_01), z_min=Z_MIN)

    owner_w = SF.warp_owner(model.owner, u, v, valid0)
    owner_w = _fill_owner_backward_flow(
        owner_w, model.owner, flow_bw[..., 0], flow_bw[..., 1], valid0
    )

    ys, xs = np.where((owner_w >= 0) & ((z1 > Z_MIN) & (z1 < Z_MAX)))
    n_upd = 0
    n_gate_fail = 0
    if xs.size:
        s_id = owner_w[ys, xs]
        live = (s_id >= 0) & (s_id < n_old)
        ys, xs, s_id = ys[live], xs[live], s_id[live]
        X1 = H.backproject(z1, K)[ys, xs]
        dist = point_to_plane(X1, g.mu[s_id], g.normal[s_id])
        sigma = depth_sigma(z1[ys, xs])
        ok = dist < (K_SIGMA * sigma)
        n_gate_fail = int((~ok).sum())
        ys, xs, s_id = ys[ok], xs[ok], s_id[ok]
        X1 = X1[ok]
        w_obs = (1.0 / np.maximum(sigma[ok] ** 2, 1e-8))
        n_upd = int(xs.size)
        if n_upd:
            sum_x = np.zeros((n_old, 3), dtype=np.float64)
            sum_wp = np.zeros(n_old, dtype=np.float64)
            np.add.at(sum_x, s_id, X1 * w_obs[:, None])
            np.add.at(sum_wp, s_id, w_obs)
            touched = sum_wp > 0
            den = w_conf[touched] + sum_wp[touched]
            g.mu[touched] = (
                (w_conf[touched, None] * g.mu[touched] + sum_x[touched]) / den[:, None]
            ).astype(np.float32)
            w_conf[touched] = den.astype(np.float32)
            age[touched] = 0

    owned = owner_w >= 0
    leftover = (z1 > Z_MIN) & (z1 < Z_MAX) & ~owned
    n_new = 0
    n_cand_new = 0
    n_hit_old = 0
    n_blocked = 0
    new_px = np.zeros((0, 2), np.int32)
    no_hit_old = np.zeros((h, w), dtype=bool)
    hit_blocked = np.zeros((h, w), dtype=bool)
    hit_pass = np.zeros((h, w), dtype=bool)
    if leftover.any():
        g_new, _, _ = H.build_hybrid(bgr1, z1, K, SF.TEX_Q)
        px = g_new.pixel
        on = leftover[px[:, 1], px[:, 0]]
        if on.any():
            g_new = _subset(g_new, on)
            n_cand_new = len(g_new)
            depth_m, index_m, _ = H.rasterize_discs(g, K, (h, w))
            keep_new = np.ones(len(g_new), dtype=bool)
            py, pxu = g_new.pixel[:, 1], g_new.pixel[:, 0]
            hit_old = index_m[py, pxu] >= 0
            n_hit_old = int(hit_old.sum())
            dist_old = np.full(len(g_new), np.inf)
            if hit_old.any():
                sid = index_m[py, pxu]
                X = H.backproject(z1, K)[py, pxu]
                dist_old = point_to_plane(X, g.mu[np.clip(sid, 0, n_old - 1)], g.normal[np.clip(sid, 0, n_old - 1)])
                sigma = depth_sigma(z1[py, pxu])
                keep_new[hit_old] = dist_old[hit_old] >= (K_SIGMA * sigma[hit_old])
                n_blocked = int((hit_old & ~keep_new).sum())
            no_hit_old[py[~hit_old], pxu[~hit_old]] = True
            hit_blocked[py[hit_old & ~keep_new], pxu[hit_old & ~keep_new]] = True
            hit_pass[py[hit_old & keep_new], pxu[hit_old & keep_new]] = True
            g_new = _subset(g_new, keep_new)
            n_new = len(g_new)
            new_px = g_new.pixel.copy() if n_new else np.zeros((0, 2), np.int32)
            if n_new:
                g = H.concatenate_gaussians([g, g_new])
                w_conf = np.concatenate([w_conf, np.ones(n_new, dtype=np.float32)])
                age = np.concatenate([age, np.zeros(n_new, dtype=np.int32)])

    dead = (age > age_max) & (w_conf < w_min)
    if dead.any() and (~dead).sum() >= 8:
        g = _subset(g, ~dead)
        w_conf = w_conf[~dead]
        age = age[~dead]

    owner = owner_from_raster(g, K, (h, w))
    model.g, model.w, model.age, model.owner = g, w_conf, age, owner
    return {
        "n": len(g),
        "n_upd": n_upd,
        "n_new": n_new,
        "n_gate_fail": n_gate_fail,
        "valid_frac": float(valid0.mean()),
        "expanded_frac": 0.0,
        "leftover_frac": float(leftover.mean()),
        "n_dead": int(dead.sum()) if dead.size else 0,
        "n_cand_new": n_cand_new,
        "n_hit_old": n_hit_old,
        "n_blocked": n_blocked,
        "no_hit_old": no_hit_old,
        "hit_blocked": hit_blocked,
        "hit_pass": hit_pass,
        "leftover": leftover,
        "new_px": new_px,
        "hit": owned,
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--max-pairs", type=int, default=80)
    p.add_argument("--out", default=str(SEQ.parent / "output_Q"))
    p.add_argument("--age-max", type=int, default=8)
    p.add_argument("--w-min", type=float, default=2.0)
    p.add_argument("--save-ply", action="store_true")
    p.add_argument("--save-vis", action="store_true", default=False)
    args = p.parse_args()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    vis_dir = out / "vis"
    if args.save_vis:
        vis_dir.mkdir(exist_ok=True)

    pairs = associate(DATA, max_dt=0.02)
    if args.max_pairs > 0:
        pairs = pairs[: args.max_pairs + 1]
    gt_ts, gt_t, gt_q = load_groundtruth(DATA / "groundtruth.txt")
    from tum_io import load_rgb
    h, w = load_rgb(pairs[0].rgb_path).shape[:2]
    map1, map2, K = undistort_maps((h, w), FR1_INTRINSICS)

    bgr0, z0, _ = load_pair(pairs, 0, map1, map2)
    g0, _, _ = H.build_hybrid(bgr0, z0, K, SF.TEX_Q)
    model = Model(
        g=g0,
        w=np.ones(len(g0), dtype=np.float32),
        age=np.zeros(len(g0), dtype=np.int32),
        owner=owner_from_raster(g0, K, (h, w)),
    )
    rows = [{"i": -1, "n": len(g0), "n_upd": 0, "n_new": len(g0),
             "n_gate_fail": 0, "valid_frac": 1.0, "expanded_frac": 0.0,
             "leftover_frac": 0.0, "n_dead": 0,
             "n_cand_new": 0, "n_hit_old": 0, "n_blocked": 0}]
    print(f"[init] N={len(g0)}", flush=True)

    bgr_a, z_a = bgr0, z0
    for i in range(len(pairs) - 1):
        bgr_b, z_b, _ = load_pair(pairs, i + 1, map1, map2)
        m0 = interpolate_pose(pairs[i].t_rgb, gt_ts, gt_t, gt_q)
        m1 = interpolate_pose(pairs[i + 1].t_rgb, gt_ts, gt_t, gt_q)
        if m0 is None or m1 is None:
            raise RuntimeError(f"GT pose out of range at pair {i}")
        R_eg, t_eg = relative_camera_motion(*m0, *m1)
        R_10, t_10 = invert_point_motion(R_eg, t_eg)
        rec = fuse_frame_gt(model, z_a, z_b, bgr_b, K, R_10, t_10,
                            args.age_max, args.w_min)
        rec["i"] = i
        if args.save_vis:
            cv2 = __import__("cv2")
            vis = _draw_new(bgr_b, rec["leftover"], rec["hit"], rec["new_px"], rec)
            cv2.imwrite(str(vis_dir / f"new_{i:04d}.png"), vis)
        rec.pop("leftover", None)
        rec.pop("no_hit_old", None)
        rec.pop("hit_blocked", None)
        rec.pop("hit_pass", None)
        rec.pop("new_px", None)
        rec.pop("hit", None)
        rows.append(rec)
        print(
            f"[{i:03d}] N={rec['n']} upd={rec['n_upd']} new={rec['n_new']} "
            f"(cand={rec['n_cand_new']} hit_old={rec['n_hit_old']} blocked={rec['n_blocked']}) "
            f"fail={rec['n_gate_fail']} valid={rec['valid_frac']:.2f} "
            f"exp={rec['expanded_frac']:.2f} left={rec['leftover_frac']:.2f} "
            f"dead={rec['n_dead']}",
            flush=True,
        )
        bgr_a, z_a = bgr_b, z_b

    keys = list(rows[0].keys())
    with (out / "fusion.csv").open("w", newline="") as f:
        wri = csv.DictWriter(f, fieldnames=keys)
        wri.writeheader()
        wri.writerows(rows)
    summary = {
        "n_frames": len(rows) - 1,
        "n_init": rows[0]["n"],
        "n_final": rows[-1]["n"],
        "n_upd_mean": float(np.mean([r["n_upd"] for r in rows[1:]])),
        "n_new_mean": float(np.mean([r["n_new"] for r in rows[1:]])),
    }
    (out / "summary.json").write_text(json.dumps(summary, indent=2))
    if args.save_ply:
        write_ply(out / "model.ply", model.g)
    print(json.dumps(summary, indent=2))
    print(f"wrote {out}")


if __name__ == "__main__":
    main()