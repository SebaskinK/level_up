"""Experiment J (EWA): same GT skip-5 novel view, rendered with EWA splatting.

Does not modify the default ray-disc path in exp_j_gt_skip5.py.
Defaults: sigma_extent=2.0, cov_scale=0.33 (finalized EWA档).
"""

from __future__ import annotations

import sys
import time
from pathlib import Path

import cv2
import numpy as np

HERE = Path(__file__).resolve().parent
SEQ_ROOT = HERE.parent
SINGLE_SCRIPTS = SEQ_ROOT.parent / "SINGLE FRAME" / "scripts"
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(SINGLE_SCRIPTS))
import h_pipeline_final as H  # noqa: E402
import exp_surfel_render as EWA  # noqa: E402
from exp_j_gt_skip5 import (  # noqa: E402
    SKIP, N_PAIRS, OUT, data_dir, parse_tum, pose_at, transform_gaussians,
    colorize_depth, colorize_diff_mm, label, shrink,
)

SIGMA_EXTENT = 2.0
COV_SCALE = 0.33


def main():
    dd = data_dir()
    pairs = H.associate(dd)
    gt = parse_tum(dd / "groundtruth.txt")
    map1, map2, K = H.undistort_maps((480, 640), H.FR1_INTRINSICS)
    OUT.mkdir(parents=True, exist_ok=True)

    rgb_rows = [[], [], [], []]
    dep_rows = [[], [], [], []]
    print(f"{'n':>4}{'tgt':>5}{'Ngs':>8}{'hit':>8}{'psnr':>8}{'rmse':>8}{'med':>8}",
          flush=True)

    for n in range(N_PAIRS):
        t = n + SKIP
        fr0, fr1 = pairs[n], pairs[t]
        bgr0 = H.remap_rgb(H.load_rgb(fr0.rgb_path), map1, map2)
        z0 = H.remap_depth(H.load_depth(fr0.depth_path), map1, map2)
        bgr1 = H.remap_rgb(H.load_rgb(fr1.rgb_path), map1, map2)
        z1 = H.remap_depth(H.load_depth(fr1.depth_path), map1, map2)

        t0 = time.perf_counter()
        g, _, _ = H.build_hybrid(bgr0, z0, K, 0.6)
        dt_build = time.perf_counter() - t0

        M0, _ = pose_at(gt, fr0.t_rgb)
        M1, _ = pose_at(gt, fr1.t_rgb)
        Mrel = np.linalg.inv(M1) @ M0
        gt_g = transform_gaussians(g, Mrel)

        t1 = time.perf_counter()
        color, depth, weight = EWA.render_ewa(
            gt_g, K, (480, 640),
            sigma_extent=SIGMA_EXTENT, mode="normalized", cov_scale=COV_SCALE,
        )
        dt_ewa = time.perf_counter() - t1

        hit = weight > 0
        render = np.zeros((480, 640, 3), dtype=np.uint8)
        render[hit] = (np.clip(color[hit][:, ::-1], 0.0, 1.0) * 255.0).astype(np.uint8)

        err_rgb = color - (bgr1.astype(np.float32) / 255.0)[:, :, ::-1]
        psnr = -20.0 * np.log10(np.sqrt(np.mean(err_rgb[hit] ** 2)) + 1e-12)

        hit_d = np.isfinite(depth)
        m = hit_d & H.depth_valid(z1)
        err_d = (depth[m] - z1[m]) * 1000.0
        rmse = float(np.sqrt(np.mean(err_d ** 2))) if m.any() else float("nan")
        med = float(np.median(np.abs(err_d))) if m.any() else float("nan")
        print(f"{n:>4}{t:>5}{len(g):>8}{hit.mean():>8.3f}{psnr:>8.2f}"
              f"{rmse:>8.1f}{med:>8.1f}  build={dt_build:.1f}s ewa={dt_ewa:.1f}s",
              flush=True)

        rgb_rows[0].append(label(bgr0, f"frame {n} rgb"))
        rgb_rows[1].append(label(bgr1, f"frame {t} rgb"))
        rgb_rows[2].append(label(render, f"EWA f{n}->f{t}"))
        rgb_rows[3].append(label(cv2.absdiff(render, bgr1), f"diff PSNR={psnr:.1f}"))

        v0, v1 = H.depth_valid(z0), H.depth_valid(z1)
        dep_rows[0].append(label(colorize_depth(z0, v0), f"frame {n} depth"))
        dep_rows[1].append(label(colorize_depth(z1, v1), f"frame {t} depth"))
        dep_rows[2].append(label(colorize_depth(depth, hit_d), f"EWA f{n}->f{t} depth"))
        diff = np.abs(depth - z1) * 1000.0
        dep_rows[3].append(label(colorize_diff_mm(diff, m), f"|diff|mm RMSE={rmse:.1f}"))

        if n == 0:
            cv2.imwrite(str(OUT / "f0_to_f5_ewa_rgb.png"), render)
            cv2.imwrite(str(OUT / "f0_to_f5_ewa_depth.png"), colorize_depth(depth, hit_d))

    rgb_panel = np.vstack([np.hstack(r) for r in rgb_rows])
    dep_panel = np.vstack([np.hstack(r) for r in dep_rows])
    cv2.imwrite(str(OUT / "novelview_rgb_skip5_ewa.png"), rgb_panel)
    cv2.imwrite(str(OUT / "novelview_depth_skip5_ewa.png"), dep_panel)
    cv2.imwrite(str(OUT / "novelview_rgb_skip5_ewa_small.png"), shrink(rgb_panel))
    cv2.imwrite(str(OUT / "novelview_depth_skip5_ewa_small.png"), shrink(dep_panel))
    print(f"wrote {OUT}", flush=True)


if __name__ == "__main__":
    main()
