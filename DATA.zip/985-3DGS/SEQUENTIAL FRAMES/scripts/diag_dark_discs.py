"""Trace the near-black discs that render as vertical stripes in the gray strip.

The user's 'vertical stripe holes' are NOT coverage holes (depth>0) but pixels
covered by discs whose colour is near-black. This script re-rasterizes the final
frame-0 model, finds the disc covering each such dark pixel, and reports its
birth frame / isotropic(S2) vs curvature / colour, plus their column pattern.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

SEQ = Path(__file__).resolve().parent
SINGLE = SEQ.parent.parent / "SINGLE FRAME" / "scripts"
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SFLOW))
sys.path.insert(0, str(SINGLE))
sys.path.insert(0, str(SEQ))

import h_pipeline_final as H            # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402

OUT = SEQ.parent / "output_discmask_align"


def tangent_basis(n):
    n = n.astype(np.float64)
    n = n / np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-12)
    ref = np.tile(np.array([0.0, 0.0, 1.0]), (n.shape[0], 1))
    ref[np.abs(n[:, 2]) > 0.9] = np.array([1.0, 0.0, 0.0])
    t1 = np.cross(ref, n)
    t1 = t1 / np.maximum(np.linalg.norm(t1, axis=1, keepdims=True), 1e-12)
    t2 = np.cross(n, t1)
    return t1, t2


def main() -> None:
    d = np.load(OUT / "model_f0.npz")
    mu = d["mu"].astype(np.float32)
    normal = d["normal"].astype(np.float32)
    scale = d["scale"].astype(np.float32)
    color = d["color"].astype(np.float32)
    birth = d["birth"]
    t1, t2 = tangent_basis(normal)
    g = H.Gaussians(
        mu=mu, normal=normal, scale=scale,
        quat=H._quat_from_frame(t1.astype(np.float32), t2.astype(np.float32), normal),
        color=color, alpha=None,
        pixel=np.zeros((len(mu), 2), np.int32), axis1=t1.astype(np.float32), axis2=t2.astype(np.float32),
    )

    pairs = SF.associate(SF.DATA, max_dt=0.02)[: 11]
    sm = SF.load_rgb(pairs[0].rgb_path); h, w = sm.shape[:2]
    m1, m2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)
    bgr0, z0, _ = SF.load_pair(pairs, 0, m1, m2)
    valid = (z0 > SF.Z_MIN) & (z0 < SF.Z_MAX)

    depth, index, _ = H.rasterize_discs(g, K, (h, w))
    covered = np.isfinite(depth) & valid
    # dark-covered: covered (depth>0) but rendered colour near-black
    cmax = color.max(axis=1) if False else None
    lum = g0_color_lum = None
    # per-pixel colour of covering disc
    idx = index.astype(np.int64)
    pix_rgb = np.zeros((h, w, 3), np.float32)
    m = np.isfinite(depth) & valid
    pix_rgb[m] = color[idx[m]]
    dark = m & (pix_rgb.sum(axis=2) < 0.05)  # near-black covered pixel
    print(f"covered(valid)={covered.sum()}  dark-covered={dark.sum()}")

    band = (np.arange(h)[:, None] >= 32) & (np.arange(h)[:, None] < 426)
    dark_band = dark & band
    print(f"dark-covered in band rows[32,426]: {dark_band.sum()}")

    # covering disc identity for dark pixels (right half)
    ids = idx[dark & band & (np.arange(w)[None, :] >= w // 2)]
    if ids.size:
        u, c = np.unique(ids, return_counts=True)
        b = birth[u]
        csum = color[u].sum(axis=1)
        iso = np.abs(scale[u, 0] - scale[u, 1]) < 1e-6 * np.maximum(scale[u, 0], 1e-9)
        print(f"\nunique dark-pixel covering discs: {u.size}")
        print(f"birth hist: {np.bincount(b, minlength=12).tolist()}")
        print(f"iso(S2) frac: {iso.mean():.3f}")
        print(f"disc colour sum: min={csum.min():.3f} med={np.median(csum):.3f} "
              f"max={csum.max():.3f}")
        print(f"disc colour mean RGB: {color[u].mean(axis=0).round(3)}")
        # top discs by pixel count (the biggest vertical stripes)
        order = np.argsort(-c)
        print("top 12 dark discs by pixel-count (birth, iso, colour BGR, npix):")
        for ii in order[:12]:
            print(f"  disc {u[ii]}: birth={b[ii]} iso={iso[ii]} "
                  f"color=({color[u[ii]][2]:.3f},{color[u[ii]][1]:.3f},{color[u[ii]][0]:.3f}) "
                  f"npix={c[ii]}")

    # column pattern of dark pixels (right half, band) -> vertical stripes
    ys, xs = np.nonzero(dark_band & (np.arange(w)[None, :] >= w // 2))
    if xs.size:
        ch = np.bincount(xs, minlength=w)
        nz = np.flatnonzero(ch > 0)
        print(f"\ndark-pixel column hist (right half): cols [{nz.min()},{nz.max()}] "
              f"max_per_col={ch[nz].max()}")
        # strongest columns
        top = np.argsort(-ch[nz])[:15]
        print("top 15 darkest columns:")
        for c in nz[top]:
            print(f"  col {c}: {ch[c]} dark px")


if __name__ == "__main__":
    main()