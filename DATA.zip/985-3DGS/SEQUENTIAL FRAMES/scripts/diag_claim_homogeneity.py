"""Single-frame claim-interior homogeneity diagnostic.

For every emitted curvature disc (frame 0, fr1/desk), take its *0.6-overlap*
claim ellipse -- the same footprint `select_curvature_seeds` uses for seed
spacing, i.e. semi-axes = 0.6 x emitted r1/r2 projected through the first-order
Jacobian. Then measure, over all pixels inside that small ellipse, how far each
pixel's attribute (depth, normal, colour) is from the disc CENTRE's attribute.

This directly tests the "the disc is decided by its centre pixel" assumption:
if the interior is flat / self-similar, centre == region and single-point update
is safe; if the interior differs a lot, centre-only loses real information.

Only curvature discs are tested (S2 discs have no 0.6 claim circle -- they own
a 2x2 cell). Curvature radii clipped exactly as in `_curv_radii_clip`.
"""

from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np

import h_pipeline_final as H

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent
DATA_DIR = ROOT.parent.parent.parent / "986-SceneFlow" / "rgbd_dataset_freiburg1_desk"

OVERLAP = 0.6          # the claim spacing used in seed selection
TEX_QUANTILE = 0.6
TEX_TOL_PX = 4.5
FLOOR_SCALE = np.sqrt(2.0)


def hist_stats(hist: np.ndarray, edges: np.ndarray) -> dict:
    c = np.cumsum(hist)
    tot = c[-1]
    centers = 0.5 * (edges[:-1] + edges[1:])
    if tot <= 0:
        return {}
    mean = float(np.sum(hist * centers) / tot)

    def q(p: float) -> float:
        idx = int(np.searchsorted(c, p * tot))
        return float(centers[min(idx, len(centers) - 1)])

    return {"mean": mean, "p50": q(0.5), "p90": q(0.9), "p95": q(0.95), "p99": q(0.99)}


def to_heat(img: np.ndarray) -> np.ndarray:
    img = np.nan_to_num(img, nan=0.0, posinf=0.0, neginf=0.0)
    vmax = float(np.percentile(img[img > 0] if (img > 0).any() else img, 98))
    vmax = max(vmax, 1e-6)
    u8 = np.clip(img / vmax * 255.0, 0, 255).astype(np.uint8)
    return cv2.applyColorMap(u8, cv2.COLORMAP_TURBO)


def main() -> None:
    pairs = H.associate(DATA_DIR)
    fr = pairs[0]
    map1, map2, K = H.undistort_maps((480, 640), H.FR1_INTRINSICS)
    bgr = H.remap_rgb(H.load_rgb(fr.rgb_path), map1, map2)
    z = H.remap_depth(H.load_depth(fr.depth_path), map1, map2)
    z[z < H.GEO_CFG["z_min"]] = 0.0
    z[z > H.GEO_CFG["z_max"]] = 0.0

    h, w = z.shape
    geo = H.compute_scene_geometry(z, K, H.GEO_CFG["eps"], H.GEO_CFG["gauss_sigma"],
                                   H.GEO_CFG["disc_rel"])
    rgb = (bgr.astype(np.float32)[..., ::-1]) / 255.0
    tex_mask = H.texture_mask(rgb, TEX_QUANTILE)
    r_cap = H.tex_boundary_limit(z, K, tex_mask, tol_px=TEX_TOL_PX) if TEX_TOL_PX > 0 else None

    keep_geo = H.select_curvature_seeds(
        z, K, H.GEO_CFG["eps"], H.GEO_CFG["gauss_sigma"], H.GEO_CFG["z_min"],
        H.GEO_CFG["z_max"], H.GEO_CFG["disc_rel"], OVERLAP, H.GEO_CFG["r_max"],
        edge_fallback_fp=True, r_cap=r_cap, geo=geo, floor_scale=FLOOR_SCALE,
    )
    keep_geo = keep_geo & ~tex_mask

    ys, xs = np.where(keep_geo)
    N = int(ys.size)
    if N == 0:
        print("no curvature discs")
        return

    r1, r2 = H._curv_radii_clip(geo, ys, xs, r_cap, FLOOR_SCALE)
    e1, e2 = H.claim_footprint(z, K, ys, xs, r1, r2, OVERLAP, geo)

    YY, XX = np.meshgrid(np.arange(h), np.arange(w), indexing="ij")
    valid_z = z > 1e-6
    n_ok = geo.n_ok

    mean_dz_rel = np.zeros(N, np.float32)
    mean_dz_mm = np.zeros(N, np.float32)
    mean_ang = np.zeros(N, np.float32)
    mean_col = np.zeros(N, np.float32)
    n_in = np.zeros(N, np.int64)

    bins_dz = np.linspace(0.0, 0.2, 401)
    bins_ang = np.linspace(0.0, 90.0, 181)
    bins_col = np.linspace(0.0, 1.0, 201)
    hist_dz = np.zeros(len(bins_dz) - 1, np.float64)
    hist_ang = np.zeros(len(bins_ang) - 1, np.float64)
    hist_col = np.zeros(len(bins_col) - 1, np.float64)

    det = e1[:, 0] * e2[:, 1] - e2[:, 0] * e1[:, 1]
    for i in range(N):
        y, x = int(ys[i]), int(xs[i])
        if abs(det[i]) < 1e-12:
            continue
        bx = max(int(np.ceil(np.hypot(e1[i, 0], e2[i, 0]))), 0)
        by = max(int(np.ceil(np.hypot(e1[i, 1], e2[i, 1]))), 0)
        y0, y1 = max(y - by, 0), min(y + by + 1, h)
        x0, x1 = max(x - bx, 0), min(x + bx + 1, w)
        if x0 >= x1 or y0 >= y1:
            continue
        px = XX[y0:y1, x0:x1] - x
        py = YY[y0:y1, x0:x1] - y
        c0 = (e2[i, 1] * px - e2[i, 0] * py) / det[i]
        c1 = (-e1[i, 1] * px + e1[i, 0] * py) / det[i]
        mz = (c0 * c0 + c1 * c1 <= 1.0) & valid_z[y0:y1, x0:x1]
        mzf = mz.ravel()
        if not mzf.any():
            continue
        zc = float(z[y, x])
        zp = z[y0:y1, x0:x1].ravel()[mzf].astype(np.float64)
        dz = np.abs(zp - zc)
        dz_rel = dz / max(zc, 1e-6)

        cc = rgb[y, x].astype(np.float64)
        cpx = rgb[y0:y1, x0:x1].reshape(-1, 3)[mzf].astype(np.float64)
        col = np.linalg.norm(cpx - cc, axis=1)

        ang = np.zeros(int(mzf.sum()), np.float64)
        mnf = mzf & n_ok[y0:y1, x0:x1].ravel()
        if mnf.any():
            ncor = geo.normal[y, x].astype(np.float64)
            ncor = ncor / (np.linalg.norm(ncor) + 1e-12)
            npix = geo.normal[y0:y1, x0:x1].reshape(-1, 3)[mnf].astype(np.float64)
            dot = np.abs(np.einsum("ij,j->i", npix, ncor))
            rank = np.cumsum(mzf) - 1
            ang[rank[mnf]] = np.degrees(np.arccos(np.clip(dot, -1.0, 1.0)))

        n_in[i] = int(mzf.sum())
        mean_dz_rel[i] = float(dz_rel.mean())
        mean_dz_mm[i] = float((dz * 1000.0).mean())
        mean_ang[i] = float(ang.mean())
        mean_col[i] = float(col.mean())
        hist_dz += np.histogram(np.minimum(dz_rel, 0.2), bins_dz)[0]
        hist_ang += np.histogram(ang, bins_ang)[0]
        hist_col += np.histogram(np.minimum(col, 1.0), bins_col)[0]

    dz_s = hist_stats(hist_dz, bins_dz)
    ang_s = hist_stats(hist_ang, bins_ang)
    col_s = hist_stats(hist_col, bins_col)

    # per-disc mean distributions (a few bad discs must not dominate the headline)
    def pd(arr):
        live = arr[n_in > 0]
        if live.size == 0:
            return {}
        return {"mean": float(live.mean()), "p50": float(np.median(live)),
                "p90": float(np.percentile(live, 90)),
                "p95": float(np.percentile(live, 95))}

    dz_pd = pd(mean_dz_rel)
    dmm_pd = pd(mean_dz_mm)
    ang_pd = pd(mean_ang)
    col_pd = pd(mean_col)

    print(f"N_curv={N}  N_px_in_0.6claim={int(n_in.sum())}  "
          f"mean_px_per_claim={float(n_in.mean()):.1f}")
    print(f"[pixel-level] depth rel |dz|/z : {dz_s}")
    print(f"[pixel-level] normal ang deg  : {ang_s}")
    print(f"[pixel-level] colour |dRGB|   : {col_s}")
    print(f"[per-disc   ] depth rel        : {dz_pd}")
    print(f"[per-disc   ] depth |dz| mm    : {dmm_pd}")
    print(f"[per-disc   ] normal ang deg   : {ang_pd}")
    print(f"[per-disc   ] colour |dRGB|    : {col_pd}")

    # ---- visualization: greedy 0.6-claim owner painted by per-disc mean error
    owner = H.claim_owner(ys, xs, e1, e2, (h, w))
    owned = owner >= 0
    out = BASE / "output_claim_homogeneity"
    out.mkdir(parents=True, exist_ok=True)

    def paint(vals_fn):
        m = np.full((h, w), np.nan, np.float32)
        ids = owner[owned]
        m[owned] = vals_fn(ids)
        return m

    im_dz = to_heat(paint(lambda i: mean_dz_rel[i]))
    im_ang = to_heat(paint(lambda i: mean_ang[i]))
    im_col = to_heat(paint(lambda i: mean_col[i]))

    def bar(text, width):
        b = np.full((34, width, 3), 30, np.uint8)
        cv2.putText(b, text, (8, 23), cv2.FONT_HERSHEY_SIMPLEX, 0.42,
                    (225, 225, 225), 1, cv2.LINE_AA)
        return b

    caption = (f"0.6-claim interior homogeneity (per-disc mean). "
               f"depth p50={dz_pd.get('p50', 0):.2e} p90={dz_pd.get('p90', 0):.2e}; "
               f"normal p50={ang_pd.get('p50', 0):.2f} p90={ang_pd.get('p90', 0):.2f} deg; "
               f"colour p50={col_pd.get('p50', 0):.3f} p90={col_pd.get('p90', 0):.3f}")
    cv2.imwrite(str(out / "depth_rel.png"), np.vstack([im_dz, bar("depth |dz|/z", w)]))
    cv2.imwrite(str(out / "normal_ang.png"), np.vstack([im_ang, bar("normal ang deg", w)]))
    cv2.imwrite(str(out / "color_l2.png"), np.vstack([im_col, bar("colour |dRGB|", w)]))
    b = bar(caption, w)
    cv2.imwrite(str(out / "cmp.png"), np.vstack([b, im_dz, im_ang, im_col]))
    print(f"saved -> {out}")


if __name__ == "__main__":
    main()