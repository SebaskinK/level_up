"""Track absorb-driven disc growth across the 10-frame run.

Method: run the fusion with the age-prune disabled (so disc indices are stable,
no remap; new discs only append). Each frame, diff the OLD discs' `scale` --
only the absorb branch mutates an existing disc's scale (the hit branch updates
mu/color only, new discs only append), so `post_scale != pre_scale` on an old
disc index == that disc was absorb-nudged this frame.

Reports:
  * per frame: # absorbed pixels, # old discs nudged, their radius growth
  * growth magnitude: equivalent footprint radius (max(r1,r2)) in mm and px
  * split: frame-0 initial discs vs later-born discs
  * cumulative: a disc tracked from birth, total growth after all absorbs
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

SEQ = Path(__file__).resolve().parent
SINGLE = SEQ.parent.parent / "SINGLE FRAME" / "scripts"
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SINGLE))
sys.path.insert(0, str(SFLOW))

import h_pipeline_final as H  # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402


def radius(g, ids=None):
    """Footprint radius = max(r1, r2), the quantity rasterize_discs uses."""
    r = np.maximum(g.scale[:, 0], g.scale[:, 1])
    if ids is not None:
        return r[ids]
    return r


def main() -> None:
    pairs = SF.associate(SF.DATA, max_dt=0.02)[:11]
    sample = SF.load_rgb(pairs[0].rgb_path)
    h, w = sample.shape[:2]
    map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)
    f_mean = 0.5 * (K[0, 0] + K[1, 1])

    bgr0, z0, _ = SF.load_pair(pairs, 0, map1, map2)
    g0, _, _ = H.build_hybrid(bgr0, z0, K, SF.TEX_Q)
    model = SF.Model(
        g=g0, w=np.ones(len(g0), dtype=np.float32),
        age=np.zeros(len(g0), dtype=np.int32),
        owner=SF.owner_from_raster(g0, K, (h, w)),
        birth=np.zeros(len(g0), dtype=np.int32),
        cnt=np.ones(len(g0), dtype=np.float32),
    )
    n_init = len(g0)

    # per-frame records
    rows = []
    prev_sf = None
    prev_dt = 1.0
    bgr_a, z_a = bgr0, z0
    for i in range(len(pairs) - 1):
        bgr_b, z_b, _ = SF.load_pair(pairs, i + 1, map1, map2)
        dt = pairs[i + 1].t_rgb - pairs[i].t_rgb
        sf = SF.compute_scene_flow(bgr_a, bgr_b, z_a, z_b, K,
                                   prev=prev_sf, dt=dt, prev_dt=prev_dt)
        R_10, t_10 = SF.se3_exp(sf.xi)

        n_pre = len(model.g)
        pre_scale = model.g.scale.copy()
        pre_r = radius(model.g)

        rec = SF.fuse_frame(model, sf, z_a, z_b, bgr_b, K,
                            age_max=10**6, w_min=2.0, frame_idx=i,
                            R_10=R_10, t_10=t_10)

        post_scale = model.g.scale[:n_pre]           # no remap, old discs only
        post_r = radius(model.g)[:n_pre]
        grown = np.where(np.any(post_scale != pre_scale, axis=1))[0]

        if grown.size:
            gr_before = pre_r[grown] * 1000.0               # mm
            gr_after = post_r[grown] * 1000.0
            gr_delta = gr_after - gr_before
            zc = np.maximum(model.g.mu[grown, 2], 1e-6)
            px_before = pre_r[grown] * f_mean / zc
            px_after = post_r[grown] * f_mean / zc
            is_init = grown < n_init
        else:
            gr_before = gr_after = gr_delta = np.array([])
            px_before = px_after = np.array([])
            is_init = np.array([], dtype=bool)

        rows.append({
            "frame": i,
            "n_old": n_pre,
            "n_absorb_px": rec["n_absorb"],
            "n_grown": int(grown.size),
            "n_grown_init": int(is_init.sum()),
            "grow_med_mm": float(np.median(gr_delta)) if grown.size else 0.0,
            "grow_p90_mm": float(np.percentile(gr_delta, 90)) if grown.size else 0.0,
            "grow_max_mm": float(gr_delta.max()) if grown.size else 0.0,
            "r_med_before_mm": float(np.median(gr_before)) if grown.size else 0.0,
            "r_med_after_mm": float(np.median(gr_after)) if grown.size else 0.0,
            "px_med_before": float(np.median(px_before)) if grown.size else 0.0,
            "px_med_after": float(np.median(px_after)) if grown.size else 0.0,
        })
        print(f"[f{i}] absorb_px={rec['n_absorb']:5d} grown={int(grown.size):5d} "
              f"(init {int(is_init.sum())})  "
              f"r_med {rows[-1]['r_med_before_mm']:.1f}->{rows[-1]['r_med_after_mm']:.1f} mm  "
              f"(+{rows[-1]['grow_med_mm']:.2f} mm med, +{rows[-1]['grow_max_mm']:.2f} max)  "
              f"px {rows[-1]['px_med_before']:.1f}->{rows[-1]['px_med_after']:.1f}",
              flush=True)

        bgr_a, z_a = bgr_b, z_b
        prev_sf, prev_dt = sf, dt

    # ---- summary ----
    print("\n=== per-frame absorb growth ===")
    print(f"{'f':>2} {'absorb_px':>9} {'grown':>6} {'init':>5} "
          f"{'r_med_bf':>9} {'r_med_af':>9} {'grow_med':>8} {'grow_p90':>8} "
          f"{'grow_max':>8} {'px_bf':>6} {'px_af':>6}")
    for r in rows:
        print(f"{r['frame']:>2} {r['n_absorb_px']:>9} {r['n_grown']:>6} "
              f"{r['n_grown_init']:>5} {r['r_med_before_mm']:>9.1f} {r['r_med_after_mm']:>9.1f} "
              f"{r['grow_med_mm']:>8.2f} {r['grow_p90_mm']:>8.2f} {r['grow_max_mm']:>8.2f} "
              f"{r['px_med_before']:>6.1f} {r['px_med_after']:>6.1f}")

    tot_grown = sum(r["n_grown"] for r in rows)
    tot_absorb_px = sum(r["n_absorb_px"] for r in rows)
    print(f"\ntotal: absorb_px={tot_absorb_px}  disc-nudge events={tot_grown}  "
          f"avg {tot_absorb_px/max(tot_grown,1):.1f} px per nudge")

if __name__ == "__main__":
    main()