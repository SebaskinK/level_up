# disc_mask 回退记录（2026-09-17）

**结论一句话**：把 4 处 `disc_mask` 全部回退到旧的 `depth_discontinuity_mask`，同时**保留**
`edge_distance_limit` 继续用新的 `depth_jump_mask`；关老化的 10 帧增量结果正好命中
`n_init=30238 / n_final=42210`。

---

## 1. 最终结果

运行 `sequential_fusion_flowonly.py`（`--max-pairs 10 --age-max 1000000 --w-min 0`，
黑边填充与 absorb 默认开），目录 `output_f0_10frame_fix`：

| 指标 | 值 |
| --- | --- |
| n_init（帧 0 单帧建盘） | **30238** ✓ |
| n_final（10 帧增量） | **42210** ✓（正好等于目标） |
| 老化剪枝 | 关（`age_max=1e6, w_min=0`，每帧 `n_dead=0`） |
| 黑边填充（edge_fallback_fp） | 开 |
| absorb_leftover_pixels | 开 |
| 逐帧轨迹 | 30238 → 31649 → 32533 → 33722 → 35079 → 36424 → 37556 → 38713 → 39804 → 41019 → 42210 |
| n_upd_mean（每帧命中更新） | 26788 |
| n_new_mean（每帧新增盘） | 1197.2 |

投回第 0 帧渲染（`render_f0_images.py`，统一单色椭圆边界）：

| 渲染口径 | 孔洞 |
| --- | --- |
| 硬着色（ray-disc 最近命中） | 1.32% |
| EWA（cov_scale=0.33） | 0.57% |

模型已存 `output_f0_ellipse_final/model_f0.npz`（帧 0 坐标系）与 `model.ply`（末帧坐标系）。

---

## 2. 本次改动（代码）

### h_pipeline_final.py
- `compute_scene_geometry`（≈L562）：`disc_mask = depth_discontinuity_mask(...)`
  —— 回退。之前误用 `depth_jump_mask`，多了 ~785 个初始盘（31023 vs 30238）。
- `edge_distance_limit`（≈L523）：**保持** `edge = depth_jump_mask(...)`（正确，未动）。
- `emit_footprint_discs` fallback（≈L932）：`disc_mask = depth_discontinuity_mask(...)`。
- `emit_curvature_discs` fallback（≈L1033）：`disc_mask = depth_discontinuity_mask(...)`。
- `eval_setup`（≈L1370）：`~depth_discontinuity_mask(...)`（回退到与生盘口径一致）。
- 注释更新：`CurvatureGeometry` 字段 `r_edge` / `disc_mask` 的说明，
  以及 `depth_discontinuity_mask` / `depth_jump_mask` / `edge_distance_limit` 三段 docstring，
  把「r_edge 与 disc_mask 同语义」这句过时/错误的话改掉了。

### incremental_hybrid.py
- `_geometry_cropped`（≈L107）：`disc_mask = H.depth_discontinuity_mask(...)`（回退）。

---

## 3. 根因：两个 mask 管两件事，故意相反

| 用途 | 用的 mask | void（FOV 边框/传感器洞）怎么算 |
| --- | --- | --- |
| `disc_mask`（决定**要不要生盘**） | `depth_discontinuity_mask`（旧） | **算"头"**：单帧里可视面到此结束，要生盘封口 |
| `edge_distance_limit` / `r_edge`（决定**盘半径能扩多大**） | `depth_jump_mask`（新） | **不算"头"**：FOV 只是"没数据"，表面还在延伸，下一帧会观测到，半径不能被截短 |

- 生盘按「看见的表面到头了」算（void=边界），半径按「表面没真断」算（void≠边界）——
  两件事物理含义相反，所以墙也得相反，**不是写错**。
- 之前把 `disc_mask` 误换成 `depth_jump_mask` 后，void-adjacent 像素不再被当作"该封口"，
  于是发射了更多盘 → `n_init=31023`（+785），后续覆盖/吸收一路漂移。

---

## 4. 经验教训

1. **两个同名墙语义相反**：`depth_discontinuity_mask`（void=seam）与 `depth_jump_mask`
   （void≠seam）不能互相替。改任何一处前先确认它是「生盘」还是「半径」。
2. **回退要按"字段"而不是按"文件"**：`disc_mask` 有 1 个主计算 + 2 个 fallback + 1 个
   eval + 1 个增量裁剪版本，共 5 个位置，漏任何一处都会造成 init 漂移或增量漂移。
3. **注释会过时**：`edge_distance_limit` 的 docstring 之前写着「Matches disc_mask
   (depth_jump_mask)… same semantics」，回退后反而与代码相反，最容易在日后回溯时再次带偏。
   这次已同步改掉。
4. **无 git 的代价**：本目录不是真 git 仓库（`/home/sti/Work/.git` 是 Trae 日志目录），
   大量修改是临时的、未提交的。已用手动快照兜底：
   `scripts/backup/20260917_150803/`（含 `sequential_fusion.py` 旧命中代数 + README）。
   破坏性改动前继续沿用「先快照到 `backup/<时间戳>/`」的做法。
5. **数字是唯一硬锚点**：`n_init=30238` 与 `n_final=42210` 来自历史 `output_jumpmask_noprune`
   记录，是本次回退是否正确的最终判据；对照任何代码改动前先跑 3 帧烟测看 init 是否仍在 30238。

---

## 5. 复现命令

```bash
cd "/home/sti/Work/985-3DGS/SEQUENTIAL FRAMES/scripts"

# 10 帧增量（无老化剪枝、黑边填充+absorb 开）
"/home/sti/Work/985-3DGS/SINGLE FRAME/.venv/bin/python" sequential_fusion_flowonly.py \
    --max-pairs 10 --age-max 1000000 --w-min 0 --out ../output_f0_10frame_fix

# 同一套融合 + 投回第 0 帧渲染（统一单色椭圆 f0_ellipse.png）
"/home/sti/Work/985-3DGS/SINGLE FRAME/.venv/bin/python" render_f0_images.py \
    --frames 11 --out ../output_f0_ellipse_final
```