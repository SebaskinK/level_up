"""Sequential RGB-D surfel fusion (A1): scene-flow identity, point-to-plane gate.

Frame 0: build_hybrid.
Later frames: 986 scene flow (DIS residual + rigid inlier expand) warps the
pixel→disc table; a point-to-plane gate decides whether to write the disc.
Seeds update position+colour; expanded inliers update position only.
Normals and radii stay frozen. Uncovered depth_valid pixels get a local
build_hybrid. Poses are 986-produced, not TUM GT.

Does not import SINGLE FRAME experiment drivers beyond h_pipeline_final.
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np

SEQ = Path(__file__).resolve().parent
SINGLE = SEQ.parent.parent / "SINGLE FRAME" / "scripts"
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SINGLE))
sys.path.insert(0, str(SFLOW))

import h_pipeline_final as H  # noqa: E402
from rigid_motion import depth_sigma, invert_point_motion  # noqa: E402
from scene_flow import compute_scene_flow  # noqa: E402
from se3 import se3_exp  # noqa: E402
from tum_io import (  # noqa: E402
    FR1_INTRINSICS,
    associate,
    interpolate_pose,
    load_depth,
    load_groundtruth,
    load_rgb,
    relative_camera_motion,
    remap_depth,
    remap_rgb,
    undistort_maps,
)

DATA = Path("/home/sti/Work/986-SceneFlow/rgbd_dataset_freiburg1_desk")
Z_MIN, Z_MAX = H.GEO_CFG["z_min"], H.GEO_CFG["z_max"]
TEX_Q = 0.6
K_SIGMA = 3.0


@dataclass
class Model:
    g: H.Gaussians
    w: np.ndarray
    age: np.ndarray
    owner: np.ndarray  # int32 (H, W), -1 empty; in current camera


def _subset(g: H.Gaussians, keep: np.ndarray) -> H.Gaussians:
    ax1 = g.axis1[keep] if g.axis1 is not None else None
    ax2 = g.axis2[keep] if g.axis2 is not None else None
    return H.Gaussians(
        mu=g.mu[keep],
        normal=g.normal[keep],
        scale=g.scale[keep],
        quat=g.quat[keep],
        color=g.color[keep],
        alpha=g.alpha[keep],
        pixel=g.pixel[keep],
        axis1=ax1,
        axis2=ax2,
    )


def transform_to_next(g: H.Gaussians, R_10: np.ndarray, t_10: np.ndarray) -> H.Gaussians:
    """Point-motion X1 = R_10 X0 + t_10, same convention as 986 xi."""
    R = R_10.astype(np.float32)
    t = t_10.astype(np.float32)
    mu = g.mu @ R.T + t
    n = g.normal @ R.T
    nn = np.linalg.norm(n, axis=1, keepdims=True)
    n = n / np.maximum(nn, 1e-8)
    ax1 = g.axis1 @ R.T if g.axis1 is not None else None
    ax2 = g.axis2 @ R.T if g.axis2 is not None else None
    if ax1 is not None:
        ax1 = ax1 / np.maximum(np.linalg.norm(ax1, axis=1, keepdims=True), 1e-8)
    if ax2 is not None:
        ax2 = ax2 / np.maximum(np.linalg.norm(ax2, axis=1, keepdims=True), 1e-8)
    return H.Gaussians(
        mu=mu.astype(np.float32),
        normal=n.astype(np.float32),
        scale=g.scale,
        quat=H._quat_from_normal(n),
        color=g.color,
        alpha=g.alpha,
        pixel=g.pixel,
        axis1=None if ax1 is None else ax1.astype(np.float32),
        axis2=None if ax2 is None else ax2.astype(np.float32),
    )


def owner_from_raster(g: H.Gaussians, K: np.ndarray, shape: tuple[int, int]) -> np.ndarray:
    _, index, _ = H.rasterize_discs(g, K, shape)
    return index.astype(np.int32)


def warp_owner(owner: np.ndarray, u: np.ndarray, v: np.ndarray, valid: np.ndarray) -> np.ndarray:
    h, w = owner.shape
    out = np.full((h, w), -1, dtype=np.int32)
    ys, xs = np.where(valid & (owner >= 0))
    if xs.size == 0:
        return out
    x1 = np.clip(np.rint(xs + u[ys, xs]).astype(np.int32), 0, w - 1)
    y1 = np.clip(np.rint(ys + v[ys, xs]).astype(np.int32), 0, h - 1)
    out[y1, x1] = owner[ys, xs]
    return out



def _fill_owner_backward(owner_w, owner_src, sf):
    """If forward round missed, take identity from backward flow."""
    if sf.bw_u is None:
        return owner_w
    h, w = owner_w.shape
    xs_g, ys_g = np.meshgrid(np.arange(w, dtype=np.float32), np.arange(h, dtype=np.float32))
    x0 = xs_g + sf.bw_u
    y0 = ys_g + sf.bw_v
    inb = (x0 >= 0) & (x0 <= w - 1) & (y0 >= 0) & (y0 <= h - 1)
    x0i = np.clip(np.rint(x0).astype(np.int32), 0, w - 1)
    y0i = np.clip(np.rint(y0).astype(np.int32), 0, h - 1)
    src_id = owner_src[y0i, x0i]
    src_ok = inb & (src_id >= 0) & sf.valid[y0i, x0i]
    take = (owner_w < 0) & src_ok
    owner_w = owner_w.copy()
    owner_w[take] = src_id[take]
    return owner_w


def point_to_plane(X: np.ndarray, mu: np.ndarray, n: np.ndarray) -> np.ndarray:
    return np.abs(np.einsum("ij,ij->i", X - mu, n))


def fuse_frame(
    model: Model,
    sf,
    z0: np.ndarray,
    z1: np.ndarray,
    bgr1: np.ndarray,
    K: np.ndarray,
    age_max: int,
    w_min: float,
    R_10: np.ndarray | None = None,
    t_10: np.ndarray | None = None,
) -> dict:
    h, w = z0.shape
    fx, fy, cx, cy = float(K[0, 0]), float(K[1, 1]), float(K[0, 2]), float(K[1, 2])
    if R_10 is None or t_10 is None:
        if sf.xi is None:
            raise RuntimeError("scene flow produced no twist")
        R_10, t_10 = se3_exp(sf.xi)
    g = transform_to_next(model.g, R_10, t_10)
    n_old = len(g)
    w_conf = model.w.copy()
    age = model.age.copy() + 1

    owner_w = warp_owner(model.owner, sf.u, sf.v, sf.valid)
    expanded = sf.expanded if sf.expanded is not None else np.zeros((h, w), dtype=bool)
    seed = sf.valid & ~expanded
    owner_w = _fill_owner_backward(owner_w, model.owner, sf)

    ys, xs = np.where((owner_w >= 0) & ((z1 > Z_MIN) & (z1 < Z_MAX)))
    n_cand = int(xs.size)
    n_upd = 0
    n_gate_fail = 0
    if n_cand:
        s_id = owner_w[ys, xs]
        live = (s_id >= 0) & (s_id < n_old)
        ys, xs, s_id = ys[live], xs[live], s_id[live]
        X1 = H.backproject(z1, K)[ys, xs]
        dist = point_to_plane(X1, g.mu[s_id], g.normal[s_id])
        sigma = depth_sigma(z1[ys, xs])
        ok = dist < (K_SIGMA * sigma)
        n_gate_fail = int((~ok).sum())
        ys, xs, s_id = ys[ok], xs[ok], s_id[ok]
        X1 = X1[ok]
        w_obs = (1.0 / np.maximum(sigma[ok] ** 2, 1e-8))
        n_upd = int(xs.size)
        if n_upd:
            is_seed = seed[ys, xs]
            rgb = bgr1[ys, xs][:, ::-1].astype(np.float64) / 255.0
            sum_x = np.zeros((n_old, 3), dtype=np.float64)
            sum_c = np.zeros((n_old, 3), dtype=np.float64)
            sum_wp = np.zeros(n_old, dtype=np.float64)
            sum_wc = np.zeros(n_old, dtype=np.float64)
            np.add.at(sum_x, s_id, X1 * w_obs[:, None])
            np.add.at(sum_wp, s_id, w_obs)
            if is_seed.any():
                np.add.at(sum_c, s_id[is_seed], rgb[is_seed] * w_obs[is_seed, None])
                np.add.at(sum_wc, s_id[is_seed], w_obs[is_seed])
            touched = sum_wp > 0
            den = w_conf[touched] + sum_wp[touched]
            g.mu[touched] = (
                (w_conf[touched, None] * g.mu[touched] + sum_x[touched]) / den[:, None]
            ).astype(np.float32)
            col = sum_wc > 0
            den_c = w_conf[col] + sum_wc[col]
            g.color[col] = (
                (w_conf[col, None] * g.color[col] + sum_c[col]) / den_c[:, None]
            ).astype(np.float32)
            np.clip(g.color, 0.0, 1.0, out=g.color)
            w_conf[touched] = den.astype(np.float32)
            age[touched] = 0

    owned = owner_w >= 0
    leftover = (z1 > Z_MIN) & (z1 < Z_MAX) & ~owned
    hit = owned
    n_new = 0
    new_px = np.zeros((0, 2), np.int32)
    if leftover.any():
        g_new, _, _ = H.build_hybrid(bgr1, z1, K, TEX_Q)
        px = g_new.pixel
        on = leftover[px[:, 1], px[:, 0]]
        if on.any():
            g_new = _subset(g_new, on)
            depth_m, index_m, _ = H.rasterize_discs(g, K, (h, w))
            keep_new = np.ones(len(g_new), dtype=bool)
            py, pxu = g_new.pixel[:, 1], g_new.pixel[:, 0]
            hit_old = index_m[py, pxu] >= 0
            if hit_old.any():
                sid = index_m[py, pxu]
                X = H.backproject(z1, K)[py, pxu]
                dist = point_to_plane(X, g.mu[np.clip(sid, 0, n_old - 1)], g.normal[np.clip(sid, 0, n_old - 1)])
                sigma = depth_sigma(z1[py, pxu])
                keep_new[hit_old] = dist[hit_old] >= (K_SIGMA * sigma[hit_old])
            g_new = _subset(g_new, keep_new)
            n_new = len(g_new)
            new_px = g_new.pixel.copy() if n_new else np.zeros((0, 2), np.int32)
            if n_new:
                g = H.concatenate_gaussians([g, g_new])
                w_conf = np.concatenate([w_conf, np.ones(n_new, dtype=np.float32)])
                age = np.concatenate([age, np.zeros(n_new, dtype=np.int32)])
            else:
                new_px = np.zeros((0, 2), np.int32)

    dead = (age > age_max) & (w_conf < w_min)
    if dead.any() and (~dead).sum() >= 8:
        g = _subset(g, ~dead)
        w_conf = w_conf[~dead]
        age = age[~dead]

    owner = owner_from_raster(g, K, (h, w))
    depth_valid = (z1 > Z_MIN) & (z1 < Z_MAX)
    model.g, model.w, model.age, model.owner = g, w_conf, age, owner
    return {
        "n": len(g),
        "n_upd": n_upd,
        "n_new": n_new,
        "n_gate_fail": n_gate_fail,
        "n_owned": int(np.sum((owner >= 0) & depth_valid)),
        "n_cand": int(np.sum((owner_w >= 0) & depth_valid)),
        "valid_frac": float(sf.valid.mean()),
        "expanded_frac": float(expanded.mean()),
        "leftover_frac": float(leftover.mean()),
        "n_dead": int(dead.sum()) if dead.size else 0,
        "leftover": leftover,
        "new_px": new_px,
        "hit": hit,
    }



def _draw_new(bgr, leftover, hit, new_px, rec) -> np.ndarray:
    vis = bgr.copy()
    overlay = vis.astype(np.float32)
    leftover_bgr = (0, 160, 255)
    new_bgr = (0, 0, 255)
    m = leftover
    overlay[m] = 0.45 * overlay[m] + 0.55 * np.array(leftover_bgr, np.float32)
    vis = np.clip(overlay, 0, 255).astype(np.uint8)
    for u, v in new_px:
        cv2.circle(vis, (int(u), int(v)), 2, new_bgr, -1, lineType=cv2.LINE_AA)
    h, w = vis.shape[:2]
    bar = np.full((52, w, 3), 30, np.uint8)
    items = [
        (leftover_bgr, "leftover mask (no flow hit)"),
        (new_bgr, "new disc centres"),
    ]
    x = 8
    for col, name in items:
        cv2.rectangle(bar, (x, 8), (x + 16, 24), col, -1)
        cv2.rectangle(bar, (x, 8), (x + 16, 24), (240, 240, 240), 1)
        cv2.putText(bar, name, (x + 22, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.45,
                    (220, 220, 220), 1, cv2.LINE_AA)
        x += 22 + 8 * len(name) + 28
    cv2.putText(
        bar,
        f"new={rec['n_new']} leftover={100*rec['leftover_frac']:.1f}% "
        f"upd={rec['n_upd']} N={rec['n']}",
        (8, 44), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (220, 220, 220), 1, cv2.LINE_AA,
    )
    return np.vstack([vis, bar])


def load_pair(pairs, i, map1, map2):
    p = pairs[i]
    bgr = remap_rgb(load_rgb(p.rgb_path), map1, map2)
    z = remap_depth(load_depth(p.depth_path), map1, map2)
    z[z < Z_MIN] = 0.0
    z[z > Z_MAX] = 0.0
    return bgr, z, p.t_rgb


def write_ply(path: Path, g: H.Gaussians) -> None:
    """Standard 3DGS PLY (binary_little_endian, sh_degree 0).

    Conventions matched to the reference rasterizer:
      * f_dc = (linear_rgb - 0.5) / SH_C0
      * opacity = logit(alpha)
      * scale = log([r1, r2, thin]) along rot's x/y/z (thin = normal)
      * rot = wxyz quaternion, shortest axis aligned to normal
    """
    n = len(g)
    sh_c0 = 0.28209479177387814
    rgb = np.clip(g.color, 0.0, 1.0).astype(np.float64)
    f_dc = (rgb - 0.5) / sh_c0
    alpha = np.clip(g.alpha, 1e-6, 1.0 - 1e-6).astype(np.float64)
    opacity = np.log(alpha / (1.0 - alpha))
    scale = np.log(np.maximum(g.scale, 1e-12).astype(np.float64))
    rot = g.quat.astype(np.float64)
    header = (
        "ply\n"
        "format binary_little_endian 1.0\n"
        f"element vertex {n}\n"
        "property float x\nproperty float y\nproperty float z\n"
        "property float nx\nproperty float ny\nproperty float nz\n"
        "property float f_dc_0\nproperty float f_dc_1\nproperty float f_dc_2\n"
        "property float opacity\n"
        "property float scale_0\nproperty float scale_1\nproperty float scale_2\n"
        "property float rot_0\nproperty float rot_1\nproperty float rot_2\nproperty float rot_3\n"
        "end_header\n"
    )
    cols = np.concatenate(
        [g.mu, g.normal, f_dc, opacity[:, None], scale, rot], axis=1
    ).astype(np.float64)
    with path.open("wb") as f:
        f.write(header.encode("ascii"))
        f.write(cols.astype("<f4").tobytes())


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--max-pairs", type=int, default=10)
    p.add_argument("--out", default=str(SEQ.parent / "output_K"))
    p.add_argument("--age-max", type=int, default=8)
    p.add_argument("--w-min", type=float, default=2.0)
    p.add_argument("--save-ply", action="store_true")
    p.add_argument("--save-vis", action="store_true", default=True)
    p.add_argument("--no-save-vis", action="store_false", dest="save_vis")
    p.add_argument("--gt-pose", action="store_true",
                   help="use TUM ground-truth camera motion instead of 986 xi")
    args = p.parse_args()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    vis_dir = out / "vis"
    if args.save_vis:
        vis_dir.mkdir(exist_ok=True)

    pairs = associate(DATA, max_dt=0.02)
    if args.max_pairs > 0:
        pairs = pairs[: args.max_pairs + 1]
    if args.gt_pose:
        gt_ts, gt_t, gt_q = load_groundtruth(DATA / "groundtruth.txt")
    sample = load_rgb(pairs[0].rgb_path)
    h, w = sample.shape[:2]
    map1, map2, K = undistort_maps((h, w), FR1_INTRINSICS)

    bgr0, z0, _ = load_pair(pairs, 0, map1, map2)
    g0, _, _ = H.build_hybrid(bgr0, z0, K, TEX_Q)
    model = Model(
        g=g0,
        w=np.ones(len(g0), dtype=np.float32),
        age=np.zeros(len(g0), dtype=np.int32),
        owner=owner_from_raster(g0, K, (h, w)),
    )
    rows = [{"i": -1, "n": len(g0), "n_upd": 0, "n_new": len(g0),
             "n_gate_fail": 0, "valid_frac": 1.0, "expanded_frac": 0.0,
             "leftover_frac": 0.0, "n_dead": 0, "n_owned": 0, "n_cand": 0}]
    print(f"[init] N={len(g0)}", flush=True)

    prev_sf = None
    prev_dt = 1.0
    bgr_a, z_a = bgr0, z0
    for i in range(len(pairs) - 1):
        bgr_b, z_b, _ = load_pair(pairs, i + 1, map1, map2)
        dt = pairs[i + 1].t_rgb - pairs[i].t_rgb
        sf = compute_scene_flow(
            bgr_a, bgr_b, z_a, z_b, K,
            prev=prev_sf, dt=dt, prev_dt=prev_dt,
        )
        R_10 = t_10 = None
        if args.gt_pose:
            m0 = interpolate_pose(pairs[i].t_rgb, gt_ts, gt_t, gt_q)
            m1 = interpolate_pose(pairs[i + 1].t_rgb, gt_ts, gt_t, gt_q)
            if m0 is None or m1 is None:
                raise RuntimeError(f"GT pose out of range at pair {i}")
            R_eg, t_eg = relative_camera_motion(*m0, *m1)
            R_10, t_10 = invert_point_motion(R_eg, t_eg)
        rec = fuse_frame(model, sf, z_a, z_b, bgr_b, K, args.age_max, args.w_min,
                         R_10, t_10)
        rec["i"] = i
        if args.save_vis:
            vis = _draw_new(bgr_b, rec["leftover"], rec["hit"], rec["new_px"], rec)
            cv2.imwrite(str(vis_dir / f"new_{i:04d}.png"), vis)
        rec.pop("leftover", None)
        rec.pop("new_px", None)
        rec.pop("hit", None)
        rows.append(rec)
        print(
            f"[{i:03d}] N={rec['n']} upd={rec['n_upd']} new={rec['n_new']} "
            f"owned={rec['n_owned']} cand={rec['n_cand']} "
            f"fail={rec['n_gate_fail']} valid={rec['valid_frac']:.2f} "
            f"exp={rec['expanded_frac']:.2f} left={rec['leftover_frac']:.2f} "
            f"dead={rec['n_dead']}",
            flush=True,
        )
        bgr_a, z_a = bgr_b, z_b
        prev_sf, prev_dt = sf, dt

    keys = list(rows[0].keys())
    with (out / "fusion.csv").open("w", newline="") as f:
        wri = csv.DictWriter(f, fieldnames=keys)
        wri.writeheader()
        wri.writerows(rows)
    summary = {
        "n_frames": len(rows) - 1,
        "n_init": rows[0]["n"],
        "n_final": rows[-1]["n"],
        "n_upd_mean": float(np.mean([r["n_upd"] for r in rows[1:]])),
        "n_new_mean": float(np.mean([r["n_new"] for r in rows[1:]])),
    }
    (out / "summary.json").write_text(json.dumps(summary, indent=2))
    if args.save_ply:
        write_ply(out / "model.ply", model.g)
    print(json.dumps(summary, indent=2))
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
