"""Diagnose ray-coverage holes in the accumulated frame-0 model.

Re-runs the 10-frame fusion (aging off, no absorb) exactly like
render_f0_images.py, transforms the final model back to frame 0, then for
every pixel the ray-disc renderer misses, reports the nearest disc's projected
centre distance / scale / birth frame and whether it is S2 (isotropic) vs
curvature (anisotropic). This separates (a) no disc near -> coverage gap from
(b) disc present but footprint too small/thin/occluded.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

SEQ = Path(__file__).resolve().parent
SINGLE = SEQ.parent.parent / "SINGLE FRAME" / "scripts"
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SFLOW))
sys.path.insert(0, str(SINGLE))
sys.path.insert(0, str(SEQ))

import h_pipeline_final as H            # noqa: E402  (multi-frame copy)
import sequential_fusion_flowonly as SF  # noqa: E402

AGE_MAX = 1000000
W_MIN = 0.0


def run_fusion(n_pairs: int = 11, no_absorb: bool = True):
    pairs = SF.associate(SF.DATA, max_dt=0.02)[: n_pairs]
    sample = SF.load_rgb(pairs[0].rgb_path)
    h, w = sample.shape[:2]
    map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)

    bgr0, z0, _ = SF.load_pair(pairs, 0, map1, map2)
    g0, _, _, owner0 = H.build_hybrid_with_owner(bgr0, z0, K, SF.TEX_Q)
    model = SF.Model(
        g=g0, w=np.ones(len(g0), dtype=np.float32),
        age=np.zeros(len(g0), dtype=np.int32), owner=owner0,
        birth=np.zeros(len(g0), dtype=np.int32), cnt=np.ones(len(g0), dtype=np.float32),
    )

    FL = [None] * len(pairs)
    FL[0] = (np.eye(3), np.zeros(3))
    prev_FL = FL[0]
    prev_sf = None
    prev_dt = 1.0
    bgr_a, z_a = bgr0, z0
    for i in range(len(pairs) - 1):
        bgr_b, z_b, _ = SF.load_pair(pairs, i + 1, map1, map2)
        dt = pairs[i + 1].t_rgb - pairs[i].t_rgb
        sf = SF.compute_scene_flow(bgr_a, bgr_b, z_a, z_b, K,
                                   prev=prev_sf, dt=dt, prev_dt=prev_dt)
        R_10, t_10 = SF.se3_exp(sf.xi)
        FL[i + 1] = (R_10 @ prev_FL[0], R_10 @ prev_FL[1] + t_10)
        SF.fuse_frame(model, sf, z_a, z_b, bgr_b, K, age_max=AGE_MAX, w_min=W_MIN,
                      frame_idx=i, R_10=R_10, t_10=t_10, no_absorb=no_absorb)
        bgr_a, z_a = bgr_b, z_b
        prev_sf, prev_dt = sf, dt
        prev_FL = FL[i + 1]

    Rf, tf = FL[len(pairs) - 1]
    Rt, tt = Rf.T, -Rf.T @ tf
    g0f = SF.transform_to_next(model.g, Rt, tt)
    return z0, K, g0f, model.birth


def main() -> None:
    z0, K, g, birth = run_fusion(no_absorb=True)
    h, w = z0.shape
    depth, index, _ = H.rasterize_discs(g, K, (h, w))
    hole = ~np.isfinite(depth) & ((z0 > SF.Z_MIN) & (z0 < SF.Z_MAX))

    # projected disc centres
    fx, fy, cx, cy = (float(K[0, 0]), float(K[1, 1]), float(K[0, 2]), float(K[1, 2]))
    zc = np.maximum(g.mu[:, 2], 1e-6)
    uc = (fx * g.mu[:, 0] / zc + cx).astype(np.float64)
    vc = (fy * g.mu[:, 1] / zc + cy).astype(np.float64)

    hy, hx = np.nonzero(hole)
    print(f"total holes = {hy.size}  ({100.0 * hy.size / max(int((z0 > 0).sum()), 1):.3f}% of valid)")
    if hy.size == 0:
        return

    # nearest disc centre (brute force ok ~52k discs x ~4k holes)
    # use small KD-ish: bin discs into a grid for speed
    radius_px = np.maximum(g.scale[:, 0], g.scale[:, 1]) * 0.5 * (fx + fy) / zc
    # vectorized: for each hole, min over discs of (du^2+dv^2)
    # chunk holes to bound memory
    best_d = np.full(hy.size, np.inf)
    best_i = np.full(hy.size, -1, dtype=np.int32)
    CH = 256
    for s in range(0, hy.size, CH):
        e = min(s + CH, hy.size)
        du = hx[s:e, None] - uc[None, :]
        dv = hy[s:e, None] - vc[None, :]
        dd = du * du + dv * dv
        bi = dd.argmin(axis=1)
        bd = dd[np.arange(e - s), bi]
        best_d[s:e] = bd
        best_i[s:e] = bi

    best_d = np.sqrt(best_d)
    idx = best_i
    is_s2 = np.abs(g.scale[:, 0] - g.scale[:, 1]) < 1e-6 * np.maximum(g.scale[:, 0], 1e-9)
    b = birth[idx]
    r1 = g.scale[idx, 0]
    r2 = g.scale[idx, 1]
    r_px = np.maximum(r1, r2) * 0.5 * (fx + fy) / np.maximum(g.mu[idx, 2], 1e-6)

    print("\n-- all holes: nearest-disc centre distance (px) --")
    for lo, hi in [(0, 1), (1, 2), (2, 3), (3, 5), (5, 10), (10, np.inf)]:
        m = (best_d >= lo) & (best_d < hi)
        if m.any():
            print(f"  d in [{lo:>2},{hi:>2}): {m.sum():6d}  "
                  f"s2_frac={is_s2[m].mean():.3f}  birth_mean={b[m].mean():.2f}")

    print("\n-- holes in RIGHT HALF (x >= w/2) --")
    right = hx >= w // 2
    m = right
    if m.any():
        print(f"  count={m.sum()}")
        print("  per-column (last 40 cols):")
        colcount = np.bincount(hx[hy >= 0] if False else hx[m], minlength=w)
        # only right half columns
        for c in range(w - 40, w):
            print(f"    col {c}: {colcount[c]}")
        print("  nearest d quartiles:", np.percentile(best_d[m], [25, 50, 75, 90]).round(2))
        print("  s2_frac:", is_s2[m].mean().round(3))
        print("  birth hist:", np.bincount(b[m], minlength=12))

    print("\n-- holes: disc footprint radius_px at nearest disc (d vs r_px) --")
    cover = r_px >= best_d  # nearest disc radius actually reaches the hole centre?
    print(f"  nearest disc would REACH hole: {cover.mean():.3f}")
    print(f"  (if high but still hole -> occluded or disk too thin one axis)")


if __name__ == "__main__":
    main()