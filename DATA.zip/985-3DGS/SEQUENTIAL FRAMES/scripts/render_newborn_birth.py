"""Re-render the top birth frames with the dirty new discs' footprints clearly
overlaid (no 80-frame fusion: reads records.npz + dirty_idx.npy from
diag_newborn_birth.py). Produces one 2x2 grid for easy side-by-side viewing.

Footprint = the discs' rasterized coverage at their birth frame (filled
magenta). Center = bright green dot. Bowtie caption: which pixel column the disc
was born at, so left-born vs right-born is visible at a glance.
"""

from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np

import h_pipeline_final as H
import sequential_fusion_flowonly as SF


def main() -> None:
    OUT = SF.SEQ.parent / "output_newborn"
    r = np.load(OUT / "records.npz")
    mu = r["mu"]; scale = r["scale"]; color = r["color"]; normal = r["normal"]
    pixel = r["pixel"]; axis1 = r["axis1"]; axis2 = r["axis2"]
    source = r["source"]; birth = r["birth"]
    dirty = np.load(OUT / "dirty_idx.npy")

    src = source[dirty]; bir = birth[dirty]
    from collections import Counter
    top = Counter(bir.tolist()).most_common(4)

    NPAIR = 81
    pairs = SF.associate(SF.DATA, max_dt=0.02)[:NPAIR]
    h, w = SF.load_rgb(pairs[0].rgb_path).shape[:2]
    map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)

    tiles = []
    for bf, cnt in top:
        sel_glob = dirty[bir == bf]
        sub = H.Gaussians(
            mu=mu[sel_glob].astype(np.float32),
            normal=normal[sel_glob].astype(np.float32),
            scale=scale[sel_glob].astype(np.float32),
            quat=H._quat_from_frame(axis1[sel_glob].astype(np.float32),
                                    axis2[sel_glob].astype(np.float32),
                                    normal[sel_glob].astype(np.float32)),
            color=color[sel_glob].astype(np.float32),
            alpha=np.full(len(sel_glob), H.OPAQUE_ALPHA, dtype=np.float32),
            pixel=pixel[sel_glob].astype(np.int32),
            axis1=axis1[sel_glob].astype(np.float32),
            axis2=axis2[sel_glob].astype(np.float32),
        )
        bgr, _, _ = SF.load_pair(pairs, bf + 1, map1, map2)
        _, idx_sub, _ = H.rasterize_discs(sub, K, (h, w))
        cov = idx_sub >= 0
        vis = bgr.astype(np.float32)
        magenta = np.array([255.0, 0.0, 255.0], np.float32)
        vis[cov] = 0.35 * vis[cov] + 0.65 * magenta
        vis = vis.astype(np.uint8)
        # centers colored by birth column: left-born cyan, right-born yellow
        bx = pixel[sel_glob][:, 0]
        for k, (u, v) in enumerate(pixel[sel_glob]):
            c = (255, 255, 0) if bx[k] >= 256 else (0, 255, 255)
            cv2.circle(vis, (int(u), int(v)), 2, c, -1, lineType=cv2.LINE_AA)
        cv2.putText(vis, f"birth frame {bf}  ({cnt} discs)  cyan=born left  yellow=born right",
                    (6, 18), cv2.FONT_HERSHEY_SIMPLEX, 0.42, (0, 255, 0), 1, cv2.LINE_AA)
        cv2.putText(vis, f"cov={int(cov.sum())}px",
                    (6, 36), cv2.FONT_HERSHEY_SIMPLEX, 0.42, (0, 255, 0), 1, cv2.LINE_AA)
        tiles.append(vis)

    # 2x2 grid
    grid = np.vstack([np.hstack(tiles[:2]), np.hstack(tiles[2:])])
    cv2.imwrite(str(OUT / "grid_birth_top4.png"), grid)
    for i, t in enumerate(tiles):
        cv2.imwrite(str(OUT / f"tile_{i:02d}.png"), t)
    print("wrote grid_birth_top4.png + tiles", flush=True)


if __name__ == "__main__":
    main()