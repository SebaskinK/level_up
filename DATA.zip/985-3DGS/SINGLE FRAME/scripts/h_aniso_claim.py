"""Validate the anisotropic claim: does the greedy actually keep discs apart?

WHY THIS FILE EXISTS
--------------------
`select_curvature_seeds` claims an ELLIPSE with image-space semi-axis vectors
e1, e2 = J @ [overlap*r1*a1, overlap*r2*a2]; a pixel offset d is claimed iff
||M^-1 d|| <= 1 for M = [e1 e2].  The invariant that buys is:

    for any pair (i, j) with i placed first, centre_j is OUTSIDE i's ellipse.

WHAT THIS FILE REPLACED (2026-09-16)
------------------------------------
It used to score the claim with `frac(nn / r_long < overlap)` -- nearest
neighbour distance over the LONG semi-axis.  **That criterion is invalid.**  The
greedy excludes an ellipse, not a disc of radius r_long: a neighbour lying along
the SHORT axis only has to clear overlap*r_short, which for an aspect-2 disc is
0.3*r_long and reads as a "violation" while being perfectly legal.  Measured on
frame 0, the supposed violation rate tracks the aspect ratio and nothing else:

    aspect [1.00,1.05)  frac(nn/r_long<0.6) 0.532   real breaches 0
    aspect [1.05,1.50)                      0.558                 0
    aspect [1.50,2.50)                      0.802                 0
    aspect >= 2.50                          0.983                 0

The "residual 79.1 % -> 71.7 %, not zeroed" recorded in
`SEQUENTIAL FRAMES/scripts/OPEN_ITEMS.md` section 0.5 was this artefact, and its
attribution to the claim/emit normal mismatch was wrong: corr(mismatch angle,
nn/r_long) = -0.17, and the real breach count is 0 either way.  The file also
used to carry a line-by-line copy of the shipped aniso implementation for an A/B
that became degenerate the moment aniso became the default (both columns equal);
that dead copy is gone.

Usage
-----
    python h_aniso_claim.py [frame_idx]
"""

import sys
from pathlib import Path

import numpy as np
from scipy.spatial import cKDTree

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

import h_pipeline_final as H  # noqa: E402

DATA = ROOT.parent.parent.parent / "986-SceneFlow" / "rgbd_dataset_freiburg1_desk"


def _load(frame_idx: int):
    fr = H.associate(DATA)[frame_idx]
    map1, map2, K = H.undistort_maps((480, 640), H.FR1_INTRINSICS)
    bgr = H.remap_rgb(H.load_rgb(fr.rgb_path), map1, map2)
    z = H.remap_depth(H.load_depth(fr.depth_path), map1, map2)
    z[(z < H.GEO_CFG["z_min"]) | (z > H.GEO_CFG["z_max"])] = 0.0
    return bgr, z, K


def claim_state(bgr, z, K, texture_quantile=0.6,
                curvature_floor_scale=np.sqrt(2.0), tex_boundary_tol_px=4.5):
    """Re-derive the kept seeds and the claim footprints the greedy used."""
    G = H.GEO_CFG
    rgb = bgr[..., ::-1].astype(np.float32) / 255.0
    tex = H.texture_mask(rgb, texture_quantile)
    r_cap = (H.tex_boundary_limit(z, K, tex, tol_px=tex_boundary_tol_px)
             if tex_boundary_tol_px > 0 else None)
    geo = H.compute_scene_geometry(z, K, G["eps"], G["gauss_sigma"], G["disc_rel"])
    keep = H.select_curvature_seeds(
        z, K, G["eps"], G["gauss_sigma"], G["z_min"], G["z_max"], G["disc_rel"],
        G["overlap"], G["r_max"], edge_fallback_fp=True, r_cap=r_cap, geo=geo,
        floor_scale=curvature_floor_scale) & ~tex
    ys, xs = np.where(keep)

    lim = np.minimum(G["r_max"], geo.r_edge)
    if r_cap is not None:
        lim = np.minimum(lim, r_cap)
    floor = geo.r_fp * curvature_floor_scale
    hi = np.maximum(lim, floor)
    r1 = np.clip(geo.r_k1[ys, xs], floor[ys, xs], hi[ys, xs]).astype(np.float64)
    r2 = np.clip(geo.r_k2[ys, xs], floor[ys, xs], hi[ys, xs]).astype(np.float64)
    e1, e2 = H.claim_footprint(z, K, ys, xs, r1, r2, G["overlap"], geo)
    return ys, xs, r1, r2, e1, e2, geo


def claim_breaches(ys, xs, e1, e2):
    """For each disc, the nearest LATER centre measured in its own ellipse metric.

    Returns (breach, closest) where breach[i] is True iff some centre placed
    after i fell inside i's claim ellipse, and closest[i] is min ||M^-1 d||
    over those later centres (inf when i has no later neighbour in reach).
    """
    det = np.abs(e1[:, 0] * e2[:, 1] - e2[:, 0] * e1[:, 1])
    rank = np.empty(det.size, np.int64)
    rank[np.argsort(-det)] = np.arange(det.size)      # greedy order
    pts = np.stack([xs, ys], axis=1).astype(np.float64)
    tree = cKDTree(pts)
    reach = np.maximum(np.hypot(e1[:, 0], e2[:, 0]), np.hypot(e1[:, 1], e2[:, 1]))

    breach = np.zeros(det.size, dtype=bool)
    closest = np.full(det.size, np.inf)
    for i in range(det.size):
        if det[i] < 1e-12:
            continue
        nb = np.asarray(tree.query_ball_point(pts[i], reach[i] + 1.0))
        nb = nb[(nb != i) & (rank[nb] > rank[i])]
        if nb.size == 0:
            continue
        d = pts[nb] - pts[i]
        c0 = (e2[i, 1] * d[:, 0] - e2[i, 0] * d[:, 1]) / det[i]
        c1 = (-e1[i, 1] * d[:, 0] + e1[i, 0] * d[:, 1]) / det[i]
        m = c0 * c0 + c1 * c1
        closest[i] = np.sqrt(m.min())
        breach[i] = bool((m <= 1.0).any())
    return breach, closest


def main(frame_idx: int = 0) -> None:
    bgr, z, K = _load(frame_idx)
    ys, xs, r1, r2, e1, e2, geo = claim_state(bgr, z, K)
    breach, closest = claim_breaches(ys, xs, e1, e2)
    has_nb = np.isfinite(closest)

    print(f"frame {frame_idx}: curvature discs {ys.size}")
    print()
    print("CLAIM INVARIANT  (later centre must satisfy ||M^-1 d|| >= 1)")
    print(f"  discs with a later neighbour in reach : {has_nb.sum()}")
    print(f"  BREACHES                              : {breach.sum()}"
          f"  ({breach.mean():.4%})")
    print(f"  ||M^-1 d|| to nearest later centre    : "
          f"min {closest[has_nb].min():.3f}"
          f"  p5 {np.percentile(closest[has_nb], 5):.3f}"
          f"  med {np.median(closest[has_nb]):.3f}")

    # The retired criterion, kept only so nobody re-derives it from scratch.
    mu = H.backproject(z, K)[ys, xs]
    nn = cKDTree(mu).query(mu, k=2)[0][:, 1]
    r_long = np.maximum(r1, r2)
    ratio = nn / np.maximum(r_long, 1e-12)
    aspect = r_long / np.maximum(np.minimum(r1, r2), 1e-12)
    print()
    print("RETIRED CRITERION  nn / r_long < overlap  -- INVALID, see module docstring")
    print(f"  med {np.median(ratio):.3f}   frac<{H.GEO_CFG['overlap']}"
          f" {(ratio < H.GEO_CFG['overlap']).mean():.4f}")
    print("  it tracks the aspect ratio, not the claim:")
    for lo, up in ((1.0, 1.05), (1.05, 1.5), (1.5, 2.5), (2.5, np.inf)):
        m = (aspect >= lo) & (aspect < up)
        if m.sum() < 20:
            continue
        print(f"    aspect [{lo:4.2f},{up:5.2f})  n={m.sum():5d}"
              f"   frac(nn/r_long<0.6) {(ratio[m] < 0.6).mean():.4f}"
              f"   breaches {breach[m].sum()}")

    # claim uses the seed's Sobel normal; emit refits from the disc inliers
    g, keep_geo, _ = H.build_hybrid(bgr, z, K, 0.6)
    n_curv = int(keep_geo.sum())
    ang = np.degrees(np.arccos(np.clip(np.abs(np.einsum(
        "ij,ij->i", geo.normal[ys, xs], g.normal[:n_curv])), 0, 1)))
    print()
    print("CLAIM vs EMIT NORMAL  (Sobel @ seed  vs  disc-inlier refit)")
    print(f"  med {np.median(ang):.2f} deg   p90 {np.percentile(ang, 90):.2f}"
          f"   p99 {np.percentile(ang, 99):.2f}   max {ang.max():.2f}")
    print(f"  corr(angle, nn/r_long) = {np.corrcoef(ang, ratio)[0, 1]:+.4f}"
          f"   -- weak: the mismatch is NOT what drives the retired number")


if __name__ == "__main__":
    main(int(sys.argv[1]) if len(sys.argv) > 1 else 0)
