"""Variational RGB-D scene flow (Spies range-flow + brightness).

Unknown per pixel is (u, v, w) with w = V_Z (m/frame):

    I_x du + I_y dv           + I_t           = 0
    Z_x du + Z_y dv - dw      + (Z_t - w)     = 0

I_t, Z_t are measured after warping I1, Z1 by the current (u, v). The
linearisation is therefore on the increment (du, dv, dw) only — the current
(u, v) must not be dotted into the residual a second time.

Pyramid: (u, v) are in pixels of the current level, so they double on
upsampling; w is metric and is only resized.
"""

from __future__ import annotations

import cv2
import numpy as np


def _grad_xy(img: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    # Sobel ksize=3 is un-normalised (×8); LK needs per-pixel derivatives.
    return (
        cv2.Sobel(img, cv2.CV_32F, 1, 0, ksize=3) / 8.0,
        cv2.Sobel(img, cv2.CV_32F, 0, 1, ksize=3) / 8.0,
    )


def _depth_weight(z, sigma_ref=0.0031, z_ref=0.75, exponent=1.33):
    sigma = sigma_ref * (np.maximum(z, 0.3) / z_ref) ** exponent
    sigma = np.maximum(sigma, 1e-3)
    return np.clip(1.0 / (sigma ** 2), 0.0, 1e6)


def _laplacian_avg(F: np.ndarray) -> np.ndarray:
    k = np.array([[0, 1, 0], [1, 0, 1], [0, 1, 0]], dtype=np.float32) / 4.0
    out = np.empty_like(F)
    for c in range(F.shape[2]):
        out[..., c] = cv2.filter2D(F[..., c], -1, k)
    return out


def _pyr_down(img: np.ndarray) -> np.ndarray:
    return cv2.resize(
        img,
        (img.shape[1] // 2, img.shape[0] // 2),
        interpolation=cv2.INTER_AREA,
    )


def _warp(img: np.ndarray, u: np.ndarray, v: np.ndarray) -> np.ndarray:
    h, w = img.shape[:2]
    xs, ys = np.meshgrid(
        np.arange(w, dtype=np.float32), np.arange(h, dtype=np.float32)
    )
    return cv2.remap(
        img,
        xs + u,
        ys + v,
        interpolation=cv2.INTER_LINEAR,
        borderMode=cv2.BORDER_CONSTANT,
        borderValue=0.0,
    )


def _upsample_field(F: np.ndarray, lw: int, lh: int) -> np.ndarray:
    out = cv2.resize(F, (lw, lh), interpolation=cv2.INTER_LINEAR)
    out[..., 0] *= 2.0
    out[..., 1] *= 2.0
    return out


def _solve3(M: np.ndarray, rhs: np.ndarray) -> np.ndarray:
    try:
        x = np.linalg.solve(M, rhs[..., None])[..., 0]
    except np.linalg.LinAlgError:
        x = np.zeros_like(rhs)
    return np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)


def _warp_flow(u: np.ndarray, v: np.ndarray, fu: np.ndarray, fv: np.ndarray):
    """Sample flow (fu, fv) at x + (u, v)."""
    return _warp(fu, u, v), _warp(fv, u, v)


def variational_flow(
    gray0: np.ndarray,
    gray1: np.ndarray,
    z0: np.ndarray,
    z1: np.ndarray,
    K: np.ndarray,
    lambda_depth: float = 5.0,
    alpha: float = 20.0,
    levels: int = 4,
    warp_iters: int = 8,
    jacobi_iters: int = 40,
    z_min: float = 0.4,
    z_max: float = 4.0,
    sigma_zgrad: float = 1.5,
    robust: bool = True,
    c_photo: float = 15.0,
    c_depth: float = 0.02,
    init_uv: np.ndarray | None = None,
) -> dict:
    h, w = gray0.shape[:2]
    fx, fy, cx, cy = float(K[0, 0]), float(K[1, 1]), float(K[0, 2]), float(K[1, 2])

    g0 = gray0.astype(np.float32)
    g1 = gray1.astype(np.float32)
    d0 = z0.astype(np.float32)
    d1 = z1.astype(np.float32)

    g0s, g1s, d0s, d1s = [g0], [g1], [d0], [d1]
    for _ in range(levels - 1):
        g0s.append(_pyr_down(g0s[-1]))
        g1s.append(_pyr_down(g1s[-1]))
        d0s.append(_pyr_down(d0s[-1]))
        d1s.append(_pyr_down(d1s[-1]))

    # α_z: 1 m neighbour jump ~ (f / Z_ref) px, so w-smoothness matches (u, v).
    z_ref = float(np.median(d0[d0 > z_min])) if np.any(d0 > z_min) else 1.0
    alpha_z = alpha * (fx / max(z_ref, 0.3)) ** 2

    F = None
    for lvl in range(levels - 1, -1, -1):
        gg0, gg1 = g0s[lvl], g1s[lvl]
        dd0, dd1 = d0s[lvl], d1s[lvl]
        lh, lw = gg0.shape[:2]

        Z0 = np.clip(dd0, z_min, z_max)
        wd = _depth_weight(Z0).astype(np.float32)
        Z0s = cv2.GaussianBlur(Z0, (0, 0), sigma_zgrad)
        ix0, iy0 = _grad_xy(gg0)
        zx0, zy0 = _grad_xy(Z0s)

        if F is None:
            F = np.zeros((lh, lw, 3), dtype=np.float32)
            if init_uv is not None:
                scale = 2.0 ** lvl
                F[..., 0] = cv2.resize(init_uv[..., 0], (lw, lh), interpolation=cv2.INTER_LINEAR) / scale
                F[..., 1] = cv2.resize(init_uv[..., 1], (lw, lh), interpolation=cv2.INTER_LINEAR) / scale
        else:
            F = _upsample_field(F, lw, lh)

        for _ in range(warp_iters):
            u, v, w_ = F[..., 0], F[..., 1], F[..., 2]
            g1w = _warp(gg1, u, v)
            d1w = _warp(dd1, u, v)
            It = g1w - gg0
            Zt = d1w - Z0
            rz = Zt - w_

            if robust:
                W0 = 1.0 / (1.0 + (It / c_photo) ** 2)
                Wd = wd / (1.0 + (rz / c_depth) ** 2)
            else:
                W0 = np.ones_like(It)
                Wd = wd

            ax, ay, az = ix0, iy0, np.zeros_like(ix0)
            bx, by, bz = zx0, zy0, -np.ones_like(zx0)

            m00 = W0 * ax * ax + lambda_depth * Wd * bx * bx
            m01 = W0 * ax * ay + lambda_depth * Wd * bx * by
            m02 = W0 * ax * az + lambda_depth * Wd * bx * bz
            m11 = W0 * ay * ay + lambda_depth * Wd * by * by
            m12 = W0 * ay * az + lambda_depth * Wd * by * bz
            m22 = W0 * az * az + lambda_depth * Wd * bz * bz

            r0 = -W0 * It * ax - lambda_depth * Wd * rz * bx
            r1 = -W0 * It * ay - lambda_depth * Wd * rz * by
            r2 = -W0 * It * az - lambda_depth * Wd * rz * bz

            M = np.zeros((lh, lw, 3, 3), dtype=np.float64)
            M[..., 0, 0] = m00
            M[..., 0, 1] = m01
            M[..., 0, 2] = m02
            M[..., 1, 0] = m01
            M[..., 1, 1] = m11
            M[..., 1, 2] = m12
            M[..., 2, 0] = m02
            M[..., 2, 1] = m12
            M[..., 2, 2] = m22
            M[..., 0, 0] += alpha
            M[..., 1, 1] += alpha
            M[..., 2, 2] += alpha_z

            dF = np.zeros_like(F)
            for _ in range(jacobi_iters):
                T = F + dF
                Tavg = _laplacian_avg(T)
                rhs = np.empty((lh, lw, 3), dtype=np.float64)
                rhs[..., 0] = r0 + alpha * (Tavg[..., 0] - F[..., 0])
                rhs[..., 1] = r1 + alpha * (Tavg[..., 1] - F[..., 1])
                rhs[..., 2] = r2 + alpha_z * (Tavg[..., 2] - F[..., 2])
                dF = _solve3(M, rhs).astype(np.float32)
            F = F + dF

    xs, ys = np.meshgrid(
        np.arange(w, dtype=np.float32), np.arange(h, dtype=np.float32)
    )
    u, v, w_ = F[..., 0], F[..., 1], F[..., 2]
    Z = np.clip(z0, z_min, z_max)
    vx = (u * Z + (xs - cx) * w_) / fx
    vy = (v * Z + (ys - cy) * w_) / fy
    vz = w_

    X0 = _backproject(z0, K)
    X1 = X0 + np.stack([vx, vy, vz], axis=-1)
    z1w = _warp(z1, u, v)
    in_b = (
        (xs + u >= 0)
        & (xs + u <= w - 1)
        & (ys + v >= 0)
        & (ys + v <= h - 1)
    )
    valid = (
        in_b
        & (Z > z_min)
        & (Z < z_max)
        & (z1w > z_min)
        & (z1w < z_max)
        & np.isfinite(u)
        & np.isfinite(v)
        & np.isfinite(vz)
    )
    return {
        "u": u.astype(np.float32),
        "v": v.astype(np.float32),
        "vz": vz.astype(np.float32),
        "vx": vx.astype(np.float32),
        "vy": vy.astype(np.float32),
        "valid": valid,
        "X0": X0,
        "X1": X1,
    }


def variational_flow_bidirectional(
    gray0: np.ndarray,
    gray1: np.ndarray,
    z0: np.ndarray,
    z1: np.ndarray,
    K: np.ndarray,
    lambda_depth: float = 5.0,
    alpha: float = 20.0,
    lambda_sym: float = 0.5,
    levels: int = 4,
    warp_iters: int = 8,
    jacobi_iters: int = 40,
    z_min: float = 0.4,
    z_max: float = 4.0,
    init_fw: np.ndarray | None = None,
    init_bw: np.ndarray | None = None,
) -> tuple[dict, dict]:
    """Joint Spies energy on forward and backward fields.

    After each data increment, pull
        F + warp(B, F) -> 0
        B + warp(F, B) -> 0
    so the two fields are approximate inverses. Literature Range Flow is the
    shared data term; invertibility is the extra coupling the pipeline FB gate
    actually needs.
    """
    h, w = gray0.shape[:2]
    g0 = gray0.astype(np.float32)
    g1 = gray1.astype(np.float32)
    d0 = z0.astype(np.float32)
    d1 = z1.astype(np.float32)
    g0s, g1s, d0s, d1s = [g0], [g1], [d0], [d1]
    for _ in range(levels - 1):
        g0s.append(_pyr_down(g0s[-1]))
        g1s.append(_pyr_down(g1s[-1]))
        d0s.append(_pyr_down(d0s[-1]))
        d1s.append(_pyr_down(d1s[-1]))

    Ff = None
    Bb = None
    for lvl in range(levels - 1, -1, -1):
        lh, lw = g0s[lvl].shape[:2]
        scale = 2.0 ** lvl
        if Ff is None:
            Ff = np.zeros((lh, lw, 3), dtype=np.float32)
            Bb = np.zeros((lh, lw, 3), dtype=np.float32)
            if init_fw is not None:
                Ff[..., 0] = cv2.resize(init_fw[..., 0], (lw, lh), interpolation=cv2.INTER_LINEAR) / scale
                Ff[..., 1] = cv2.resize(init_fw[..., 1], (lw, lh), interpolation=cv2.INTER_LINEAR) / scale
            if init_bw is not None:
                Bb[..., 0] = cv2.resize(init_bw[..., 0], (lw, lh), interpolation=cv2.INTER_LINEAR) / scale
                Bb[..., 1] = cv2.resize(init_bw[..., 1], (lw, lh), interpolation=cv2.INTER_LINEAR) / scale
        else:
            Ff = _upsample_field(Ff, lw, lh)
            Bb = _upsample_field(Bb, lw, lh)

        for _ in range(warp_iters):
            Ff = _data_increment(
                g0s[lvl], g1s[lvl], d0s[lvl], d1s[lvl], Ff,
                lambda_depth, alpha, jacobi_iters, z_min, z_max,
            )
            Bb = _data_increment(
                g1s[lvl], g0s[lvl], d1s[lvl], d0s[lvl], Bb,
                lambda_depth, alpha, jacobi_iters, z_min, z_max,
            )
            Bu, Bv = _warp_flow(Ff[..., 0], Ff[..., 1], Bb[..., 0], Bb[..., 1])
            Fu, Fv = _warp_flow(Bb[..., 0], Bb[..., 1], Ff[..., 0], Ff[..., 1])
            Ff[..., 0] -= lambda_sym * (Ff[..., 0] + Bu)
            Ff[..., 1] -= lambda_sym * (Ff[..., 1] + Bv)
            Bb[..., 0] -= lambda_sym * (Bb[..., 0] + Fu)
            Bb[..., 1] -= lambda_sym * (Bb[..., 1] + Fv)

    def _pack(F, z_ref, gray_a, gray_b, za, zb):
        xs, ys = np.meshgrid(
            np.arange(w, dtype=np.float32), np.arange(h, dtype=np.float32)
        )
        u, v, w_ = F[..., 0], F[..., 1], F[..., 2]
        fx, fy, cx, cy = float(K[0, 0]), float(K[1, 1]), float(K[0, 2]), float(K[1, 2])
        Z = np.clip(z_ref, z_min, z_max)
        vx = (u * Z + (xs - cx) * w_) / fx
        vy = (v * Z + (ys - cy) * w_) / fy
        X0 = _backproject(z_ref, K)
        X1 = X0 + np.stack([vx, vy, w_], axis=-1)
        in_b = (xs + u >= 0) & (xs + u <= w - 1) & (ys + v >= 0) & (ys + v <= h - 1)
        valid = in_b & (Z > z_min) & (Z < z_max) & np.isfinite(u) & np.isfinite(v)
        return {
            "u": u.astype(np.float32),
            "v": v.astype(np.float32),
            "vz": w_.astype(np.float32),
            "vx": vx.astype(np.float32),
            "vy": vy.astype(np.float32),
            "valid": valid,
            "X0": X0,
            "X1": X1,
        }

    return _pack(Ff, z0, g0, g1, d0, d1), _pack(Bb, z1, g1, g0, d1, d0)


def _data_increment(
    gg0, gg1, dd0, dd1, F, lambda_depth, alpha, jacobi_iters, z_min, z_max,
    sigma_zgrad=1.5, robust=True, c_photo=15.0, c_depth=0.02,
):
    """One increment-LK data step of variational_flow, in-place on F."""
    lh, lw = gg0.shape[:2]
    Z0 = np.clip(dd0, z_min, z_max)
    wd = _depth_weight(Z0).astype(np.float32)
    ix0, iy0 = _grad_xy(gg0)
    zx0, zy0 = _grad_xy(cv2.GaussianBlur(Z0, (0, 0), sigma_zgrad))
    u, v, w_ = F[..., 0], F[..., 1], F[..., 2]
    g1w = _warp(gg1, u, v)
    d1w = _warp(dd1, u, v)
    It = g1w - gg0
    rz = (d1w - Z0) - w_
    if robust:
        W0 = 1.0 / (1.0 + (It / c_photo) ** 2)
        Wd = wd / (1.0 + (rz / c_depth) ** 2)
    else:
        W0 = np.ones_like(It)
        Wd = wd
    ax, ay, az = ix0, iy0, np.zeros_like(ix0)
    bx, by, bz = zx0, zy0, -np.ones_like(zx0)
    m00 = W0 * ax * ax + lambda_depth * Wd * bx * bx
    m01 = W0 * ax * ay + lambda_depth * Wd * bx * by
    m02 = W0 * ax * az + lambda_depth * Wd * bx * bz
    m11 = W0 * ay * ay + lambda_depth * Wd * by * by
    m12 = W0 * ay * az + lambda_depth * Wd * by * bz
    m22 = W0 * az * az + lambda_depth * Wd * bz * bz
    r0 = -W0 * It * ax - lambda_depth * Wd * rz * bx
    r1 = -W0 * It * ay - lambda_depth * Wd * rz * by
    r2 = -W0 * It * az - lambda_depth * Wd * rz * bz
    M = np.zeros((lh, lw, 3, 3), dtype=np.float64)
    M[..., 0, 0] = m00 + alpha
    M[..., 0, 1] = m01
    M[..., 0, 2] = m02
    M[..., 1, 0] = m01
    M[..., 1, 1] = m11 + alpha
    M[..., 1, 2] = m12
    M[..., 2, 0] = m02
    M[..., 2, 1] = m12
    M[..., 2, 2] = m22 + alpha
    dF = np.zeros_like(F)
    for _ in range(jacobi_iters):
        T = F + dF
        Tavg = _laplacian_avg(T)
        rhs = np.empty((lh, lw, 3), dtype=np.float64)
        rhs[..., 0] = r0 + alpha * (Tavg[..., 0] - F[..., 0])
        rhs[..., 1] = r1 + alpha * (Tavg[..., 1] - F[..., 1])
        rhs[..., 2] = r2 + alpha * (Tavg[..., 2] - F[..., 2])
        dF = _solve3(M, rhs).astype(np.float32)
    return F + dF



def _backproject(z: np.ndarray, K: np.ndarray) -> np.ndarray:
    h, w = z.shape
    fx, fy, cx, cy = K[0, 0], K[1, 1], K[0, 2], K[1, 2]
    xs, ys = np.meshgrid(
        np.arange(w, dtype=np.float32), np.arange(h, dtype=np.float32)
    )
    X = (xs - cx) * z / fx
    Y = (ys - cy) * z / fy
    return np.stack([X, Y, z], axis=-1)
