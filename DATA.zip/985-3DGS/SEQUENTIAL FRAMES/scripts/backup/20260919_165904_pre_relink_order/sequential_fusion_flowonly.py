"""Sequential RGB-D surfel fusion (A1): PURE FLOW identity, zero full-model ray-disc.

Frame 0: build_hybrid.
Later frames: 986 scene flow (DIS residual + rigid inlier expand) warps the
pixel->disc table; each existing disc's centre is flow-tracked to the new frame
and updated from a single pixel -- position/colour/normal running-averaged,
radius frozen (`update_hits_onepoint`, the one-point-per-disc anti-drift policy).

Contrast with sequential_fusion.py (baseline) and sequential_fusion_indexed.py:
  * owner is NEVER recomputed by full-model rasterize_discs(g, ...).
  * leftover pixels go STRAIGHT to build_hybrid -- no hit_old gate against the
    existing model (that gate is the "second ray-disc usage", removed here).
  * New discs register their claim ellipse into owner (from build_hybrid_region,
    claim-based), so the next frame's flow warp knows those pixels are already
    owned -- O(N_new), and no ray-disc for that either.
Poses are 986-produced, not TUM GT.
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np

SEQ = Path(__file__).resolve().parent
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SEQ))
sys.path.insert(0, str(SFLOW))

import h_pipeline_final as H  # noqa: E402
import incremental_hybrid as INC  # noqa: E402
from rigid_motion import depth_sigma, invert_point_motion  # noqa: E402
from scene_flow import compute_scene_flow  # noqa: E402
from se3 import se3_exp  # noqa: E402
from tum_io import (  # noqa: E402
    FR1_INTRINSICS,
    associate,
    interpolate_pose,
    load_depth,
    load_groundtruth,
    load_rgb,
    relative_camera_motion,
    remap_depth,
    remap_rgb,
    undistort_maps,
)

DATA = Path("/home/sti/Work/986-SceneFlow/rgbd_dataset_freiburg1_desk")
Z_MIN, Z_MAX = H.GEO_CFG["z_min"], H.GEO_CFG["z_max"]
TEX_Q = 0.6
K_SIGMA = 3.0
COLOR_GATE_K = 6.0          # colour gate SPATIAL term: distance <= k * local texture sigma
COLOR_GATE_VAR_FLOOR = H.TEX_VAR_THR  # colour-gate variance floor == fixed texture threshold (see TEX_VAR_THR)
RELINK_COLOR_GATE_K = 6.0   # spatial K for the sparse disc-centre re-link, kept separate
                            # from COLOR_GATE_K (the temporal age term already covers
                            # re-visit exposure shift -- see color_gate_thresh).
COLOR_CONF_MAX = 50.0       # cap on the colour observation-count confidence. Colour is
                            # running-averaged by THIS count, NOT by w_conf (depth
                            # confidence 1/sigma_z^2 ~ 1e4, which freezes colour after
                            # one write). Keller/ElasticFusion share one channel-
                            # confidence for pos/normal/colour with a modest per-obs
                            # weight; surfel convention caps it w_max ~ 50 (w_init=1,
                            # w_min~0.2) so the running mean keeps a non-zero rate.
COLOR_LIGHT_RATE = 0.013     # per-frame lighting/exposure drift the colour gate may
                             # underwrite for each frame of a disc's AGE (time-domain).
                             # Measured by diag_exposure_drift.py: median per-frame
                             # colour step = 0.0133 (p90 0.030) over the 80-frame run.
COLOR_LIGHT_MAX = 0.27       # cap on that temporal budget == total drift of the run
                             # (diag_exposure_drift: median frame0->80 = 0.2655), so an
                             # old disc admits its own lighting drift but never swallows
                             # a genuinely different surface next to it.
TEX_BOUNDARY_TOL_PX = 4.5    # curvature discs may poke this far into the texture mask edge


@dataclass
class Model:
    g: H.Gaussians
    w: np.ndarray
    w_col: np.ndarray  # float32 (N,), capped colour observation-count confidence
    age: np.ndarray
    owner: np.ndarray  # int32 (H, W), -1 empty; in current camera
    birth: np.ndarray  # int32 (N,), frame index the disc was first created
    birth_color: np.ndarray = None  # float32 (N, 3), colour at creation (exposure-drift probe)


def _subset(g: H.Gaussians, keep: np.ndarray) -> H.Gaussians:
    ax1 = g.axis1[keep] if g.axis1 is not None else None
    ax2 = g.axis2[keep] if g.axis2 is not None else None
    return H.Gaussians(
        mu=g.mu[keep],
        normal=g.normal[keep],
        scale=g.scale[keep],
        quat=g.quat[keep],
        color=g.color[keep],
        alpha=g.alpha[keep],
        pixel=g.pixel[keep],
        axis1=ax1,
        axis2=ax2,
    )


def transform_to_next(g: H.Gaussians, R_10: np.ndarray, t_10: np.ndarray) -> H.Gaussians:
    """Point-motion X1 = R_10 X0 + t_10, same convention as 986 xi."""
    R = R_10.astype(np.float32)
    t = t_10.astype(np.float32)
    mu = g.mu @ R.T + t
    n = g.normal @ R.T
    nn = np.linalg.norm(n, axis=1, keepdims=True)
    n = n / np.maximum(nn, 1e-8)
    ax1 = g.axis1 @ R.T if g.axis1 is not None else None
    ax2 = g.axis2 @ R.T if g.axis2 is not None else None
    if ax1 is not None:
        ax1 = ax1 / np.maximum(np.linalg.norm(ax1, axis=1, keepdims=True), 1e-8)
    if ax2 is not None:
        ax2 = ax2 / np.maximum(np.linalg.norm(ax2, axis=1, keepdims=True), 1e-8)
    return H.Gaussians(
        mu=mu.astype(np.float32),
        normal=n.astype(np.float32),
        scale=g.scale,
        quat=H._quat_from_normal(n),
        color=g.color,
        alpha=g.alpha,
        pixel=g.pixel,
        axis1=None if ax1 is None else ax1.astype(np.float32),
        axis2=None if ax2 is None else ax2.astype(np.float32),
    )


def owner_from_raster(g: H.Gaussians, K: np.ndarray, shape: tuple[int, int]) -> np.ndarray:
    _, index, _ = H.rasterize_discs(g, K, shape)
    return index.astype(np.int32)


def warp_owner(owner: np.ndarray, u: np.ndarray, v: np.ndarray, valid: np.ndarray) -> np.ndarray:
    h, w = owner.shape
    out = np.full((h, w), -1, dtype=np.int32)
    ys, xs = np.where(valid & (owner >= 0))
    if xs.size == 0:
        return out
    x1 = np.clip(np.rint(xs + u[ys, xs]).astype(np.int32), 0, w - 1)
    y1 = np.clip(np.rint(ys + v[ys, xs]).astype(np.int32), 0, h - 1)
    out[y1, x1] = owner[ys, xs]
    return out



def _fill_owner_backward(owner_w, owner_src, sf):
    """If forward round missed, take identity from backward flow."""
    if sf.bw_u is None:
        return owner_w
    h, w = owner_w.shape
    xs_g, ys_g = np.meshgrid(np.arange(w, dtype=np.float32), np.arange(h, dtype=np.float32))
    x0 = xs_g + sf.bw_u
    y0 = ys_g + sf.bw_v
    inb = (x0 >= 0) & (x0 <= w - 1) & (y0 >= 0) & (y0 <= h - 1)
    x0i = np.clip(np.rint(x0).astype(np.int32), 0, w - 1)
    y0i = np.clip(np.rint(y0).astype(np.int32), 0, h - 1)
    src_id = owner_src[y0i, x0i]
    src_ok = inb & (src_id >= 0) & sf.valid[y0i, x0i]
    take = (owner_w < 0) & src_ok
    owner_w = owner_w.copy()
    owner_w[take] = src_id[take]
    return owner_w


def relink_projective(owner_w: np.ndarray, g: H.Gaussians, K: np.ndarray,
                      z1: np.ndarray, bgr1: np.ndarray, age: np.ndarray,
                      color_gate: bool = True,
                      center_only: bool = False) -> tuple[np.ndarray, int, int, int]:
    """Sparse projective re-link -- the identity chain, now with association gates.

    When a disc's owner pixels leave the FOV, its chained identity is broken:
    `warp_owner` + `_fill_owner_backward` both miss them, so that pixel re-surfaces
    as leftover and (once the camera comes back) gets stacked with a *new* disc.
    This step re-links such discs by projecting them into the current frame and
    re-claiming the pixels they cover -- no full-model ray-disc rasterisation
    (only the surviving candidates are projected).

    Coverage is the WHOLE footprint: a disc is a thin planar lamina, so projecting
    its boundary and filling the image ellipse puts back the coverage that the flow
    lost while the disc was out of view. Claiming only the centre pixel leaves the
    rest of the ellipse "unowned", so it re-births as an S2 fragment stacked on top
    of the disc that already draws it (the left-edge fragmentation). Only EMPTY
    pixels are written, so the flow-warped identity of what is already visible is
    never clobbered -- that "empty-only" rule is also what settles occlusion, since
    a surface hidden behind a nearer one is already owned. Far discs are filled
    first and nearer ones overwrite, so overlapping candidates settle front-most
    (one argsort on disc depth, not ray-disc intersection).

    Gates (both must pass for disc s -> pixel p):
      1. point-to-plane  : |(X_obs(p) - mu_s) . n_s| < k * sigma(z_obs). This is
                           the depth-consistency check written in world space: a
                           disc occluded by a nearer surface, or floating in front
                           of a farther one, produces a large signed plane residual
                           and is rejected (covers both occlusion directions). It
                           is evaluated at the projected CENTRE pixel.
      2. colour          : ||c(p) - c_s|| <= spatial texture std (RELINK_COLOR_GATE_K)
                           summed in quadrature with a temporal lighting term that
                           grows with the disc's age -- see color_gate_thresh. The
                           re-visited surface may shift colour between passes
                           (exposure drift), which the age term underwrites.

    Sparse pre-filters (not gates): the projected centre must land in-bounds, the
    destination pixel must hold a valid observed depth and still be empty.

    `center_only` restores the old one-pixel-per-disc behaviour (A/B control).

    Returns (owner_w, n_px_claimed, n_plane_fail, n_colour_fail): plane/colour fail
    counts are disjoint and sum with n_relinked to the number of gate candidates,
    so the colour gate's tightness can be read off directly.
    """
    h, w = owner_w.shape
    n = len(g)
    if n == 0:
        return owner_w, 0, 0, 0
    fx, fy, cx, cy = float(K[0, 0]), float(K[1, 1]), float(K[0, 2]), float(K[1, 2])
    mu = g.mu
    zc = mu[:, 2]
    px = fx * mu[:, 0] / np.maximum(zc, 1e-6) + cx
    py = fy * mu[:, 1] / np.maximum(zc, 1e-6) + cy
    pxi = np.rint(px).astype(np.int32)
    pyi = np.rint(py).astype(np.int32)
    inb = ((pxi >= 0) & (pxi < w) & (pyi >= 0) & (pyi < h)
           & (zc > Z_MIN) & (zc < Z_MAX))
    cand = np.flatnonzero(inb)
    if cand.size == 0:
        return owner_w, 0, 0, 0

    px_c = pxi[cand]
    py_c = pyi[cand]
    z_obs = z1[py_c, px_c]
    dest_ok = ((z_obs > Z_MIN) & (z_obs < Z_MAX) & (owner_w[py_c, px_c] < 0))
    cand = cand[dest_ok]
    if cand.size == 0:
        return owner_w, 0, 0, 0
    px_c = px_c[dest_ok]
    py_c = py_c[dest_ok]
    z_obs = z_obs[dest_ok]

    # Observed 3D point from the destination pixel's own depth.
    X_obs = np.stack(
        [(px_c - cx) * z_obs / fx, (py_c - cy) * z_obs / fy, z_obs], axis=1,
    )

    # gate 1: point-to-plane (== depth consistency, both occlusion directions)
    dist = point_to_plane(X_obs, g.mu[cand], g.normal[cand])
    g1 = dist < (K_SIGMA * depth_sigma(z_obs))
    n_plane_fail = int((~g1).sum())

    # gate 2: colour = texture (space, 9x9 std) + lighting (time, age-driven).
    if color_gate:
        rgb1 = bgr1[..., ::-1].astype(np.float32) / 255.0
        tex_sigma = np.sqrt(np.maximum(
            H.texture_variance(rgb1, win=9), COLOR_GATE_VAR_FLOOR,
        ))
        c_obs = rgb1[py_c, px_c]
        dcol = np.linalg.norm(c_obs - g.color[cand], axis=1)
        g2 = dcol <= color_gate_thresh(
            tex_sigma[py_c, px_c], age[cand], RELINK_COLOR_GATE_K,
        )
        n_colour_fail = int((g1 & ~g2).sum())
    else:
        g2 = np.ones_like(g1)
        n_colour_fail = 0

    ok = g1 & g2
    cand = cand[ok]
    if cand.size == 0:
        return owner_w, 0, n_plane_fail, n_colour_fail

    owner_w = owner_w.copy()
    if center_only:
        px_c = px_c[ok]
        py_c = py_c[ok]
        order = np.lexsort((cand, py_c, px_c))
        px_s = px_c[order]
        py_s = py_c[order]
        id_s = cand[order]
        flat = np.ravel_multi_index((py_s, px_s), (h, w))
        _, first = np.unique(flat, return_index=True)
        owner_w[py_s[first], px_s[first]] = id_s[first].astype(np.int32)
        return owner_w, int(first.size), n_plane_fail, n_colour_fail

    # Whole-footprint re-claim: project each candidate's disc boundary and fill.
    order = cand[np.argsort(-mu[cand, 2])]          # far first -> near overwrites
    buf = np.full((h, w), -1, dtype=np.int32)
    th = np.linspace(0.0, 2.0 * np.pi, 32, endpoint=False)
    cs = np.cos(th)[:, None]
    sn = np.sin(th)[:, None]
    for s in order:
        if g.axis1 is None or g.axis2 is None:
            owner_w[pyi[s], pxi[s]] = int(s)        # no axes: centre-pixel fallback
            continue
        P = (mu[s][None, :]
             + g.scale[s, 0] * cs * g.axis1[s][None, :]
             + g.scale[s, 1] * sn * g.axis2[s][None, :])
        pz = P[:, 2]
        if (pz <= 1e-6).any():
            continue
        u = fx * P[:, 0] / pz + cx
        v = fy * P[:, 1] / pz + cy
        x0 = max(int(np.floor(u.min())), 0)
        y0 = max(int(np.floor(v.min())), 0)
        x1 = min(int(np.ceil(u.max())), w - 1)
        y1 = min(int(np.ceil(v.max())), h - 1)
        if x1 < x0 or y1 < y0:
            continue
        poly = np.stack([u - x0, v - y0], axis=1).astype(np.int32)
        m = np.zeros((y1 - y0 + 1, x1 - x0 + 1), dtype=np.uint8)
        cv2.fillPoly(m, [poly], 1)
        sub = buf[y0:y1 + 1, x0:x1 + 1]
        sub[m > 0] = int(s)

    take = (owner_w < 0) & (buf >= 0)
    owner_w[take] = buf[take]
    return owner_w, int(take.sum()), n_plane_fail, n_colour_fail


# how far a leftover pixel searches for an old disc: the radius of a 9x9 window,
# matching the texture-variance aggregation window in the single-frame baseline.
ABSORB_NBR_R = 4  # (9x9 window) // 2


def point_to_plane(X: np.ndarray, mu: np.ndarray, n: np.ndarray) -> np.ndarray:
    return np.abs(np.einsum("ij,ij->i", X - mu, n))


def color_gate_thresh(sigma_tex: np.ndarray, age: np.ndarray, k: float) -> np.ndarray:
    """Colour-gate allowance = texture (space) and lighting (time) in quadrature.

    The old single gate `dcol <= k * sigma_tex` used the 9x9 *spatial* texture
    std to underwrite exposure drift too -- two different error sources sharing
    one threshold. A same-surface observation differs from a disc's stored colour
    by (a) the surface's spatial texture spread and (b) how far the lighting has
    drifted since the disc last updated (`age`, in frames). These are independent,
    so they add in quadrature; the temporal term grows with `age` and is bounded
    by `COLOR_LIGHT_MAX`.
    """
    light = np.minimum(COLOR_LIGHT_RATE * age, COLOR_LIGHT_MAX)
    return np.sqrt((k * sigma_tex) ** 2 + light ** 2)


def merge_absorbed_points(g: H.Gaussians, w_conf: np.ndarray,
                          w_col: np.ndarray, age: np.ndarray,
                          best: np.ndarray, Xp: np.ndarray, rgb: np.ndarray,
                          n_obs: np.ndarray, nvalid: np.ndarray,
                          sigma: np.ndarray) -> int:
    """Batch of `update_hits_onepoint`'s per-attribute merge, for the absorb path.

    Several absorbed pixels can fan into one disc per call, so the flow-hit
    running average is accumulated with np.add.at over `best`:

      mu     = (w_conf*mu + sum w_obs*X) / (w_conf + sum w_obs)   (w_obs=1/sigma^2)
      color  = (n_col*color + sum rgb) / (n_col + count), n_col = min(w_col, CAP)
      normal = normalize(w_conf*normal + sum n_obs)   # only where n_ok
      scale  = FROZEN -- a rigid static scene keeps a disc's world radius
               constant; growing it toward absorbed pixels was the growth half of
               the drift, exactly the logic update_hits_onepoint removed.

    quat / axis1 / axis2 are re-derived from the updated normal, identical to the
    flow-hit branch. age is reset to 0 on every touched disc. Returns n_touched.
    """
    n_all = len(g)
    w_obs = 1.0 / np.maximum(sigma ** 2, 1e-8)

    sum_x = np.zeros((n_all, 3), dtype=np.float64)
    sum_c = np.zeros((n_all, 3), dtype=np.float64)
    sum_wp = np.zeros(n_all, dtype=np.float64)
    sum_wc = np.zeros(n_all, dtype=np.float64)
    sum_n = np.zeros((n_all, 3), dtype=np.float64)
    sum_nc = np.zeros(n_all, dtype=np.float64)
    np.add.at(sum_x, best, Xp.astype(np.float64) * w_obs[:, None])
    np.add.at(sum_wp, best, w_obs)
    np.add.at(sum_c, best, rgb.astype(np.float64))
    np.add.at(sum_wc, best, 1.0)
    if nvalid.any():
        bv = best[nvalid]
        np.add.at(sum_n, bv, n_obs[nvalid].astype(np.float64))
        np.add.at(sum_nc, bv, 1.0)

    touched = sum_wp > 0
    if not touched.any():
        return 0

    # position: depth-confidence weighted running mean.
    den = w_conf[touched] + sum_wp[touched]
    g.mu[touched] = (
        (w_conf[touched, None] * g.mu[touched] + sum_x[touched]) / den[:, None]
    ).astype(np.float32)
    w_conf[touched] = den.astype(np.float32)

    # colour: capped observation-count running mean, decoupled from w_conf.
    col = sum_wc > 0
    n_col = np.minimum(w_col[col], COLOR_CONF_MAX)
    den_c = n_col + sum_wc[col]
    g.color[col] = (
        (n_col[:, None] * g.color[col] + sum_c[col]) / den_c[:, None]
    ).astype(np.float32)
    np.clip(g.color, 0.0, 1.0, out=g.color)
    w_col[col] = np.minimum(n_col + sum_wc[col], COLOR_CONF_MAX)

    # normal: unit-weighted running sum re-normalized, then re-derive the tangent
    # frame + quaternion (mirrors update_hits_onepoint).
    nupd = touched & (sum_nc > 0)
    if nupd.any():
        acc = w_conf[nupd, None] * g.normal[nupd] + sum_n[nupd]
        accn = np.linalg.norm(acc, axis=1, keepdims=True)
        g.normal[nupd] = (acc / np.maximum(accn, 1e-12)).astype(np.float32)
        if g.axis1 is not None and g.axis2 is not None:
            a1 = g.axis1[nupd] - np.einsum(
                "ij,ij->i", g.axis1[nupd], g.normal[nupd],
            )[:, None] * g.normal[nupd]
            a1 /= np.maximum(np.linalg.norm(a1, axis=1, keepdims=True), 1e-12)
            a2 = np.cross(g.normal[nupd], a1)
            a2 /= np.maximum(np.linalg.norm(a2, axis=1, keepdims=True), 1e-12)
            g.axis1[nupd] = a1.astype(np.float32)
            g.axis2[nupd] = a2.astype(np.float32)
            g.quat[nupd] = H._quat_from_frame(a1, a2, g.normal[nupd]).astype(np.float32)

    age[touched] = 0
    return int(touched.sum())


def absorb_leftover_pixels(
    g: H.Gaussians,
    w_conf: np.ndarray,
    w_col: np.ndarray,
    age: np.ndarray,
    leftover: np.ndarray,
    owner: np.ndarray,
    z1: np.ndarray,
    bgr1: np.ndarray,
    K: np.ndarray,
    geo: H.CurvatureGeometry,
):
    """Light-weight per-pixel absorb of leftover strips into neighbour discs.

    "先判后建": a leftover pixel is either folded into an existing neighbour disc
    (the same per-attribute merge algebra as the flow-hit branch, see
    merge_absorbed_points), or left alone so `build_hybrid_region` materialises it
    as a new disc. position / colour / normal are running-averaged exactly like
    update_hits_onepoint; the disc's scale (radius) is LEFT FROZEN -- folding a
    leftover pixel in refines the disc it lands on, it never grows it.

    Gates, in order (all must pass for pixel p -> disc s):
      1. co-planar   : point-to-plane(p, s) < k * sigma(z)
      2. radius      : tangential offset of p on s's plane <= r_k(p), the
                       curvature sagitta budget r_k(p)=sqrt(2 eps/|k|) -- the
                       radius a flat disc may legally grow to at p. This is the
                       core gate: it separates "flat strip, absorb" from
                       "high-curvature pixel, build its own small disc".
      3. colour      : ||c(p) - c(s)|| <= k * local 9x9 texture sigma -- a flat
                       texture boundary (poster vs wall) has flat depth so gates
                       1-2 pass, yet it must NOT be absorbed across colours. No
                       lighting/age term here: p and s are co-located in the SAME
                       frame, so lighting is common-mode and cancels -- this is a
                       purely spatial same-surface check.
    No normal-angle gate: the flow identity already carries the geometry (see
    OPEN_ITEMS §1.1); these leftover pixels have NO flow identity, so the
    point-to-plane distance is the only orientation check. A pixel that sat on
    the disc's plane surrounds p with the same normal anyway once the sagitta
    gate shrinks r_k on curved strips.

    Returns (absorbed, n_absorbed, n_color_reject): `absorbed` (bool HxW) flags
    the folded pixels, n_absorbed is their count, n_color_reject is the subset
    of leftover pixels that had a neighbour passing gates 1+2 but were rejected
    by colour only (the colour gate's own over-fire count). Updates `g.mu` /
    `g.color` / `g.normal` / `g.quat` / `g.axis1` / `g.axis2` (scale frozen) and
    `w_conf` in place; only the touched discs are written.
    """
    h, w = leftover.shape
    ys, xs = np.where(leftover)
    if ys.size == 0:
        return np.zeros_like(leftover), 0, 0

    n_all = len(g)
    X1 = H.backproject(z1, K)          # (H, W, 3)

    # r_k1 came from the caller's shared geometry (`geo`), the same field
    # `build_hybrid_region` reuses -- NOT recomputed here (OPEN_ITEMS §1.6.5).
    r_k = geo.r_k1

    # Neighbour discs per leftover pixel: ALL owners inside the (2R+1)x(2R+1)
    # window, R = ABSORB_NBR_R -- the same footprint as the 9x9 texture-variance
    # box the colour gate uses. Among candidates passing all three gates, take
    # the one with the smallest in-plane (tangential) offset d_proj, the exact
    # quantity the disc footprint growth consumes. Not the first box hit (that
    # had a top-left bias), and not full 3D Euclidean distance (that mixes in
    # the out-of-plane residual gate 1 already budgets separately).
    rgb1 = bgr1[..., ::-1].astype(np.float32) / 255.0
    Xp = X1[ys, xs]                        # (P,3) leftover points
    sig_p = depth_sigma(z1[ys, xs])        # (P,) gate-1 budget
    rk_p = r_k[ys, xs]                     # (P,) gate-2 budget (sagitta)
    rgb_p = rgb1[ys, xs]                   # (P,3) leftover colour
    sigma_tex = np.sqrt(np.maximum(
        H.texture_variance(rgb1, win=9)[ys, xs], COLOR_GATE_VAR_FLOOR,
    ))                                     # (P,) gate-3 spatial texture budget

    best = np.full(xs.shape[0], -1, dtype=np.int32)
    best_d = np.full(xs.shape[0], np.inf, dtype=np.float32)
    has_nbr = np.zeros(xs.shape[0], dtype=bool)
    g12_seen = np.zeros(xs.shape[0], dtype=bool)   # any neighbour passed gates 1+2
    for dy in range(-ABSORB_NBR_R, ABSORB_NBR_R + 1):
        for dx in range(-ABSORB_NBR_R, ABSORB_NBR_R + 1):
            if dy == 0 and dx == 0:
                continue
            ny = ys + dy
            nx = xs + dx
            inb = (ny >= 0) & (ny < h) & (nx >= 0) & (nx < w)
            cand = np.full(xs.shape[0], -1, dtype=np.int32)
            cand[inb] = owner[ny[inb], nx[inb]]
            has = inb & (cand >= 0)
            has_nbr |= has
            if not has.any():
                continue
            idx = np.flatnonzero(has)
            c = cand[idx]
            mu_c = g.mu[c]
            n_c = g.normal[c]
            # gate 1: point-to-plane
            d1 = point_to_plane(Xp[idx], mu_c, n_c)
            g1 = d1 < (K_SIGMA * sig_p[idx])
            # gate 2: tangential offset within the sagitta budget
            off = Xp[idx] - mu_c
            off_t = off - np.einsum("ij,ij->i", off, n_c)[:, None] * n_c
            d2 = np.linalg.norm(off_t, axis=1)
            g2 = d2 <= rk_p[idx]
            # gate 3: colour -- spatial texture only (same-frame adjacency, lighting common-mode)
            d3 = np.linalg.norm(rgb_p[idx] - g.color[c], axis=1)
            g3 = d3 <= (COLOR_GATE_K * sigma_tex[idx])
            g12_seen[idx] |= (g1 & g2)
            ok = g1 & g2 & g3
            if not ok.any():
                continue
            i_ok = idx[ok]
            d_ok = d2[ok]
            improve = d_ok < best_d[i_ok]
            best[i_ok[improve]] = c[ok][improve]
            best_d[i_ok[improve]] = d_ok[improve]

    n_absorbed = int((best >= 0).sum())
    n_no_nbr = int((~has_nbr).sum())
    n_reject = int((has_nbr & (best < 0)).sum())
    n_color_reject = int((g12_seen & (best < 0)).sum())
    print(f"[absorb-debug] n_leftover={xs.size} no_nbr={n_no_nbr} "
          f"reject={n_reject} pass={n_absorbed} color_reject={n_color_reject}",
          flush=True)

    have = best >= 0
    if not have.any():
        return np.zeros_like(leftover), 0, n_color_reject

    ys, xs, best = ys[have], xs[have], best[have]
    Xp = Xp[have]

    # Merge with the flow-hit algebra (batch): position/colour/normal running
    # average, scale frozen. Folding a leftover pixel in refines the disc it
    # lands on -- it never grows the disc's radius.
    merge_absorbed_points(
        g, w_conf, w_col, age, best, Xp, rgb1[ys, xs],
        geo.normal[ys, xs], geo.n_ok[ys, xs], depth_sigma(z1[ys, xs]),
    )

    absorbed = np.zeros_like(leftover)
    absorbed[ys, xs] = True
    # register absorbed pixels as owned by their neighbour disc, so next frame's
    # flow warp carries their identity (otherwise they would re-surface as
    # leftover and need re-absorbing every frame).
    owner[ys, xs] = best
    return absorbed, int(xs.size), n_color_reject


# Per-leftover-pixel classification of *why* no existing disc claimed the pixel.
# Same neighbour window / gates as absorb_leftover_pixels (point-to-plane ->
# sagitta radius -> colour), but classification only: nothing is folded in.
LEFT_NBR_NO = 0      # no owner disc inside the (2R+1)^2 window
LEFT_NBR_PLANE = 1   # neighbour(s) exist, all failed point-to-plane
LEFT_NBR_RADIUS = 2  # some passed plane, all failed the sagitta radius budget
LEFT_NBR_COLOUR = 3  # some passed plane+radius, all failed the colour gate
LEFT_NBR_PASS = 4    # a neighbour passed all three (absorb would have taken it)


def classify_leftover_neighbours(
    g: H.Gaussians,
    owner: np.ndarray,
    leftover: np.ndarray,
    z1: np.ndarray,
    bgr1: np.ndarray,
    K: np.ndarray,
    geo: H.CurvatureGeometry,
):
    """Per-leftover-pixel absorb-gate outcome against the *existing* owner map.

    Diagnostics only (default-off path in `fuse_frame`): for every leftover pixel
    it answers "which gate rejected the old disc that sits next to me", so a new
    disc's birth can be attributed. Returns `(cls (H,W) int8, nbr_dcol (H,W)
    float32, nbr_covered (H,W) bool)`; `nbr_dcol` is the colour distance to the
    nearest plane+radius-passing neighbour (nan where none), i.e. the gap the
    colour gate saw. `nbr_covered` says whether that same neighbour's ACTUAL
    (frozen) ellipse already contains the pixel -- if so a newborn disc there
    over-draws an old disc that would have rendered the pixel anyway.
    """
    h, w = leftover.shape
    cls = np.full((h, w), LEFT_NBR_NO, dtype=np.int8)
    nbr_dcol = np.full((h, w), np.nan, dtype=np.float32)
    nbr_covered = np.zeros((h, w), dtype=bool)
    ys, xs = np.where(leftover)
    if ys.size == 0:
        return cls, nbr_dcol, nbr_covered
    X1 = H.backproject(z1, K)
    r_k = geo.r_k1
    rgb1 = bgr1[..., ::-1].astype(np.float32) / 255.0
    Xp = X1[ys, xs]
    sig_p = depth_sigma(z1[ys, xs])
    rk_p = r_k[ys, xs]
    rgb_p = rgb1[ys, xs]
    sigma_tex = np.sqrt(np.maximum(
        H.texture_variance(rgb1, win=9)[ys, xs], COLOR_GATE_VAR_FLOOR,
    ))

    has_nbr = np.zeros(ys.size, dtype=bool)
    plane_seen = np.zeros(ys.size, dtype=bool)
    g12_seen = np.zeros(ys.size, dtype=bool)
    pass_seen = np.zeros(ys.size, dtype=bool)
    best_dcol = np.full(ys.size, np.inf, dtype=np.float32)
    best_c = np.full(ys.size, -1, dtype=np.int32)      # nearest g12-passing owner
    best_d2 = np.full(ys.size, np.inf, dtype=np.float32)

    for dy in range(-ABSORB_NBR_R, ABSORB_NBR_R + 1):
        for dx in range(-ABSORB_NBR_R, ABSORB_NBR_R + 1):
            if dy == 0 and dx == 0:
                continue
            ny, nx = ys + dy, xs + dx
            inb = (ny >= 0) & (ny < h) & (nx >= 0) & (nx < w)
            cand = np.full(ys.size, -1, dtype=np.int32)
            cand[inb] = owner[ny[inb], nx[inb]]
            has = inb & (cand >= 0)
            has_nbr |= has
            if not has.any():
                continue
            idx = np.flatnonzero(has)
            c = cand[idx]
            n_c = g.normal[c]
            g1 = point_to_plane(Xp[idx], g.mu[c], n_c) < (K_SIGMA * sig_p[idx])
            plane_seen[idx] |= g1
            off = Xp[idx] - g.mu[c]
            off_t = off - np.einsum("ij,ij->i", off, n_c)[:, None] * n_c
            d2 = np.linalg.norm(off_t, axis=1)
            g12 = g1 & (d2 <= rk_p[idx])
            g12_seen[idx] |= g12
            d3 = np.linalg.norm(rgb_p[idx] - g.color[c], axis=1)
            np.minimum.at(best_dcol, idx, np.where(g12, d3, np.inf))
            pass_seen[idx] |= g12 & (d3 <= (COLOR_GATE_K * sigma_tex[idx]))
            d2m = np.where(g12, d2, np.inf).astype(np.float32)
            upd = d2m < best_d2[idx]
            best_c[idx[upd]] = c[upd]
            best_d2[idx[upd]] = d2m[upd]

    # does the nearest plane+radius-passing neighbour's own ellipse already
    # contain the pixel? (frozen radius => an absorbed pixel is not necessarily
    # drawn by the old disc)
    covered = np.zeros(ys.size, dtype=bool)
    has_best = best_c >= 0
    if has_best.any():
        bb = best_c[has_best]
        offb = Xp[has_best] - g.mu[bb]
        if g.axis1 is not None and g.axis2 is not None:
            ra = np.maximum(g.scale[bb, 0].astype(np.float64), 1e-9)
            rb = np.maximum(g.scale[bb, 1].astype(np.float64), 1e-9)
            pa = np.einsum("ij,ij->i", offb, g.axis1[bb]) / ra
            pb = np.einsum("ij,ij->i", offb, g.axis2[bb]) / rb
            covered[has_best] = (pa * pa + pb * pb) <= 1.0
        else:
            r = np.maximum(g.scale[bb, 0].astype(np.float64), 1e-9)
            covered[has_best] = np.linalg.norm(offb, axis=1) <= r

    cls[ys[has_nbr], xs[has_nbr]] = LEFT_NBR_PLANE
    cls[ys[plane_seen], xs[plane_seen]] = LEFT_NBR_RADIUS
    cls[ys[g12_seen], xs[g12_seen]] = LEFT_NBR_COLOUR
    cls[ys[pass_seen], xs[pass_seen]] = LEFT_NBR_PASS
    nbr_dcol[ys, xs] = best_dcol
    nbr_covered[ys, xs] = covered
    return cls, nbr_dcol, nbr_covered


def owner_birth_map(owner: np.ndarray, birth: np.ndarray) -> np.ndarray:
    """Per-pixel disc birth frame: birth[owner[y,x]], -1 where owner is empty.

    Convenience for the common `owner -> disc id -> birth` double index
    (visualisation, revisit/relayer analysis) without scattering `birth[owner]`
    everywhere. Returns int32 (H, W); caller must not read birth on the -1 cell.
    """
    h, w = owner.shape[:2]
    out = np.full((h, w), -1, dtype=np.int32)
    owned = owner >= 0
    out[owned] = birth[np.clip(owner[owned], 0, len(birth) - 1)]
    return out


def fuse_footprint_color(
    g: H.Gaussians,
    w_col: np.ndarray,
    age: np.ndarray,
    owner_w: np.ndarray,
    z1: np.ndarray,
    rgb1: np.ndarray,
    tex_sigma: np.ndarray,
    K: np.ndarray,
) -> int:
    """Fuse EVERY owned pixel of a disc as one colour observation.

    Keller / ElasticFusion splat the model into an index map and fuse every pixel
    that lands on a surfel, so a disc's colour confidence counts *pixel*
    observations and saturates within a frame or two. The hit path used to feed a
    single flow-tracked centre pixel per disc per frame, which both lags the
    exposure drift (memory is COLOR_CONF_MAX frames) and is noisy where the
    surface is flat. Counting pixels is the same statistic the absorb path
    (`merge_absorbed_points`) already uses. Geometry is not touched here:
    position / normal stay on the one-point-per-disc rule; only the colour
    running average and its confidence count come from the footprint.
    """
    n = len(g)
    fx, fy, cx, cy = float(K[0, 0]), float(K[1, 1]), float(K[0, 2]), float(K[1, 2])
    d = owner_w
    valid = (d >= 0) & (z1 > Z_MIN) & (z1 < Z_MAX)
    if not valid.any():
        return 0
    py, px = np.nonzero(valid)
    di = d[py, px].astype(np.int64)
    zi = z1[py, px]
    Xp = np.stack(
        [(px - cx) * zi / fx, (py - cy) * zi / fy, zi], axis=1,
    ).astype(np.float32)
    geo = point_to_plane(Xp, g.mu[di], g.normal[di]) < (K_SIGMA * depth_sigma(zi))
    if not geo.any():
        return 0
    di, py, px = di[geo], py[geo], px[geo]
    rgb_p = rgb1[py, px]
    dcol = np.linalg.norm(rgb_p - g.color[di], axis=1)
    col = dcol <= color_gate_thresh(tex_sigma[py, px], age[di], COLOR_GATE_K)
    if not col.any():
        return 0
    di, rgb_p = di[col], rgb_p[col]

    cnt = np.bincount(di, minlength=n).astype(np.float32)
    sum_c = np.zeros((n, 3), dtype=np.float64)
    np.add.at(sum_c, di, rgb_p.astype(np.float64))
    upd = cnt > 0
    n_col = np.minimum(w_col[upd], COLOR_CONF_MAX)
    den = n_col + cnt[upd]
    g.color[upd] = (
        (n_col[:, None] * g.color[upd] + sum_c[upd]) / den[:, None]
    ).astype(np.float32)
    np.clip(g.color, 0.0, 1.0, out=g.color)
    w_col[upd] = np.minimum(n_col + cnt[upd], COLOR_CONF_MAX)
    return int(upd.sum())


def update_hits_onepoint(
    g: H.Gaussians,
    prev_mu: np.ndarray,
    w_conf: np.ndarray,
    w_col: np.ndarray,
    age: np.ndarray,
    sf,
    z1: np.ndarray,
    bgr1: np.ndarray,
    K: np.ndarray,
    normal_field: np.ndarray,
    n_ok: np.ndarray,
    owner_w: np.ndarray,
) -> tuple[int, int, int]:
    """One point per disc per frame (anti-drift hit update).

    Iterates over existing discs -- NOT over owner pixels. For each disc the
    previous-frame centre is flow-tracked to the current frame, and that single
    pixel supplies one depth/normal observation which is cross-frame
    running-averaged. Same-frame region weighting is removed, so the crescent
    coverage of a small edge disc can no longer drag its centre directionally
    (that centroid pull was the directional-drift root cause). Colour is the
    exception: it is written by `fuse_footprint_color`, which fuses the disc's
    whole owned footprint, before the geometry gates below.

    Updated in place: g.mu (position), g.normal, plus the tangent frame and
    quaternion re-derived from the new normal. g.scale (radius) is left frozen: a
    rigid static scene keeps a surface patch's world radius constant, and the old
    "grow radius toward the observations" logic was the growth half of the drift.
    w_conf / age accumulate exactly as before.

    Returns (n_upd, n_gate_fail, n_cand, n_color_fail, dcol_g1_med, dcol_g1_p90):
    n_cand is the number of
    discs whose centre tracked to a valid-depth pixel, n_gate_fail the subset
    failing the point-to-plane / colour gates, n_color_fail the subset that
    PASSED point-to-plane but was rejected by colour only (g1 & ~g2) -- the
    colour gate's own over-fire count -- and n_upd the subset actually written.
    dcol_g1_med / dcol_g1_p90 are the median / 90th-percentile of the
    observation-to-disc colour distance over the point-to-plane-passing
    candidates (the exposure-drift signal, nan when there are none). The gates
    and these probes stay on the centre point so the numbers remain comparable
    with the drift measurements in OPEN_ITEMS §9; they decide the geometry write
    only, colour no longer rides on them.
    """
    n = len(g)
    if n == 0:
        return 0, 0, 0, 0, float("nan"), float("nan")
    h, w = z1.shape
    fx, fy, cx, cy = float(K[0, 0]), float(K[1, 1]), float(K[0, 2]), float(K[1, 2])

    # Previous-frame centre pixel, then forward-flow it to the current frame.
    zc = prev_mu[:, 2]
    px = fx * prev_mu[:, 0] / np.maximum(zc, 1e-6) + cx
    py = fy * prev_mu[:, 1] / np.maximum(zc, 1e-6) + cy
    pxi = np.rint(px).astype(np.int32)
    pyi = np.rint(py).astype(np.int32)
    inb = (pxi >= 0) & (pxi < w) & (pyi >= 0) & (pyi < h)
    pxi_c = np.clip(pxi, 0, w - 1)
    pyi_c = np.clip(pyi, 0, h - 1)
    cu = px + sf.u[pyi_c, pxi_c]
    cv = py + sf.v[pyi_c, pxi_c]
    fok = inb & sf.valid[pyi_c, pxi_c]
    cxi = np.rint(cu).astype(np.int32)
    cyi = np.rint(cv).astype(np.int32)
    cok = fok & (cxi >= 0) & (cxi < w) & (cyi >= 0) & (cyi < h)

    z_obs = np.zeros(n, dtype=np.float32)
    z_obs[cok] = z1[cyi[cok], cxi[cok]]
    dok = cok & (z_obs > Z_MIN) & (z_obs < Z_MAX)
    n_cand = int(dok.sum())

    rgb1 = bgr1[..., ::-1].astype(np.float32) / 255.0
    tex_sigma = np.sqrt(np.maximum(
        H.texture_variance(rgb1, win=9), COLOR_GATE_VAR_FLOOR,
    ))

    # Colour is written here, from the disc's whole owned footprint, and does not
    # depend on the centre pixel having tracked -- so it runs before the early
    # return. Everything below decides the geometry write.
    fuse_footprint_color(g, w_col, age, owner_w, z1, rgb1, tex_sigma, K)

    if n_cand == 0:
        return 0, 0, 0, 0, float("nan"), float("nan")

    idx = np.flatnonzero(dok)
    zi = z_obs[idx]
    X1 = np.stack(
        [(cxi[idx] - cx) * zi / fx, (cyi[idx] - cy) * zi / fy, zi], axis=1,
    )

    # gates: point-to-plane, then colour = texture (space) + lighting (time).
    dist = point_to_plane(X1, g.mu[idx], g.normal[idx])
    g1 = dist < (K_SIGMA * depth_sigma(zi))
    rgb_obs = rgb1[cyi[idx], cxi[idx]]
    dcol = np.linalg.norm(rgb_obs - g.color[idx], axis=1)
    g2 = dcol <= color_gate_thresh(
        tex_sigma[cyi[idx], cxi[idx]], age[idx], COLOR_GATE_K,
    )

    ok = g1 & g2
    n_gate_fail = int((~ok).sum())
    n_color_fail = int((g1 & ~g2).sum())
    n_upd = int(ok.sum())

    # Observation-to-disc colour distance over the geometry-passing candidates:
    # the exposure-drift / texture-mismatch signal the colour gate actually sees.
    dcol_g1 = dcol[g1]
    dcol_g1_med = float(np.median(dcol_g1)) if dcol_g1.size else float("nan")
    dcol_g1_p90 = float(np.percentile(dcol_g1, 90)) if dcol_g1.size else float("nan")

    if n_upd == 0:
        return 0, n_gate_fail, n_cand, n_color_fail, dcol_g1_med, dcol_g1_p90

    s = idx[ok]
    zi = zi[ok]
    w_obs = 1.0 / np.maximum(depth_sigma(zi) ** 2, 1e-8)

    # position: depth-confidence weighted cross-frame running average.
    den = w_conf[s] + w_obs
    g.mu[s] = (
        (w_conf[s, None] * g.mu[s] + w_obs[:, None] * X1[ok]) / den[:, None]
    ).astype(np.float32)
    w_conf[s] = den.astype(np.float32)

    # normal: unit-weighted cumulative average from the per-frame 3x3 Sobel look-
    # up, then re-derive the tangent frame + quaternion from the new normal.
    n_obs = normal_field[cyi[s], cxi[s]]
    nvalid = n_ok[cyi[s], cxi[s]]
    if nvalid.any():
        ss = s[nvalid]
        acc = w_conf[ss, None] * g.normal[ss] + n_obs[nvalid]
        accn = np.linalg.norm(acc, axis=1, keepdims=True)
        g.normal[ss] = (acc / np.maximum(accn, 1e-12)).astype(np.float32)
        if g.axis1 is not None and g.axis2 is not None:
            a1 = g.axis1[ss] - np.einsum(
                "ij,ij->i", g.axis1[ss], g.normal[ss],
            )[:, None] * g.normal[ss]
            a1 /= np.maximum(np.linalg.norm(a1, axis=1, keepdims=True), 1e-12)
            a2 = np.cross(g.normal[ss], a1)
            a2 /= np.maximum(np.linalg.norm(a2, axis=1, keepdims=True), 1e-12)
            g.axis1[ss] = a1.astype(np.float32)
            g.axis2[ss] = a2.astype(np.float32)
            g.quat[ss] = H._quat_from_frame(a1, a2, g.normal[ss]).astype(np.float32)

    age[s] = 0
    return n_upd, n_gate_fail, n_cand, n_color_fail, dcol_g1_med, dcol_g1_p90


def fuse_frame(
    model: Model,
    sf,
    z0: np.ndarray,
    z1: np.ndarray,
    bgr1: np.ndarray,
    K: np.ndarray,
    age_max: int,
    w_min: float,
    frame_idx: int,
    R_10: np.ndarray | None = None,
    t_10: np.ndarray | None = None,
    no_absorb: bool = False,
    no_relink: bool = False,
    relink_color_gate: bool = True,
    relink_center_only: bool = False,
    diag_newborn: bool = False,
) -> dict:
    h, w = z0.shape
    fx, fy, cx, cy = float(K[0, 0]), float(K[1, 1]), float(K[0, 2]), float(K[1, 2])
    if R_10 is None or t_10 is None:
        if sf.xi is None:
            raise RuntimeError("scene flow produced no twist")
        R_10, t_10 = se3_exp(sf.xi)
    g = transform_to_next(model.g, R_10, t_10)
    n_old = len(g)
    w_conf = model.w.copy()
    w_col = model.w_col.copy()
    age = model.age.copy() + 1
    birth = model.birth.copy()
    birth_color = model.birth_color.copy() if model.birth_color is not None else g.color.copy()

    owner_w = warp_owner(model.owner, sf.u, sf.v, sf.valid)
    expanded = sf.expanded if sf.expanded is not None else np.zeros((h, w), dtype=bool)
    owner_w = _fill_owner_backward(owner_w, model.owner, sf)
    n_relink = 0
    n_relink_pfail = 0
    n_relink_cfail = 0
    if not no_relink:
        owner_w, n_relink, n_relink_pfail, n_relink_cfail = relink_projective(
            owner_w, g, K, z1, bgr1, age, relink_color_gate,
            center_only=relink_center_only,
        )

    # Shared geometry is computed once per frame and reused by both the hit
    # normal lookup and the leftover branch (S2/absorb/curvature).
    geo = H.compute_scene_geometry(
        z1, K, H.GEO_CFG["eps"], H.GEO_CFG["gauss_sigma"], H.GEO_CFG["disc_rel"],
    )
    n_upd, n_gate_fail, n_cand, n_color_fail, dcol_med, dcol_p90 = update_hits_onepoint(
        g, model.g.mu, w_conf, w_col, age, sf, z1, bgr1, K, geo.normal, geo.n_ok,
        owner_w,
    )

    owned = owner_w >= 0
    leftover = (z1 > Z_MIN) & (z1 < Z_MAX) & ~owned
    hit = owned
    n_new = 0
    n_absorb = 0
    n_absorb_color_fail = 0
    new_px = np.zeros((0, 2), np.int32)
    n_s2 = 0
    n_curv = 0
    owner_curv = None
    left_cls = None
    left_dcol = None
    left_covered = None

    # Leftover re-order: (1) S2 fill the texture part, (2) absorb what remains
    # into old/S2 discs, (3) curvature fill the still-uncovered non-texture part.
    # Geometry / texture mask / r_cap are computed once and shared by all three
    # stages (the r_k1 the absorb gates reuse lives inside `geo`).
    if leftover.any():
        n_leftover = int(leftover.sum())
        if diag_newborn:
            # Attribute each new disc's birth to the absorb gate that rejected the
            # nearest *existing* disc (old model only, before S2 claims anything).
            left_cls, left_dcol, left_covered = classify_leftover_neighbours(
                g, owner_w, leftover, z1, bgr1, K, geo,
            )
        tex_mask_full = H.texture_mask(
            bgr1[..., ::-1].astype(np.float32) / 255.0, TEX_Q,
        )
        r_cap = H.tex_boundary_limit(z1, K, tex_mask_full, tol_px=TEX_BOUNDARY_TOL_PX)

        # Grazing-angle bias: non-texture leftover pixels whose surface is seen at
        # grazing angle (|n_z| < H.GRAZE_NZ_THRESH) have unreliable texture, so
        # they are routed to S2 instead of a curvature disc whose radius can
        # diverge at the FOV edge. `graze` is restricted to the curvature
        # candidates over the leftover region (the discs that would otherwise be
        # curvature), then OR'd into the S2 mask of stage (1).
        s2_mask = tex_mask_full
        if H.GRAZE_BIAS_S2:
            graze_cand = INC.select_seeds_region(z1, K, leftover, r_cap, geo)
            graze = graze_cand & ~tex_mask_full & H.grazing_mask(geo)
            if graze.any():
                s2_mask = tex_mask_full | graze

        # (1) S2 fill.
        g_s2, owner_s2 = INC.s2_parts(bgr1, z1, K, s2_mask, leftover, geo)
        n_s2 = len(g_s2)
        owner_abs = owner_w.astype(np.int32).copy()
        if n_s2:
            s2_glob = np.where(owner_s2 >= 0, n_old + owner_s2, -1).astype(np.int32)
            owner_abs = np.where(s2_glob >= 0, s2_glob, owner_abs)
            g = H.concatenate_gaussians([g, g_s2])
            w_conf = np.concatenate([w_conf, np.ones(n_s2, dtype=np.float32)])
            w_col = np.concatenate([w_col, np.ones(n_s2, dtype=np.float32)])
            age = np.concatenate([age, np.zeros(n_s2, dtype=np.int32)])
            birth = np.concatenate([birth, np.full(n_s2, frame_idx, dtype=np.int32)])
            birth_color = np.concatenate([birth_color, g_s2.color.astype(np.float32)])

        # (2) absorb the pixels not owned by old or S2 discs.
        remaining = leftover & ~(owner_abs >= 0)
        if not no_absorb and remaining.any():
            absorbed, n_absorb, n_absorb_color_fail = absorb_leftover_pixels(
                g, w_conf, w_col, age, remaining, owner_abs, z1, bgr1, K, geo,
            )
            if n_absorb:
                remaining = remaining & ~absorbed

        # (3) curvature fill on the still-uncovered non-texture leftover.
        g_curv, owner_curv = INC.curvature_parts(
            bgr1, z1, K, remaining, tex_mask_full, geo, r_cap,
        )
        n_curv = len(g_curv)
        if n_curv:
            g = H.concatenate_gaussians([g, g_curv])
            w_conf = np.concatenate([w_conf, np.ones(n_curv, dtype=np.float32)])
            w_col = np.concatenate([w_col, np.ones(n_curv, dtype=np.float32)])
            age = np.concatenate([age, np.zeros(n_curv, dtype=np.int32)])
            birth = np.concatenate([birth, np.full(n_curv, frame_idx, dtype=np.int32)])
            birth_color = np.concatenate([birth_color, g_curv.color.astype(np.float32)])

        n_new = n_s2 + n_curv
        if n_new:
            if n_s2 and n_curv:
                new_px = np.vstack([g_s2.pixel, g_curv.pixel]).astype(np.int32)
            elif n_s2:
                new_px = g_s2.pixel.copy()
            else:
                new_px = g_curv.pixel.copy()
        else:
            new_px = np.zeros((0, 2), np.int32)
    else:
        n_leftover = 0
        owner_abs = owner_w.astype(np.int32).copy()

    new_reason = None
    new_nbr_dcol = None
    new_nbr_covered = None
    if diag_newborn and left_cls is not None and new_px.shape[0]:
        ny = new_px[:, 1].astype(np.int64)
        nx = new_px[:, 0].astype(np.int64)
        new_reason = left_cls[ny, nx].astype(np.int8)
        new_nbr_dcol = left_dcol[ny, nx].astype(np.float32)
        new_nbr_covered = left_covered[ny, nx].astype(bool)

    # Indexed owner (n -> n+1): flow-warped identity (+ absorbed pixels, which
    # `absorb_leftover_pixels` registers directly into `owner_abs`) + new discs'
    # claim footprints. S2 discs precede curvature discs, so curvature ids are
    # offset past the S2 block. No ray-disc, no full-model rasterize_discs.
    owner_pre = owner_abs.astype(np.int32).copy()
    if n_curv and owner_curv is not None:
        curv_glob = np.where(owner_curv >= 0, n_old + n_s2 + owner_curv, -1).astype(np.int32)
        take = (curv_glob >= 0) & (owner_pre < 0)
        owner_pre[take] = curv_glob[take]

    n_pre = len(g)
    dead = (age > age_max) & (w_conf < w_min)
    if dead.any() and (~dead).sum() >= 8:
        keep = ~dead
        remap = np.full(n_pre, -1, dtype=np.int32)
        remap[keep] = np.arange(int(keep.sum()), dtype=np.int32)
        g = _subset(g, keep)
        w_conf = w_conf[keep]
        w_col = w_col[keep]
        age = age[keep]
        birth = birth[keep]
        birth_color = birth_color[keep]
        valid_owner = owner_pre >= 0
        owner = np.where(
            valid_owner, remap[np.clip(owner_pre, 0, n_pre - 1)], -1
        ).astype(np.int32)
    else:
        owner = owner_pre

    model.g, model.w, model.w_col, model.age, model.owner = g, w_conf, w_col, age, owner
    model.birth = birth
    model.birth_color = birth_color
    depth_valid = (z1 > Z_MIN) & (z1 < Z_MAX)
    n_owned = int(np.sum((owner >= 0) & depth_valid))
    return {
        "n": len(g),
        "n_upd": n_upd,
        "n_new": n_new,
        "n_s2": n_s2,
        "n_curv": n_curv,
        "n_absorb": n_absorb,
        "n_relink": int(n_relink),
        "n_relink_plane_fail": int(n_relink_pfail),
        "n_relink_color_fail": int(n_relink_cfail),
        "n_leftover": n_leftover,
        "n_gate_fail": n_gate_fail,
        "n_color_fail": int(n_color_fail),
        "n_absorb_color_fail": int(n_absorb_color_fail),
        "n_owned": n_owned,
        "n_cand": int(n_cand),
        "dcol_med": dcol_med,
        "dcol_p90": dcol_p90,
        "valid_frac": float(sf.valid.mean()),
        "expanded_frac": float(expanded.mean()),
        "leftover_frac": float(leftover.mean()),
        "n_dead": int(dead.sum()) if dead.size else 0,
        "leftover": leftover,
        "new_px": new_px,
        "new_reason": new_reason,
        "new_nbr_dcol": new_nbr_dcol,
        "new_nbr_covered": new_nbr_covered,
        "hit": hit,
        "owner_final": owner,          # (H, W) int32; -1 empty
        "birth": birth,                # (N,) birth frame per disc
        "z1": z1,                      # for backprojecting the viz in-world
    }



def _draw_new(bgr, leftover, hit, new_px, rec) -> np.ndarray:
    vis = bgr.copy()
    overlay = vis.astype(np.float32)
    leftover_bgr = (0, 160, 255)
    new_bgr = (0, 0, 255)
    m = leftover
    overlay[m] = 0.45 * overlay[m] + 0.55 * np.array(leftover_bgr, np.float32)
    vis = np.clip(overlay, 0, 255).astype(np.uint8)
    for u, v in new_px:
        cv2.circle(vis, (int(u), int(v)), 2, new_bgr, -1, lineType=cv2.LINE_AA)
    h, w = vis.shape[:2]
    bar = np.full((52, w, 3), 30, np.uint8)
    items = [
        (leftover_bgr, "leftover mask (no flow hit)"),
        (new_bgr, "new disc centres"),
    ]
    x = 8
    for col, name in items:
        cv2.rectangle(bar, (x, 8), (x + 16, 24), col, -1)
        cv2.rectangle(bar, (x, 8), (x + 16, 24), (240, 240, 240), 1)
        cv2.putText(bar, name, (x + 22, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.45,
                    (220, 220, 220), 1, cv2.LINE_AA)
        x += 22 + 8 * len(name) + 28
    cv2.putText(
        bar,
        f"new={rec['n_new']} leftover={100*rec['leftover_frac']:.1f}% "
        f"upd={rec['n_upd']} N={rec['n']}",
        (8, 44), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (220, 220, 220), 1, cv2.LINE_AA,
    )
    return np.vstack([vis, bar])


def _draw_ownership(bgr, owner: np.ndarray, birth: np.ndarray,
                    cur_frame: int) -> np.ndarray:
    """Per-pixel ownership, three discrete classes (legend colours == pixel colours).

    Classes (mutually exclusive):
      * NEW this frame      (birth == cur_frame)  -> CYAN   (0,255,255)
      * OLD tracked         (birth <  cur_frame)  -> GREEN  (0,255,0)
      * NOT owned (no flow identity)              -> GRAY   (dimmed)
    """
    h, w = owner.shape[:2]
    owned = owner >= 0
    birth_map = owner_birth_map(owner, birth)
    is_new = owned & (birth_map == cur_frame)
    is_old = owned & (birth_map < cur_frame)

    out = np.full((h, w, 3), 60, np.uint8)
    out[ownership_not_owned := ~owned] = (
        0.55 * bgr[~owned] + 0.45 * np.array([40, 40, 40], np.float32)
    ).astype(np.uint8)
    out[is_old] = (0, 255, 0)      # BGR green
    out[is_new] = (0, 0, 255)    # BGR red

    # legend bar (exact same colours)
    bar = np.full((64, w, 3), 30, np.uint8)
    items = [
        ((0, 0, 255), "NEW this frame (birth == cur)"),
        ((0, 255, 0),   "OLD tracked (birth < cur)"),
        ((70, 70, 70),  "NOT owned (no flow identity)"),
    ]
    x = 8
    for col, name in items:
        cv2.rectangle(bar, (x, 10), (x + 18, 30), col, -1)
        cv2.rectangle(bar, (x, 10), (x + 18, 30), (240, 240, 240), 1)
        cv2.putText(bar, name, (x + 24, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.42,
                    (220, 220, 220), 1, cv2.LINE_AA)
        x += 24 + 8 * len(name) + 30
    cv2.putText(bar, f"pixel ownership  (frame {cur_frame}): "
                     f"new={int(is_new.sum())} old={int(is_old.sum())} "
                     f"none={int((~owned).sum())}",
                (8, 54), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (220, 220, 220), 1, cv2.LINE_AA)
    return np.vstack([out, bar])


def load_pair(pairs, i, map1, map2):
    p = pairs[i]
    bgr = remap_rgb(load_rgb(p.rgb_path), map1, map2)
    z = remap_depth(load_depth(p.depth_path), map1, map2)
    z[z < Z_MIN] = 0.0
    z[z > Z_MAX] = 0.0
    return bgr, z, p.t_rgb


def write_ply(path: Path, g: H.Gaussians) -> None:
    """Standard 3DGS PLY (binary_little_endian, sh_degree 0).

    Conventions matched to the reference rasterizer:
      * f_dc = (linear_rgb - 0.5) / SH_C0
      * opacity = logit(alpha)
      * scale = log([r1, r2, thin]) along rot's x/y/z (thin = normal)
      * rot = wxyz quaternion, shortest axis aligned to normal
    """
    n = len(g)
    sh_c0 = 0.28209479177387814
    rgb = np.clip(g.color, 0.0, 1.0).astype(np.float64)
    f_dc = (rgb - 0.5) / sh_c0
    alpha = np.clip(g.alpha, 1e-6, 1.0 - 1e-6).astype(np.float64)
    opacity = np.log(alpha / (1.0 - alpha))
    scale = np.log(np.maximum(g.scale, 1e-12).astype(np.float64))
    rot = g.quat.astype(np.float64)
    header = (
        "ply\n"
        "format binary_little_endian 1.0\n"
        f"element vertex {n}\n"
        "property float x\nproperty float y\nproperty float z\n"
        "property float nx\nproperty float ny\nproperty float nz\n"
        "property float f_dc_0\nproperty float f_dc_1\nproperty float f_dc_2\n"
        "property float opacity\n"
        "property float scale_0\nproperty float scale_1\nproperty float scale_2\n"
        "property float rot_0\nproperty float rot_1\nproperty float rot_2\nproperty float rot_3\n"
        "end_header\n"
    )
    cols = np.concatenate(
        [g.mu, g.normal, f_dc, opacity[:, None], scale, rot], axis=1
    ).astype(np.float64)
    with path.open("wb") as f:
        f.write(header.encode("ascii"))
        f.write(cols.astype("<f4").tobytes())


def main() -> None:
    global COLOR_GATE_K
    p = argparse.ArgumentParser()
    p.add_argument("--max-pairs", type=int, default=10)
    p.add_argument("--out", default=str(SEQ.parent / "output_K"))
    p.add_argument("--age-max", type=int, default=8)
    p.add_argument("--w-min", type=float, default=2.0)
    p.add_argument("--save-ply", action="store_true")
    p.add_argument("--save-vis", action="store_true", default=True)
    p.add_argument("--no-save-vis", action="store_false", dest="save_vis")
    p.add_argument("--vis-owner", action="store_true",
                   help="also write per-pixel owner visualizations (owner_XXXX.png)")
    p.add_argument("--gt-pose", action="store_true",
                   help="use TUM ground-truth camera motion instead of 986 xi")
    p.add_argument("--no-absorb", action="store_true",
                   help="skip absorb_leftover_pixels: every leftover pixel goes "
                        "straight to build_hybrid_region (edge-fallback default).")
    p.add_argument("--no-relink", action="store_true",
                   help="skip relink_projective: disable the sparse projective "
                        "disc-centre re-link (re-visit pixels stay leftover).")
    p.add_argument("--relink-no-color", action="store_true",
                   help="geometry-only relink: drop the colour gate, keep only "
                        "point-to-plane.")
    p.add_argument("--relink-center-only", action="store_true",
                   help="A/B control: relink reclaims only each disc's centre pixel "
                        "instead of its whole projected footprint.")
    p.add_argument("--color-gate-k", type=float, default=COLOR_GATE_K,
                   help="colour-gate coefficient (distance <= k * local texture "
                        "sigma) for flow-hit and absorb.")
    args = p.parse_args()
    COLOR_GATE_K = args.color_gate_k
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    vis_dir = out / "vis"
    if args.save_vis or args.vis_owner:
        vis_dir.mkdir(exist_ok=True)

    pairs = associate(DATA, max_dt=0.02)
    if args.max_pairs > 0:
        pairs = pairs[: args.max_pairs + 1]
    if args.gt_pose:
        gt_ts, gt_t, gt_q = load_groundtruth(DATA / "groundtruth.txt")
    sample = load_rgb(pairs[0].rgb_path)
    h, w = sample.shape[:2]
    map1, map2, K = undistort_maps((h, w), FR1_INTRINSICS)

    bgr0, z0, _ = load_pair(pairs, 0, map1, map2)
    g0, _, _, owner0 = H.build_hybrid_with_owner(bgr0, z0, K, TEX_Q)
    model = Model(
        g=g0,
        w=np.ones(len(g0), dtype=np.float32),
        w_col=np.ones(len(g0), dtype=np.float32),
        age=np.zeros(len(g0), dtype=np.int32),
        owner=owner0,
        birth=np.zeros(len(g0), dtype=np.int32),
        birth_color=g0.color.astype(np.float32).copy(),
    )
    rows = [{"i": -1, "n": len(g0), "n_upd": 0, "n_new": len(g0),
             "n_absorb": 0, "n_relink": 0, "n_relink_plane_fail": 0,
             "n_relink_color_fail": 0, "n_leftover": 0, "n_gate_fail": 0,
             "n_color_fail": 0, "n_absorb_color_fail": 0,
             "valid_frac": 1.0,
             "expanded_frac": 0.0, "leftover_frac": 0.0, "n_dead": 0,
             "n_owned": 0, "n_cand": 0, "n_s2": 0, "n_curv": 0,
             "dcol_med": float("nan"), "dcol_p90": float("nan")}]
    print(f"[init] N={len(g0)}", flush=True)

    prev_sf = None
    prev_dt = 1.0
    bgr_a, z_a = bgr0, z0
    for i in range(len(pairs) - 1):
        bgr_b, z_b, _ = load_pair(pairs, i + 1, map1, map2)
        dt = pairs[i + 1].t_rgb - pairs[i].t_rgb
        sf = compute_scene_flow(
            bgr_a, bgr_b, z_a, z_b, K,
            prev=prev_sf, dt=dt, prev_dt=prev_dt,
        )
        R_10 = t_10 = None
        if args.gt_pose:
            m0 = interpolate_pose(pairs[i].t_rgb, gt_ts, gt_t, gt_q)
            m1 = interpolate_pose(pairs[i + 1].t_rgb, gt_ts, gt_t, gt_q)
            if m0 is None or m1 is None:
                raise RuntimeError(f"GT pose out of range at pair {i}")
            R_eg, t_eg = relative_camera_motion(*m0, *m1)
            R_10, t_10 = invert_point_motion(R_eg, t_eg)
        rec = fuse_frame(model, sf, z_a, z_b, bgr_b, K, args.age_max, args.w_min,
                         i, R_10, t_10, no_absorb=args.no_absorb,
                         no_relink=args.no_relink,
                         relink_color_gate=not args.relink_no_color,
                         relink_center_only=args.relink_center_only)
        rec["i"] = i
        if args.save_vis:
            vis = _draw_new(bgr_b, rec["leftover"], rec["hit"], rec["new_px"], rec)
            cv2.imwrite(str(vis_dir / f"new_{i:04d}.png"), vis)
        if args.save_vis or args.vis_owner:
            vis2 = _draw_ownership(bgr_b, rec["owner_final"], rec["birth"], i)
            cv2.imwrite(str(vis_dir / f"owner_{i:04d}.png"), vis2)
        rec.pop("leftover", None)
        rec.pop("new_px", None)
        rec.pop("hit", None)
        rec.pop("owner_final", None)
        rec.pop("birth", None)
        rec.pop("z1", None)
        rows.append(rec)
        print(
            f"[{i:03d}] N={rec['n']} upd={rec['n_upd']} new={rec['n_new']} "
            f"abs={rec['n_absorb']} relink={rec['n_relink']} "
            f"rpf={rec['n_relink_plane_fail']} rcf={rec['n_relink_color_fail']} "
            f"left_px={rec['n_leftover']} "
            f"owned={rec['n_owned']} cand={rec['n_cand']} "
            f"fail={rec['n_gate_fail']} cfail={rec['n_color_fail']} "
            f"acfail={rec['n_absorb_color_fail']} valid={rec['valid_frac']:.2f} "
            f"dcol_med={rec['dcol_med']:.4f} dcol_p90={rec['dcol_p90']:.4f} "
            f"exp={rec['expanded_frac']:.2f} left={rec['leftover_frac']:.2f} "
            f"dead={rec['n_dead']}",
            flush=True,
        )
        bgr_a, z_a = bgr_b, z_b
        prev_sf, prev_dt = sf, dt

    keys = list(rows[0].keys())
    with (out / "fusion.csv").open("w", newline="") as f:
        wri = csv.DictWriter(f, fieldnames=keys)
        wri.writeheader()
        wri.writerows(rows)
    summary = {
        "n_frames": len(rows) - 1,
        "n_init": rows[0]["n"],
        "n_final": rows[-1]["n"],
        "n_upd_mean": float(np.mean([r["n_upd"] for r in rows[1:]])),
        "n_new_mean": float(np.mean([r["n_new"] for r in rows[1:]])),
    }
    (out / "summary.json").write_text(json.dumps(summary, indent=2))
    if args.save_ply:
        write_ply(out / "model.ply", model.g)
    print(json.dumps(summary, indent=2))
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
