"""Quantify the two 'dirty new disc' quality complaints:
  (1) new discs' colour vs frame-0 GT (the visible dirt), and
  (2) whether new discs are born on colour-outlier pixels (border/AA/edge).
Caches the 81 undistorted RGB frames so no repeated IO."""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

import sequential_fusion_flowonly as SF


def local_outlier(rgb, u, v, r=4):
    h, w = rgb.shape[:2]
    y0, y1 = max(v - r, 0), min(v + r + 1, h)
    x0, x1 = max(u - r, 0), min(u + r + 1, w)
    nb = rgb[y0:y1, x0:x1].reshape(-1, 3)
    return float(np.abs(nb - rgb[v, u]).sum(axis=1).mean())


def main() -> None:
    OUT = SF.SEQ.parent / "output_newborn"
    r = np.load(OUT / "records.npz")
    color = r["color"].astype(np.float32)
    source = r["source"]; birth = r["birth"]; pixel = r["pixel"]
    index80 = np.load(OUT / "index80.npy")
    n_init = int(r["n_init"])

    pairs = SF.associate(SF.DATA, max_dt=0.02)[:81]
    h, w = SF.load_rgb(pairs[0].rgb_path).shape[:2]
    map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)

    print("caching frames ...", flush=True)
    rgb = {}
    for k in range(81):
        bgr, _, _ = SF.load_pair(pairs, k, map1, map2)
        rgb[k] = bgr[..., ::-1].astype(np.float32) / 255.0

    gt0 = rgb[0]
    idx_flat = index80.reshape(-1)
    hit = idx_flat >= 0
    front = idx_flat[hit]
    d = np.abs(color[front] - gt0.reshape(-1, 3)[hit]).sum(axis=1)
    is_new = front >= n_init
    print("=== frame-0 render: disc colour vs GT (L1 0..3) ===")
    for lbl, m in [("ALL", np.ones(len(front), bool)),
                   ("OLD(orig)", ~is_new), ("NEW", is_new)]:
        dd = d[m]
        print(f"  {lbl:10s} n={int(m.sum()):6d} mean={dd.mean():.3f} "
              f"med={np.median(dd):.3f} p90={np.percentile(dd,90):.3f} "
              f">0.5:{100*(dd>0.5).mean():.0f}% >1.0:{100*(dd>1.0).mean():.0f}%")

    print("\n=== source pixel vs 9x9 neighbourhood (L1 0..3) ===")
    new_idx = np.arange(n_init, len(color))
    out = np.array([local_outlier(rgb[int(birth[i]) + 1], int(pixel[i, 0]), int(pixel[i, 1]))
                    for i in new_idx])
    oo = np.array([local_outlier(rgb[0], int(pixel[i, 0]), int(pixel[i, 1]))
                   for i in range(n_init)])
    print(f"  NEW  n={len(new_idx)}: mean={out.mean():.3f} med={np.median(out):.3f} p90={np.percentile(out,90):.3f}")
    print(f"  ORIG n={n_init}: mean={oo.mean():.3f} med={np.median(oo):.3f} p90={np.percentile(oo,90):.3f}")

    # new discs' colour vs ORIGINAL model disc colour where they are front (point 1 'also differs from old discs')
    # front pixel where NEW: compare new disc colour to the frame-0 model's front disc colour
    # (the original disc that WOULD have been front if no new disc). The 0-frame index map = index0 from earlier; recompute quickly is
    # expensive, so skip: we approximate 'old disc colour' by the GT itself is not right; report the gt comparison only.


if __name__ == "__main__":
    main()