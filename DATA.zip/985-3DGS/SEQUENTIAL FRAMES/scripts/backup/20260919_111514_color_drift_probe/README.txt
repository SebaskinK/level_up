# backup/20260919_111514_color_drift_probe —— 代码快照说明

快照时间：2026-09-19 11:15（诊断脚本 diag_color_birth_final.py 于 11:50 补入）

内容 = 当前工作区（逐字节一致）：
- sequential_fusion_flowonly.py  运行管线（含颜色置信解耦【默认】 + 漂移探针【临时】）
- render_f0_images.py            帧 0 渲染（含 w_col 初始化【默认】 + birth_color/dcol 探针【临时】）
- diag_exposure_drift.py         逐帧全局 RGB 漂移诊断（测试脚本）
- diag_color_birth_final.py      盘级 birth→final 颜色位移诊断（测试脚本，11:50 补入）

默认 vs 临时 完整清单见 scripts/ARCHIVE_20260919.md §2。

基线（解耦之前的默认代码）：backup/20260919_104002_color_conf_count/