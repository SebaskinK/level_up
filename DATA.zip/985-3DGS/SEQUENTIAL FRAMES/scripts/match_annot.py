#!/usr/bin/env python3
"""Match user's annotated crop back to f0_hard.png via FFT normalized cross-correlation."""
import numpy as np
from PIL import Image

ANN = "/home/sti/Work/985-3DGS/SEQUENTIAL FRAMES/output_discmask_align/20260917-172426.jpg"
HARD = "/home/sti/Work/985-3DGS/SEQUENTIAL FRAMES/output_discmask_align/f0_hard.png"

ann_rgb = np.array(Image.open(ANN).convert('RGB')).astype(np.int32)
hard = np.array(Image.open(HARD).convert('L')).astype(np.float64)
ann = np.array(Image.open(ANN.replace('20260917-172426.jpg', '_annot_inpainted.png')).convert('L')).astype(np.float64)

R, G, B = ann_rgb[..., 0], ann_rgb[..., 1], ann_rgb[..., 2]
red = (R > 150) & (G < 120) & (B < 120)

H, W = ann.shape
Hg, Wg = hard.shape


def moving_sum(A, nH, nW):
    """S[dy,dx] = sum_{u<dy+nH, v<dx+nW} A[u,v] over u in [dy,dy+nH)."""
    Hh, Ww = A.shape
    C = np.zeros((Hh + 1, Ww + 1))
    C[1:, 1:] = A.cumsum(0).cumsum(1)
    dy_len = Hh - nH + 1
    dx_len = Ww - nW + 1
    S = (C[nH:, nW:] - C[0:dy_len, nW:] - C[nH:, 0:dx_len] + C[0:dy_len, 0:dx_len])
    return S


def match_scale(scale):
    nH = int(round(H * scale))
    nW = int(round(W * scale))
    if nH < 4 or nW < 4 or nH > Hg or nW > Wg:
        return -1e9, -1, -1, nH, nW
    # shrink template by scale (scale < 1 => user zoomed in)
    t = np.array(Image.fromarray(ann.astype(np.uint8)).resize((nW, nH), Image.BILINEAR)).astype(np.float64)
    tm = t.mean()
    tc = t - tm
    tstd = np.sqrt((tc ** 2).sum() / t.size)
    if tstd < 1e-9:
        return -1e9, -1, -1, nH, nW

    # cross-correlation of hard with zero-mean template tc
    Hp = Hg + nH - 1
    Wp = Wg + nW - 1
    Hp2 = 1 << (Hp - 1).bit_length()
    Wp2 = 1 << (Wp - 1).bit_length()
    FI = np.fft.rfft2(hard, s=(Hp2, Wp2))
    FT = np.fft.rfft2(np.flipud(np.fliplr(tc)), s=(Hp2, Wp2))
    conv = np.fft.irfft2(FI * FT, s=(Hp2, Wp2))
    cr = conv[nH - 1:nH - 1 + (Hg - nH + 1), nW - 1:nW - 1 + (Wg - nW + 1)]

    S1 = moving_sum(hard, nH, nW)
    S2 = moving_sum(hard ** 2, nH, nW)
    N = nH * nW
    mp = S1 / N
    vp = S2 / N - mp ** 2
    stdp = np.sqrt(np.maximum(vp, 0))
    cov = cr / N
    ncc = cov / (stdp * tstd + 1e-9)

    idx = np.unravel_index(np.argmax(ncc), ncc.shape)
    return ncc[idx], int(idx[1]), int(idx[0]), nH, nW


results = []
for sc in [1.0, 0.9, 0.8, 0.75, 0.7, 0.6, 0.5, 0.45, 0.4, 0.35, 0.3, 0.25, 0.2, 1.5, 1.25, 2.0]:
    score, dx, dy, nH, nW = match_scale(sc)
    results.append((score, sc, dx, dy, nH, nW))
    print(f"scale={sc:5.3f} ncc={score:+.3f} (dx,dy)=({dx},{dy}) tpl=({nH}x{nW})")

best = max(results, key=lambda r: r[0])
print("\nBEST:", best)