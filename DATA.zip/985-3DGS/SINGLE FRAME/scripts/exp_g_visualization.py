"""Generate hole / depth backprojection / gaussian render panels.

Uses the current production config from exp_g_aniso_real.py.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from exp_g_aniso_real import CFG, build, eval_setup  # noqa: E402
from gaussian_build import depth_valid  # noqa: E402
from metrics import rasterize_discs  # noqa: E402
from rgbd_io import (  # noqa: E402
    FR1_INTRINSICS,
    associate,
    load_depth,
    load_rgb,
    remap_depth,
    remap_rgb,
    undistort_maps,
)


def label(img: np.ndarray, text: str) -> np.ndarray:
    out = img.copy()
    cv2.rectangle(out, (0, 0), (out.shape[1], 34), (0, 0, 0), -1)
    cv2.putText(out, text, (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
    return out


def colorize_depth(z: np.ndarray, mask: np.ndarray, z_min: float = 0.4, z_max: float = 4.0) -> np.ndarray:
    """Colorize depth in millimeters with turbo colormap."""
    mm = z * 1000.0
    norm = (mm - z_min * 1000.0) / (z_max * 1000.0 - z_min * 1000.0)
    norm = np.clip(norm, 0.0, 1.0)
    vis = (norm * 255.0).astype(np.uint8)
    vis = cv2.applyColorMap(vis, cv2.COLORMAP_TURBO)
    vis[~mask] = 0
    return vis


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--data", default=str(
        ROOT.parent.parent / "986-SceneFlow" / "rgbd_dataset_freiburg1_desk"))
    p.add_argument("--out", default=str(ROOT.parent / "output_G_refactor"))
    p.add_argument("--frame", type=int, default=0)
    args = p.parse_args()

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    pairs = associate(Path(args.data))
    fr = pairs[args.frame]
    sample = load_rgb(pairs[0].rgb_path)
    map1, map2, K = undistort_maps(sample.shape[:2], FR1_INTRINSICS)
    bgr = remap_rgb(load_rgb(fr.rgb_path), map1, map2)
    z = remap_depth(load_depth(fr.depth_path), map1, map2)

    normal_ref, eval_mask = eval_setup(z, K)
    g, _ = build(bgr, z, K, foreshorten=False, aniso_claim=True)
    depth, index, _ = rasterize_discs(g, K, z.shape)
    hit = index >= 0
    hole = eval_mask & ~hit

    # 1. Hole map
    hole_vis = bgr.copy()
    hole_vis[hole] = (0, 0, 255)
    hole_vis = label(hole_vis, f"hole map  N={len(g)}  hole={hole.sum()/max(eval_mask.sum(),1)*100:.2f}%")

    # 2. Depth backprojection (readout)
    depth_vis = colorize_depth(depth, hit, CFG["z_min"], CFG["z_max"])
    depth_vis = label(depth_vis, "depth backprojection (ray-disc)")

    # 3. Gaussian render (color readout)
    render = np.zeros_like(bgr)
    rgb = np.clip(g.color[index[hit]], 0.0, 1.0)
    render[hit] = (rgb[:, ::-1] * 255.0).astype(np.uint8)
    col_err = g.color[index[hit & eval_mask]] - (bgr[..., ::-1].astype(np.float32) / 255.0)[hit & eval_mask]
    psnr = -20.0 * np.log10(max(float(np.sqrt(np.mean(col_err ** 2))), 1e-12))
    render = label(render, f"gaussian render  PSNR={psnr:.1f}dB")

    # 4. Depth comparison: original vs backprojection
    valid_depth_mask = depth_valid(z)
    orig_depth_vis = colorize_depth(z, valid_depth_mask, CFG["z_min"], CFG["z_max"])
    depth_compare = np.hstack([
        label(orig_depth_vis, "original depth"),
        label(depth_vis, "gaussian backprojection"),
    ])

    # 5. RGB comparison: original vs render
    rgb_compare = np.hstack([
        label(bgr, "original RGB"),
        label(render, "gaussian render"),
    ])

    # Combined panel
    panel = np.hstack([hole_vis, depth_vis, render])
    out = out_dir / f"visualization_f{args.frame:02d}.png"
    cv2.imwrite(str(out), panel)
    print(f"N={len(g)}  hole={hole.sum()/max(eval_mask.sum(),1)*100:.2f}%  PSNR={psnr:.1f}dB")
    print(f"wrote {out}")

    # Comparison panels
    cv2.imwrite(str(out_dir / f"depth_compare_f{args.frame:02d}.png"), depth_compare)
    cv2.imwrite(str(out_dir / f"rgb_compare_f{args.frame:02d}.png"), rgb_compare)
    print(f"wrote {out_dir / f'depth_compare_f{args.frame:02d}.png'}")
    print(f"wrote {out_dir / f'rgb_compare_f{args.frame:02d}.png'}")

    # Also save individual images
    cv2.imwrite(str(out_dir / f"hole_only_f{args.frame:02d}.png"), hole_vis)
    cv2.imwrite(str(out_dir / f"depth_only_f{args.frame:02d}.png"), depth_vis)
    cv2.imwrite(str(out_dir / f"render_only_f{args.frame:02d}.png"), render)


if __name__ == "__main__":
    main()
