"""Crop the matched annotation region from f0_hard and mark near-black discs.

The vertical "stripes" reproduce as columns of near-black S2 discs (birth 0),
not coverage holes. This renders the crop, the GT crop, and a mask of discs
whose colour luminance < 0.05, and saves a side-by-side diagnostic image.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import cv2

SEQ = Path(__file__).resolve().parent
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SFLOW))
sys.path.insert(0, str(SEQ))

import h_pipeline_final as H            # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402

OUT = SEQ.parent / "output_discmask_align"
LU = 0.05


def tb(n):
    n = n.astype(np.float64)
    n = n / np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-12)
    ref = np.tile(np.array([0.0, 0.0, 1.0]), (n.shape[0], 1))
    ref[np.abs(n[:, 2]) > 0.9] = np.array([1.0, 0.0, 0.0])
    t1 = np.cross(ref, n)
    t1 = t1 / np.maximum(np.linalg.norm(t1, axis=1, keepdims=True), 1e-12)
    t2 = np.cross(n, t1)
    return t1, t2


def main() -> None:
    d = np.load(OUT / "model_f0.npz")
    mu = d["mu"].astype(np.float32)
    normal = d["normal"].astype(np.float32)
    scale = d["scale"].astype(np.float32)
    color = d["color"].astype(np.float32)
    birth = d["birth"].astype(np.int32)
    t1, t2 = tb(normal)
    g = H.Gaussians(
        mu=mu, normal=normal, scale=scale,
        quat=H._quat_from_frame(t1.astype(np.float32), t2.astype(np.float32), normal),
        color=color, alpha=None, pixel=np.zeros((len(mu), 2), np.int32),
        axis1=t1.astype(np.float32), axis2=t2.astype(np.float32))

    pairs = SF.associate(SF.DATA, max_dt=0.02)[: 11]
    sm = SF.load_rgb(pairs[0].rgb_path)
    h, w = sm.shape[:2]
    m1, m2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)
    bgr0, z0, _ = SF.load_pair(pairs, 0, m1, m2)
    valid = (z0 > SF.Z_MIN) & (z0 < SF.Z_MAX)

    depth, index, _ = H.rasterize_discs(g, K, (h, w))
    lum = color.mean(axis=1)
    idx = index.astype(np.int64)
    cov = np.isfinite(depth) & valid
    pixl = np.zeros((h, w), np.float32)
    pixl[cov] = lum[idx[cov]]
    dark = pixl < LU   # near-black covering disc

    # matched annotation region (scale 0.25, offset 328,322)
    c0, c1, r0, r1 = 320, 470, 300, 400
    render = np.zeros((h, w, 3), np.uint8)
    render[cov] = (np.clip(color[idx[cov]], 0, 1) * 255).astype(np.uint8)[..., ::-1]
    gt = bgr0.copy()
    KZ = 3
    crop_r = cv2.resize(render[r0:r1, c0:c1], None, fx=KZ, fy=KZ, interpolation=cv2.INTER_NEAREST)
    crop_g = cv2.resize(gt[r0:r1, c0:c1], None, fx=KZ, fy=KZ, interpolation=cv2.INTER_NEAREST)
    # mark near-black discs in the render crop
    m = dark[r0:r1, c0:c1]
    m3 = cv2.resize((m * 255).astype(np.uint8), None, fx=KZ, fy=KZ, interpolation=cv2.INTER_NEAREST) > 127
    crop_m = crop_r.copy()
    crop_m[m3] = (0, 0, 255)

    Hc, Wc = crop_r.shape[:2]
    bar = np.full((30, Wc, 3), 20, np.uint8)
    labels = ["render", "-nearblack discs-", "GT (frame0)"]
    for im, lab in zip([crop_r, crop_m, crop_g], labels):
        im[:30, :] = 20
        cv2.putText(im, lab, (6, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1, cv2.LINE_AA)
    out = np.vstack([bar, crop_r, crop_m, crop_g])
    cv2.imwrite(str(OUT / "_diag_matched_crop.png"), out)

    nd = int(dark[r0:r1, c0:c1].sum())
    nh = int((valid[r0:r1, c0:c1] & ~cov[r0:r1, c0:c1]).sum())
    ids = np.unique(idx[r0:r1, c0:c1][dark[r0:r1, c0:c1] & cov[r0:r1, c0:c1]])
    iso = np.abs(scale[:, 0] - scale[:, 1]) < 1e-6 * np.maximum(scale[:, 0], 1e-9)
    print(f"crop {c0}:{c1},{r0}:{r1}: nearblack_px={nd} holes={nh}")
    print(f"nearblack discs in crop: {len(ids)} birth={np.bincount(birth[ids], minlength=12).tolist()} isoFrac={iso[ids].mean():.2f}")
    print("saved ->", OUT / "_diag_matched_crop.png")


if __name__ == "__main__":
    main()