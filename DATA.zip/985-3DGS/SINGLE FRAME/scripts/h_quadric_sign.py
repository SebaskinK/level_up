"""Quadric linear-kernel sign: ground-truth verification + A/B on real frames.

Background
----------
`quadric_kernels` built its win x win correlation kernels as
`P[i].reshape(win, win)[::-1, ::-1]`. The reshape is ALREADY in correlation
layout (row = v + r, col = u + r), which is exactly what cv2.filter2D applies,
so the extra flip was spurious: it maps (u, v) -> (-u, -v), leaving the
even-order kernels (zuu/zvv/zuv) untouched but NEGATING the odd-order ones
(zu/zv). Removed 2026-09-16 in both h_pipeline_final.py and curvature.py.

`OPEN_ITEMS.md` C5.2 used to claim the sign "cancels inside the second
fundamental form". It does not: zu/zv also appear alone in Puu/Puv/Pvv and in
the internal cross(Pu, Pv), so both the curvature magnitudes and the principal
directions were biased.

Usage
-----
    python h_quadric_sign.py              # synthetic ground-truth checks
    python h_quadric_sign.py --ab [N]     # A/B old-vs-new on N real frames
                                          # (writes panels to output_H_quadsign/)
"""

import sys
import time
from pathlib import Path

import numpy as np
import cv2

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

import h_pipeline_final as H  # noqa: E402

OUT = ROOT.parent / "output_H_quadsign"
DATA = ROOT.parent.parent.parent / "986-SceneFlow" / "rgbd_dataset_freiburg1_desk"
H_IMG, W_IMG = 480, 640

# The pipeline now ships the corrected kernels; `_legacy_kernels` reproduces the
# pre-2026-09-16 behaviour so the two can be compared back to back.
_fixed_kernels = H.quadric_kernels
_legacy_cache: dict[int, dict[str, np.ndarray]] = {}


def _legacy_kernels(win: int) -> dict[str, np.ndarray]:
    """Pre-fix kernels: the corrected ones with the spurious flip re-applied."""
    if win in _legacy_cache:
        return _legacy_cache[win]
    k = dict(_fixed_kernels(win))
    for name in ("zu", "zv", "zuu", "zvv", "zuv"):
        k[name] = np.ascontiguousarray(k[name][::-1, ::-1])
    _legacy_cache[win] = k
    return k


def set_mode(mode: str) -> None:
    """Swap the module-level kernel factory ('legacy' or 'fixed')."""
    H._QUAD_CACHE.clear()
    H.quadric_kernels = _legacy_kernels if mode == "legacy" else _fixed_kernels


def _K() -> np.ndarray:
    _, _, K = H.undistort_maps((H_IMG, W_IMG), H.FR1_INTRINSICS)
    return K


def _rays(K):
    fx, fy, cx, cy = K[0, 0], K[1, 1], K[0, 2], K[1, 2]
    us, vs = np.meshgrid(np.arange(W_IMG, dtype=np.float64),
                         np.arange(H_IMG, dtype=np.float64))
    return np.stack([(us - cx) / fx, (vs - cy) / fy, np.ones_like(us)], axis=-1)


# --------------------------------------------------------------------------
# A. analytic tilted plane -> is zu/zv signed like the truth (and like Sobel)?
# --------------------------------------------------------------------------

def check_plane(K) -> None:
    print("=" * 72)
    print("A. tilted plane: quadric zu/zv vs analytic truth and 3x3 Sobel")
    print("=" * 72)
    d = _rays(K)
    pn = np.array([0.30, 0.15, -0.94])
    pn /= np.linalg.norm(pn)
    dist = 1.5
    z = ((-dist / (d @ pn)) * d[..., 2]).astype(np.float32)

    # truth: z(u, v) = -dist / (pn . K^-1 [u, v, 1]); differentiate in u
    fx, cx = K[0, 0], K[0, 2]
    yc, xc = H_IMG // 2, W_IMG // 2
    ray = np.array([(xc - cx) / fx, (yc - K[1, 2]) / K[1, 1], 1.0])
    denom = pn @ ray
    zu_true = dist * (pn[0] / fx) / denom ** 2

    zu_s = cv2.Sobel(z, cv2.CV_32F, 1, 0, ksize=3)[yc, xc] / 8.0
    for mode in ("legacy", "fixed"):
        set_mode(mode)
        kq = H.quadric_kernels(9)
        zu_q = cv2.filter2D(z, cv2.CV_32F, kq["zu"],
                            borderType=cv2.BORDER_REPLICATE)[yc, xc]
        print(f"  {mode:>7}: quadric zu = {zu_q:+.6e}")
    print(f"  {'sobel':>7}: quadric zu = {zu_s:+.6e}")
    print(f"  {'truth':>7}: quadric zu = {zu_true:+.6e}")
    print()


# --------------------------------------------------------------------------
# B. analytic cylinder -> |k1| = 1/R, and t1 must be the circumferential dir
# --------------------------------------------------------------------------

def _cylinder(K, axis, R=0.20, centre=np.array([0.0, 0.0, 1.2])):
    a = np.asarray(axis, dtype=np.float64)
    a /= np.linalg.norm(a)
    dd = _rays(K)
    d_perp = dd - (dd @ a)[..., None] * a
    c_perp = centre - (centre @ a) * a
    A = np.einsum("ijk,ijk->ij", d_perp, d_perp)
    B = -2.0 * (d_perp @ c_perp)
    C = c_perp @ c_perp - R * R
    disc = B * B - 4 * A * C
    t = (-B - np.sqrt(np.maximum(disc, 0.0))) / (2 * A)
    hit = (disc > 0) & (t > 0)
    z = np.where(hit, t * dd[..., 2], 0.0).astype(np.float32)
    P = t[..., None] * dd
    n = P - (centre + ((P - centre) @ a)[..., None] * a)
    n /= np.maximum(np.linalg.norm(n, axis=-1, keepdims=True), 1e-12)
    n = np.where((n[..., 2] > 0)[..., None], -n, n)
    circ = np.cross(n, a)
    circ /= np.maximum(np.linalg.norm(circ, axis=-1, keepdims=True), 1e-12)
    return z, hit, circ, a


def check_cylinder(K, R=0.20) -> None:
    print("=" * 72)
    print(f"B. cylinder R={R}: |k1| truth {1/R:.3f} 1/m, |k2| truth 0,")
    print("   t1 truth = circumferential direction")
    print("=" * 72)
    axes = [("X  ", [1, 0, 0]), ("Y  ", [0, 1, 0]),
            ("30d", [np.cos(np.pi / 6), np.sin(np.pi / 6), 0])]
    for mode in ("legacy", "fixed"):
        set_mode(mode)
        print(f"  --- {mode} ---")
        for name, ax in axes:
            z, hit, circ, a = _cylinder(K, ax, R=R)
            valid = z > 1e-6
            zs = H.prefilter_depth(z, "gauss", H.GEO_CFG["gauss_sigma"], valid=valid)
            k1, k2, t1, ok, _ = H.scale_space_curvature(zs, K)
            m = (cv2.erode(valid.astype(np.uint8),
                           np.ones((25, 25), np.uint8)) > 0) & ok & hit
            ang = np.degrees(np.arccos(np.clip(
                np.abs(np.einsum("ij,ij->i", t1[m], circ[m])), 0, 1)))
            print(f"    axis {name}  |k1| med {np.median(np.abs(k1[m])):6.3f}"
                  f"   angle(t1, circ) med {np.median(ang):6.2f} deg"
                  f"  p90 {np.percentile(ang, 90):6.2f} deg")
    print()


# --------------------------------------------------------------------------
# C. analytic sphere -> |k1| = |k2| = 1/R
# --------------------------------------------------------------------------

def check_sphere(K, R=0.50) -> None:
    print("=" * 72)
    print(f"C. sphere R={R}: |k1| = |k2| truth {1/R:.3f} 1/m")
    print("=" * 72)
    dd = _rays(K)
    centre = np.array([0.0, 0.0, 1.5])
    A = np.einsum("ijk,ijk->ij", dd, dd)
    B = -2.0 * (dd @ centre)
    C = centre @ centre - R * R
    disc = B * B - 4 * A * C
    t = (-B - np.sqrt(np.maximum(disc, 0.0))) / (2 * A)
    hit = (disc > 0) & (t > 0)
    z = np.where(hit, t * dd[..., 2], 0.0).astype(np.float32)
    valid = z > 1e-6
    for mode in ("legacy", "fixed"):
        set_mode(mode)
        zs = H.prefilter_depth(z, "gauss", H.GEO_CFG["gauss_sigma"], valid=valid)
        k1, k2, _, ok, _ = H.scale_space_curvature(zs, K)
        m = (cv2.erode(valid.astype(np.uint8),
                       np.ones((25, 25), np.uint8)) > 0) & ok & hit
        if m.sum() < 50:
            print(f"  {mode:>7}: too few interior px")
            continue
        print(f"  {mode:>7}: |k1| med {np.median(np.abs(k1[m])):6.3f}"
              f"   |k2| med {np.median(np.abs(k2[m])):6.3f}"
              f"   (err {100*abs(np.median(np.abs(k1[m]))-1/R)/(1/R):5.1f} %)")
    print()


# --------------------------------------------------------------------------
# D. A/B on real frames
# --------------------------------------------------------------------------

def _load(frame_idx):
    fr = H.associate(DATA)[frame_idx]
    map1, map2, K = H.undistort_maps((H_IMG, W_IMG), H.FR1_INTRINSICS)
    bgr = H.remap_rgb(H.load_rgb(fr.rgb_path), map1, map2)
    z = H.remap_depth(H.load_depth(fr.depth_path), map1, map2)
    z[z < H.GEO_CFG["z_min"]] = 0.0
    z[z > H.GEO_CFG["z_max"]] = 0.0
    return bgr, z, K


def _run(bgr, z, K, mode):
    set_mode(mode)
    normal_ref, eval_mask = H.eval_setup(z, K)
    t0 = time.perf_counter()
    g, keep_geo, tex_mask = H.build_hybrid(bgr, z, K, 0.6)
    m = H.evaluate(g, z, bgr, normal_ref, eval_mask, K)
    m["build_s"] = time.perf_counter() - t0
    m["n_curv"] = int(keep_geo.sum())
    m["n_s2"] = len(g) - m["n_curv"]
    nc = m["n_curv"]
    if nc:
        r1, r2 = g.scale[:nc, 0], g.scale[:nc, 1]
        m["curv_r1_med_mm"] = float(np.median(r1) * 1000)
        m["curv_r2_med_mm"] = float(np.median(r2) * 1000)
    zd = H.depth_valid(z)
    zs = H.prefilter_depth(z, "gauss", H.GEO_CFG["gauss_sigma"], valid=zd)
    k1, _, t1, ok, dirs = H.scale_space_curvature(zs, K)
    cm = ok & zd
    m["k1_abs_med"] = float(np.median(np.abs(k1[cm])))
    return g, m, eval_mask, t1, dirs, cm


ROWS = [("n_gaussians", "N total", "{:d}"),
        ("n_curv", "N curvature", "{:d}"),
        ("n_s2", "N S2", "{:d}"),
        ("depth_rmse_mm", "depth RMSE mm", "{:.2f}"),
        ("depth_med_mm", "depth med mm", "{:.2f}"),
        ("color_psnr_db", "PSNR dB", "{:.2f}"),
        ("hole_frac", "hole frac", "{:.4f}"),
        ("normal_med_deg", "normal med deg", "{:.2f}"),
        ("normal_area_med_deg", "normal area med deg", "{:.2f}"),
        ("curv_r1_med_mm", "curv r1 med mm", "{:.2f}"),
        ("curv_r2_med_mm", "curv r2 med mm", "{:.2f}"),
        ("k1_abs_med", "|k1| med 1/m", "{:.3f}"),
        ("surface_area_m2", "area m2", "{:.3f}"),
        ("build_s", "build s", "{:.2f}")]


def _label(img, text):
    img = img.copy()
    cv2.rectangle(img, (0, 0), (img.shape[1], 26), (0, 0, 0), -1)
    cv2.putText(img, text, (6, 19), cv2.FONT_HERSHEY_SIMPLEX, 0.55,
                (255, 255, 255), 1, cv2.LINE_AA)
    return img


def run_ab(n_frames: int) -> None:
    OUT.mkdir(exist_ok=True)
    first = None
    for fi in range(n_frames):
        bgr, z, K = _load(fi)
        g_l, m_l, emask, t1_l, dir_l, cm = _run(bgr, z, K, "legacy")
        g_f, m_f, _, t1_f, dir_f, _ = _run(bgr, z, K, "fixed")
        shift = np.degrees(np.arccos(np.clip(
            np.abs(np.einsum("ijk,ijk->ij", t1_l, t1_f))[cm], 0, 1)))
        print("=" * 76)
        print(f"FRAME {fi}   t1 direction shift legacy->fixed:"
              f" median {np.median(shift):.2f} deg")
        print(f"  {'metric':<24}{'legacy':>16}{'fixed':>16}{'delta':>14}")
        for key, label, fmt in ROWS:
            if key not in m_l:
                continue
            vl, vf = m_l[key], m_f[key]
            d = f"{vf - vl:+d}" if isinstance(vl, int) else fmt.format(vf - vl)
            print(f"  {label:<24}{fmt.format(vl):>16}{fmt.format(vf):>16}{d:>14}")
        print()
        if fi == 0:
            first = (g_l, g_f, m_l, m_f, bgr, z, K, emask, dir_l, dir_f, cm)

    if first is None:
        return
    g_l, g_f, m_l, m_f, bgr, z, K, emask, dir_l, dir_f, cm = first

    def render(g, mode):
        set_mode(mode)
        d, i, _ = H.rasterize_discs(g, K, z.shape)
        img = np.zeros((*z.shape, 3), np.uint8)
        hit = i >= 0
        img[hit] = (g.color[i[hit]][:, ::-1] * 255).astype(np.uint8)
        e = np.zeros(z.shape, np.float32)
        mm = np.isfinite(d) & emask
        e[mm] = np.abs(d[mm] - z[mm]) * 1000
        err = cv2.applyColorMap(
            np.clip(e / 15.0 * 255, 0, 255).astype(np.uint8), cv2.COLORMAP_INFERNO)
        err[~mm] = (40, 40, 40)
        return img, err

    img_l, err_l = render(g_l, "legacy")
    img_f, err_f = render(g_f, "fixed")
    panel = np.vstack([
        np.hstack([
            _label(img_l, f"LEGACY N={m_l['n_gaussians']} PSNR={m_l['color_psnr_db']:.2f}dB"),
            _label(img_f, f"FIXED  N={m_f['n_gaussians']} PSNR={m_f['color_psnr_db']:.2f}dB")]),
        np.hstack([
            _label(err_l, f"LEGACY |depth err| 0-15mm RMSE={m_l['depth_rmse_mm']:.2f}mm"),
            _label(err_f, f"FIXED  |depth err| 0-15mm RMSE={m_f['depth_rmse_mm']:.2f}mm")]),
    ])
    cv2.imwrite(str(OUT / "quadsign_ab_frame0.png"), panel)

    def quiver(dirs, ok, step=14):
        img = bgr.copy()
        for y in range(step, ok.shape[0] - step, step):
            for x in range(step, ok.shape[1] - step, step):
                if not ok[y, x]:
                    continue
                du, dv = dirs[y, x]
                cv2.line(img, (int(x - du * 6), int(y - dv * 6)),
                         (int(x + du * 6), int(y + dv * 6)),
                         (0, 255, 255), 1, cv2.LINE_AA)
        return img

    cv2.imwrite(str(OUT / "quadsign_dirs_frame0.png"), np.hstack([
        _label(quiver(dir_l, cm), "LEGACY principal direction (image space)"),
        _label(quiver(dir_f, cm), "FIXED principal direction")]))
    print(f"wrote {OUT}/quadsign_ab_frame0.png")
    print(f"wrote {OUT}/quadsign_dirs_frame0.png")
    set_mode("fixed")


if __name__ == "__main__":
    if "--ab" in sys.argv:
        idx = sys.argv.index("--ab")
        n = int(sys.argv[idx + 1]) if len(sys.argv) > idx + 1 else 3
        run_ab(n)
    else:
        K = _K()
        check_plane(K)
        check_cylinder(K)
        check_sphere(K)
        set_mode("fixed")
