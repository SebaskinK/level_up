"""A/B: does the FOV change to edge_distance_limit re-introduce the desk-edge
white-over-gray? Build frame 0 twice -- once with the sequential depth_jump_mask
(void adjacency ignored) and once with the single-frame depth_discontinuity_mask
(void adjacency = seam) -- and count white-over-gray pixels."""
import sys
from pathlib import Path

import numpy as np
import cv2

SEQ = Path(__file__).resolve().parent
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SEQ))
sys.path.insert(0, str(SFLOW))

import h_pipeline_final as H  # noqa: E402  (sequential)
import sequential_fusion_flowonly as SF  # noqa: E402


def depth_discontinuity_mask_single(z, rel_thresh=0.02, valid=None):
    if valid is None:
        valid = H.depth_valid(z)
    step = np.full(z.shape, -1.0, dtype=np.float32)
    for dy, dx in ((0, 1), (0, -1), (1, 0), (-1, 0)):
        shifted = np.roll(np.roll(z, dy, axis=0), dx, axis=1)
        nbr = np.where(np.roll(np.roll(valid, dy, axis=0), dx, axis=1), shifted, 0.0)
        step = np.maximum(step, np.abs(z - nbr))
    edge = step > rel_thresh * np.maximum(z, 1e-6)
    return edge & valid


def edge_distance_limit_single(z, K, disc_rel=0.02, valid=None):
    edge = depth_discontinuity_mask_single(z, disc_rel, valid=valid)
    free = (~edge).astype(np.uint8)
    dist_px = cv2.distanceTransform(free, cv2.DIST_L2, 3)
    return (dist_px * z / (0.5 * (K[0, 0] + K[1, 1]))).astype(np.float32)


pairs = SF.associate(SF.DATA, max_dt=0.02)[:1]
h, w = SF.load_rgb(pairs[0].rgb_path).shape[:2]
map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)
bgr0, z0, _ = SF.load_pair(pairs, 0, map1, map2)
gt = bgr0[..., ::-1].astype(np.float32) / 255.0


def count(g0):
    depth, index, _ = H.rasterize_discs(g0, K, (h, w))
    render = np.zeros((h, w, 3), np.float32)
    hit = np.isfinite(depth)
    render[hit] = g0.color[index[hit]]
    hw = render.min(axis=2) > 0.68
    gs = (gt.mean(axis=2) > 0.15) & (gt.mean(axis=2) < 0.6)
    mask = hw & gs & hit
    sub = mask[366:400, 400:640]
    return int(mask.sum()), int(sub.sum()), len(g0)


# --- A: sequential (depth_jump_mask) ---
gA, _, _, _ = H.build_hybrid_with_owner(bgr0, z0, K, SF.TEX_Q)
print("A sequential (void ignored):   ", count(gA))

# --- B: single-frame edge semantics ---
H.edge_distance_limit = edge_distance_limit_single
gB, _, _, _ = H.build_hybrid_with_owner(bgr0, z0, K, SF.TEX_Q)
print("B single-frame (void = seam):  ", count(gB))