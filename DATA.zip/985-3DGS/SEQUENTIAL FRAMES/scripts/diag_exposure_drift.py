"""Measure global exposure / white-balance drift over the 80-frame sequence.

The colour gate compares a disc's stored colour against the current pixel
observation:  ||c_obs - c_disc|| <= COLOR_GATE_K * sqrt(TEX_VAR_THR).
If the camera's auto-exposure / white-balance drifts over the run, the same
physical surface is observed with slowly changing colour, so a disc that has
not been written recently drifts away from the live observation and the gate
starts rejecting it (spurious new discs -> dirty edges).

This script measures the *global* per-frame colour trend (median + mean RGB
over the undistorted image), which isolates exposure drift from the content
change a moving camera introduces. It does NOT run the fusion; it only loads
the raw frames the pipeline consumes.

Reports:
  * per-frame median RGB and per-frame mean RGB (CSV + console)
  * total drift  ||m79 - m0||  and per-frame median step, both vs the gate
    threshold COLOR_GATE_K * sqrt(TEX_VAR_THR).
"""

from __future__ import annotations

import csv
import sys
from pathlib import Path

import cv2
import numpy as np

SEQ = Path(__file__).resolve().parent
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SEQ))
sys.path.insert(0, str(SFLOW))

import sequential_fusion_flowonly as SF  # noqa: E402
from tum_io import FR1_INTRINSICS  # noqa: E402

OUT = SF.SEQ.parent / "output_exposure_drift.csv"
GATE = SF.COLOR_GATE_K * float(np.sqrt(SF.COLOR_GATE_VAR_FLOOR))


def main() -> None:
    nframes = 81  # frames 0..80 == the 80-transition run
    pairs = SF.associate(SF.DATA, max_dt=0.02)[:nframes]
    sample = SF.load_rgb(pairs[0].rgb_path)
    h, w = sample.shape[:2]
    map1, map2, _ = SF.undistort_maps((h, w), FR1_INTRINSICS)

    med = np.zeros((len(pairs), 3), dtype=np.float64)
    mean = np.zeros((len(pairs), 3), dtype=np.float64)
    for i, p in enumerate(pairs):
        bgr = SF.remap_rgb(SF.load_rgb(p.rgb_path), map1, map2).astype(np.float32) / 255.0
        rgb = bgr[..., ::-1].reshape(-1, 3)
        # exclude the undistortion black border (near-zero luminance pixels)
        lum = rgb @ np.array([0.299, 0.587, 0.114])
        keep = lum > 0.05
        rgb = rgb[keep]
        med[i] = np.median(rgb, axis=0)
        mean[i] = np.mean(rgb, axis=0)

    with OUT.open("w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["frame", "med_r", "med_g", "med_b", "mean_r", "mean_g", "mean_b"])
        for i in range(len(pairs)):
            w.writerow([i, *[f"{v:.6f}" for v in med[i]], *[f"{v:.6f}" for v in mean[i]]])

    dmed = np.diff(med, axis=0)
    dmean = np.diff(mean, axis=0)
    med_step = np.linalg.norm(dmed, axis=1)
    mean_step = np.linalg.norm(dmean, axis=1)

    total_med = float(np.linalg.norm(med[-1] - med[0]))
    total_mean = float(np.linalg.norm(mean[-1] - mean[0]))

    # drift-from-frame0 trajectory: ||med[i] - med[0]|| for each frame. Its
    # percentiles are the candidate COLOR_LIGHT_MAX values (vs the current median
    # total 0.27) -- the budget an old disc would need to admit the run's lighting
    # drift at each percentile of "how far the camera colour sits from frame 0".
    med_from0 = np.linalg.norm(med - med[0], axis=1)
    mean_from0 = np.linalg.norm(mean - mean[0], axis=1)

    print(f"gate threshold  = {GATE:.5f}  (COLOR_GATE_K * sqrt(TEX_VAR_THR))")
    print(f"n_frames        = {len(pairs)} (frames 0..{len(pairs)-1})")
    print()
    print(f"median-colour drift  frame0->frame{len(pairs)-1}: {total_med:.5f}  "
          f"({total_med / GATE:.2f}x gate)")
    print(f"mean-colour   drift  frame0->frame{len(pairs)-1}: {total_mean:.5f}  "
          f"({total_mean / GATE:.2f}x gate)")
    print()
    for tag, s in [("median-colour", med_step), ("mean-colour", mean_step)]:
        print(f"  {tag} per-frame step: p50={np.percentile(s, 50):.5f} "
              f"p75={np.percentile(s, 75):.5f} p90={np.percentile(s, 90):.5f} "
              f"max={s.max():.5f}")
    print()
    for tag, s in [("median-colour", med_from0), ("mean-colour", mean_from0)]:
        print(f"  {tag} drift-from-frame0: p50={np.percentile(s, 50):.5f} "
              f"p75={np.percentile(s, 75):.5f} p90={np.percentile(s, 90):.5f} "
              f"max={s.max():.5f}")
    print()
    print("per-frame median RGB (r,g,b):")
    for i in range(len(pairs)):
        print(f"  {i:3d}  {med[i,0]:.4f} {med[i,1]:.4f} {med[i,2]:.4f}   "
              f"| step={med_step[i-1]:.4f}" if i else f"  {i:3d}  {med[i,0]:.4f} {med[i,1]:.4f} {med[i,2]:.4f}")
    print()
    print(f"wrote {OUT}")


if __name__ == "__main__":
    main()