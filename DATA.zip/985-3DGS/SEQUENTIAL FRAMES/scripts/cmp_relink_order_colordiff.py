"""Hard ray-disc render vs original frame-0 RGB, A/B on relink order.

The ablation changed disc colours (A relink-first vs B flow-first). This diffs
each run's ray-disc render (`f0_hard.png`) against the undistorted frame-0 RGB
(`f0_gt.png`) so the colour discrepancy is visible and measurable.

Holes are taken from `f0_depth_hard.npy` (0.0 == no hit) so near-black discs are
not mistaken for holes; the fair A-vs-B number is reported on the shared hit set.

Run:
  python scripts/cmp_relink_order_colordiff.py
"""

from __future__ import annotations

import json
from pathlib import Path

import cv2
import numpy as np

SEQ = Path(__file__).resolve().parent
A = SEQ.parent / "output_f0_80frame_olddraw"      # relink-first (current default)
B = SEQ.parent / "output_f0_80frame_flowfirst"    # flow-first (legacy order)
BAR = 36
LEFT_W = 160


def load(run: Path):
    gt = cv2.imread(str(run / "f0_gt.png")).astype(np.float32)
    hard = cv2.imread(str(run / "f0_hard.png"))[: -BAR].astype(np.float32)
    dep = np.load(run / "f0_depth_hard.npy")
    assert gt.shape[:2] == hard.shape[:2] == dep.shape[:2], (gt.shape, hard.shape, dep.shape)
    return gt, hard, np.isfinite(dep) & (dep > 1e-9)


def err_map(hard, gt, hit):
    e = np.abs(hard - gt).max(axis=2)
    return np.where(hit, e, 0.0)


def heat(e, hit, scale=1.5):
    n = np.clip(e * scale / 255.0, 0, 1)
    col = cv2.applyColorMap((n * 255).astype(np.uint8), cv2.COLORMAP_TURBO)
    col[~hit] = 0
    return col


def cap(img, text, h=BAR):
    bar = np.full((h, img.shape[1], 3), 20, np.uint8)
    cv2.putText(bar, text, (8, h - 12), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                (235, 235, 235), 1, cv2.LINE_AA)
    return np.vstack([img, bar])


def stats(tag, e, hit_own, hit_shared, w=0):
    def q(m):
        return (float(e[m].mean()), float(np.percentile(e[m], 95)), int((e[m] > 25).sum())) \
            if m.any() else (float("nan"),) * 2 + (0,)
    a, a95, a25 = q(hit_own)
    s, s95, s25 = q(hit_shared)
    print(f"  {tag:14s} cover={hit_own.mean():.3f}  own-hit err mean={a:6.2f} p95={a95:6.2f} "
          f">25px={a25:6d} ({100 * a25 / max(int(hit_own.sum()), 1):4.1f}%)")
    print(f"  {'':14s} shared-hit err mean={s:6.2f} p95={s95:6.2f} "
          f">25px={s25:6d} ({100 * s25 / max(int(hit_shared.sum()), 1):4.1f}%)")
    return dict(cover=float(hit_own.mean()), err_mean=a, err_p95=a95, px_gt25=a25,
                shared_mean=s, shared_p95=s95, shared_gt25=s25)


def main() -> None:
    gt_a, hard_a, hit_a = load(A)
    gt_b, hard_b, hit_b = load(B)
    assert np.array_equal(gt_a, gt_b)
    gt = gt_a
    shared = hit_a & hit_b
    left = np.zeros(gt.shape[:2], bool)
    left[:, :LEFT_W] = True

    ea = err_map(hard_a, gt, hit_a)
    eb = err_map(hard_b, gt, hit_b)

    print("== hard ray-disc render vs frame-0 RGB ==")
    sa = stats("A relink-first", ea, hit_a, shared)
    sb = stats("B flow-first", eb, hit_b, shared)
    print(f"  shared hit {int(shared.sum())} px ({100 * shared.mean():.1f}% of image)")
    for nm, m in (("A only", hit_a & ~hit_b), ("B only", hit_b & ~hit_a)):
        print(f"  {nm:8s} hit {int(m.sum()):6d} px  left={int((m & left).sum()):6d}")
    for nm, m in (("all", shared), ("left", shared & left)):
        d = np.abs(hard_a - hard_b).max(axis=2)[m]
        w = ea[m] - eb[m]
        print(f"  [{nm:4s}] shared A-B render |d| mean={d.mean():6.2f} p95={np.percentile(d, 95):6.2f}"
              f"  ({100 * (d > 25).mean():4.1f}% >25)   err(A-B) mean={w.mean():+6.2f} "
              f"(A worse on {100 * (w > 10).mean():4.1f}%, B worse on {100 * (w < -10).mean():4.1f}%)")
    stat = dict(a=sa, b=sb, shared_px=int(shared.sum()))

    # ---------- montage ----------
    gtg = cap(gt.astype(np.uint8), "GT frame0 RGB (undistorted)")
    gha = cap(hard_a.astype(np.uint8), f"A relink-first 81f | err mean {sa['err_mean']:.1f}")
    ghb = cap(hard_b.astype(np.uint8), f"B flow-first  81f | err mean {sb['err_mean']:.1f}")
    hea = cap(heat(ea, hit_a), "|A - GT| error (turbo, holes black)")
    heb = cap(heat(eb, hit_b), "|B - GT| error (turbo, holes black)")
    sd = np.clip(ea - eb, -255, 255)
    sc = np.zeros((*sd.shape, 3), np.uint8)
    sc[..., 2] = np.clip(sd * 2, 0, 255)      # red  = A further from GT
    sc[..., 0] = np.clip(-sd * 2, 0, 255)     # blue = B further from GT
    sc[~shared] = 0
    gsd = cap(sc, "err(A) - err(B) on shared hit: RED=A worse, BLUE=B worse")
    full = np.vstack([gtg, gha, ghb, hea, heb, gsd])
    out = B / "cmp_relink_order_colordiff.png"
    cv2.imwrite(str(out), full)

    leftmont = np.hstack([x[:480, :LEFT_W] for x in (gtg, gha, ghb, hea, heb, gsd)])
    leftmont = np.vstack([
        np.vstack([gtg[:480, :LEFT_W], gha[:480, :LEFT_W], ghb[:480, :LEFT_W]]),
        np.vstack([hea[:480, :LEFT_W], heb[:480, :LEFT_W], gsd[:480, :LEFT_W]]),
    ])
    lout = B / "cmp_relink_order_colordiff_left.png"
    cv2.imwrite(str(lout),
                cv2.resize(leftmont, None, fx=2.4, fy=2.4, interpolation=cv2.INTER_NEAREST))
    (B / "cmp_relink_order_colordiff_stats.json").write_text(json.dumps(stat, indent=2))
    print(f"\nsaved -> {out}\n         {lout}")


if __name__ == "__main__":
    main()