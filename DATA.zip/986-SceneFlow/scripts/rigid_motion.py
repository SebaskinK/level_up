"""Fit camera motion from scene-flow correspondences (static-scene step).

X1 = R_10 X0 + t_10   (3D points expressed in each camera frame)
Camera ego-motion T_01 is the inverse: R_01 = R_10^T, t_01 = -R_10^T t_10
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class RigidFit:
    R_10: np.ndarray
    t_10: np.ndarray
    inlier_ratio: float
    n_used: int
    n_inliers: int
    residual_med: float
    inliers: np.ndarray | None = None


def umeyama(
    src: np.ndarray,
    dst: np.ndarray,
    w: np.ndarray | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    """Best rigid transform dst ≈ R @ src + t (no scale). src/dst: (N,3)."""
    if w is None:
        mu_s = src.mean(axis=0)
        mu_d = dst.mean(axis=0)
        cov = ((dst - mu_d).T @ (src - mu_s)) / src.shape[0]
    else:
        wn = w / w.sum()
        mu_s = wn @ src
        mu_d = wn @ dst
        cov = (dst - mu_d).T @ ((src - mu_s) * wn[:, None])
    U, _, Vt = np.linalg.svd(cov)
    S = np.eye(3)
    if np.linalg.det(U) * np.linalg.det(Vt) < 0:
        S[2, 2] = -1
    R = U @ S @ Vt
    t = mu_d - R @ mu_s
    return R, t


def depth_sigma(z: np.ndarray, sigma_ref: float = 0.0031, z_ref: float = 0.75) -> np.ndarray:
    """Correspondence noise grows as z^1.33 (measured on fr1/desk)."""
    return sigma_ref * (np.maximum(z, 0.3) / z_ref) ** 1.33


def ransac_rigid(
    X0: np.ndarray,
    X1: np.ndarray,
    thresh: float = 0.025,
    iters: int = 80,
    min_pts: int = 32,
    rng: np.random.Generator | None = None,
) -> RigidFit | None:
    rng = rng or np.random.default_rng(0)
    n = X0.shape[0]
    if n < min_pts:
        return None
    sigma = depth_sigma(X0[:, 2])
    gate = thresh
    best_inl = None
    best_count = 0
    for _ in range(iters):
        idx = rng.choice(n, size=3, replace=False)
        try:
            R, t = umeyama(X0[idx], X1[idx])
        except np.linalg.LinAlgError:
            continue
        err = np.linalg.norm(X0 @ R.T + t - X1, axis=1)
        inl = err < gate
        c = int(inl.sum())
        if c > best_count:
            best_count = c
            best_inl = inl
    if best_inl is None or best_count < min_pts:
        return None

    inl = best_inl
    for _ in range(3):
        w = 1.0 / sigma[inl] ** 2
        R, t = umeyama(X0[inl], X1[inl], w)
        err = np.linalg.norm(X0 @ R.T + t - X1, axis=1)
        new_inl = err < gate
        if int(new_inl.sum()) < min_pts:
            break
        inl = new_inl

    w = 1.0 / sigma[inl] ** 2
    R, t = umeyama(X0[inl], X1[inl], w)
    res = np.linalg.norm(X0[inl] @ R.T + t - X1[inl], axis=1)
    return RigidFit(
        R_10=R,
        t_10=t,
        inlier_ratio=float(inl.mean()),
        n_used=n,
        n_inliers=int(inl.sum()),
        residual_med=float(np.median(res)),
        inliers=inl,
    )


def invert_point_motion(R_10: np.ndarray, t_10: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    R_01 = R_10.T
    t_01 = -R_10.T @ t_10
    return R_01, t_01


def rot_angle_deg(R: np.ndarray) -> float:
    c = np.clip((np.trace(R) - 1.0) * 0.5, -1.0, 1.0)
    return float(np.degrees(np.arccos(c)))


def geodesic_deg(R_est: np.ndarray, R_gt: np.ndarray) -> float:
    return rot_angle_deg(R_est.T @ R_gt)
