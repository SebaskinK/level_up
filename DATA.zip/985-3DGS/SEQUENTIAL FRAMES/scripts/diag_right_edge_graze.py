"""Confirm the right-edge fracture mechanism: are the nearest discs near
edge-on (grazing angle) and sub-pixel in projected minor axis?

For each hole pixel in the region, print the nearest disc's 3D radius (mm),
projected major/minor radii (px), grazing angle between normal and view ray,
and isotropic(S2) vs anisotropic class. This separates (a) sub-pixel projected
ellipse -> integer-rasterization gaps from (b) a genuine 3D coverage void.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

SEQ = Path(__file__).resolve().parent
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SEQ))
sys.path.insert(0, str(SFLOW))

import h_pipeline_final as H            # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402

FINAL = SEQ.parent / "output_f0_ellipse_final" / "model_f0.npz"
F0 = SEQ.parent / "output_f0_0frame" / "model_f0.npz"
Z_MIN, Z_MAX = 0.4, 4.0


def tangent_basis(n):
    n = n.astype(np.float64)
    n = n / np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-12)
    ref = np.tile(np.array([0.0, 0.0, 1.0]), (n.shape[0], 1))
    ref[np.abs(n[:, 2]) > 0.9] = np.array([1.0, 0.0, 0.0])
    t1 = np.cross(ref, n)
    t1 = t1 / np.maximum(np.linalg.norm(t1, axis=1, keepdims=True), 1e-12)
    t2 = np.cross(n, t1)
    return t1, t2


def load_g(path: Path):
    d = np.load(path)
    mu = d["mu"].astype(np.float64)
    normal = d["normal"].astype(np.float64)
    scale = d["scale"].astype(np.float64)
    color = d["color"].astype(np.float64)
    birth = d["birth"].astype(np.int64)
    t1, t2 = tangent_basis(normal)
    g = H.Gaussians(
        mu=mu, normal=normal, scale=scale,
        quat=H._quat_from_frame(t1.astype(np.float32), t2.astype(np.float32), normal.astype(np.float32)),
        color=color, alpha=None,
        pixel=np.zeros((len(mu), 2), np.int32),
        axis1=t1.astype(np.float32), axis2=t2.astype(np.float32))
    return g, birth


def main() -> None:
    pairs = SF.associate(SF.DATA, max_dt=0.02)[: 11]
    sm = SF.load_rgb(pairs[0].rgb_path)
    h, w = sm.shape[:2]
    m1, m2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)
    bgr0, z0, _ = SF.load_pair(pairs, 0, m1, m2)
    valid = (z0 > Z_MIN) & (z0 < Z_MAX)

    for name, path in [("FINAL10", FINAL), ("FRAME0", F0)]:
        g, birth = load_g(path)
        depth, index, _ = H.rasterize_discs(g, K, (h, w))
        hole = ~np.isfinite(depth) & valid
        R0, R1, C0 = 335, 390, 560
        reg = hole[R0:R1, C0:]
        yy, xx = np.nonzero(reg)
        hy = yy + R0
        hx = xx + C0

        fx, fy, cx, cy = (float(K[0,0]), float(K[1,1]), float(K[0,2]), float(K[1,2]))
        zc = np.maximum(g.mu[:, 2], 1e-6)
        uc = (fx * g.mu[:, 0] / zc + cx).astype(np.float64)
        vc = (fy * g.mu[:, 1] / zc + cy).astype(np.float64)
        # nearest disc
        best_d = np.full(hy.size, np.inf)
        best_i = np.full(hy.size, -1, np.int32)
        CH = 512
        for s in range(0, hy.size, CH):
            e = min(s + CH, hy.size)
            du = hx[s:e, None] - uc[None, :]
            dv = hy[s:e, None] - vc[None, :]
            dd = du*du + dv*dv
            bi = dd.argmin(axis=1)
            best_d[s:e] = dd[np.arange(e-s), bi]
            best_i[s:e] = bi
        best_d = np.sqrt(best_d)
        idx = best_i

        r1 = g.scale[idx, 0]
        r2 = g.scale[idx, 1]
        thin = g.scale[idx, 2]
        nrm = g.normal[idx]
        mu = g.mu[idx]
        zz = np.maximum(mu[:, 2], 1e-6)
        # view ray direction = (0,0,0) - mu normalized -> -mu/|mu|
        view = -mu / np.linalg.norm(mu, axis=1, keepdims=True)
        cosg = np.abs(np.einsum("ij,ij->i", nrm, view))
        graze_deg = np.degrees(np.arccos(np.clip(cosg, 0, 1)))
        proj_maj = 0.5*(fx+fy) * np.maximum(r1, r2) / zz
        proj_min = 0.5*(fx+fy) * np.minimum(r1, r2) / zz
        # for a circle, minor shrinks by cos(grazing); approx projected minor axis
        proj_min_eff = proj_min * cosg
        iso = np.abs(r1 - r2) < 1e-6 * np.maximum(r1, 1e-9)

        print(f"\n=== {name}: {hy.size} holes in region ===  (radii in mm)")
        # aggregate
        for label, v in [("r1_mm", r1*1000), ("r2_mm", r2*1000), ("thin_mm", thin*1000),
                         ("proj_maj_px", proj_maj), ("proj_min_px", proj_min),
                         ("proj_min_eff_px", proj_min_eff), ("graze_deg", graze_deg),
                         ("ctr_dist_px", best_d)]:
            print(f"  {label:16s} min={v.min():.2f} med={np.median(v):.2f} p90={np.percentile(v,90):.2f} max={v.max():.2f}")
        print(f"  S2(iso) frac={iso.mean():.3f}")
        print(f"  graze>70deg frac={(graze_deg>70).mean():.3f}  >80deg={(graze_deg>80).mean():.3f}")
        print(f"  proj_min_eff<0.5px frac={(proj_min_eff<0.5).mean():.3f}")
        # nearest disc that FAILS to cover: hole pixel outside projected ellipse even using exact axes?
        # (we only have tangent-basis approx axes; for iso discs it is exact)
        print("  sample holes (row,col | r1 r2 mm | projMaj projMin px | graze | dist | iso | birth):")
        order = np.argsort(graze_deg)[::-1][:12]
        for k in np.sort(order):
            print(f"    ({hy[k]:3d},{hx[k]:3d}) r1={r1[k]*1000:5.1f} r2={r2[k]*1000:5.1f} "
                  f"maj={proj_maj[k]:4.2f} min={proj_min[k]:4.2f} "
                  f"graze={graze_deg[k]:5.1f} d={best_d[k]:4.2f} iso={int(iso[k])} birth={birth[idx[k]]}")


if __name__ == "__main__":
    main()