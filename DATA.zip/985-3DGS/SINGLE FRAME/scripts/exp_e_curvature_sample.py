"""Experiment E: curvature-anisotropic discs with coverage sampling.

Chains the three pieces validated in experiment D:

  1. Gaussian scale-space curvature (the box blur used earlier was the wrong
     low-pass for a second derivative)
  2. per-direction radius r_i = min(sqrt(2 eps / |k_i|), footprint)
  3. greedy coverage sampling so the spacing follows the radius -- without this
     the count never drops, however large the discs grow

Compared against the uniform-stride baselines from experiment A at matched
primitive counts. The question experiment B failed to answer: can fewer, larger
primitives keep both coverage and depth accuracy?
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
import time
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from curvature import curvature_radii, scale_space_curvature  # noqa: E402
from gaussian_build import (  # noqa: E402
    CurvatureGeometry,
    build_gaussians,
    build_gaussians_curvature,
    compute_curvature_geometry,
    coverage_sample,
    coverage_sample_elliptical,
    coverage_sample_elliptical_fast,
    depth_discontinuity_mask,
    depth_valid,
    edge_distance_limit,
    normals_from_depth,
    prefilter_depth,
    surfel_radius,
)
from metrics import evaluate  # noqa: E402
from rgbd_io import (  # noqa: E402
    FR1_INTRINSICS,
    associate,
    load_depth,
    load_rgb,
    remap_depth,
    remap_rgb,
    undistort_maps,
)

METRIC_KEYS = (
    "n_gaussians", "coverage", "hole_frac",
    "depth_rmse_mm", "depth_mae_mm", "depth_med_mm", "depth_p95_mm",
    "normal_med_deg", "normal_mean_deg", "normal_p95_deg",
    "color_rmse", "color_psnr_db",
    "gauss_per_m2", "radius_med_mm", "build_ms",
)


def curvature_mask(
    z: np.ndarray, K: np.ndarray, eps: float, gauss_sigma: float,
    z_min: float, z_max: float, disc_rel: float, overlap: float,
    r_max: float, foreshorten: bool = False,
    aniso_claim: bool = True,
    min_nz: float = 0.15,
    edge_fallback_fp: bool = True,
    texture_mask: np.ndarray | None = None,
    r_cap: np.ndarray | None = None,
    geo: CurvatureGeometry | None = None,
    greedy_fast: bool = True,
) -> np.ndarray:
    """Pixels to keep: coverage sampling driven by the curvature radius.

    z must be the RAW depth: the Gaussian is applied here so the normal and the
    curvature come from one and the same smoothed surface.

    aniso_claim defaults True: claim the disc's projected ellipse rather than a
    square, so holes only open where a disc genuinely cannot reach (tilt >
    arccos(overlap)) instead of where the square's diagonal over-runs the
    projection. Measured on fr1/desk (3 frames): coverage 0.908 -> 0.940, hole
    0.092 -> 0.060, at 2.02x primitives -- vs the old foreshortening's 2.57x for
    the same coverage. See exp_g_aniso_real.py / EXPERIMENT_G.md E1.

    edge_fallback_fp defaults True: a pixel whose distance to a depth
    discontinuity is below one footprint (lim < r_fp) used to be dropped, which
    carved a black band on BOTH sides of every A/B occlusion edge. Re-emit it at
    the footprint radius instead: a ~2 px disc cannot over-reach far enough to
    win a background depth test, and the emitter's own depth is a real
    measurement. Measured on fr1/desk (3 frames): hole 0.060 -> 0.031 with no
    RMSE regression. See EXPERIMENT_G.md sec 9.

    Pass `geo` (from compute_curvature_geometry) to reuse the geometry already
    computed for the emitter instead of recomputing it here. When omitted the
    fields are computed internally (standalone baseline behaviour preserved).
    """
    if geo is not None:
        valid_depth = geo.valid_depth
        z_s, normal, n_ok = geo.z_grad, geo.normal, geo.n_ok
        c_ok = geo.c_ok
        r_k1, r_k2 = geo.r_k1, geo.r_k2
        r_fp = geo.r_fp
        r_edge = geo.r_edge
        k1, k2 = geo.k1, geo.k2
        disc_mask = geo.disc_mask
    else:
        valid_depth = depth_valid(z)
        z_s = prefilter_depth(z, "gauss", gauss_sigma, valid=valid_depth)
        normal, n_ok = normals_from_depth(z_s, K)
        k1, k2, _, c_ok, _ = scale_space_curvature(z_s, K)
        r_k1, _ = curvature_radii(k1, k2, eps)
        r_fp = surfel_radius(z, normal[..., 2], K)
        r_edge = edge_distance_limit(z, K, disc_rel, valid=valid_depth)
        disc_mask = depth_discontinuity_mask(z, disc_rel, valid=valid_depth)
    # Spacing follows the *short* axis: that is what limits how far apart
    # neighbouring discs may sit before a hole opens.
    lim = np.minimum(r_max, r_edge)
    # Where the constraints contradict each other, drop the pixel instead of
    # relaxing a constraint to keep it. Two cases, both previously papered over:
    #   r_k1 < r_fp : curvature says the disc must be smaller than one pixel's
    #                 footprint, i.e. the structure is finer than the sampling.
    #                 clip() used to raise it to r_fp and keep the pixel.
    #   lim  < r_fp : the pixel sits closer to a depth discontinuity than one
    #                 footprint. max(lim, r_fp) used to pick r_fp, silently
    #                 discarding the edge constraint exactly where it matters.
    # Measured on validated planar blocks, grouped by which term set the radius:
    #   curvature wins 86.1% -> normal error 5.78 deg
    #   edge cap  wins  8.2% -> 20.48 deg
    #   fp floor  wins  6.5% -> 54.22 deg
    # so the two contradiction cases carry a 3.5-9.4x worse normal. They are
    # dominated by noise spikes rather than real structure: inside blocks whose
    # true curvature is ~0 the floor still fires on 1.57% of pixels at |k1| ~ 101
    # 1/m, twenty times the 5.1 1/m noise floor, and the outside-block rate fires
    # at a statistically indistinguishable 89.6 1/m.
    consistent = (r_k1 >= r_fp) & (lim >= r_fp)
    r = np.clip(r_k1, r_fp, np.maximum(lim, r_fp))
    if texture_mask is not None:
        # Texture regions stay at one pixel's footprint: no curvature enlargement.
        r = np.where(texture_mask, r_fp, r)
    if r_cap is not None:
        # Same radius wall the emitter applies (tex_boundary_limit): the greedy
        # claim MUST use the same shrunk radius or it claims space the emitted
        # disc no longer covers, opening a seam along the boundary.
        r = np.minimum(r, r_cap)
    radius_px = 0.5 * (K[0, 0] + K[1, 1]) * r / np.maximum(z, 1e-6)
    if foreshorten:
        # DISABLED by default. A tilted disc does project to an ellipse squashed
        # by |n_z|, so in principle the claim should shrink by that factor. But
        # |n_z| itself is what is suspect: on a flat table patch whose fitted
        # plane has |n_z| = 0.466, the per-pixel normals report a median of 0.700
        # with a 10th percentile of 0.203. Scaling by a quantity that is itself
        # biased just cancels one error with another -- and it cost 4.4x more
        # primitives (11.5k -> 51k) to do it. Re-enable only once the normal
        # field has been validated against a trustworthy ground truth.
        radius_px = radius_px * np.abs(normal[..., 2])

    if edge_fallback_fp:
        # A "too close to a depth discontinuity" pixel was dropped entirely,
        # which carved a black band on BOTH sides of every A/B occlusion edge:
        # 74.5% of the genuine-boundary holes (>= 8 px from any z=0 void) came
        # back as lim < r_fp, i.e. the disc never got emitted. That is the wrong
        # trade for a ~1 px footprint disc. The safety the edge cap exists for
        # was large discs over-reaching a boundary and winning the depth test for
        # background pixels (RMSE ~190 mm); a footprint disc r = sqrt(2) z / f
        # over-reaches by at most ~1 px. And the position comes from the RAW
        # depth, so the emitter's own depth is a real measurement -- only its
        # normal is unreliable (54 deg) because the Gaussian straddles the
        # boundary, and at 2 px that error stays on the pixel itself.
        # Re-emit the dropped pixel at the footprint radius instead of dropping.
        # r_k1 < r_fp (structure finer than the sampling) is kept as a drop: it
        # means the measured curvature is inconsistent with a real surface.
        keep_edge = consistent | (lim < r_fp)
    else:
        keep_edge = consistent
    valid = (
        n_ok & c_ok & keep_edge & valid_depth
        & (z > z_min) & (z < z_max)
        & ~disc_mask
    )
    if not aniso_claim:
        return coverage_sample(radius_px.astype(np.float32), valid, overlap=overlap)

    # Anisotropic claim: the disc projects to an ellipse squashed along the
    # surface tilt direction. The radius feeding this is the curvature short-axis
    # radius r (already clipped to [fp, min(lim, r_max)]); the disc's long axis
    # is parallel to the isobath of the depth field, so the projectively squashed
    # short axis runs along the depth gradient direction in the image. We take
    # that from the normal's (nx, ny) two-view: the tilt direction in image space
    # is where the surface drops away, i.e. the gradient of 1/z restricted to the
    # plane. Using the normal directly (rather than the curvature principal axis)
    # keeps the claim tied to the observable that actually controls the hole:
    # |n_z|.
    fx, fy, cx, cy = K[0, 0], K[1, 1], K[0, 2], K[1, 2]
    n = normal.astype(np.float32)
    # Image-space direction of steepest descent of the surface: the projection
    # gradient of the surface normal onto the image plane. For a fronto-parallel
    # pixel the long axis is arbitrary (any direction), which is fine: the claim
    # is a circle there.
    dir_u = n[..., 0] / fx
    dir_v = n[..., 1] / fy
    dn = np.hypot(dir_u, dir_v)
    # Where the tilt direction is degenerate (n_x = n_y = 0), the ellipse is a
    # circle so we may as well use the u direction; the claim will be round.
    bad = dn < 1e-9
    # Normalise. For exactly fronto-parallel normals the direction is undefined;
    # use the image u axis to keep it deterministic.
    dir_u = np.where(bad, 1.0, dir_u / np.maximum(dn, 1e-9))
    dir_v = np.where(bad, 0.0, dir_v / np.maximum(dn, 1e-9))

    return coverage_sample_elliptical_fast(
        radius_px.astype(np.float32), valid, overlap=overlap,
        nz=np.abs(n[..., 2]), dir_u=dir_u, dir_v=dir_v, min_nz=min_nz,
    ) if greedy_fast else coverage_sample_elliptical(
        radius_px.astype(np.float32), valid, overlap=overlap,
        nz=np.abs(n[..., 2]), dir_u=dir_u, dir_v=dir_v, min_nz=min_nz,
    )


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--data", default=str(ROOT.parent.parent / "986-SceneFlow" / "rgbd_dataset_freiburg1_desk"))
    p.add_argument("--out", default=str(ROOT.parent / "output_E"))
    p.add_argument("--frames", type=int, default=10)
    p.add_argument("--eps", type=float, nargs="+", default=[0.001, 0.003])
    p.add_argument("--gauss-sigma", type=float, nargs="+", default=[2.0, 3.0, 4.0])
    p.add_argument("--overlap", type=float, default=0.7)
    p.add_argument("--r-max", type=float, default=0.15, help="hard cap on disc radius (m)")
    p.add_argument("--shrink", type=float, nargs="+", default=[0.95],
                   help="pull discs in from their own edge (edge carries the "
                        "sagitta budget, so it is the worst-error ring)")
    p.add_argument("--plane-normals", action="store_true",
                   help="fit the normal over a fixed noise-driven window")
    p.add_argument("--plane-win-px", type=float, default=9.0)
    p.add_argument("--baseline-strides", type=int, nargs="+", default=[1, 2, 4])
    p.add_argument("--prefilter", default="gauss",
                   help="normals AND curvature share this; gauss is the only "
                        "scale-space-consistent choice")
    p.add_argument("--prefilter-size", type=int, default=3)
    p.add_argument("--z-min", type=float, default=0.4)
    p.add_argument("--z-max", type=float, default=4.0)
    p.add_argument("--disc-rel", type=float, default=0.02)
    args = p.parse_args()

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    pairs = associate(Path(args.data))[: args.frames]
    if not pairs:
        raise SystemExit(f"no RGB-D pairs under {args.data}")

    sample = load_rgb(pairs[0].rgb_path)
    map1, map2, K = undistort_maps(sample.shape[:2], FR1_INTRINSICS)

    rows = []
    for i, fr in enumerate(pairs):
        bgr = remap_rgb(load_rgb(fr.rgb_path), map1, map2)
        z = remap_depth(load_depth(fr.depth_path), map1, map2)

        z_grad = prefilter_depth(z, args.prefilter, args.prefilter_size)
        normal_ref, n_ok = normals_from_depth(z_grad, K)
        eval_mask = (
            n_ok & (z > args.z_min) & (z < args.z_max)
            & ~depth_discontinuity_mask(z, args.disc_rel)
        )

        for stride in args.baseline_strides:
            t0 = time.perf_counter()
            g = build_gaussians(
                bgr, z, K, z_min=args.z_min, z_max=args.z_max,
                disc_rel=args.disc_rel, stride=stride,
                prefilter=args.prefilter, prefilter_size=args.prefilter_size,
            )
            dt = time.perf_counter() - t0
            m = evaluate(g, z, bgr, normal_ref, eval_mask, K)
            m.update(frame=i, method="uniform", param=f"s{stride}", build_ms=dt * 1e3)
            rows.append(m)
            _log(m)

        for eps in args.eps:
          for sh in args.shrink:
            for gs in args.gauss_sigma:
                t0 = time.perf_counter()
                keep = curvature_mask(
                    z, K, eps, gs, args.z_min, args.z_max,
                    args.disc_rel, args.overlap, args.r_max,
                )
                g = build_gaussians_curvature(
                    bgr, z, K, eps=eps, gauss_sigma=gs, r_max=args.r_max,
                    shrink=sh,
                    z_min=args.z_min, z_max=args.z_max,
                    disc_rel=args.disc_rel, mask=keep,
                    prefilter=args.prefilter, prefilter_size=args.prefilter_size,
                    use_plane_normals=args.plane_normals,
                    plane_win_px=args.plane_win_px,
                )
                dt = time.perf_counter() - t0
                m = evaluate(g, z, bgr, normal_ref, eval_mask, K)
                m.update(
                    frame=i, method="curvature",
                    param=f"e{eps*1000:g}g{gs:g}k{sh:g}", build_ms=dt * 1e3,
                )
                rows.append(m)
                _log(m)

    params = [f"s{s}" for s in args.baseline_strides]
    params += [f"e{e*1000:g}g{g:g}k{k:g}" for e in args.eps
               for k in args.shrink for g in args.gauss_sigma]
    summary = {}
    for prm in params:
        sel = [r for r in rows if r["param"] == prm]
        if sel:
            summary[prm] = {k: float(np.mean([r[k] for r in sel])) for k in METRIC_KEYS}

    (out_dir / "summary.json").write_text(json.dumps(summary, indent=2))
    with (out_dir / "frames.csv").open("w", newline="") as f:
        wr = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        wr.writeheader()
        wr.writerows(rows)

    print("\n=== summary (mean over frames) ===")
    print(f"{'config':<18}{'N':>8}{'cover':>8}{'rmse_mm':>9}{'med_mm':>8}"
          f"{'p95_mm':>8}{'normal':>8}{'psnr':>7}{'r_med':>8}{'ms':>7}")
    for k, v in summary.items():
        print(f"{k:<18}{v['n_gaussians']:>8.0f}{v['coverage']:>8.3f}"
              f"{v['depth_rmse_mm']:>9.2f}{v['depth_med_mm']:>8.2f}"
              f"{v['depth_p95_mm']:>8.2f}{v['normal_med_deg']:>8.2f}"
              f"{v['color_psnr_db']:>7.2f}{v['radius_med_mm']:>8.1f}"
              f"{v['build_ms']:>7.0f}")
    print(f"wrote {out_dir}")


def _log(m: dict) -> None:
    print(
        f"[f{m['frame']:02d} {m['param']:<10}] N={m['n_gaussians']:6d} "
        f"cov={m['coverage']:.3f} rmse={m['depth_rmse_mm']:6.2f}mm "
        f"med={m['depth_med_mm']:5.2f}mm normal={m['normal_med_deg']:5.2f}deg "
        f"psnr={m['color_psnr_db']:5.2f} r={m['radius_med_mm']:5.1f}mm "
        f"{m['build_ms']:6.0f}ms",
        flush=True,
    )


if __name__ == "__main__":
    main()
