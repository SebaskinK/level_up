"""Average disc radius for discs whose footprint lands in the COVERED region.

Frame 0 -> 1 (same setup as vis_overflow.py). A disc from the new leftover-miss
build is "COVERED-region" discard if its rasterized footprint overlaps the
leftover (flow-miss) mask. Reports both the world-space scale axes and the
projected pixel-footprint radius, so the number is comparable to the pixel
footprint class in the overflow visualisation.
"""

import sys
from pathlib import Path

import numpy as np

SEQ = Path(__file__).resolve().parent
SINGLE = SEQ.parent.parent / "SINGLE FRAME" / "scripts"
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SINGLE))
sys.path.insert(0, str(SFLOW))

import h_pipeline_final as H  # noqa: E402
import incremental_hybrid as INC  # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402
from scene_flow import compute_scene_flow  # noqa: E402
from se3 import se3_exp  # noqa: E402
from tum_io import associate, load_rgb, load_depth, undistort_maps, FR1_INTRINSICS, remap_rgb, remap_depth  # noqa: E402


def stats(a, name):
    if a.size == 0:
        print(f"  {name:28s} n=0")
        return
    print(f"  {name:28s} n={a.size:6d}  "
          f"mean={a.mean():.4f}  med={np.median(a):.4f}  "
          f"p10={np.percentile(a,10):.4f}  p90={np.percentile(a,90):.4f}")


def main() -> None:
    pairs = associate(SF.DATA)
    h, w = load_rgb(pairs[0].rgb_path).shape[:2]
    map1, map2, K = undistort_maps((h, w), FR1_INTRINSICS)

    def lp(i):
        p = pairs[i]
        bgr = remap_rgb(load_rgb(p.rgb_path), map1, map2)
        z = remap_depth(load_depth(p.depth_path), map1, map2)
        z[z < SF.Z_MIN] = 0.0
        z[z > SF.Z_MAX] = 0.0
        return bgr, z

    bgr0, z0 = lp(0)
    g0, _, _ = H.build_hybrid(bgr0, z0, K, SF.TEX_Q)
    model = SF.Model(
        g=g0, w=np.ones(len(g0), np.float32), age=np.zeros(len(g0), np.int32),
        owner=SF.owner_from_raster(g0, K, (h, w)), birth=np.zeros(len(g0), np.int32),
        cnt=np.ones(len(g0), np.float32),
    )

    bgr1, z1 = lp(1)
    sf = compute_scene_flow(bgr0, bgr1, z0, z1, K, prev=None, dt=1.0, prev_dt=1.0)
    R_10, t_10 = se3_exp(sf.xi)
    owner_w = SF.warp_owner(model.owner, sf.u, sf.v, sf.valid)
    owner_w = SF._fill_owner_backward(owner_w, model.owner, sf)

    valid_depth = (z1 > SF.Z_MIN) & (z1 < SF.Z_MAX)
    leftover = valid_depth & (owner_w < 0)
    g_new = INC.build_hybrid_region(bgr1, z1, K, SF.TEX_Q, leftover)

    _, idx_new, _ = H.rasterize_discs(g_new, K, (h, w))
    new_hit = idx_new >= 0
    covered = new_hit & leftover

    # Disc ids whose footprint covers at least one leftover pixel.
    covered_ids = np.unique(idx_new[covered])
    covered_ids = covered_ids[covered_ids >= 0]

    other_ids = np.unique(idx_new[new_hit & ~leftover])
    other_ids = other_ids[(other_ids >= 0) & ~np.isin(other_ids, covered_ids)]

    f_mean = 0.5 * (K[0, 0] + K[1, 1])
    zc = g_new.mu[:, 2]
    # projected pixel-footprint radius, matching rasterize_discs' max(r_a, r_b)
    proj_px = f_mean * np.maximum(g_new.scale[:, 0], g_new.scale[:, 1]) / np.maximum(zc, 1e-6)

    print(f"leftover px      = {int(leftover.sum())}")
    print(f"new discs total  = {len(g_new)}")
    print(f"covered px       = {int(covered.sum())}")
    print(f"covered discs    = {covered_ids.size}")
    print(f"other discs      = {other_ids.size}")
    print()
    print("COVERED-region discs:")
    stats(g_new.scale[covered_ids, 0] * 1000.0, "short axis r1 (mm)")
    stats(g_new.scale[covered_ids, 1] * 1000.0, "long axis r2 (mm)")
    stats(g_new.scale[covered_ids, 2] * 1000.0, "thin axis (mm)")
    stats(proj_px[covered_ids], "proj footprint radius (px)")
    print()
    print("ALL new discs (for contrast):")
    stats(g_new.scale[:, 0] * 1000.0, "short axis r1 (mm)")
    stats(g_new.scale[:, 1] * 1000.0, "long axis r2 (mm)")
    stats(proj_px, "proj footprint radius (px)")
    print()
    print("OTHER (overflow-only) discs:")
    stats(g_new.scale[other_ids, 1] * 1000.0, "long axis r2 (mm)")
    stats(proj_px[other_ids], "proj footprint radius (px)")


if __name__ == "__main__":
    main()