"""Experiment H: curvature pipeline with a texture mask forcing footprint discs.

Idea (supersedes the S2-seeded hybrid in exp_g_s2_hybrid.py, which was driven
bottom-up from S2 seeds and never had a principled texture criterion):

  * the curvature pipeline stays the base (same normal/curvature/coverage path)
  * a texture mask is computed FIRST, in RGB, cheaply, without the curvature
    computation
  * pixels inside the mask keep one pixel's footprint radius (no curvature
    enlargement); pixels outside use the full curvature radius
  * the mask threshold is adaptive: a quantile of the per-pixel local colour
    variance, so it lands on a value for most scenes but needs no hand tuning
    while being developed

Local colour variance is computed in RGB (no Lab conversion: cheaper and no
extra colour path), over a 9x9 box window -- the SAME explicit support the
curvature quadric uses, so the texture estimate is self-consistent with the
geometric scale instead of tied to the disc radius (which experiment records
as a dead end: planar-but-textured regions make every large disc non-uniform).

Baselines emitted for comparison:
  * S2 uniform stride-2 (build_gaussians)
  * footprint-only (curvature path but every kept pixel stays at footprint,
    i.e. texture_mask = all True) -- this is exactly what the texture regions
    of the hybrid produce, and it was never measured standalone before.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from exp_g_aniso_real import CFG as GEO_CFG, eval_setup  # noqa: E402
from exp_e_curvature_sample import curvature_mask  # noqa: E402
from gaussian_build import build_gaussians, build_gaussians_curvature  # noqa: E402
from metrics import evaluate, rasterize_discs  # noqa: E402
from rgbd_io import (  # noqa: E402
    FR1_INTRINSICS,
    associate,
    load_depth,
    load_rgb,
    remap_depth,
    remap_rgb,
    undistort_maps,
)


def texture_variance(rgb: np.ndarray, win: int = 9) -> np.ndarray:
    """Per-pixel RGB variance over a win x win box, mean over channels.

    RGB in [0, 1] float (H, W, 3). The box support is exactly win x win, matching
    the curvature quadric's explicit support, so the texture estimate and the
    geometric derivatives see the same neighbourhood. Variance (not std) keeps
    the statistic linear and separable: E[c^2] - E[c]^2 via two box blurs.
    """
    mu = cv2.blur(rgb, (win, win))
    mu2 = cv2.blur(rgb * rgb, (win, win))
    var = mu2 - mu * mu
    return var.mean(axis=-1)  # (H, W) texture score in [0, ~0.25]


def texture_mask(rgb: np.ndarray, quantile: float, win: int = 9,
                 floor: float = 1e-9) -> np.ndarray:
    """Adaptive binary texture mask from the variance quantile.

    The threshold is the given quantile of the full-frame variance distribution,
    so it re-converges per scene without a hand-tuned absolute value. `floor`
    guards the degenerate all-zero (perfectly flat) case.
    """
    var = texture_variance(rgb, win)
    thr = float(np.quantile(var, quantile))
    thr = max(thr, floor)
    return var > thr


def concat(parts: list) -> object:
    from gaussian_build import Gaussians
    if len(parts) == 1:
        return parts[0]
    return Gaussians(
        mu=np.concatenate([p.mu for p in parts], axis=0).astype(np.float32),
        normal=np.concatenate([p.normal for p in parts], axis=0).astype(np.float32),
        scale=np.concatenate([p.scale for p in parts], axis=0).astype(np.float32),
        quat=np.concatenate([p.quat for p in parts], axis=0).astype(np.float32),
        color=np.concatenate([p.color for p in parts], axis=0).astype(np.float32),
        alpha=np.concatenate([p.alpha for p in parts], axis=0).astype(np.float32),
        pixel=np.concatenate([p.pixel for p in parts], axis=0).astype(np.int32),
        axis1=(
            np.concatenate([p.axis1 for p in parts if p.axis1 is not None], axis=0)
            if all(p.axis1 is not None for p in parts) else None
        ),
        axis2=(
            np.concatenate([p.axis2 for p in parts if p.axis2 is not None], axis=0)
            if all(p.axis2 is not None for p in parts) else None
        ),
    )


def build(dbgr, z, K, texture_quantile: float | None):
    """Build the hybrid: curvature pipeline with an optional texture mask.

    texture_quantile=None  -> full curvature baseline (mask disabled)
    otherwise              -> adaptive texture mask; masked pixels stay footprint
    """
    rgb = dbgr[..., ::-1].astype(np.float32) / 255.0
    tex_mask = texture_mask(rgb, texture_quantile) if texture_quantile is not None else None
    keep = curvature_mask(
        z, K, GEO_CFG["eps"], GEO_CFG["gauss_sigma"], GEO_CFG["z_min"],
        GEO_CFG["z_max"], GEO_CFG["disc_rel"], GEO_CFG["overlap"], GEO_CFG["r_max"],
        foreshorten=False, aniso_claim=True, edge_fallback_fp=True,
        texture_mask=tex_mask,
    )
    g = build_gaussians_curvature(
        dbgr, z, K, eps=GEO_CFG["eps"], gauss_sigma=GEO_CFG["gauss_sigma"],
        r_max=GEO_CFG["r_max"], shrink=GEO_CFG["shrink"],
        normal_mode="disc_inliers", z_min=GEO_CFG["z_min"], z_max=GEO_CFG["z_max"],
        disc_rel=GEO_CFG["disc_rel"], mask=keep, prefilter="gauss",
        prefilter_size=int(GEO_CFG["gauss_sigma"]),
    )
    return g, keep, tex_mask


def label(img, text):
    out = img.copy()
    cv2.rectangle(out, (0, 0), (out.shape[1], 34), (0, 0, 0), -1)
    cv2.putText(out, text, (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
    return out


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--data", default=str(
        ROOT.parent.parent / "986-SceneFlow" / "rgbd_dataset_freiburg1_desk"))
    p.add_argument("--out", default=str(ROOT.parent / "output_H"))
    p.add_argument("--frames", type=int, default=3)
    p.add_argument("--quantiles", type=float, nargs="+", default=[0.5, 0.6, 0.75, 0.9])
    p.add_argument("--win", type=int, default=9)
    args = p.parse_args()

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    pairs = associate(Path(args.data))
    sample = load_rgb(pairs[0].rgb_path)
    map1, map2, K = undistort_maps(sample.shape[:2], FR1_INTRINSICS)

    methods = ["S2", "footprint", "curv"]
    methods += [f"tex{q:g}" for q in args.quantiles]

    print(f"{'frame':>6}{'method':>10}{'N':>8}{'cover':>8}{'hole':>8}"
          f"{'rmse_mm':>9}{'med_mm':>8}{'n_area':>8}{'psnr':>7}")
    acc = {m: [] for m in methods}
    for i, fr in enumerate(pairs[:args.frames]):
        bgr = remap_rgb(load_rgb(fr.rgb_path), map1, map2)
        z = remap_depth(load_depth(fr.depth_path), map1, map2)
        normal_ref, eval_mask = eval_setup(z, K)

        # S2 baseline
        g_s2 = build_gaussians(
            bgr, z, K, z_min=GEO_CFG["z_min"], z_max=GEO_CFG["z_max"],
            disc_rel=GEO_CFG["disc_rel"], stride=2,
            prefilter="gauss", prefilter_size=int(GEO_CFG["gauss_sigma"]),
        )
        m = evaluate(g_s2, z, bgr, normal_ref, eval_mask, K)
        acc["S2"].append(m)
        print(f"{i:>6}{'S2':>10}{m['n_gaussians']:>8d}{m['coverage']:>8.3f}"
              f"{m['hole_frac']:>8.3f}{m['depth_rmse_mm']:>9.2f}{m['depth_med_mm']:>8.2f}"
              f"{m['normal_area_med_deg']:>8.2f}{m['color_psnr_db']:>7.2f}", flush=True)

        # footprint-only: curvature path with texture_mask = all True
        keep_fp = curvature_mask(
            z, K, GEO_CFG["eps"], GEO_CFG["gauss_sigma"], GEO_CFG["z_min"],
            GEO_CFG["z_max"], GEO_CFG["disc_rel"], GEO_CFG["overlap"], GEO_CFG["r_max"],
            foreshorten=False, aniso_claim=True, edge_fallback_fp=True,
            texture_mask=np.ones(z.shape, dtype=bool),
        )
        g_fp = build_gaussians_curvature(
            bgr, z, K, eps=GEO_CFG["eps"], gauss_sigma=GEO_CFG["gauss_sigma"],
            r_max=GEO_CFG["r_max"], shrink=GEO_CFG["shrink"],
            normal_mode="disc_inliers", z_min=GEO_CFG["z_min"], z_max=GEO_CFG["z_max"],
            disc_rel=GEO_CFG["disc_rel"], mask=keep_fp, prefilter="gauss",
            prefilter_size=int(GEO_CFG["gauss_sigma"]),
        )
        m = evaluate(g_fp, z, bgr, normal_ref, eval_mask, K)
        acc["footprint"].append(m)
        print(f"{i:>6}{'footprint':>10}{m['n_gaussians']:>8d}{m['coverage']:>8.3f}"
              f"{m['hole_frac']:>8.3f}{m['depth_rmse_mm']:>9.2f}{m['depth_med_mm']:>8.2f}"
              f"{m['normal_area_med_deg']:>8.2f}{m['color_psnr_db']:>7.2f}", flush=True)

        # full curvature baseline (no mask)
        g_cur, _, _ = build(bgr, z, K, None)
        m = evaluate(g_cur, z, bgr, normal_ref, eval_mask, K)
        acc["curv"].append(m)
        print(f"{i:>6}{'curv':>10}{m['n_gaussians']:>8d}{m['coverage']:>8.3f}"
              f"{m['hole_frac']:>8.3f}{m['depth_rmse_mm']:>9.2f}{m['depth_med_mm']:>8.2f}"
              f"{m['normal_area_med_deg']:>8.2f}{m['color_psnr_db']:>7.2f}", flush=True)

        # texture-masked hybrid at each quantile
        for q in args.quantiles:
            g_h, _, _ = build(bgr, z, K, q)
            m = evaluate(g_h, z, bgr, normal_ref, eval_mask, K)
            acc[f"tex{q:g}"].append(m)
            print(f"{i:>6}{f'tex{q:g}':>10}{m['n_gaussians']:>8d}{m['coverage']:>8.3f}"
                  f"{m['hole_frac']:>8.3f}{m['depth_rmse_mm']:>9.2f}{m['depth_med_mm']:>8.2f}"
                  f"{m['normal_area_med_deg']:>8.2f}{m['color_psnr_db']:>7.2f}", flush=True)

    print("-" * 100)
    for mth in methods:
        rs = acc[mth]
        if not rs:
            continue
        f = lambda k: float(np.mean([x[k] for x in rs]))  # noqa: E731
        print(f"{'MEAN':>6}{mth:>10}{f('n_gaussians'):>8.0f}{f('coverage'):>8.3f}"
              f"{f('hole_frac'):>8.3f}{f('depth_rmse_mm'):>9.2f}{f('depth_med_mm'):>8.2f}"
              f"{f('normal_area_med_deg'):>8.2f}{f('color_psnr_db'):>7.2f}")

    print(f"\nwrote metrics to {out_dir}")


if __name__ == "__main__":
    main()