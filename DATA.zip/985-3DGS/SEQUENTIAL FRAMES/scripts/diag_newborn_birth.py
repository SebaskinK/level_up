"""Trace the SOURCE and BIRTH-FRAME of the newly-born discs that end up front on
the left edge (the 'dirty' drift), plus render them at their birth frame.

Runs the same 80-frame fusion as diag_trace_left_edge.py (aging off), and as it
goes, records every new disc's:
  * global index (final-model array index; aging off => only append, no reindex)
  * source (0 = S2 footprint disc, 1 = curvature disc)
  * birth frame (transition index i = first observed in RGB frame i+1)
  * geometry AT BIRTH in the birth-frame camera coordinates (mu/scale/color/
    normal/pixel/axis1/axis2), so we can rasterize it in its own birth view.

Then rasterizes the final model onto the frame-0 view, finds the new discs that
become front-most on the left edge (x<64), and reports their source/birth split +
renders the top birth frames with those discs' footprints overlaid.
"""

from __future__ import annotations

import time
from pathlib import Path

import cv2
import numpy as np

import h_pipeline_final as H
import sequential_fusion_flowonly as SF


def pm_compose(a, b):
    Ra, ta = a
    Rb, tb = b
    return Rb @ Ra, Rb @ ta + tb


def pm_inv(a):
    R, t = a
    return R.T, -R.T @ t


def concat(lst):
    return np.concatenate(lst, axis=0)


def main() -> None:
    OUT = SF.SEQ.parent / "output_newborn"
    OUT.mkdir(parents=True, exist_ok=True)

    NPAIR = 81
    AGE_MAX = 1000000
    W_MIN = 0.0
    LEFT = 64  # left edge strip width in px

    pairs = SF.associate(SF.DATA, max_dt=0.02)[:NPAIR]
    sample = SF.load_rgb(pairs[0].rgb_path)
    h, w = sample.shape[:2]
    map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)

    print("building frame-0 model ...", flush=True)
    bgr0, z0, _ = SF.load_pair(pairs, 0, map1, map2)
    g0, _, _, owner0 = H.build_hybrid_with_owner(bgr0, z0, K, SF.TEX_Q)
    n_init = len(g0)
    print(f"n_init={n_init}", flush=True)

    # per-disc records, indexed by final-model global index. Originals first.
    mu_l = [g0.mu]; sc_l = [g0.scale]; co_l = [g0.color]
    nm_l = [g0.normal]; px_l = [g0.pixel]
    a1_l = [g0.axis1]; a2_l = [g0.axis2]
    src_l = [np.full(n_init, -1, dtype=np.int8)]   # -1 original
    bir_l = [np.zeros(n_init, dtype=np.int32)]      # 0 = frame 0

    model = SF.Model(
        g=g0,
        w=np.ones(n_init, dtype=np.float32),
        age=np.zeros(n_init, dtype=np.int32),
        owner=owner0,
        birth=np.zeros(n_init, dtype=np.int32),
    )
    FL = [None] * NPAIR
    FL[0] = (np.eye(3), np.zeros(3))
    prev_FL = FL[0]
    prev_sf, prev_dt = None, 1.0
    bgr_a, z_a = bgr0, z0

    t0 = time.perf_counter()
    for i in range(NPAIR - 1):
        bgr_b, z_b, _ = SF.load_pair(pairs, i + 1, map1, map2)
        dt = pairs[i + 1].t_rgb - pairs[i].t_rgb
        sf = SF.compute_scene_flow(bgr_a, bgr_b, z_a, z_b, K,
                                   prev=prev_sf, dt=dt, prev_dt=prev_dt)
        R_10, t_10 = SF.se3_exp(sf.xi)
        FL[i + 1] = pm_compose(prev_FL, (R_10, t_10))

        n_before = len(model.g)
        rec = SF.fuse_frame(model, sf, z_a, z_b, bgr_b, K,
                            age_max=AGE_MAX, w_min=W_MIN, frame_idx=i,
                            R_10=R_10, t_10=t_10)
        n_after = len(model.g)
        n_s2 = rec["n_s2"]; n_curv = rec["n_curv"]; n_new = rec["n_new"]
        assert n_new == n_s2 + n_curv == n_after - n_before, (n_new, n_s2, n_curv, n_after - n_before)

        if n_new:
            sl = slice(n_before, n_after)
            ng = model.g
            mu_l.append(np.asarray(ng.mu[sl]))
            sc_l.append(np.asarray(ng.scale[sl]))
            co_l.append(np.asarray(ng.color[sl]))
            nm_l.append(np.asarray(ng.normal[sl]))
            px_l.append(np.asarray(ng.pixel[sl]))
            a1_l.append(np.asarray(ng.axis1[sl]))
            a2_l.append(np.asarray(ng.axis2[sl]))
            src_l.append(np.concatenate([
                np.zeros(n_s2, dtype=np.int8),
                np.ones(n_curv, dtype=np.int8),
            ]))
            bir_l.append(np.full(n_new, i, dtype=np.int32))

        if (i + 1) % 10 == 0:
            print(f"[{i+1:03d}] N={len(model.g)} cum={time.perf_counter()-t0:.1f}s",
                  flush=True)
        bgr_a, z_a = bgr_b, z_b
        prev_sf, prev_dt = sf, dt
        prev_FL = FL[i + 1]

    g = model.g
    print(f"final N={len(g)}  transforming to frame 0 ...", flush=True)
    g0f = SF.transform_to_next(g, *pm_inv(FL[NPAIR - 1]))
    if g0f.axis1 is not None and g0f.axis2 is not None:
        g0f.quat = H._quat_from_frame(g0f.axis1, g0f.axis2, g0f.normal)

    print("rasterizing 80-frame model ...", flush=True)
    depth80, index80, _ = H.rasterize_discs(g0f, K, (h, w))

    # concatenate per-disc records
    mu = concat(mu_l); scale = concat(sc_l); color = concat(co_l)
    normal = concat(nm_l); pixel = concat(px_l)
    axis1 = concat(a1_l); axis2 = concat(a2_l)
    source = concat(src_l); birth = concat(bir_l)
    N = len(g)
    assert N == len(mu) == len(source) == len(birth), (N, len(mu), len(source), len(birth))

    # dirty new discs front on the left edge
    left_mask = np.zeros((h, w), dtype=bool)
    left_mask[:, :LEFT] = True
    i80_l = index80[left_mask]
    dirty_px = i80_l[(i80_l >= n_init)]           # pixels whose front disc is NEW
    dirty_idx = np.unique(dirty_px)               # unique global new-disc indices
    dirty_src = source[dirty_idx]
    dirty_bir = birth[dirty_idx]

    print("=" * 70)
    print(f"LEFT x<{LEFT}: pixels fronted by NEW discs = {len(dirty_px)}")
    print(f"  unique NEW discs front there     = {len(dirty_idx)}")
    print(f"  by source: S2={int((dirty_src==0).sum())}  curv={int((dirty_src==1).sum())}")
    src_of_px = source[i80_l[i80_l >= n_init]]
    print(f"  pixel-weighted source: S2={int((src_of_px==0).sum())}  curv={int((src_of_px==1).sum())}")

    # birth histogram (unique discs)
    b_hist, b_edges = np.histogram(dirty_bir, bins=np.arange(-0.5, 80.5, 10))
    print("  birth hist (10-frame bins, unique discs):")
    for k in range(len(b_hist)):
        if b_hist[k]:
            print(f"    {int(b_edges[k]):3d}-{int(b_edges[k+1]-1):3d}: {b_hist[k]:5d}")
    # per-source birth hist
    for lbl, sval in [("S2", 0), ("curv", 1)]:
        sel = dirty_src == sval
        if sel.any():
            hh, _ = np.histogram(dirty_bir[sel], bins=np.arange(-0.5, 80.5, 10))
            top = int(np.argmax(hh))
            print(f"  {lbl}: n={int(sel.sum())}  mode birth={hh.max()} @frame-bin {top*10}-{top*10+9}")

    # top birth frames by dirty unique-disc count
    from collections import Counter
    c = Counter(dirty_bir.tolist())
    top = c.most_common(4)
    print("  top birth frames (unique dirty discs):", top)

    # save records
    np.savez(OUT / "records.npz",
             mu=mu.astype(np.float32), scale=scale.astype(np.float32),
             color=color.astype(np.float32), normal=normal.astype(np.float32),
             pixel=pixel.astype(np.int32),
             axis1=axis1.astype(np.float32), axis2=axis2.astype(np.float32),
             source=source.astype(np.int8), birth=birth.astype(np.int32),
             n_init=np.int32(n_init))
    np.save(OUT / "index80.npy", index80.astype(np.int64))
    np.save(OUT / "dirty_idx.npy", dirty_idx.astype(np.int64))

    # render the top birth frames with the dirty discs born there overlaid
    for rank, (bf, cnt) in enumerate(top):
        sel_glob = dirty_idx[dirty_bir == bf]   # global indices born at frame bf
        if len(sel_glob) == 0:
            continue
        sub = H.Gaussians(
            mu=mu[sel_glob].astype(np.float32),
            normal=normal[sel_glob].astype(np.float32),
            scale=scale[sel_glob].astype(np.float32),
            quat=H._quat_from_frame(axis1[sel_glob].astype(np.float32),
                                    axis2[sel_glob].astype(np.float32),
                                    normal[sel_glob].astype(np.float32)),
            color=color[sel_glob].astype(np.float32),
            alpha=np.full(len(sel_glob), H.OPAQUE_ALPHA, dtype=np.float32),
            pixel=pixel[sel_glob].astype(np.int32),
            axis1=axis1[sel_glob].astype(np.float32),
            axis2=axis2[sel_glob].astype(np.float32),
        )
        # birth RGB = frame bf+1 (0-indexed)
        bgr_bf, _, _ = SF.load_pair(pairs, bf + 1, map1, map2)
        _, idx_sub, _ = H.rasterize_discs(sub, K, (h, w))
        cov = idx_sub >= 0
        vis = bgr_bf.copy()
        vis[cov] = (0, 0, 255)  # red = these dirty discs' footprint at birth
        vis = cv2.addWeighted(bgr_bf, 0.55, vis, 0.45, 0)
        # mark centres too
        for (u, v) in pixel[sel_glob]:
            cv2.circle(vis, (int(u), int(v)), 1, (0, 255, 255), -1, lineType=cv2.LINE_AA)
        fn = OUT / f"birth_{bf:03d}_n{cnt}.png"
        cv2.imwrite(str(fn), vis)
        print(f"wrote {fn}  (birth frame {bf}, {cnt} dirty discs, cov={int(cov.sum())}px)")

    print("done", flush=True)


if __name__ == "__main__":
    main()