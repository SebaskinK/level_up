"""Render arbitrary birth frames with dirty-new-disc footprints, as an Nx2 grid.

Usage: render_newborn_frames.py <frame> [<frame> ...]
Reads records.npz + dirty_idx.npy from output_newborn/ (see diag_newborn_birth.py).
"""

from __future__ import annotations

import sys
from pathlib import Path

import cv2
import numpy as np

import h_pipeline_final as H
import sequential_fusion_flowonly as SF


def tile(bf: int, mu, scale, color, normal, pixel, axis1, axis2, birth, dirty,
         pairs, map1, map2, K):
    bir_d = birth[dirty]
    sel_glob = dirty[bir_d == bf]
    sub = H.Gaussians(
        mu=mu[sel_glob].astype(np.float32),
        normal=normal[sel_glob].astype(np.float32),
        scale=scale[sel_glob].astype(np.float32),
        quat=H._quat_from_frame(axis1[sel_glob].astype(np.float32),
                                axis2[sel_glob].astype(np.float32),
                                normal[sel_glob].astype(np.float32)),
        color=color[sel_glob].astype(np.float32),
        alpha=np.full(len(sel_glob), H.OPAQUE_ALPHA, dtype=np.float32),
        pixel=pixel[sel_glob].astype(np.int32),
        axis1=axis1[sel_glob].astype(np.float32),
        axis2=axis2[sel_glob].astype(np.float32),
    )
    h, w = mu.shape[0], 0
    bgr, _, _ = SF.load_pair(pairs, bf + 1, map1, map2)
    h, w = bgr.shape[:2]
    _, idx_sub, _ = H.rasterize_discs(sub, K, (h, w))
    cov = idx_sub >= 0
    vis = bgr.astype(np.float32)
    vis[cov] = 0.35 * vis[cov] + 0.65 * np.array([255.0, 0.0, 255.0], np.float32)
    vis = vis.astype(np.uint8)
    bx = pixel[sel_glob][:, 0]
    for k, (u, v) in enumerate(pixel[sel_glob]):
        c = (255, 255, 0) if bx[k] >= 256 else (0, 255, 255)
        cv2.circle(vis, (int(u), int(v)), 2, c, -1, lineType=cv2.LINE_AA)
    cv2.putText(vis, f"birth frame {bf}  ({len(sel_glob)} discs)  cyan=born left  yellow=born right",
                (6, 18), cv2.FONT_HERSHEY_SIMPLEX, 0.42, (0, 255, 0), 1, cv2.LINE_AA)
    cv2.putText(vis, f"cov={int(cov.sum())}px", (6, 36),
                cv2.FONT_HERSHEY_SIMPLEX, 0.42, (0, 255, 0), 1, cv2.LINE_AA)
    return vis


def main() -> None:
    frames = [int(x) for x in sys.argv[1:]]
    if not frames:
        print("pass frame indices", file=sys.stderr)
        return
    OUT = SF.SEQ.parent / "output_newborn"
    r = np.load(OUT / "records.npz")
    mu = r["mu"]; scale = r["scale"]; color = r["color"]; normal = r["normal"]
    pixel = r["pixel"]; axis1 = r["axis1"]; axis2 = r["axis2"]
    birth = r["birth"]
    dirty = np.load(OUT / "dirty_idx.npy")

    NPAIR = 81
    pairs = SF.associate(SF.DATA, max_dt=0.02)[:NPAIR]
    h, w = SF.load_rgb(pairs[0].rgb_path).shape[:2]
    map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)

    tiles = [tile(bf, mu, scale, color, normal, pixel, axis1, axis2, birth, dirty,
                  pairs, map1, map2, K) for bf in frames]
    # pad to even
    if len(tiles) % 2:
        blank = np.full_like(tiles[0], 30)
        tiles.append(blank)
    rows = [np.hstack(tiles[i:i + 2]) for i in range(0, len(tiles), 2)]
    grid = np.vstack(rows)
    name = "grid_frames_" + "_".join(f"{f:02d}" for f in frames) + ".png"
    cv2.imwrite(str(OUT / name), grid)
    print("wrote", OUT / name, grid.shape)


if __name__ == "__main__":
    main()