"""Expand scene-flow inliers with a rigid model (ICP-like, not ICP).

Does not modify compute_scene_flow. Seed correspondences stay the FB-valid
DIS field. Pixels that have depth but failed appearance/FB get a correspondence
from flow_from_twist(ξ), then a geometric gate.

Borrowed from ICP: alternate fit → associate → expand; keep original inliers;
few rounds; point-to-plane gate with a 3σ depth-adaptive threshold.

Not copied from ICP: no closest-point search in 3D (dense RGB-D correspondence
is a projection, not a nearest neighbour); do not replace DIS matches; do not
iterate to convergence.
"""

from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np

from rigid_motion import depth_sigma
from scene_flow import SceneFlow, estimate_twist, flow_from_twist, warp, _grid
from se3 import apply_point_motion, se3_exp


@dataclass
class ExpandResult:
    u: np.ndarray
    v: np.ndarray
    X1: np.ndarray
    valid: np.ndarray
    expanded: np.ndarray
    xi: np.ndarray | None
    n_seed: int
    n_added: int
    rounds: int


def _normals_organized(X: np.ndarray) -> np.ndarray:
    """Camera-facing normals from an organized point map (finite differences)."""
    dx = np.roll(X, -1, axis=1) - np.roll(X, 1, axis=1)
    dy = np.roll(X, -1, axis=0) - np.roll(X, 1, axis=0)
    n = np.cross(dx, dy)
    nn = np.linalg.norm(n, axis=-1, keepdims=True)
    n = np.divide(n, np.maximum(nn, 1e-8))
    flip = np.sum(n * X, axis=-1) > 0
    n[flip] *= -1
    n[0] = n[-1] = n[:, 0] = n[:, -1] = 0
    return n


def expand_rigid_inliers(
    sf: SceneFlow,
    z0: np.ndarray,
    z1: np.ndarray,
    K: np.ndarray,
    z_min: float = 0.4,
    z_max: float = 4.0,
    rounds: int = 2,
    k_sigma: float = 3.0,
    subsample: int = 4,
) -> ExpandResult:
    """Return a copy of the field with extra geometrically consistent tracks.

    Seed = sf.valid (FB + depth). Candidates = z0 in range and not seed.
    Association for candidates is rigid projection, not closest point.
    """
    h, w = z0.shape
    xs, ys = _grid(h, w)
    fx, fy, cx, cy = float(K[0, 0]), float(K[1, 1]), float(K[0, 2]), float(K[1, 2])

    u = sf.u.copy()
    v = sf.v.copy()
    X0 = sf.X0
    X1 = sf.X1.copy()
    seed = sf.valid.copy()
    expanded = np.zeros((h, w), dtype=bool)
    n0 = _normals_organized(X0)
    n_ok = np.linalg.norm(n0, axis=-1) > 0.5
    z0_ok = (z0 > z_min) & (z0 < z_max)

    def _fit(mask: np.ndarray) -> np.ndarray | None:
        yy, xx = np.where(mask)
        if xx.size < 32:
            return None
        keep = (xx % subsample == 0) & (yy % subsample == 0)
        return estimate_twist(X0[yy[keep], xx[keep]], X1[yy[keep], xx[keep]])

    xi = sf.xi if sf.xi is not None else _fit(seed)
    if xi is None:
        return ExpandResult(u, v, X1, seed, expanded, None, int(seed.sum()), 0, 0)

    added_total = 0
    used_rounds = 0
    for _ in range(rounds):
        R, t = se3_exp(xi)
        model = flow_from_twist(X0, z0, K, xi, z_min=z_min)
        X1_model = apply_point_motion(X0, R, t)
        z1w = warp(z1, model, interpolation=cv2.INTER_NEAREST)
        x1 = xs + model[..., 0]
        y1 = ys + model[..., 1]
        inb = (x1 >= 0) & (x1 <= w - 1) & (y1 >= 0) & (y1 <= h - 1)
        z1_ok = (z1w > z_min) & (z1w < z_max)
        X1_obs = np.stack(
            [(x1 - cx) * z1w / fx, (y1 - cy) * z1w / fy, z1w],
            axis=-1,
        )
        p2p_z = np.abs(X1_obs[..., 2] - X1_model[..., 2])
        p2plane = np.abs(np.sum((X1_obs - X1_model) * n0, axis=-1))
        sigma = depth_sigma(z0)
        gate = (
            z0_ok
            & ~seed
            & ~expanded
            & inb
            & z1_ok
            & n_ok
            & (p2plane < k_sigma * sigma)
            & (p2p_z < 4.0 * k_sigma * sigma)
            & np.isfinite(model).all(axis=-1)
            & ((np.abs(model[..., 0]) + np.abs(model[..., 1])) > 0)
        )
        n_new = int(gate.sum())
        if n_new == 0:
            break
        used_rounds += 1
        expanded |= gate
        u[gate] = model[..., 0][gate]
        v[gate] = model[..., 1][gate]
        X1[gate] = X1_obs[gate]
        added_total += n_new
        xi_new = _fit(seed | expanded)
        if xi_new is None:
            break
        xi = xi_new

    return ExpandResult(
        u=u,
        v=v,
        X1=X1,
        valid=seed | expanded,
        expanded=expanded,
        xi=xi,
        n_seed=int(seed.sum()),
        n_added=added_total,
        rounds=used_rounds,
    )
