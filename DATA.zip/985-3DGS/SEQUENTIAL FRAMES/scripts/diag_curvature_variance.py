"""Reproduce the 'curvature seeds on high-variance pixels' claim and test the
void-dilution hypothesis directly.

For every curvature disc in the OLD trace (output_newborn/records.npz), evaluate
its source pixel in its birth RGB frame:
  * v_old = texture_variance (void-including, the pre-fix pipeline stat)
  * v_new = texture_variance(valid) (void-excluding)
  * dist_to_void (pixels to nearest z<=0)
Then report how the misclassification (v above the frame's texture threshold)
relates to the FOV boundary, and whether excluding void actually changes it.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import scipy.ndimage as ndi

import sequential_fusion_flowonly as SF
import h_pipeline_final as H

SEQ = Path(__file__).resolve().parent


def main() -> None:
    OUT = SEQ.parent / "output_newborn"
    r = np.load(OUT / "records.npz")
    source = r["source"].astype(np.int8)
    birth = r["birth"].astype(np.int32)
    pixel = r["pixel"].astype(np.int32)
    n_init = int(r["n_init"])

    curv = np.flatnonzero(source == 1)          # all curvature discs (incl. init)
    print(f"total discs={len(source)}  curvature={len(curv)}  n_init={n_init}")

    pairs = SF.associate(SF.DATA, max_dt=0.02)[:81]
    h, w = SF.load_rgb(pairs[0].rgb_path).shape[:2]
    map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)

    print("caching 81 frames (rgb+z) ...", flush=True)
    rgb = {}
    z = {}
    valid = {}
    for k in range(81):
        bgr, zk, _ = SF.load_pair(pairs, k, map1, map2)
        rgb[k] = bgr[..., ::-1].astype(np.float32) / 255.0
        z[k] = zk
        valid[k] = H.depth_valid(zk)

    # precompute per-frame variance maps (old + new) and threshold once — NOT per disc
    var_old = {}
    var_new = {}
    thr_old = {}
    dist = {}
    for k in range(81):
        var_old[k] = H.texture_variance(rgb[k], 9)
        var_new[k] = H.texture_variance(rgb[k], 9, valid=valid[k])
        thr_old[k] = max(float(np.quantile(var_old[k], SF.TEX_Q)), 1e-9)
        dist[k] = ndi.distance_transform_edt(valid[k].astype(np.uint8))

    n = len(curv)
    v_old = np.empty(n, np.float32)
    v_new = np.empty(n, np.float32)
    d_void = np.empty(n, np.float32)
    bfr = np.empty(n, np.int32)
    for j, gi in enumerate(curv):
        bf = int(birth[gi]) + 1                 # source RGB frame index
        bf = min(max(bf, 0), 80)
        u = int(pixel[gi, 0]); vv = int(pixel[gi, 1])
        u = min(max(u, 0), w - 1); vv = min(max(vv, 0), h - 1)
        v_old[j] = var_old[bf][vv, u]
        v_new[j] = var_new[bf][vv, u]
        d_void[j] = dist[bf][vv, u]
        bfr[j] = bf

    above_old = np.array([v_old[j] > thr_old[int(bfr[j])] for j in range(n)])
    print(f"\ncurvature seeds: n={n}")
    print(f"  v_old: med={np.median(v_old):.5f}  p90={np.percentile(v_old,90):.5f}")
    print(f"  above frame thr (old pipeline): {100*above_old.mean():.1f}%")
    print(f"  d_void: med={np.median(d_void):.1f}px  <=1px={100*(d_void<=1).mean():.1f}%")
    # does 'above threshold' concentrate at the border?
    near = d_void <= 1
    print(f"  above-thr among border(<=1px): {100*above_old[near].mean():.1f}%"
          f"  vs interior(>1px): {100*above_old[~near].mean():.1f}%")
    # does excluding void change borderline seeds?
    for j in range(n):
        pass
    print(f"\n  v_old->v_new change at border seeds:")
    mask = near
    if mask.sum():
        up = (v_new[mask] > v_old[mask]).mean()
        dn = (v_new[mask] < v_old[mask]).mean()
        print(f"    up={up:.2f} dn={dn:.2f}  med v_old={np.median(v_old[mask]):.5f} "
              f"med v_new={np.median(v_new[mask]):.5f}")


if __name__ == "__main__":
    main()