"""Synthetic ground-truth validation of the curvature estimator (idea 1).

Before trusting curvature on real depth, check the formula against surfaces
whose principal curvatures are known in closed form. Curvature is second order,
so it must pass cleanly on noiseless data before any real-data claim is made.

Surfaces, rendered by ray-surface intersection so the depth map is exactly what
a pinhole camera would see, composited against a background plane so there are
no NaNs and the occlusion boundaries are realistic:

  plane      k1 = k2 = 0
  sphere R   |k1| = |k2| = 1/R
  cylinder R |k1| = 1/R, k2 = 0, principal direction across the axis

Sign convention: normals face the camera, so convex surfaces read negative.
Only magnitude matters for sizing a disc.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from curvature import curvature_radii, principal_curvatures  # noqa: E402
from gaussian_build import prefilter_depth  # noqa: E402
from rgbd_io import FR1_INTRINSICS, camera_matrix  # noqa: E402

H, W = 480, 640
BG_DEPTH = 3.0


def _rays(K: np.ndarray) -> np.ndarray:
    fx, fy, cx, cy = K[0, 0], K[1, 1], K[0, 2], K[1, 2]
    us, vs = np.meshgrid(
        np.arange(W, dtype=np.float64), np.arange(H, dtype=np.float64)
    )
    r = np.stack([(us - cx) / fx, (vs - cy) / fy, np.ones_like(us)], axis=-1)
    return r / np.linalg.norm(r, axis=-1, keepdims=True)


def depth_plane(K: np.ndarray, n: np.ndarray, d: float) -> np.ndarray:
    fx, fy, cx, cy = K[0, 0], K[1, 1], K[0, 2], K[1, 2]
    us, vs = np.meshgrid(
        np.arange(W, dtype=np.float64), np.arange(H, dtype=np.float64)
    )
    r = np.stack([(us - cx) / fx, (vs - cy) / fy, np.ones_like(us)], axis=-1)
    return (d / np.einsum("ijk,k->ij", r, n)).astype(np.float32)


def depth_sphere(K: np.ndarray, centre: np.ndarray, R: float):
    rn = _rays(K)
    b = np.einsum("ijk,k->ij", rn, centre)
    c = centre @ centre - R * R
    disc = b * b - c
    hit = disc >= 0
    t = np.where(hit, b - np.sqrt(np.maximum(disc, 0.0)), np.inf)
    z = t * rn[..., 2]
    return _composite(z, hit & (t > 0))


def depth_cylinder(K: np.ndarray, centre: np.ndarray, R: float, axis: np.ndarray):
    axis = axis / np.linalg.norm(axis)
    rn = _rays(K)
    d_perp = rn - np.einsum("ijk,k->ij", rn, axis)[..., None] * axis
    o = -centre
    o_perp = o - (o @ axis) * axis
    A = np.einsum("ijk,ijk->ij", d_perp, d_perp)
    B = 2.0 * np.einsum("ijk,k->ij", d_perp, o_perp)
    C = o_perp @ o_perp - R * R
    disc = B * B - 4 * A * C
    hit = (disc >= 0) & (A > 1e-12)
    t = np.where(hit, (-B - np.sqrt(np.maximum(disc, 0.0))) / (2 * np.maximum(A, 1e-12)), np.inf)
    z = t * rn[..., 2]
    return _composite(z, hit & (t > 0))


def _composite(z: np.ndarray, hit: np.ndarray):
    """Put the object in front of a flat background; return (depth, object mask)."""
    obj = hit & np.isfinite(z) & (z < BG_DEPTH)
    out = np.where(obj, z, BG_DEPTH)
    return out.astype(np.float32), obj


def _erode(mask: np.ndarray, k: int) -> np.ndarray:
    """Shrink the object mask so the report never straddles the silhouette."""
    import cv2

    return cv2.erode(mask.astype(np.uint8), np.ones((k, k), np.uint8)).astype(bool)


def _report(tag: str, z: np.ndarray, K: np.ndarray, mask, k1_gt: float, k2_gt: float):
    k1, k2, _, ok = principal_curvatures(z, K)
    sel = ok & mask
    if sel.sum() < 50:
        print(f"  {tag:<32} only {int(sel.sum())} valid px")
        return
    a1 = np.abs(k1[sel])
    a2 = np.abs(k2[sel])
    e1 = np.median(np.abs(a1 - abs(k1_gt)))
    e2 = np.median(np.abs(a2 - abs(k2_gt)))
    ref = max(abs(k1_gt), 1.0)
    print(
        f"  {tag:<32} |k1| {np.median(a1):7.3f} (gt {abs(k1_gt):6.3f})  "
        f"|k2| {np.median(a2):7.3f} (gt {abs(k2_gt):6.3f})  "
        f"err {max(e1, e2):7.3f} 1/m = {max(e1, e2)/ref:6.1%} of k1"
    )


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--noise", type=float, nargs="+", default=[0.0002, 0.0005, 0.002])
    p.add_argument("--quant", type=float, default=0.0029, help="TUM disparity law")
    args = p.parse_args()

    K = camera_matrix(FR1_INTRINSICS)
    rng = np.random.default_rng(0)
    full = np.zeros((H, W), bool)
    full[40:-40, 40:-40] = True

    print("=" * 104)
    print("1. CLEAN SURFACES -- does the formula recover known curvature exactly?")
    print("=" * 104)
    _report("plane fronto-parallel z=2", depth_plane(K, np.array([0, 0, -1.0]), -2.0), K, full, 0.0, 0.0)
    a = np.radians(30)
    _report(
        "plane tilted 30 deg",
        depth_plane(K, np.array([0.0, np.sin(a), -np.cos(a)]), -2.0 * np.cos(a)),
        K, full, 0.0, 0.0,
    )
    for R in (0.15, 0.5, 1.0):
        z, m = depth_sphere(K, np.array([0.0, 0.0, 1.2 + R]), R)
        _report(f"sphere R={R} m  (k={1/R:.2f})", z, K, _erode(m, 9), 1.0 / R, 1.0 / R)
    for R in (0.05, 0.2, 0.5):
        z, m = depth_cylinder(K, np.array([0.0, 0.0, 1.2 + R]), R, np.array([1.0, 0.0, 0.0]))
        _report(f"cylinder R={R} m (k={1/R:.2f}, 0)", z, K, _erode(m, 9), 1.0 / R, 0.0)

    print()
    print("=" * 104)
    print("2. NOISE SENSITIVITY -- sphere R=0.5 (k=2.0). Curvature is 2nd order.")
    print("=" * 104)
    z0, m0 = depth_sphere(K, np.array([0.0, 0.0, 1.7]), 0.5)
    m0 = _erode(m0, 15)
    _report("clean", z0, K, m0, 2.0, 2.0)
    for s in args.noise:
        zn = (z0 + rng.normal(0, s, z0.shape)).astype(np.float32)
        _report(f"sigma={s*1000:.2f} mm  raw", zn, K, m0, 2.0, 2.0)
        for size in (5, 9, 15):
            _report(
                f"sigma={s*1000:.2f} mm  bilateral d={size}",
                prefilter_depth(zn, "bilateral", size), K, m0, 2.0, 2.0,
            )
        for size in (5, 9):
            _report(
                f"sigma={s*1000:.2f} mm  box {size}",
                prefilter_depth(zn, "box", size), K, m0, 2.0, 2.0,
            )

    print()
    print("=" * 104)
    print(f"3. QUANTIZATION -- TUM law dz = {args.quant} z^2, the wall from experiment A")
    print("=" * 104)
    inv = 1.0 / z0
    zq = (1.0 / (np.round(inv / args.quant) * args.quant)).astype(np.float32)
    _report("quantized  raw", zq, K, m0, 2.0, 2.0)
    for size in (5, 9, 15, 21):
        _report(f"quantized  bilateral d={size}", prefilter_depth(zq, "bilateral", size), K, m0, 2.0, 2.0)
    for size in (5, 9, 15):
        _report(f"quantized  box {size}", prefilter_depth(zq, "box", size), K, m0, 2.0, 2.0)

    print()
    print("=" * 104)
    print("4. THE RADIUS RULE  r = sqrt(2 eps / |k|)  -- what anisotropy buys")
    print("=" * 104)
    print(f"{'surface':<24}{'|k1|':>7}{'|k2|':>7}   {'eps=1mm  r1 x r2 (mm)':<26}{'eps=3mm  r1 x r2 (mm)':<26}")
    for tag, k1v, k2v in (
        ("plane", 0.0, 0.0),
        ("sphere R=1.0", 1.0, 1.0),
        ("sphere R=0.5", 2.0, 2.0),
        ("sphere R=0.15", 6.667, 6.667),
        ("cylinder R=0.5", 2.0, 0.0),
        ("cylinder R=0.2", 5.0, 0.0),
        ("cylinder R=0.05", 20.0, 0.0),
    ):
        row = f"{tag:<24}{k1v:>7.2f}{k2v:>7.2f}   "
        for eps in (0.001, 0.003):
            r1, r2 = curvature_radii(np.array([k1v]), np.array([k2v]), eps)
            s1 = f"{min(r1[0], 1.0)*1000:.0f}"
            s2 = f"{min(r2[0], 1.0)*1000:.0f}"
            cap = "+" if r2[0] > 1.0 else ""
            row += f"{s1:>6} x {s2:>6}{cap:<12}"
        print(row)
    print()
    print("r capped at 1000 mm for display ('+' = unbounded, footprint rule takes over)")


if __name__ == "__main__":
    main()
