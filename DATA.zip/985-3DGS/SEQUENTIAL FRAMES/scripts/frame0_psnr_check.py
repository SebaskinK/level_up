"""Frame-0 single-frame PSNR under both renderers.

Method A: hard ray-disc (H.rasterize_discs -> front-most disc centre colour),
          exactly what H.evaluate uses.
Method B: EWA normalized (exp_surfel_render.render_ewa), soft elliptical average.

Both are scored in linear RGB over the same eval_mask produced by H.eval_setup
(so the number is comparable to the single-frame pipeline's own self-check),
and also over the full covered pixels (whole image minus holes).
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

SEQ = Path(__file__).resolve().parent
SINGLE = SEQ.parent.parent / "SINGLE FRAME" / "scripts"
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SINGLE))
sys.path.insert(0, str(SFLOW))

import h_pipeline_final as H  # noqa: E402
from exp_surfel_render import render_ewa  # noqa: E402
from tum_io import (  # noqa: E402
    FR1_INTRINSICS,
    associate,
    load_depth,
    load_rgb,
    remap_depth,
    remap_rgb,
    undistort_maps,
)

DATA = Path("/home/sti/Work/986-SceneFlow/rgbd_dataset_freiburg1_desk")


def psnr_linear(render_rgb, rgb_ref, mask):
    if not mask.any():
        return float("nan")
    err = render_rgb[mask] - rgb_ref[mask]
    rmse = float(np.sqrt(np.mean(err ** 2)))
    return float(-20.0 * np.log10(max(rmse, 1e-12)))


def main() -> None:
    pairs = associate(DATA)
    fr = pairs[0]
    sample = load_rgb(fr.rgb_path)
    h, w = sample.shape[:2]
    map1, map2, K = undistort_maps((h, w), FR1_INTRINSICS)
    bgr = remap_rgb(load_rgb(fr.rgb_path), map1, map2)
    z = remap_depth(load_depth(fr.depth_path), map1, map2)
    z[(z < H.GEO_CFG["z_min"]) | (z > H.GEO_CFG["z_max"])] = 0.0

    rgb_ref = bgr[..., ::-1].astype(np.float32) / 255.0
    normal_ref, eval_mask = H.eval_setup(z, K)

    g, keep_geo, tex_mask = H.build_hybrid(bgr, z, K, 0.6)
    print(f"N={len(g)}  geo={int(keep_geo.sum())}  tex_mask={int(tex_mask.sum())}")

    # ---- Method A: hard ray-disc ----
    depth_a, index_a, _ = H.rasterize_discs(g, K, (h, w))
    hit_a = np.isfinite(depth_a)
    render_a = np.zeros((h, w, 3), np.float32)
    render_a[hit_a] = g.color[index_a[hit_a]]
    print("\n[METHOD A] hard ray-disc")
    print(f"  covered={float(hit_a.mean()):.4f}  hole={1 - float(hit_a.mean()):.4f}")
    print(f"  PSNR(eval_mask) = {psnr_linear(render_a, rgb_ref, eval_mask & hit_a):.2f} dB")
    print(f"  PSNR(all_cover) = {psnr_linear(render_a, rgb_ref, hit_a):.2f} dB")

    # ---- Method B: EWA normalized ----
    color_b, depth_b, weight_b = render_ewa(g, K, (h, w), mode="normalized")
    hit_b = weight_b > 0
    print("\n[METHOD B] EWA normalized")
    print(f"  covered={float(hit_b.mean()):.4f}  hole={1 - float(hit_b.mean()):.4f}")
    print(f"  PSNR(eval_mask) = {psnr_linear(color_b, rgb_ref, eval_mask & hit_b):.2f} dB")
    print(f"  PSNR(all_cover) = {psnr_linear(color_b, rgb_ref, hit_b):.2f} dB")

    # reference: H.evaluate (sanity that Method A matches the pipeline number)
    m = H.evaluate(g, z, bgr, normal_ref, eval_mask, K)
    print(f"\n[H.evaluate reference] PSNR={m['color_psnr_db']:.2f} dB "
          f"hole={m['hole_frac']:.4f} depth_rmse={m['depth_rmse_mm']:.2f}mm")

    # ---- save images ----
    import cv2
    out = SEQ.parent / "output_absorb_v2" / "render"
    bgr_a = (np.clip(render_a, 0, 1) * 255).astype(np.uint8)[..., ::-1].copy()
    bgr_a[~hit_a] = 0
    bgr_b = (np.clip(color_b, 0, 1) * 255).astype(np.uint8)[..., ::-1].copy()
    bgr_b[~hit_b] = 0
    cv2.imwrite(str(out / "f0_gt.png"), bgr)
    cv2.imwrite(str(out / "f0_hard.png"), bgr_a)
    cv2.imwrite(str(out / "f0_ewa.png"), bgr_b)
    print(f"saved f0_gt.png / f0_hard.png / f0_ewa.png -> {out}")


if __name__ == "__main__":
    main()