"""Original / current / S2-stride comparison for depth and RGB.

- original: input depth / RGB
- current: curvature-based Gaussians (exp_g_aniso_real CFG)
- S2: uniform stride-2 Gaussians (build_gaussians)
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from exp_g_aniso_real import CFG as CUR_CFG, build as cur_build, eval_setup  # noqa: E402
from gaussian_build import build_gaussians, depth_valid  # noqa: E402
from metrics import evaluate, rasterize_discs  # noqa: E402
from rgbd_io import (  # noqa: E402
    FR1_INTRINSICS,
    associate,
    load_depth,
    load_rgb,
    remap_depth,
    remap_rgb,
    undistort_maps,
)


def label(img: np.ndarray, text: str) -> np.ndarray:
    out = img.copy()
    cv2.rectangle(out, (0, 0), (out.shape[1], 34), (0, 0, 0), -1)
    cv2.putText(out, text, (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
    return out


def colorize_depth(z: np.ndarray, mask: np.ndarray, z_min: float = 0.4, z_max: float = 4.0) -> np.ndarray:
    mm = z * 1000.0
    norm = (mm - z_min * 1000.0) / (z_max * 1000.0 - z_min * 1000.0)
    norm = np.clip(norm, 0.0, 1.0)
    vis = (norm * 255.0).astype(np.uint8)
    vis = cv2.applyColorMap(vis, cv2.COLORMAP_TURBO)
    vis[~mask] = 0
    return vis


def render_color(g, shape, K):
    depth, index, _ = rasterize_discs(g, K, shape)
    hit = index >= 0
    render = np.zeros((*shape, 3), dtype=np.uint8)
    rgb = np.clip(g.color[index[hit]], 0.0, 1.0)
    render[hit] = (rgb[:, ::-1] * 255.0).astype(np.uint8)
    return render, depth, index, hit


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--data", default=str(
        ROOT.parent.parent / "986-SceneFlow" / "rgbd_dataset_freiburg1_desk"))
    p.add_argument("--out", default=str(ROOT.parent / "output_G_refactor"))
    p.add_argument("--frame", type=int, default=0)
    args = p.parse_args()

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    pairs = associate(Path(args.data))
    fr = pairs[args.frame]
    sample = load_rgb(pairs[0].rgb_path)
    map1, map2, K = undistort_maps(sample.shape[:2], FR1_INTRINSICS)
    bgr = remap_rgb(load_rgb(fr.rgb_path), map1, map2)
    z = remap_depth(load_depth(fr.depth_path), map1, map2)

    normal_ref, eval_mask = eval_setup(z, K)

    # S2 baseline
    g_s2 = build_gaussians(
        bgr, z, K,
        z_min=CUR_CFG["z_min"], z_max=CUR_CFG["z_max"],
        disc_rel=CUR_CFG["disc_rel"], stride=2,
        prefilter="gauss", prefilter_size=int(CUR_CFG["gauss_sigma"]),
    )
    render_s2, depth_s2, _, hit_s2 = render_color(g_s2, z.shape, K)

    # Current curvature-based
    g_cur, _ = cur_build(bgr, z, K, foreshorten=False, aniso_claim=True)
    render_cur, depth_cur, _, hit_cur = render_color(g_cur, z.shape, K)

    # Metrics
    m_s2 = evaluate(g_s2, z, bgr, normal_ref, eval_mask, K)
    m_cur = evaluate(g_cur, z, bgr, normal_ref, eval_mask, K)

    # PSNR over eval_mask hits
    _, index_s2_full, _ = rasterize_discs(g_s2, K, z.shape)
    _, index_cur_full, _ = rasterize_discs(g_cur, K, z.shape)
    mask_s2 = hit_s2 & eval_mask
    mask_cur = hit_cur & eval_mask
    psnr_s2 = -20.0 * np.log10(max(float(np.sqrt(np.mean(
        (g_s2.color[index_s2_full[mask_s2]] - (bgr[..., ::-1].astype(np.float32) / 255.0)[mask_s2]) ** 2
    ))), 1e-12))
    psnr_cur = -20.0 * np.log10(max(float(np.sqrt(np.mean(
        (g_cur.color[index_cur_full[mask_cur]] - (bgr[..., ::-1].astype(np.float32) / 255.0)[mask_cur]) ** 2
    ))), 1e-12))

    valid_depth_mask = depth_valid(z)

    # Depth comparison panel
    depth_panel = np.hstack([
        label(colorize_depth(z, valid_depth_mask, CUR_CFG["z_min"], CUR_CFG["z_max"]), "original depth"),
        label(colorize_depth(depth_cur, hit_cur, CUR_CFG["z_min"], CUR_CFG["z_max"]),
              f"current  N={len(g_cur)}  RMSE={m_cur['depth_rmse_mm']:.2f}mm  cov={m_cur['coverage']:.3f}"),
        label(colorize_depth(depth_s2, hit_s2, CUR_CFG["z_min"], CUR_CFG["z_max"]),
              f"S2 uniform  N={len(g_s2)}  RMSE={m_s2['depth_rmse_mm']:.2f}mm  cov={m_s2['coverage']:.3f}"),
    ])

    # RGB comparison panel
    rgb_panel = np.hstack([
        label(bgr, "original RGB"),
        label(render_cur, f"current render  PSNR={psnr_cur:.1f}dB  N={len(g_cur)}"),
        label(render_s2, f"S2 render  PSNR={psnr_s2:.1f}dB  N={len(g_s2)}"),
    ])

    cv2.imwrite(str(out_dir / f"depth_compare_s2_f{args.frame:02d}.png"), depth_panel)
    cv2.imwrite(str(out_dir / f"rgb_compare_s2_f{args.frame:02d}.png"), rgb_panel)
    print(f"current: N={len(g_cur)}  RMSE={m_cur['depth_rmse_mm']:.2f}mm  cov={m_cur['coverage']:.3f}  PSNR={psnr_cur:.1f}dB")
    print(f"S2:      N={len(g_s2)}  RMSE={m_s2['depth_rmse_mm']:.2f}mm  cov={m_s2['coverage']:.3f}  PSNR={psnr_s2:.1f}dB")
    print(f"wrote {out_dir / f'depth_compare_s2_f{args.frame:02d}.png'}")
    print(f"wrote {out_dir / f'rgb_compare_s2_f{args.frame:02d}.png'}")


if __name__ == "__main__":
    main()
