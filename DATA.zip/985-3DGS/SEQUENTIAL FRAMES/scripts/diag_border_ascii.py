from __future__ import annotations
import sys
from pathlib import Path
import numpy as np

SEQ = Path(__file__).resolve().parent
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SEQ))
sys.path.insert(0, str(SFLOW))
import h_pipeline_final as H
import sequential_fusion_flowonly as SF


def tang(n):
    n = n.astype(np.float64)
    n = n / np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-12)
    ref = np.tile(np.array([0.0, 0.0, 1.0]), (n.shape[0], 1))
    ref[np.abs(n[:, 2]) > 0.9] = [1, 0, 0]
    t1 = np.cross(ref, n)
    t1 = t1 / np.maximum(np.linalg.norm(t1, axis=1, keepdims=True), 1e-12)
    t2 = np.cross(n, t1)
    return t1, t2


d = np.load(SEQ.parent / "output_f0_ellipse_final" / "model_f0.npz")
mu = d["mu"].astype(np.float64)
n = d["normal"].astype(np.float64)
s = d["scale"].astype(np.float64)
c = d["color"].astype(np.float64)
b = d["birth"].astype(np.int64)
t1, t2 = tang(n)
g = H.Gaussians(mu=mu, normal=n, scale=s,
                quat=H._quat_from_frame(t1.astype(np.float32), t2.astype(np.float32), n.astype(np.float32)),
                color=c, alpha=None, pixel=np.zeros((len(mu), 2), np.int32),
                axis1=t1.astype(np.float32), axis2=t2.astype(np.float32))

pairs = SF.associate(SF.DATA, max_dt=0.02)[:11]
sm = SF.load_rgb(pairs[0].rgb_path)
h, w = sm.shape[:2]
m1, m2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)
depth, index, _ = H.rasterize_discs(g, K, (h, w))
idx = index.astype(np.int64)
hit = np.isfinite(depth)
pb = np.full((h, w), -1, np.int32)
pb[hit] = b[idx[hit]]

print("Final10 render, border region. #=hole  .=covered. cols 595-639")
print("     " + "".join(str((c // 10) % 10) for c in range(595, 640)) + "  (tens)")
print("     " + "".join(str(c % 10) for c in range(595, 640)) + "  (ones)")
for r in range(320, 420, 2):
    line = "".join("#" if not hit[r, c] else "." for c in range(595, 640))
    print(f"{r:3d} {line}")

# also birth map for covered pixels: 0-9 -> digit, hole -> '#'
print("\nbirth map (digit=disc birth frame, #=hole):")
print("     " + "".join(str((c // 10) % 10) for c in range(595, 640)) + "  (tens)")
print("     " + "".join(str(c % 10) for c in range(595, 640)) + "  (ones)")
for r in range(320, 420, 2):
    line = "".join("#" if not hit[r, c] else str(min(pb[r, c], 9)) for c in range(595, 640))
    print(f"{r:3d} {line}")