"""Incremental hybrid build restricted to a region mask (the flow-miss / leftover region).

`build_hybrid` builds the whole frame, then the flowonly pipeline masks the result
down to the leftover region. That pays the full Python-loop cost (~0.65 s) to keep
~4% of the pixels.

The two expensive parts of `build_hybrid` are both Python loops over the WHOLE frame:

  * `coverage_sample_elliptical_fast`  -- largest-radius-first greedy over every
    valid pixel (~254k candidates), a per-candidate per-ellipse claim.
  * `_normal_from_disc_inliers_fast`   -- per-disc inlier-normal fit (~34k discs).

Everything else is a handful of C-level cv2 ops (blur / Sobel / quadric filter2D /
distanceTransform). Only ONE of those is a true global statistic that cannot be
cropped without changing its meaning:

  * `texture_mask`  -- the variance threshold is the fixed `TEX_VAR_THR` hyperparameter.

The rest of the frame-level geometry (smoothed depth, normals, curvatures,
depth-edge distance, tex-boundary distance) is locally supported. We crop the frame
to the region's bounding box plus a padding `CROP_PAD` and recompute it there with a
shifted intrinsic `K_crop` (cx/cy moved by -bbox offset; fx/fy unchanged), so every
backprojection / ray ends up in the SAME world frame as the full-frame build.

Why `CROP_PAD` is safe:
  * the largest disc in-picture radius is r_max * f_mean / z_min = 0.05 * 517 / 0.4
    ~ 65 px;
  * the inlier-normal fit reads smoothed depth out to ceil(that radius)+1 ~ 66 px;
  * smoothed depth / normals / curvature are themselves derived from a masked-gauss
    (sigma 3) + 3x3 Sobel + 9x9 quadric, i.e. <= ~15 px of further support.
  * distance transforms only matter while the distance is < r_max's footprint
    (~65 px); past that the radius cap no longer binds.

So 96 px of padding keeps every in-region disc's geometry bit-consistent with the
full-frame build, while the boundary of the cropped tile only distorts the padding
zone itself (never sampled by an in-region disc).

Design decision (deliberate): the greedy is restricted to region candidates, which
emits MORE discs than `build_hybrid`-then-mask. In the full build a leftover pixel's
centre can be "claimed" by a neighbouring non-leftover disc and then dropped by the
masking step; in the region build that pixel legitimately gets its own disc. For
covering the flow-miss region this is the desired behaviour: every leftover pixel
needs a disc.

Correctness anchor: with `region_mask` = the full valid-depth mask the crop window is
the full frame (K_crop == K, no offset), and `build_hybrid_region` reproduces
`build_hybrid` exactly (same N, same discs, same order) -- verified by `_selfcheck()`.
"""

from __future__ import annotations

from pathlib import Path
import sys

import cv2
import numpy as np

SEQ = Path(__file__).resolve().parent
sys.path.insert(0, str(SEQ))

import h_pipeline_final as H  # noqa: E402

# padding around the region bbox; see module docstring for the sizing argument.
CROP_PAD = 96


def empty_gaussians() -> H.Gaussians:
    return H.Gaussians(
        mu=np.zeros((0, 3), np.float32),
        normal=np.zeros((0, 3), np.float32),
        scale=np.zeros((0, 3), np.float32),
        quat=np.zeros((0, 4), np.float32),
        color=np.zeros((0, 3), np.float32),
        alpha=np.zeros(0, np.float32),
        pixel=np.zeros((0, 2), np.int32),
    )


def _region_window(region_mask, pad):
    """Bounding box of `region_mask` grown by `pad`, clipped to the image.

    Returns (y0, x0, y1, x1). Caller uses [y0:y1, x0:x1] to crop.
    """
    h, w = region_mask.shape
    ys, xs = np.where(region_mask)
    y0 = max(0, int(ys.min()) - pad)
    x0 = max(0, int(xs.min()) - pad)
    y1 = min(h, int(ys.max()) + 1 + pad)
    x1 = min(w, int(xs.max()) + 1 + pad)
    return y0, x0, y1, x1


def _geometry_cropped(z_crop, K_crop, valid_crop):
    """Recompute the single-frame geometry on a cropped tile (local templates only).

    Same field set as `H.compute_scene_geometry`, but every derivative / distance
    pass runs on the padded tile with the shifted intrinsics `K_crop`, so the world
    frame is unchanged.
    """
    cfg = H.GEO_CFG
    z_grad = H.prefilter_depth(z_crop, "gauss", cfg["gauss_sigma"], valid=valid_crop)
    normal, n_ok = H.surface_normals(z_grad, K_crop)
    k1, k2, t1, c_ok, dir_img = H.scale_space_curvature(z_grad, K_crop)
    r_k1, r_k2 = H.curvature_radii(k1, k2, cfg["eps"])
    r_fp = H.surfel_radius(z_crop, normal[..., 2], K_crop)
    r_edge = H.edge_distance_limit(z_crop, K_crop, cfg["disc_rel"], valid=valid_crop)
    disc_mask = H.depth_discontinuity_mask(z_crop, cfg["disc_rel"], valid=valid_crop)
    return H.CurvatureGeometry(
        z_grad=z_grad, normal=normal, n_ok=n_ok,
        k1=k1, k2=k2, t1=t1, c_ok=c_ok, dir_img=dir_img,
        r_k1=r_k1, r_k2=r_k2, r_fp=r_fp, r_edge=r_edge,
        disc_mask=disc_mask, valid_depth=valid_crop,
    )


def select_seeds_region(z, K, region_mask, r_cap, geo, floor_scale=np.sqrt(2.0)):
    """Curvature coverage sampling restricted to `region_mask`.

    Mirrors `H.select_curvature_seeds` (anisotropic claim, edge_fallback_fp=True,
    texture_mask=None) and ANDs `region_mask` into the candidate `valid` before
    the greedy. Works in whatever coordinate frame `z`/`K` carry (full-frame or
    cropped tile). `floor_scale` matches the curvature floor so curvature discs
    share the S2 lower bound (r_fp * sqrt(2)).
    """
    cfg = H.GEO_CFG
    lim = np.minimum(cfg["r_max"], geo.r_edge)
    if r_cap is not None:
        lim = np.minimum(lim, r_cap)
    fp = geo.r_fp * float(floor_scale)
    consistent = (geo.r_k1 >= fp) & (lim >= fp)
    # Two contradiction cases re-emitted at the floor (single-frame
    # edge_fallback_fp=True): (lim < floor) and (r_k1 < floor). Dropping the
    # latter re-opens holes on high-curvature shallow pixels.
    keep_edge = consistent | (lim < fp) | (geo.r_k1 < fp)
    valid = (
        geo.n_ok & geo.c_ok & keep_edge & geo.valid_depth
        & (z > cfg["z_min"]) & (z < cfg["z_max"])
        & ~geo.disc_mask
        & region_mask
    )
    ys, xs = np.where(valid)
    if ys.size == 0:
        return valid

    hi = np.maximum(lim, fp)
    r1 = np.clip(geo.r_k1[ys, xs], fp[ys, xs], hi[ys, xs]).astype(np.float64)
    r2 = np.clip(geo.r_k2[ys, xs], fp[ys, xs], hi[ys, xs]).astype(np.float64)
    e1, e2 = H.claim_footprint(z, K, ys, xs, r1, r2, cfg["overlap"], geo)
    return H.coverage_sample_aniso(ys, xs, e1, e2, valid.shape)


def build_hybrid_region(dbgr, z, K, texture_quantile, region_mask,
                        radius_scale=np.sqrt(2.0),
                        tex_boundary_tol_px=4.5,
                        crop=True,
                        geo=None,
                        return_owner=False):
    """`build_hybrid` restricted to `region_mask` (bool HxW).

    Returns a `Gaussians` of discs whose source pixel lies in `region_mask`
    (possibly empty). Mirrors `H.build_hybrid`'s exact radius/emission knobs.
    With `crop=True` (default) the frame-level geometry is recomputed on the
    region bbox + `CROP_PAD`; the texture mask is still computed full-frame
    with the fixed `TEX_VAR_THR` threshold.
    Pass `geo` (a full-frame `CurvatureGeometry`) to skip the internal compute
    and share the caller's geometry -- `crop` is then ignored (a precomputed
    full-frame geometry implies the full-frame path).

    With `return_owner=True`, returns `(gaussians, owner_new)` where `owner_new`
    is a claim-based per-pixel owner map (int32 HxW, -1 empty) in the new discs'
    local index order (0..len-1, matching the returned Gaussians). No ray-disc.
    Curvature discs own their full anisotropic claim ellipse; S2 discs own an
    analytic 2x2 cell.
    """
    if not region_mask.any():
        if return_owner:
            return empty_gaussians(), np.full(z.shape, -1, dtype=np.int32)
        return empty_gaussians()

    rgb = dbgr[..., ::-1].astype(np.float32) / 255.0
    tex_mask_full = H.texture_mask(rgb, texture_quantile)

    provided_geo = geo is not None
    if not crop or provided_geo:
        if geo is None:
            geo = H.compute_scene_geometry(
                z, K, H.GEO_CFG["eps"], H.GEO_CFG["gauss_sigma"], H.GEO_CFG["disc_rel"],
            )
        r_cap = (H.tex_boundary_limit(z, K, tex_mask_full, tol_px=tex_boundary_tol_px)
                 if tex_boundary_tol_px > 0 else None)
        keep_geo = select_seeds_region(z, K, region_mask, r_cap, geo)
        keep_geo = keep_geo & ~tex_mask_full
        parts = []
        if keep_geo.any():
            parts.append(H.emit_curvature_discs(
                dbgr, z, K, eps=H.GEO_CFG["eps"], gauss_sigma=H.GEO_CFG["gauss_sigma"],
                r_max=H.GEO_CFG["r_max"], shrink=H.GEO_CFG["shrink"],
                z_min=H.GEO_CFG["z_min"], z_max=H.GEO_CFG["z_max"],
                disc_rel=H.GEO_CFG["disc_rel"], mask=keep_geo, r_cap=r_cap, geo=geo,
            ))
        tex_region = tex_mask_full & region_mask
        if tex_region.any():
            parts.append(H.emit_footprint_discs(
                dbgr, z, K, z_min=H.GEO_CFG["z_min"], z_max=H.GEO_CFG["z_max"],
                disc_rel=H.GEO_CFG["disc_rel"], stride=2, mask=tex_region,
                radius_scale=radius_scale, geo=geo,
            ))
        if not parts:
            if return_owner:
                return empty_gaussians(), np.full(z.shape, -1, dtype=np.int32)
            return empty_gaussians()
        g = H.concatenate_gaussians(parts)
        if return_owner:
            owner = H.owner_from_claim(z, K, geo, keep_geo, tex_region, r_cap,
                                       np.sqrt(2.0))
            return g, owner
        return g

    # --- cropped path ---------------------------------------------------------
    y0, x0, y1, x1 = _region_window(region_mask, CROP_PAD)
    K_crop = K.astype(np.float64).copy()
    K_crop[0, 2] -= x0
    K_crop[1, 2] -= y0

    z_crop = z[y0:y1, x0:x1]
    bgr_crop = dbgr[y0:y1, x0:x1]
    tex_mask = tex_mask_full[y0:y1, x0:x1]
    region = region_mask[y0:y1, x0:x1]
    valid_crop = z_crop > 0

    r_cap = (H.tex_boundary_limit(z_crop, K_crop, tex_mask, tol_px=tex_boundary_tol_px)
             if tex_boundary_tol_px > 0 else None)
    geo = _geometry_cropped(z_crop, K_crop, valid_crop)

    keep_geo = select_seeds_region(z_crop, K_crop, region, r_cap, geo)
    keep_geo = keep_geo & ~tex_mask
    parts = []
    if keep_geo.any():
        parts.append(H.emit_curvature_discs(
            bgr_crop, z_crop, K_crop, eps=H.GEO_CFG["eps"],
            gauss_sigma=H.GEO_CFG["gauss_sigma"],
            r_max=H.GEO_CFG["r_max"], shrink=H.GEO_CFG["shrink"],
            z_min=H.GEO_CFG["z_min"], z_max=H.GEO_CFG["z_max"],
            disc_rel=H.GEO_CFG["disc_rel"], mask=keep_geo, r_cap=r_cap, geo=geo,
        ))
    tex_region = tex_mask & region
    if tex_region.any():
        parts.append(H.emit_footprint_discs(
            bgr_crop, z_crop, K_crop, z_min=H.GEO_CFG["z_min"],
            z_max=H.GEO_CFG["z_max"],
            disc_rel=H.GEO_CFG["disc_rel"], stride=2, mask=tex_region,
            radius_scale=radius_scale, geo=geo,
        ))
    if not parts:
        if return_owner:
            return empty_gaussians(), np.full(z.shape, -1, dtype=np.int32)
        return empty_gaussians()
    g = H.concatenate_gaussians(parts)
    # pixel coords are in cropped frame; shift back to full-frame.
    g.pixel[:, 0] += x0
    g.pixel[:, 1] += y0
    if return_owner:
        owner_crop = H.owner_from_claim(z_crop, K_crop, geo, keep_geo, tex_region,
                                        r_cap, np.sqrt(2.0))
        owner = np.full(z.shape, -1, dtype=np.int32)
        owner[y0:y1, x0:x1] = owner_crop
        return g, owner
    return g


def s2_parts(dbgr, z, K, tex_mask, region_mask, geo,
             radius_scale=np.sqrt(2.0)):
    """Emit stride-2 footprint discs on `tex_mask & region_mask` (S2 fill).

    First stage of the leftover re-order (S2 -> absorb -> curvature). Returns
    `(g_s2, owner_s2)`; `owner_s2` is the analytic 2x2-cell owner map with ids
    0..N_s2-1 in S2 emission order (no ray-disc). The caller appends `g_s2` to
    the running model and offsets `owner_s2` by its running disc count before
    the neighbour search and next-frame owner.
    """
    tex_region = tex_mask & region_mask
    if not tex_region.any():
        return empty_gaussians(), np.full(z.shape, -1, dtype=np.int32)
    g = H.emit_footprint_discs(
        dbgr, z, K, z_min=H.GEO_CFG["z_min"], z_max=H.GEO_CFG["z_max"],
        disc_rel=H.GEO_CFG["disc_rel"], stride=2, mask=tex_region,
        radius_scale=radius_scale, geo=geo,
    )
    owner = H.s2_owner(z, geo, tex_region, z.shape, offset=0)
    return g, owner


def curvature_parts(dbgr, z, K, region_mask, tex_mask, geo, r_cap,
                    floor_scale=np.sqrt(2.0)):
    """Emit curvature discs on `select_seeds_region(region_mask) & ~tex_mask`.

    Last stage of the leftover re-order. Returns `(g_curv, owner_curv)` with
    `owner_curv` ids 0..N_curv-1 in curvature emission order.
    """
    keep_geo = select_seeds_region(z, K, region_mask, r_cap, geo)
    keep_geo = keep_geo & ~tex_mask
    if not keep_geo.any():
        return empty_gaussians(), np.full(z.shape, -1, dtype=np.int32)
    g = H.emit_curvature_discs(
        dbgr, z, K, eps=H.GEO_CFG["eps"], gauss_sigma=H.GEO_CFG["gauss_sigma"],
        r_max=H.GEO_CFG["r_max"], shrink=H.GEO_CFG["shrink"],
        z_min=H.GEO_CFG["z_min"], z_max=H.GEO_CFG["z_max"],
        disc_rel=H.GEO_CFG["disc_rel"], mask=keep_geo, r_cap=r_cap, geo=geo,
        floor_scale=floor_scale,
    )
    owner = H.curvature_owner(z, K, geo, keep_geo, r_cap, floor_scale)
    return g, owner


def _selfcheck() -> None:
    import time

    data_dir = Path("/home/sti/Work/986-SceneFlow/rgbd_dataset_freiburg1_desk")
    pairs = H.associate(data_dir)
    fr = pairs[0]
    map1, map2, K = H.undistort_maps((480, 640), H.FR1_INTRINSICS)
    bgr = H.remap_rgb(H.load_rgb(fr.rgb_path), map1, map2)
    z = H.remap_depth(H.load_depth(fr.depth_path), map1, map2)
    z[z < H.GEO_CFG["z_min"]] = 0.0
    z[z > H.GEO_CFG["z_max"]] = 0.0
    valid = H.depth_valid(z) & (z > H.GEO_CFG["z_min"]) & (z < H.GEO_CFG["z_max"])

    t0 = time.perf_counter()
    g_full, _, _ = H.build_hybrid(bgr, z, K, 0.6)
    dt_full = time.perf_counter() - t0

    t0 = time.perf_counter()
    g_reg = build_hybrid_region(bgr, z, K, 0.6, valid)
    dt_reg = time.perf_counter() - t0

    match = (
        len(g_full) == len(g_reg)
        and np.allclose(g_full.mu, g_reg.mu)
        and np.allclose(g_full.normal, g_reg.normal)
        and np.allclose(g_full.scale, g_reg.scale)
        and np.allclose(g_full.color, g_reg.color)
        and np.allclose(g_full.pixel, g_reg.pixel)
    )
    print(f"full           N={len(g_full):6d}  {dt_full:.3f}s")
    print(f"region(=valid) N={len(g_reg):6d}  {dt_reg:.3f}s   identity={match}")

    rng = np.random.default_rng(0)
    small = np.zeros_like(valid)
    ys, xs = np.where(valid)
    idx = rng.choice(ys.size, size=ys.size // 25, replace=False)
    small[ys[idx], xs[idx]] = True
    t0 = time.perf_counter()
    g_small = build_hybrid_region(bgr, z, K, 0.6, small)
    dt_small = time.perf_counter() - t0
    print(f"region( 4% )   N={len(g_small):6d}  {dt_small:.3f}s   "
          f"frac={100 * small.mean():.1f}%")


if __name__ == "__main__":
    _selfcheck()