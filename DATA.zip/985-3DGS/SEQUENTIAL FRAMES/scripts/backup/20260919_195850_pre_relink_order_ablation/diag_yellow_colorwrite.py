"""Is every yellow (old disc, colour-drifted) pixel's drift explained by colour write?

Colour can only be modified by two code paths, both of which increment `w_col`
(initialised to 1.0 at birth, capped at COLOR_CONF_MAX=50):
  * fuse_footprint_color   -- flow-hit path, writes the disc's whole owned footprint
  * merge_absorbed_points  -- leftover absorb path
If a drifted disc has w_col == 1.0 it was NEVER written and its colour changed some
other way -- that would be a real bug. This script cross-tabulates drift vs w_col.

Run:
  python scripts/diag_yellow_colorwrite.py --run output_f0_80frame_olddraw
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

SEQ = Path(__file__).resolve().parent
sys.path.insert(0, str(SEQ))

import h_pipeline_final as H          # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402

DRIFT_EPS = 0.04
DEPTH_TOL = 0.05
WCOL_INIT = 1.0


def tangent_basis(n: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    ref = np.zeros_like(n)
    ref[:, 2] = 1.0
    flip = np.abs(n[:, 2]) > 0.9
    ref[flip] = np.array([1.0, 0.0, 0.0])
    a1 = np.cross(n, ref)
    a1 /= np.maximum(np.linalg.norm(a1, axis=1, keepdims=True), 1e-9)
    a2 = np.cross(n, a1)
    a2 /= np.maximum(np.linalg.norm(a2, axis=1, keepdims=True), 1e-9)
    return a1, a2


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", default="output_f0_80frame_olddraw")
    ap.add_argument("--frames", type=int, default=81)
    args = ap.parse_args()
    run = SEQ.parent / args.run

    d = np.load(run / "model_f0.npz")
    mu, normal, scale = d["mu"], d["normal"], d["scale"]
    color, birth, birth_color = d["color"], d["birth"], d["birth_color"]
    w_col = d["w_col"]
    a1, a2 = tangent_basis(normal)
    g = H.Gaussians(mu=mu, normal=normal, scale=scale, quat=np.zeros((len(mu), 4)),
                    color=color, alpha=np.ones(len(mu)), pixel=np.zeros((len(mu), 2)),
                    axis1=a1, axis2=a2)

    pairs = SF.associate(SF.DATA, max_dt=0.02)[: args.frames]
    sample = SF.load_rgb(pairs[0].rgb_path)
    h, w = sample.shape[:2]
    map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)
    bgr0, z0, _ = SF.load_pair(pairs, 0, map1, map2)
    gt = bgr0[..., ::-1].astype(np.float32) / 255.0

    depth, index, _ = H.rasterize_discs(g, K, (h, w))
    hit = index >= 0
    own = index[hit]
    b = birth[own]
    dc = np.linalg.norm(color - birth_color, axis=1)
    wc = w_col

    print(f"run={args.run}  N={len(mu)}  hard coverage={hit.mean():.4f}")
    print(f"w_col: init={WCOL_INIT}  min={wc.min():.1f}  median={np.median(wc):.1f} "
          f"max={wc.max():.1f}  frac>init={100 * (wc > WCOL_INIT).mean():.2f}%")

    old = birth == 0
    print("\n== ALL discs (not just rendered) ==")
    print(f"  old(birth=0)={int(old.sum())}  new={int((~old).sum())}")
    for name, sel in [("old", old), ("new", ~old)]:
        s = sel & (dc > DRIFT_EPS)
        print(f"  {name}: drifted(>{DRIFT_EPS}) discs={int(s.sum())} "
              f"({100 * s.sum() / max(sel.sum(), 1):.1f}%)  "
              f"of which w_col=={WCOL_INIT}: {int((s & (wc == WCOL_INIT)).sum())}  "
              f"min w_col among drifted={wc[s].min() if s.any() else float('nan'):.1f}")

    # ---- rendered pixels, classified as in the owner map ----
    dz = np.where(hit, np.abs(depth - z0) / np.maximum(z0, 1e-6), np.inf)
    on_surf = dz < DEPTH_TOL
    cls = np.zeros((h, w), np.uint8)          # 0 empty
    b_px = np.full((h, w), -1, np.int32)
    b_px[hit] = birth[own]
    oldm = hit & (b_px == 0)
    dcp = np.zeros((h, w))
    dcp[hit] = dc[own]
    wp = np.zeros((h, w))
    wp[hit] = wc[own]
    cls[oldm & (dcp <= DRIFT_EPS)] = 1
    cls[oldm & (dcp > DRIFT_EPS)] = 2
    newm = hit & (b_px >= 1)
    cls[newm & on_surf] = 3
    cls[newm & ~on_surf] = 4

    print("\n== rendered pixels ==")
    names = {1: "GREEN  old, unchanged", 2: "YELLOW old, drifted",
             3: "BLUE   new, on f0 surf", 4: "MAGENTA new, off f0 surf"}
    for k, nm in names.items():
        m = cls == k
        if not m.any():
            continue
        ww = wp[m]
        print(f"  {nm:24s} px={int(m.sum()):7d}  "
              f"w_col: never-written={100 * (ww <= WCOL_INIT).mean():6.2f}%  "
              f"median={np.median(ww):5.1f}  max={ww.max():5.1f}  "
              f"dcol: median={np.median(dcp[m]):.4f} p90={np.percentile(dcp[m], 90):.4f}")

    # ---- does the drift track the current appearance or wander? ----
    err_gt = np.zeros((h, w))
    err_gt[hit] = np.linalg.norm(color[own] - gt[hit], axis=1)
    birth_err_gt = np.zeros((h, w))
    birth_err_gt[hit] = np.linalg.norm(birth_color[own] - gt[hit], axis=1)
    ym = cls == 2
    if ym.any():
        helped = err_gt[ym] < birth_err_gt[ym]
        print(f"\n  YELLOW: drift reduced |colour-f0image| (i.e. moved toward the "
              f"target appearance): {100 * float(helped.mean()):.1f}%  "
              f"mean err {1000 * err_gt[ym].mean():.1f}e-3 (was "
              f"{1000 * birth_err_gt[ym].mean():.1f}e-3)")

    # ---- drift vs write count: is more writing = more drift? ----
    print("\n  old discs owning pixels, bucketed by w_col:")
    ids = np.unique(own)
    io = ids[birth[ids] == 0]
    print(f"  {'w_col bucket':16s} {'discs':>7s} {'drift%':>7s} {'mean|dcol|':>11s}")
    for lo, hi in [(0, 1.0001), (1.0001, 2.5), (2.5, 10), (10, 30), (30, 50.01)]:
        s = (wc[io] >= lo) & (wc[io] < hi)
        if not s.any():
            continue
        sub = io[s]
        print(f"  [{lo:5.1f},{hi:5.1f})     {int(s.sum()):7d} "
              f"{100 * (dc[sub] > DRIFT_EPS).mean():7.1f} {dc[sub].mean():11.4f}")

    # ---- left band, same decomposition ----
    selL = np.zeros((h, w), bool)
    selL[:, :128] = True
    print("\n== left band x<128 ==")
    for k, nm in names.items():
        m = (cls == k) & selL
        if not m.any():
            continue
        ww = wp[m]
        print(f"  {nm:24s} px={int(m.sum()):7d}  "
              f"never-written={100 * (ww <= WCOL_INIT).mean():6.2f}%  "
              f"dcol median={np.median(dcp[m]):.4f}")

    stats = {
        "run": args.run,
        "wcol_frac_written_all": float((wc > WCOL_INIT).mean()),
        "old_drifted_discs": int((old & (dc > DRIFT_EPS)).sum()),
        "old_drifted_never_written": int((old & (dc > DRIFT_EPS) & (wc == WCOL_INIT)).sum()),
        "new_drifted_discs": int((~old & (dc > DRIFT_EPS)).sum()),
        "new_drifted_never_written": int((~old & (dc > DRIFT_EPS) & (wc == WCOL_INIT)).sum()),
        "px_yellow": int((cls == 2).sum()),
        "px_yellow_never_written": int(((cls == 2) & (wp <= WCOL_INIT)).sum()),
        "px_green": int((cls == 1).sum()),
        "px_green_never_written": int(((cls == 1) & (wp <= WCOL_INIT)).sum()),
        "yellow_drift_toward_target_pct": float(
            100 * float((err_gt[ym] < birth_err_gt[ym]).mean())) if ym.any() else None,
    }
    (run / "diag_yellow_colorwrite_stats.json").write_text(json.dumps(stats, indent=2))
    print("\nsaved ->", run / "diag_yellow_colorwrite_stats.json")


if __name__ == "__main__":
    main()