"""Definitive: dense sub-pixel ray sweep against ALL local discs.

For each hole pixel, cast a 7x7 grid of sub-rays through the pixel and test
every disc whose projected centre lies within 15px. Reports how many hole
pixels are covered by at least one sub-ray (=> renderer undersampling) vs
truly uncovered at sub-pixel resolution (=> real tiling gap).
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

SEQ = Path(__file__).resolve().parent
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SEQ))
sys.path.insert(0, str(SFLOW))

import h_pipeline_final as H            # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402

FINAL = SEQ.parent / "output_f0_ellipse_final" / "model_f0.npz"
F0 = SEQ.parent / "output_f0_0frame" / "model_f0.npz"
Z_MIN, Z_MAX = 0.4, 4.0


def tangent_basis(n):
    n = n.astype(np.float64)
    n = n / np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-12)
    ref = np.tile(np.array([0.0, 0.0, 1.0]), (n.shape[0], 1))
    ref[np.abs(n[:, 2]) > 0.9] = np.array([1.0, 0.0, 0.0])
    t1 = np.cross(ref, n)
    t1 = t1 / np.maximum(np.linalg.norm(t1, axis=1, keepdims=True), 1e-12)
    t2 = np.cross(n, t1)
    return t1, t2


def load_g(path: Path):
    d = np.load(path)
    mu = d["mu"].astype(np.float64)
    normal = d["normal"].astype(np.float64)
    scale = d["scale"].astype(np.float64)
    color = d["color"].astype(np.float64)
    birth = d["birth"].astype(np.int64)
    t1, t2 = tangent_basis(normal)
    g = H.Gaussians(
        mu=mu, normal=normal, scale=scale,
        quat=H._quat_from_frame(t1.astype(np.float32), t2.astype(np.float32), normal.astype(np.float32)),
        color=color, alpha=None,
        pixel=np.zeros((len(mu), 2), np.int32),
        axis1=t1.astype(np.float32), axis2=t2.astype(np.float32))
    return g, birth


def main() -> None:
    pairs = SF.associate(SF.DATA, max_dt=0.02)[: 11]
    sm = SF.load_rgb(pairs[0].rgb_path)
    h, w = sm.shape[:2]
    m1, m2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)
    bgr0, z0, _ = SF.load_pair(pairs, 0, m1, m2)
    valid = (z0 > Z_MIN) & (z0 < Z_MAX)
    fx, fy, cx, cy = (float(K[0,0]), float(K[1,1]), float(K[0,2]), float(K[1,2]))

    grid = [(i/7.0 + 1/14.0, j/7.0 + 1/14.0) for i in range(7) for j in range(7)]

    for name, path in [("FINAL10", FINAL), ("FRAME0", F0)]:
        g, birth = load_g(path)
        depth, index, _ = H.rasterize_discs(g, K, (h, w))
        hole = ~np.isfinite(depth) & valid
        R0, R1, C0 = 335, 390, 560
        reg = hole[R0:R1, C0:]
        yy, xx = np.nonzero(reg)
        hy = (yy + R0).astype(np.float64)
        hx = (xx + C0).astype(np.float64)

        zc = np.maximum(g.mu[:, 2], 1e-6)
        uc = (fx * g.mu[:, 0] / zc + cx)
        vc = (fy * g.mu[:, 1] / zc + cy)
        nrm = g.normal.astype(np.float64)
        mu = g.mu.astype(np.float64)
        r1 = g.scale[:, 0]
        r2 = g.scale[:, 1]
        ax1 = g.axis1.astype(np.float64)
        ax2 = g.axis2.astype(np.float64)
        n_dot_mu = np.einsum("ij,ij->i", nrm, mu)

        covered = np.zeros(hy.size, bool)
        for du, dv in grid:
            uu = (hx + du - cx) / fx
            vv = (hy + dv - cy) / fy
            dvec = np.stack([uu, vv, np.ones_like(uu)], axis=1)   # (P,3)
            # candidates: discs within 15px
            dist2 = (uc[None, :] - (hx + du)[:, None])**2 + (vc[None, :] - (hy + dv)[:, None])**2
            order = np.argsort(dist2, axis=1)[:, :200]
            for k in range(order.shape[0]):
                cd = order[k]
                P = dvec[k]  # (3,)
                nm = nrm[cd]; mux = mu[cd]
                denom = np.einsum("ij,j->i", nm, P)
                live = np.abs(denom) > 1e-9
                t = np.full(cd.shape, np.nan)
                t[live] = n_dot_mu[cd][live] / denom[live]
                ok = live & (t > 0)
                if not ok.any():
                    continue
                Q = P[None, :] * t[:, None]
                off = Q - mux
                pa = np.einsum("ij,ij->i", off, ax1[cd]) / np.maximum(r1[cd], 1e-9)
                pb = np.einsum("ij,ij->i", off, ax2[cd]) / np.maximum(r2[cd], 1e-9)
                inside = (pa*pa + pb*pb) <= 1.0
                if inside.any():
                    covered[k] = True
        print(f"{name}: {hy.size} holes; sub-pixel(7x7) coverage = {covered.sum()} ({covered.mean():.3f})")

        # also fraction covered at each supersample level for a cleaner story
        # (just report: covered at 7x7 means at least one of 49 rays)


if __name__ == "__main__":
    main()