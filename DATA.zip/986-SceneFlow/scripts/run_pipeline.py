"""Run RGB-D scene flow → camera motion on TUM fr1/desk.

Motion constraints are applied inside scene flow (residual DIS around a
constant-twist prediction). Pose is still a later compression of that field.
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from flow_io import write_scene_flow  # noqa: E402
from rigid_motion import (  # noqa: E402
    geodesic_deg,
    invert_point_motion,
    ransac_rigid,
    rot_angle_deg,
)
from scene_flow import compute_scene_flow  # noqa: E402
from se3 import se3_exp, se3_log  # noqa: E402
from sliding_window import optimize_window, quality_scale  # noqa: E402
from tum_io import (  # noqa: E402
    FR1_INTRINSICS,
    associate,
    interpolate_pose,
    load_depth,
    load_groundtruth,
    load_rgb,
    relative_camera_motion,
    remap_depth,
    remap_rgb,
    undistort_maps,
)


def subsample_valid(valid: np.ndarray, stride: int) -> np.ndarray:
    ys, xs = np.where(valid)
    keep = (xs % stride == 0) & (ys % stride == 0)
    return ys[keep], xs[keep]


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument(
        "--data",
        default=str(ROOT.parent / "rgbd_dataset_freiburg1_desk"),
    )
    p.add_argument("--out", default=str(ROOT.parent / "output"))
    p.add_argument("--max-pairs", type=int, default=80)
    p.add_argument("--skip", type=int, default=1, help="use every skip-th associated pair")
    p.add_argument("--stride", type=int, default=4, help="pixel stride when fitting SE(3)")
    p.add_argument("--undistort", action="store_true", default=True)
    p.add_argument("--no-undistort", action="store_false", dest="undistort")
    p.add_argument("--max-dt", type=float, default=0.02)
    p.add_argument("--fb-thresh", type=float, default=1.5)
    p.add_argument("--ransac-thresh", type=float, default=0.03)
    p.add_argument(
        "--no-motion-constraint",
        action="store_true",
        help="disable temporal/rigid residual model inside scene flow",
    )
    p.add_argument("--window", type=int, default=3, help="sliding window size (1 disables)")
    p.add_argument("--smooth-lambda", type=float, default=0.1, help="constant-twist weight")
    p.add_argument(
        "--no-stats",
        action="store_true",
        help="skip diagnostic statistics (needs to stay off for adaptive-lambda)",
    )
    p.add_argument(
        "--adaptive-lambda",
        action="store_true",
        default=True,
        help="scale the smoothing weight by per-pair flow quality",
    )
    p.add_argument(
        "--save-flow",
        action="store_true",
        help="write dense scene flow to out/flow/*.exr",
    )
    p.add_argument(
        "--project",
        action="store_true",
        help="replace the DIS/model blend with a clean projection onto SE(3) "
        "and regenerate the dense field from the fitted twist",
    )
    p.add_argument(
        "--flow",
        choices=("dis", "var"),
        default="dis",
        help="dense matcher: OpenCV DIS residual (default), or joint variational",
    )
    p.add_argument(
        "--no-expand",
        action="store_true",
        help="disable rigid inlier expansion after DIS (on by default)",
    )
    p.add_argument(
        "--var-lambda",
        type=float,
        default=5.0,
        help="Range Flow weight in the joint variational matcher",
    )
    p.add_argument(
        "--var-sym",
        type=float,
        default=0.5,
        help="forward/backward invertibility weight in the variational matcher",
    )
    args = p.parse_args()

    data_dir = Path(args.data)
    out_dir = Path(args.out)
    vis_dir = out_dir / "vis"
    flow_dir = out_dir / "flow"
    out_dir.mkdir(parents=True, exist_ok=True)
    vis_dir.mkdir(parents=True, exist_ok=True)
    if args.save_flow:
        flow_dir.mkdir(parents=True, exist_ok=True)

    pairs = associate(data_dir, max_dt=args.max_dt)
    if args.skip > 1:
        pairs = pairs[:: args.skip]
    if args.max_pairs > 0:
        pairs = pairs[: args.max_pairs + 1]
    if len(pairs) < 2:
        raise SystemExit(f"not enough RGB-D pairs: {len(pairs)}")

    gt_ts, gt_t, gt_q = load_groundtruth(data_dir / "groundtruth.txt")
    sample = load_rgb(pairs[0].rgb_path)
    h, w = sample.shape[:2]
    if args.undistort:
        map1, map2, K = undistort_maps((h, w), FR1_INTRINSICS)
    else:
        map1 = map2 = None
        from tum_io import camera_matrix

        K = camera_matrix(FR1_INTRINSICS)

    rows = []
    rng = np.random.default_rng(0)

    def prep(pair):
        bgr = load_rgb(pair.rgb_path)
        z = load_depth(pair.depth_path)
        if map1 is not None:
            bgr = remap_rgb(bgr, map1, map2)
            z = remap_depth(z, map1, map2)
        return bgr, z

    bgr0, z0 = prep(pairs[0])
    prev_sf = None
    prev_dt = 1.0
    win_xi: list[np.ndarray] = []
    win_corr: list[tuple[np.ndarray, np.ndarray]] = []
    win_dt: list[float] = []
    win_q: list[float] = []
    win_rec: list[dict] = []
    win_ts: list[float] = []
    R_wc = np.eye(3)
    t_wc = np.zeros(3)
    traj = [(pairs[0].t_rgb, R_wc.copy(), t_wc.copy())]
    W = max(1, args.window)

    def commit(xi_pt, rec, ts):
        nonlocal R_wc, t_wc
        if xi_pt is not None:
            R_10, t_10 = se3_exp(xi_pt)
            R_01, t_01 = invert_point_motion(R_10, t_10)
            t_wc = t_wc + R_wc @ t_01
            R_wc = R_wc @ R_01
            rec["trans_est"] = float(np.linalg.norm(t_01))
            rec["rot_est_deg"] = rot_angle_deg(R_01)
            if np.isfinite(rec.get("trans_gt", np.nan)):
                rec["trans_err"] = float(np.linalg.norm(t_01 - rec["_t_gt"]))
                rec["rot_err_deg"] = geodesic_deg(R_01, rec["_R_gt"])
        traj.append((ts, R_wc.copy(), t_wc.copy()))
        rows.append(rec)
        print(
            f"[{rec['i']:03d}] dt={rec['dt']:.3f}s valid={rec['valid_frac']:.2f} "
            f"res={rec['res_mag_mean']:.2f}px rigidΔ={rec['rigid_delta_mean']:.2f}px "
            f"|t|est={rec.get('trans_est', np.nan):.3f} "
            f"terr={rec.get('trans_err', np.nan):.3f}m "
            f"rerr={rec.get('rot_err_deg', np.nan):.2f}deg",
            flush=True,
        )

    for i in range(len(pairs) - 1):
        p0, p1 = pairs[i], pairs[i + 1]
        bgr1, z1 = prep(p1)
        dt = p1.t_rgb - p0.t_rgb
        sf = compute_scene_flow(
            bgr0,
            bgr1,
            z0,
            z1,
            K,
            fb_thresh=args.fb_thresh,
            prev=prev_sf,
            dt=dt,
            prev_dt=prev_dt,
            motion_constraint=not args.no_motion_constraint,
            project_mode=args.project,
            flow_backend=args.flow,
            var_lambda=args.var_lambda,
            var_sym=args.var_sym,
            expand_inliers=not args.no_expand,
        )
        ys, xs = subsample_valid(sf.valid, args.stride)
        X0 = sf.X0[ys, xs]
        X1 = sf.X1[ys, xs]
        fit = ransac_rigid(X0, X1, thresh=args.ransac_thresh, iters=80, rng=rng)

        rec = {
            "i": i,
            "t0": p0.t_rgb,
            "t1": p1.t_rgb,
            "dt": dt,
            "valid_frac": float(sf.valid.mean()),
            "n_pts": int(X0.shape[0]),
            "flow_mag_mean": sf.stats.get("flow_mag_mean", np.nan),
            "res_mag_mean": sf.stats.get("res_mag_mean", np.nan),
            "pred_mag_mean": sf.stats.get("pred_mag_mean", np.nan),
            "rigid_delta_mean": sf.stats.get("rigid_delta_mean", np.nan),
            "photo_mean": sf.stats.get("photo_mean", np.nan),
            "used_pred": sf.stats.get("used_pred", 0),
            "expanded_frac": sf.stats.get("expanded_frac", 0.0),
            "seed_frac": sf.stats.get("seed_frac", np.nan),
            "trans_gt": np.nan,
            "rot_gt_deg": np.nan,
            "trans_err": np.nan,
            "rot_err_deg": np.nan,
            "trans_est": np.nan,
            "rot_est_deg": np.nan,
        }
        pose0 = interpolate_pose(p0.t_rgb, gt_ts, gt_t, gt_q)
        pose1 = interpolate_pose(p1.t_rgb, gt_ts, gt_t, gt_q)
        if pose0 is not None and pose1 is not None:
            R_gt, t_gt = relative_camera_motion(*pose0, *pose1)
            rec["trans_gt"] = float(np.linalg.norm(t_gt))
            rec["rot_gt_deg"] = rot_angle_deg(R_gt)
            rec["_R_gt"] = R_gt
            rec["_t_gt"] = t_gt

        if fit is None:
            rec.update(ok=0, inlier_ratio=0.0, n_inliers=0, residual_med=np.nan)
        else:
            rec.update(
                ok=1,
                inlier_ratio=fit.inlier_ratio,
                n_inliers=fit.n_inliers,
                residual_med=fit.residual_med,
            )

        if i < 8 or i % 10 == 0:
            _save_preview(vis_dir / f"pair_{i:04d}.png", bgr0, sf, rec)

        if args.save_flow:
            write_scene_flow(flow_dir / f"{i:06d}.exr", sf.X1 - sf.X0, sf.valid)

        if fit is None or W == 1:
            xi_pt = None if fit is None else se3_log(fit.R_10, fit.t_10)
            while win_xi:
                opt = optimize_window(
                    win_xi, win_corr, win_dt, args.smooth_lambda, quality=win_q
                )
                commit(opt[0], win_rec.pop(0), win_ts.pop(0))
                win_xi.pop(0)
                win_corr.pop(0)
                win_dt.pop(0)
                win_q.pop(0)
            commit(xi_pt, rec, p1.t_rgb)
        else:
            inl = fit.inliers
            win_xi.append(se3_log(fit.R_10, fit.t_10))
            win_corr.append((X0[inl], X1[inl]))
            win_dt.append(dt)
            win_rec.append(rec)
            win_ts.append(p1.t_rgb)
            win_q.append(
                quality_scale(rec["rigid_delta_mean"], rec["valid_frac"])
                if args.adaptive_lambda
                else 1.0
            )
            if len(win_xi) == W:
                opt = optimize_window(
                    win_xi, win_corr, win_dt, args.smooth_lambda, quality=win_q
                )
                win_xi[:] = opt
                commit(opt[0], win_rec.pop(0), win_ts.pop(0))
                win_xi.pop(0)
                win_corr.pop(0)
                win_dt.pop(0)
                win_q.pop(0)

        bgr0, z0 = bgr1, z1
        prev_sf = sf
        prev_dt = dt

    while win_xi:
        opt = optimize_window(
            win_xi, win_corr, win_dt, args.smooth_lambda, quality=win_q
        )
        commit(opt[0], win_rec.pop(0), win_ts.pop(0))
        win_xi.pop(0)
        win_corr.pop(0)
        win_dt.pop(0)
        win_q.pop(0)

    _write_csv(out_dir / "frame_errors.csv", rows)
    _write_trajectory(out_dir / "trajectory.txt", traj)
    summary = _summarize(rows)
    (out_dir / "summary.json").write_text(json.dumps(summary, indent=2))
    print("\n=== summary ===")
    print(json.dumps(summary, indent=2))
    print(f"wrote {out_dir}")


def _save_preview(path: Path, bgr0: np.ndarray, sf, rec: dict) -> None:
    vis = bgr0.copy()
    h, w = vis.shape[:2]
    step = 12
    for y in range(0, h, step):
        for x in range(0, w, step):
            if not sf.valid[y, x]:
                continue
            x2 = int(round(x + sf.u[y, x]))
            y2 = int(round(y + sf.v[y, x]))
            cv2.arrowedLine(vis, (x, y), (x2, y2), (0, 255, 0), 1, tipLength=0.3)
            if sf.pred_u is not None:
                xp = int(round(x + sf.pred_u[y, x]))
                yp = int(round(y + sf.pred_v[y, x]))
                cv2.arrowedLine(vis, (x, y), (xp, yp), (0, 128, 255), 1, tipLength=0.3)
    overlay = vis.copy()
    overlay[~sf.valid] = (overlay[~sf.valid] * 0.25).astype(np.uint8)
    vis = overlay
    txt = (
        f"i={rec['i']} valid={rec['valid_frac']:.2f} "
        f"res={rec['res_mag_mean']:.2f}px "
        f"terr={rec.get('trans_err', float('nan')):.3f}m"
    )
    cv2.putText(vis, txt, (8, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 255, 255), 1, cv2.LINE_AA)
    cv2.imwrite(str(path), vis)


def _R_to_quat_xyzw(R: np.ndarray) -> np.ndarray:
    tr = np.trace(R)
    if tr > 0:
        s = np.sqrt(tr + 1.0) * 2
        w = 0.25 * s
        x = (R[2, 1] - R[1, 2]) / s
        y = (R[0, 2] - R[2, 0]) / s
        z = (R[1, 0] - R[0, 1]) / s
    elif R[0, 0] > R[1, 1] and R[0, 0] > R[2, 2]:
        s = np.sqrt(1.0 + R[0, 0] - R[1, 1] - R[2, 2]) * 2
        w = (R[2, 1] - R[1, 2]) / s
        x = 0.25 * s
        y = (R[0, 1] + R[1, 0]) / s
        z = (R[0, 2] + R[2, 0]) / s
    elif R[1, 1] > R[2, 2]:
        s = np.sqrt(1.0 + R[1, 1] - R[0, 0] - R[2, 2]) * 2
        w = (R[0, 2] - R[2, 0]) / s
        x = (R[0, 1] + R[1, 0]) / s
        y = 0.25 * s
        z = (R[1, 2] + R[2, 1]) / s
    else:
        s = np.sqrt(1.0 + R[2, 2] - R[0, 0] - R[1, 1]) * 2
        w = (R[1, 0] - R[0, 1]) / s
        x = (R[0, 2] + R[2, 0]) / s
        y = (R[1, 2] + R[2, 1]) / s
        z = 0.25 * s
    q = np.array([x, y, z, w])
    return q / np.linalg.norm(q)


def _write_trajectory(path: Path, traj) -> None:
    with path.open("w") as f:
        f.write("# estimated trajectory (TUM format)\n")
        f.write("# timestamp tx ty tz qx qy qz qw\n")
        for ts, R, t in traj:
            q = _R_to_quat_xyzw(R)
            f.write(
                f"{ts:.6f} {t[0]:.6f} {t[1]:.6f} {t[2]:.6f} "
                f"{q[0]:.6f} {q[1]:.6f} {q[2]:.6f} {q[3]:.6f}\n"
            )


def _write_csv(path: Path, rows: list[dict]) -> None:
    keys = [
        "i",
        "t0",
        "t1",
        "dt",
        "ok",
        "valid_frac",
        "n_pts",
        "n_inliers",
        "inlier_ratio",
        "residual_med",
        "trans_est",
        "trans_gt",
        "trans_err",
        "rot_est_deg",
        "rot_gt_deg",
        "rot_err_deg",
        "flow_mag_mean",
        "res_mag_mean",
        "pred_mag_mean",
        "rigid_delta_mean",
        "photo_mean",
        "used_pred",
    ]
    with path.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys, extrasaction="ignore")
        w.writeheader()
        for r in rows:
            w.writerow(r)


def _summarize(rows: list[dict]) -> dict:
    ok = [r for r in rows if r.get("ok") and np.isfinite(r.get("trans_err", np.nan))]
    if not ok:
        return {"n_frames": len(rows), "n_eval": 0}
    terr = np.array([r["trans_err"] for r in ok])
    rerr = np.array([r["rot_err_deg"] for r in ok])
    tgt = np.array([r["trans_gt"] for r in ok])
    return {
        "n_frames": len(rows),
        "n_eval": len(ok),
        "valid_frac_mean": float(np.mean([r["valid_frac"] for r in rows])),
        "inlier_ratio_mean": float(np.mean([r["inlier_ratio"] for r in ok])),
        "trans_err_med_m": float(np.median(terr)),
        "trans_err_mean_m": float(np.mean(terr)),
        "rot_err_med_deg": float(np.median(rerr)),
        "rot_err_mean_deg": float(np.mean(rerr)),
        "gt_trans_med_m": float(np.median(tgt)),
        "gt_rot_med_deg": float(np.median([r["rot_gt_deg"] for r in ok])),
        "trans_rel_med": float(np.median(terr / np.maximum(tgt, 1e-4))),
        "flow_mag_mean": float(np.mean([r["flow_mag_mean"] for r in rows])),
        "res_mag_mean": float(np.mean([r["res_mag_mean"] for r in rows])),
        "rigid_delta_mean": float(np.mean([r["rigid_delta_mean"] for r in rows])),
        "photo_mean": float(np.mean([r["photo_mean"] for r in rows])),
    }


if __name__ == "__main__":
    main()
