"""Texture mask comparison panel for experiment H (quantile sweep)."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from exp_h_texture_mask import texture_mask, texture_variance  # noqa: E402
from rgbd_io import (  # noqa: E402
    FR1_INTRINSICS,
    associate,
    load_depth,
    load_rgb,
    remap_depth,
    remap_rgb,
    undistort_maps,
)


def label(img, text):
    out = img.copy()
    cv2.rectangle(out, (0, 0), (out.shape[1], 34), (0, 0, 0), -1)
    cv2.putText(out, text, (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
    return out


def mask_overlay(bgr, mask, color=(0, 0, 255)):
    out = bgr.copy()
    out[mask] = (out[mask] * 0.3 + np.array(color) * 0.7).astype(np.uint8)
    return out


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--data", default=str(
        ROOT.parent.parent / "986-SceneFlow" / "rgbd_dataset_freiburg1_desk"))
    p.add_argument("--out", default=str(ROOT.parent / "output_H"))
    p.add_argument("--frame", type=int, default=0)
    args = p.parse_args()

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    pairs = associate(Path(args.data))
    fr = pairs[args.frame]
    sample = load_rgb(pairs[0].rgb_path)
    map1, map2, K = undistort_maps(sample.shape[:2], FR1_INTRINSICS)
    bgr = remap_rgb(load_rgb(fr.rgb_path), map1, map2)
    z = remap_depth(load_depth(fr.depth_path), map1, map2)
    rgb = bgr[..., ::-1].astype(np.float32) / 255.0

    var = texture_variance(rgb, 9)
    # Normalize variance to [0,255] for a heat view (log for visibility).
    var_vis = np.log1p(var)
    var_vis = (var_vis / max(var_vis.max(), 1e-9) * 255).astype(np.uint8)
    var_vis = cv2.applyColorMap(var_vis, cv2.COLORMAP_TURBO)

    cells = [
        label(bgr, "original RGB"),
        label(var_vis, "texture variance (9x9, log)"),
    ]

    for q in (0.5, 0.6, 0.75, 0.9):
        m = texture_mask(rgb, q, 9)
        frac = m.mean() * 100
        cells.append(label(
            mask_overlay(bgr, m),
            f"mask q={q:g}  tex={frac:.0f}%",
        ))

    while len(cells) % 3 != 0:
        cells.append(np.zeros_like(bgr))
    rows = []
    for i in range(0, len(cells), 3):
        rows.append(np.hstack(cells[i:i + 3]))
    panel = np.vstack(rows)

    out = out_dir / f"mask_panel_f{args.frame:02d}.png"
    cv2.imwrite(str(out), panel)
    print(f"wrote {out}")


if __name__ == "__main__":
    main()