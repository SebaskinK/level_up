"""Brute-force sweep of COLOR_GATE_K over the 80-frame revisit pipeline.

For each K: run render_f0_images.py (fusion + frame-0 4-image render, geometry-
only relink), then report final disc count, colour-gate rejection fraction,
hard/EWA hole + masked PSNR on frame 0.
"""

from __future__ import annotations

import csv
import json
import re
import subprocess
import sys
from pathlib import Path

SEQ = Path(__file__).resolve().parent
ROOT = SEQ.parent
KS = [2.0, 3.0, 4.0, 6.0]

HARD_RE = re.compile(r"hard  covered=([\d.]+) hole=([\d.]+) psnr=([\d.eE+-]+|\S+) dB")
EWA_RE = re.compile(r"ewa   covered=([\d.]+) hole=([\d.]+) psnr=([\d.eE+-]+|\S+) dB")


def run(k: float) -> dict:
    out = ROOT / f"output_f0_80frame_sweep_K{k:g}"
    cmd = [sys.executable, str(SEQ / "render_f0_images.py"),
           "--frames", "81", "--relink-no-color",
           "--out", str(out), "--color-gate-k", f"{k:g}"]
    print(f"\n===== K={k:g} =====  ", flush=True)
    r = subprocess.run(cmd, capture_output=True, text=True)
    sys.stdout.write(r.stdout)
    if r.returncode != 0:
        sys.stdout.write(r.stderr)
        return {"k": k, "error": r.returncode}

    summary = json.loads((out / "summary.json").read_text())
    n_final = summary["n_final"]
    with (out / "fusion.csv").open() as f:
        rows = [x for x in csv.DictReader(f) if x["i"] != "-1"]
    cand = sum(int(x["n_cand"]) for x in rows)
    cfail = sum(int(x["n_color_fail"]) for x in rows)
    acfail = sum(int(x["n_absorb_color_fail"]) for x in rows)
    n_upd = sum(int(x["n_upd"]) for x in rows)
    n_new = sum(int(x["n_new"]) for x in rows)
    n_abs = sum(int(x["n_absorb"]) for x in rows)
    n_rel = sum(int(x["n_relink"]) for x in rows)

    m_h = HARD_RE.search(r.stdout)
    m_e = EWA_RE.search(r.stdout)
    return {
        "k": k,
        "n_final": n_final,
        "n_upd": n_upd,
        "n_new": n_new,
        "n_absorb": n_abs,
        "n_relink": n_rel,
        "cand": cand,
        "color_rej_frac": cfail / cand if cand else 0.0,
        "absorb_color_fail": acfail,
        "hard_hole": float(m_h.group(2)) if m_h else float("nan"),
        "hard_psnr": float(m_h.group(3)) if m_h and m_h.group(3) not in ("inf", "nan") else float("nan"),
        "ewa_hole": float(m_e.group(2)) if m_e else float("nan"),
        "ewa_psnr": float(m_e.group(3)) if m_e and m_e.group(3) not in ("inf", "nan") else float("nan"),
    }


def main():
    results = [run(k) for k in KS]
    print("\n\n================ SUMMARY ================", flush=True)
    hdr = (f"{'K':>4} {'N_final':>8} {'colRej%':>8} {'absCFail':>8} "
           f"{'hardHole':>9} {'hardPSNR':>8} {'ewaHole':>9} {'ewaPSNR':>8} "
           f"{'n_new':>7} {'n_relink':>8}")
    print(hdr, flush=True)
    for r in results:
        if "error" in r:
            print(f"{r['k']:>4}  ERROR rc={r['error']}", flush=True)
            continue
        print(f"{r['k']:>4.1f} {r['n_final']:>8} {100*r['color_rej_frac']:>7.1f}% "
              f"{r['absorb_color_fail']:>8} "
              f"{r['hard_hole']:>9.3f} {r['hard_psnr']:>8.3f} "
              f"{r['ewa_hole']:>9.3f} {r['ewa_psnr']:>8.3f} "
              f"{r['n_new']:>7} {r['n_relink']:>8}", flush=True)
    print("=========================================", flush=True)
    (ROOT / "sweep_color_gate_k.json").write_text(
        json.dumps(results, indent=2))
    print(f"wrote {ROOT / 'sweep_color_gate_k.json'}", flush=True)


if __name__ == "__main__":
    main()