S2 disc centre: pixel-centre (+0.5) is now the DEFAULT correction

State: the S2 disc centre moves from the integer 2x2-cell corner to the
pixel centre (x+0.5, y+0.5) in emit_footprint_discs. Radius (sqrt2) and the
2x2 owner map are unchanged. This is the validated default that fixes the
keyboard-axis distortion seen in incremental modelling.

Final N (no aging prune, 10 frames): 42235 (baseline 42210, +25).
Hard hole: 1.27% (baseline ~1.32%). EWA hole: 0.56%.
