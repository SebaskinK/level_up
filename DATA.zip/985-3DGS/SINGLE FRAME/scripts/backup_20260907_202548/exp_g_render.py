"""Render the Gaussian field back to an image and compare against the input.

Readout is the same ray-disc / opaque-surfel path used by metrics.evaluate, not
an alpha-blended 3DGS rasterizer -- see OPEN_ITEMS C2 for what that leaves open.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from exp_g_aniso_real import CFG, build, eval_setup  # noqa: E402
from metrics import rasterize_discs  # noqa: E402
from rgbd_io import (  # noqa: E402
    FR1_INTRINSICS,
    associate,
    load_depth,
    load_rgb,
    remap_depth,
    remap_rgb,
    undistort_maps,
)


def label(img, text):
    out = img.copy()
    cv2.rectangle(out, (0, 0), (out.shape[1], 34), (0, 0, 0), -1)
    cv2.putText(out, text, (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
    return out


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--data", default=str(
        ROOT.parent.parent / "986-SceneFlow" / "rgbd_dataset_freiburg1_desk"))
    p.add_argument("--out", default=str(ROOT.parent / "output_G_refactor"))
    p.add_argument("--frame", type=int, default=0)
    args = p.parse_args()

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    pairs = associate(Path(args.data))
    fr = pairs[args.frame]
    sample = load_rgb(pairs[0].rgb_path)
    map1, map2, K = undistort_maps(sample.shape[:2], FR1_INTRINSICS)
    bgr = remap_rgb(load_rgb(fr.rgb_path), map1, map2)
    z = remap_depth(load_depth(fr.depth_path), map1, map2)

    _, eval_mask = eval_setup(z, K)
    g, _ = build(bgr, z, K, foreshorten=False, aniso_claim=True)
    depth, index, _ = rasterize_discs(g, K, z.shape)
    hit = index >= 0

    render = np.zeros_like(bgr)
    rgb = np.clip(g.color[index[hit]], 0.0, 1.0)
    render[hit] = (rgb[:, ::-1] * 255.0).astype(np.uint8)

    err = np.zeros(z.shape, np.float32)
    m = hit & eval_mask
    err[m] = np.abs(depth[m] - z[m])
    err_vis = cv2.applyColorMap(
        np.clip(err / 0.02 * 255.0, 0, 255).astype(np.uint8), cv2.COLORMAP_INFERNO)
    err_vis[~m] = 0

    rmse = float(np.sqrt(np.mean((depth[m] - z[m]) ** 2))) * 1000.0
    cov = float((hit & eval_mask).sum() / max(eval_mask.sum(), 1))
    col_err = g.color[index[m]] - (bgr[..., ::-1].astype(np.float32) / 255.0)[m]
    psnr = -20.0 * np.log10(max(float(np.sqrt(np.mean(col_err ** 2))), 1e-12))

    panel = np.hstack([
        label(bgr, "input RGB"),
        label(render, f"gaussian readout  N={len(g)}  PSNR={psnr:.1f}dB"),
        label(err_vis, f"|depth err| 0-20mm  RMSE={rmse:.2f}mm cov={cov:.3f}"),
    ])
    out = out_dir / f"render_compare_f{args.frame:02d}.png"
    cv2.imwrite(str(out), panel)
    print(f"N={len(g)} cov={cov:.3f} rmse={rmse:.2f}mm psnr={psnr:.2f}dB")
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
