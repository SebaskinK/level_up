"""Novel-view DEPTH comparison: build 3DGS from frame n, render from frame n+1's
pose, compare the rendered depth to frame n+1's measured depth.

Per pair, Mrel = inv(M_{n+1}) @ M_n (TUM camera-to-world). Gaussians are rigidly
transformed and re-rasterized (front-most ray-disc intersection) to get a depth
map in frame n+1's camera frame, directly comparable to frame n+1's depth z.

Output: a 4-row x N-col panel —
  row 0: frame n     depth (measured)
  row 1: frame n+1   depth (measured)
  row 2: novel-view depth (re-projected gaussians)
  row 3: |render - target| depth diff (mm, masked to valid pixels)
"""

import sys
from pathlib import Path

import cv2
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import h_pipeline_final as H


def q_to_R(qx, qy, qz, qw):
    return np.array([
        [1 - 2 * (qy * qy + qz * qz), 2 * (qx * qy - qz * qw), 2 * (qx * qz + qy * qw)],
        [2 * (qx * qy + qz * qw), 1 - 2 * (qx * qx + qz * qz), 2 * (qy * qz - qx * qw)],
        [2 * (qx * qz - qy * qw), 2 * (qy * qz + qx * qw), 1 - 2 * (qx * qx + qy * qy)],
    ])


def parse_tum(path):
    poses = []
    for line in Path(path).read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        p = line.split()
        t = np.array(list(map(float, p[1:4])))
        T = np.eye(4)
        T[:3, :3] = q_to_R(*map(float, p[4:8]))
        T[:3, 3] = t
        poses.append((float(p[0]), T))
    return poses


def transform_gaussians(g, Mrel):
    R = Mrel[:3, :3].astype(np.float32)
    t = Mrel[:3, 3].astype(np.float32)
    mu = g.mu @ R.T + t
    normal = g.normal @ R.T
    axis1 = g.axis1 @ R.T if g.axis1 is not None else None
    axis2 = g.axis2 @ R.T if g.axis2 is not None else None
    return H.Gaussians(
        mu=mu.astype(np.float32), normal=normal.astype(np.float32),
        scale=g.scale, quat=H._quat_from_normal(normal),
        color=g.color, alpha=g.alpha, pixel=g.pixel,
        axis1=axis1.astype(np.float32) if axis1 is not None else None,
        axis2=axis2.astype(np.float32) if axis2 is not None else None,
    )


def colorize_depth(z, mask, z_min=0.4, z_max=4.0):
    mm = z * 1000.0
    norm = (mm - z_min * 1000.0) / (z_max * 1000.0 - z_min * 1000.0)
    norm = np.clip(norm, 0.0, 1.0)
    vis = cv2.applyColorMap((norm * 255.0).astype(np.uint8), cv2.COLORMAP_TURBO)
    vis[~mask] = 0
    return vis


def colorize_diff_mm(d, mask, vmax=100.0):
    norm = np.clip(d / vmax, 0.0, 1.0)
    vis = cv2.applyColorMap((norm * 255.0).astype(np.uint8), cv2.COLORMAP_JET)
    vis[~mask] = 0
    return vis


def label(img, s):
    o = img.copy()
    cv2.rectangle(o, (0, 0), (o.shape[1], 34), (0, 0, 0), -1)
    cv2.putText(o, s, (10, 25), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
    return o


def main():
    import time
    pairs = H.associate(Path(H.ROOT.parent.parent / "986-SceneFlow" /
                            "rgbd_dataset_freiburg1_desk"))
    poses = parse_tum(Path(H.ROOT.parent.parent) / "986-SceneFlow" /
                      "output_final" / "trajectory.txt")
    N = 10
    map1, map2, K = H.undistort_maps((480, 640), H.FR1_INTRINSICS)

    rows = [[], [], [], []]
    print(f"{'pair':>6}{'N':>8}{'hit_frac':>10}{'rmse_mm':>9}{'med_mm':>9}", flush=True)
    for n in range(N):
        fr0 = pairs[n]
        fr1 = pairs[n + 1]
        bgr0 = H.remap_rgb(H.load_rgb(fr0.rgb_path), map1, map2)
        z0 = H.remap_depth(H.load_depth(fr0.depth_path), map1, map2)
        bgr1 = H.remap_rgb(H.load_rgb(fr1.rgb_path), map1, map2)
        z1 = H.remap_depth(H.load_depth(fr1.depth_path), map1, map2)

        t0 = time.perf_counter()
        g, _, _ = H.build_hybrid(bgr0, z0, K, 0.6)
        dt = time.perf_counter() - t0

        Mrel = np.linalg.inv(poses[n + 1][1]) @ poses[n][1]
        gt = transform_gaussians(g, Mrel)
        render, index, _ = H.rasterize_discs(gt, K, (480, 640))
        hit = np.isfinite(render)

        # compare rendered depth (camera n+1) to measured depth z1, on pixels
        # where the render actually hit AND frame n+1 has a valid reading
        m = hit & H.depth_valid(z1)
        err = (render[m] - z1[m]) * 1000.0
        rmse = float(np.sqrt(np.mean(err ** 2)))
        med = float(np.median(np.abs(err)))
        print(f"{n:>4}{len(g):>8}{hit.mean():>10.3f}{rmse:>9.2f}{med:>9.2f}  ({dt:.1f}s)", flush=True)

        v0 = H.depth_valid(z0)
        v1 = H.depth_valid(z1)
        rows[0].append(label(colorize_depth(z0, v0), f"frame {n} depth"))
        rows[1].append(label(colorize_depth(z1, v1), f"frame {n+1} depth"))
        rows[2].append(label(colorize_depth(render, hit), f"novel f{n}->f{n+1} depth"))
        diff = np.abs(render - z1) * 1000.0
        rows[3].append(label(colorize_diff_mm(diff, m), f"|diff| mm  RMSE={rmse:.1f}"))

    panel = np.vstack([np.hstack(r) for r in rows])
    out = H.ROOT.parent / "output_H" / "novelview_depth_10.png"
    out.parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(out), panel)
    print(f"wrote {out}  shape={panel.shape}")


if __name__ == "__main__":
    main()