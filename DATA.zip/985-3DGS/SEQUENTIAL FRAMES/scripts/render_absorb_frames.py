"""Render the 10-frame final model back into each frame with GT poses.

Reproduces the absorb-v2 fusion loop (default flow path, identical to
sequential_fusion_flowonly.main) to obtain the FINAL Gaussians, then renders
each of the 10 frames:

  * the model is anchored to frame 0 = identity camera;
  * the fusion integrated the flow-derived twist per step (FL_k: frame0 -> k);
  * for rendering we place the model back into each GT camera via
    T_k = GT_k . FL_9^{-1}  (point motion frame9 -> frame k).

Panel: row 1 = 10 GT RGB, row 2 = 10 EWA renders.
"""

from __future__ import annotations

import sys
from pathlib import Path

import cv2
import numpy as np

SEQ = Path(__file__).resolve().parent
SINGLE = SEQ.parent.parent / "SINGLE FRAME" / "scripts"
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SINGLE))
sys.path.insert(0, str(SFLOW))
sys.path.insert(0, str(SEQ))

import h_pipeline_final as H  # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402
from exp_surfel_render import render_ewa  # noqa: E402

OUT = SEQ.parent / "output_absorb_v2"
RENDER_DIR = OUT / "render"
RENDER_DIR.mkdir(parents=True, exist_ok=True)

LABEL_H = 26


def pm_compose(a, b):
    """Point motion compose: X_out = R_b (R_a X + t_a) + t_b."""
    Ra, ta = a
    Rb, tb = b
    return Rb @ Ra, Rb @ ta + tb


def pm_inv(a):
    R, t = a
    return R.T, -R.T @ t


def apply_pm(g, pm):
    R, t = pm
    R = R.astype(np.float32)
    t = t.astype(np.float32)
    return SF.transform_to_next(g, R, t)


def render_to_bgr(color, weight):
    bgr = (np.clip(color, 0.0, 1.0) * 255.0).astype(np.uint8)[..., ::-1].copy()
    bgr[weight <= 0] = 0
    return bgr


def label(img, text):
    strip = np.full((LABEL_H, img.shape[1], 3), 30, np.uint8)
    cv2.putText(strip, text, (8, LABEL_H - 8), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                (235, 235, 235), 1, cv2.LINE_AA)
    return np.vstack([strip, img])


def main() -> None:
    pairs = SF.associate(SF.DATA, max_dt=0.02)[: 11]
    sample = SF.load_rgb(pairs[0].rgb_path)
    h, w = sample.shape[:2]
    map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)

    gt_ts, gt_t, gt_q = SF.load_groundtruth(SF.DATA / "groundtruth.txt")

    bgr0, z0, _ = SF.load_pair(pairs, 0, map1, map2)
    g0, _, _ = H.build_hybrid(bgr0, z0, K, SF.TEX_Q)
    model = SF.Model(
        g=g0,
        w=np.ones(len(g0), dtype=np.float32),
        age=np.zeros(len(g0), dtype=np.int32),
        owner=SF.owner_from_raster(g0, K, (h, w)),
        birth=np.zeros(len(g0), dtype=np.int32),
        cnt=np.ones(len(g0), dtype=np.float32),
    )

    # per-frame images (GT row), flow/GT accumulated point motions (frame0 -> k)
    gts = [bgr0]
    FL = [None] * 11
    GT = [None] * 11
    FL[0] = (np.eye(3), np.zeros(3))
    # frame0 GT camera = identity by construction (model is anchored there)
    GT[0] = (np.eye(3), np.zeros(3))
    prev_FL = FL[0]
    prev_GT = GT[0]

    prev_sf = None
    prev_dt = 1.0
    bgr_a, z_a = bgr0, z0
    for i in range(len(pairs) - 1):
        bgr_b, z_b, t_b = SF.load_pair(pairs, i + 1, map1, map2)
        gts.append(bgr_b)
        dt = pairs[i + 1].t_rgb - pairs[i].t_rgb
        sf = SF.compute_scene_flow(
            bgr_a, bgr_b, z_a, z_b, K,
            prev=prev_sf, dt=dt, prev_dt=prev_dt,
        )
        if sf.xi is None:
            raise RuntimeError("scene flow produced no twist")
        R_10, t_10 = SF.se3_exp(sf.xi)

        # GT point motion frame i -> i+1
        m0 = SF.interpolate_pose(pairs[i].t_rgb, gt_ts, gt_t, gt_q)
        m1 = SF.interpolate_pose(pairs[i + 1].t_rgb, gt_ts, gt_t, gt_q)
        R_eg, t_eg = SF.relative_camera_motion(*m0, *m1)
        Rg, tg = SF.invert_point_motion(R_eg, t_eg)

        step_flow = (R_10, t_10)
        step_gt = (Rg, tg)
        curr_FL = pm_compose(prev_FL, step_flow)
        curr_GT = pm_compose(prev_GT, step_gt)
        FL[i + 1] = curr_FL
        GT[i + 1] = curr_GT

        rec = SF.fuse_frame(model, sf, z_a, z_b, bgr_b, K,
                            age_max=8, w_min=2.0, frame_idx=i,
                            R_10=R_10, t_10=t_10)
        print(f"[render] frame {i} N={rec['n']}", flush=True)

        bgr_a, z_a = bgr_b, z_b
        prev_sf, prev_dt = sf, dt
        prev_FL, prev_GT = curr_FL, curr_GT

    # save final model (for reuse / verification)
    g = model.g
    np.savez(
        RENDER_DIR / "model_final.npz",
        mu=g.mu, normal=g.normal, scale=g.scale, quat=g.quat,
        color=g.color, alpha=g.alpha, pixel=g.pixel,
        axis1=g.axis1, axis2=g.axis2,
        FL9=FL[9][0], FL9_t=FL[9][1],
    )
    print(f"final N={len(g)}", flush=True)

    # render every frame: T_k = GT_k . FL_9^{-1}
    FL9_inv = pm_inv(FL[9])
    cells_gt = []
    cells_rd = []
    for k in range(10):
        T_k = pm_compose(FL9_inv, GT[k])
        g_k = apply_pm(g, T_k)
        color, depth, weight = render_ewa(g_k, K, (h, w),
                                          mode="normalized", cov_scale=0.33)
        bgr_rd = render_to_bgr(color, weight)

        bgr_gt = gts[k]
        rgb_gt = bgr_gt[..., ::-1].astype(np.float32) / 255.0
        m = weight > 0
        if m.any():
            err = color[m] - rgb_gt[m]
            psnr = float(-20.0 * np.log10(max(float(np.sqrt(np.mean(err ** 2))), 1e-12)))
        else:
            psnr = 0.0

        cv2.imwrite(str(RENDER_DIR / f"gt_{k:02d}.png"), bgr_gt)
        cv2.imwrite(str(RENDER_DIR / f"render_{k:02d}.png"), bgr_rd)

        cells_gt.append(label(bgr_gt, f"GT  f{k}"))
        cells_rd.append(label(bgr_rd, f"render  f{k}  PSNR={psnr:.1f}"))
        print(f"[render] frame {k} PSNR={psnr:.2f}", flush=True)

    row1 = np.hstack(cells_gt)
    row2 = np.hstack(cells_rd)
    panel = np.vstack([row1, row2])
    out = RENDER_DIR / "panel_gt_vs_render.png"
    cv2.imwrite(str(out), panel)
    print(f"wrote {out}  shape={panel.shape}")


if __name__ == "__main__":
    main()