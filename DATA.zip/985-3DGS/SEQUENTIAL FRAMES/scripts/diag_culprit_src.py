"""Pin down the desk-edge culprit discs: their TRUE source (seed) pixel and the
fence values (r_edge / r_cap / r_k) at that seed, in the FRESH frame-0 build AND
in the saved 10-frame model. Resolves the contradiction where the saved model's
frame-0 disc has r=0.04 but the fresh build emits none at that projected centre.
"""
import os
import sys
from pathlib import Path

import numpy as np

SEQ = Path(__file__).resolve().parent
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SEQ))
sys.path.insert(0, str(SFLOW))

import h_pipeline_final as H  # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402

pairs = SF.associate(SF.DATA, max_dt=0.02)[:1]
h, w = SF.load_rgb(pairs[0].rgb_path).shape[:2]
map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)
bgr0, z0, _ = SF.load_pair(pairs, 0, map1, map2)
rgb = bgr0[..., ::-1].astype(np.float32) / 255.0

geo = H.compute_scene_geometry(
    z0, K, H.GEO_CFG["eps"], H.GEO_CFG["gauss_sigma"], H.GEO_CFG["disc_rel"],
)
tex_mask = H.texture_mask(rgb, SF.TEX_Q)
r_cap = H.tex_boundary_limit(z0, K, tex_mask, tol_px=4.5)

g0, keep_geo, _, _ = H.build_hybrid_with_owner(bgr0, z0, K, SF.TEX_Q)

fx, fy, cx, cy = (float(K[0, 0]), float(K[1, 1]), float(K[0, 2]), float(K[1, 2]))
uc = np.clip((fx * g0.mu[:, 0] / np.maximum(g0.mu[:, 2], 1e-6) + cx).astype(int), 0, w - 1)
vc = np.clip((fy * g0.mu[:, 1] / np.maximum(g0.mu[:, 2], 1e-6) + cy).astype(int), 0, h - 1)

# desk-edge region
region = (vc >= 366) & (vc <= 400) & (uc >= 400) & (uc <= 640)
print(f"fresh frame-0 discs with proj centre in desk-edge region: {int(region.sum())}")
idx = np.where(region)[0]
order = idx[np.argsort(-g0.scale[idx, 1])]
print("f0 idx | seed(u,v) | r1,r2 | r_cap@seed | r_edge@seed | r_k1,r_k2@seed | col")
for i in order[:20]:
    sx, sy = int(g0.pixel[i, 0]), int(g0.pixel[i, 1])
    sx = min(max(sx, 0), w - 1)
    sy = min(max(sy, 0), h - 1)
    print(f"{i:5d} | ({sx},{sy}) | {g0.scale[i,0]:.4f},{g0.scale[i,1]:.4f} | "
          f"{r_cap[sy,sx]:.4f} | {geo.r_edge[sy,sx]:.4f} | "
          f"{geo.r_k1[sy,sx]:.4f},{geo.r_k2[sy,sx]:.4f} | "
          f"({g0.color[i,0]:.2f},{g0.color[i,1]:.2f},{g0.color[i,2]:.2f})")

# saved model comparison
out = Path(os.environ.get("MODEL_DIR", str(SEQ.parent / "output_f0_noabsorb")))
d = np.load(out / "model_f0.npz")
mu = d["mu"].astype(np.float32); scale = d["scale"].astype(np.float32)
color = d["color"].astype(np.float32); birth = d["birth"].astype(np.int32)
uc2 = np.clip((fx * mu[:, 0] / np.maximum(mu[:, 2], 1e-6) + cx).astype(int), 0, w - 1)
vc2 = np.clip((fy * mu[:, 1] / np.maximum(mu[:, 2], 1e-6) + cy).astype(int), 0, h - 1)
region2 = (vc2 >= 366) & (vc2 <= 400) & (uc2 >= 400) & (uc2 <= 640)
print(f"\nsaved-model discs with proj centre in desk-edge region: {int(region2.sum())}")
idx2 = np.where(region2)[0]
order2 = idx2[np.argsort(-scale[idx2, 1])]
print("idx | birth | r1,r2 | col | mu.z")
for i in order2[:20]:
    print(f"{i:5d} | {birth[i]} | {scale[i,0]:.4f},{scale[i,1]:.4f} | "
          f"({color[i,0]:.2f},{color[i,1]:.2f},{color[i,2]:.2f}) | {mu[i,2]:.2f}")