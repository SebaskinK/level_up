"""Experiment B: curvature-adaptive quadtree sampling.

Experiment A established that uniform downsampling cannot win: enlarging discs
to keep coverage costs 4-5x in depth accuracy, because a flat disc cannot
follow a curved surface. Here the block size follows local planarity instead,
so flat regions get few large Gaussians and curved ones stay dense.

Compared against the uniform-stride baselines from experiment A at matched
Gaussian counts.
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from gaussian_build import (  # noqa: E402
    build_gaussians,
    build_gaussians_from_blocks,
    depth_discontinuity_mask,
    normals_from_depth,
    prefilter_depth,
)
from metrics import evaluate  # noqa: E402
from quadtree import quadtree_blocks  # noqa: E402
from rgbd_io import (  # noqa: E402
    FR1_INTRINSICS,
    associate,
    load_depth,
    load_rgb,
    remap_depth,
    remap_rgb,
    undistort_maps,
)

METRIC_KEYS = (
    "n_gaussians", "coverage", "hole_frac",
    "depth_rmse_mm", "depth_mae_mm", "depth_med_mm", "depth_p95_mm",
    "normal_med_deg", "normal_mean_deg", "normal_p95_deg",
    "color_rmse", "color_psnr_db",
    "gauss_per_m2", "radius_med_mm", "build_ms",
)


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--data", default=str(ROOT.parent.parent / "986-SceneFlow" / "rgbd_dataset_freiburg1_desk"))
    p.add_argument("--out", default=str(ROOT.parent / "output_B"))
    p.add_argument("--frames", type=int, default=10)
    p.add_argument(
        "--plane-tol", type=float, nargs="+", default=[0.0005, 0.001, 0.002, 0.005],
        help="max depth residual (m) for a block to collapse to one Gaussian",
    )
    p.add_argument("--color-tol", type=float, default=0.06)
    p.add_argument("--cover", type=float, default=1.0)
    p.add_argument(
        "--quant-coeff", type=float, default=0.0,
        help="raise plane-tol to quant_coeff*z^2 (TUM disparity quantization: 0.0029)",
    )
    p.add_argument("--min-size", type=int, default=2)
    p.add_argument("--max-size", type=int, default=32)
    p.add_argument("--baseline-strides", type=int, nargs="+", default=[1, 2, 4, 8])
    p.add_argument("--prefilter", default="bilateral")
    p.add_argument("--prefilter-size", type=int, default=5)
    p.add_argument("--z-min", type=float, default=0.4)
    p.add_argument("--z-max", type=float, default=4.0)
    p.add_argument("--disc-rel", type=float, default=0.02)
    args = p.parse_args()

    data_dir = Path(args.data)
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    pairs = associate(data_dir)[: args.frames]
    if not pairs:
        raise SystemExit(f"no RGB-D pairs under {data_dir}")

    sample = load_rgb(pairs[0].rgb_path)
    map1, map2, K = undistort_maps(sample.shape[:2], FR1_INTRINSICS)

    rows = []
    for i, fr in enumerate(pairs):
        bgr = remap_rgb(load_rgb(fr.rgb_path), map1, map2)
        z = remap_depth(load_depth(fr.depth_path), map1, map2)
        rgb = bgr[..., ::-1].astype(np.float32) / 255.0

        z_grad = prefilter_depth(z, args.prefilter, args.prefilter_size)
        normal_ref, n_ok = normals_from_depth(z_grad, K)
        valid = (
            (z > args.z_min)
            & (z < args.z_max)
            & ~depth_discontinuity_mask(z, args.disc_rel)
        )
        eval_mask = valid & n_ok

        for stride in args.baseline_strides:
            t0 = time.perf_counter()
            g = build_gaussians(
                bgr, z, K, z_min=args.z_min, z_max=args.z_max,
                disc_rel=args.disc_rel, stride=stride,
                prefilter=args.prefilter, prefilter_size=args.prefilter_size,
            )
            dt = time.perf_counter() - t0
            m = evaluate(g, z, bgr, normal_ref, eval_mask, K)
            m.update(frame=i, method="uniform", param=stride, build_ms=dt * 1e3)
            rows.append(m)
            _log(m)

        for tol in args.plane_tol:
            t0 = time.perf_counter()
            blocks = quadtree_blocks(
                z_grad, rgb, valid,
                plane_tol=tol, color_tol=args.color_tol,
                min_size=args.min_size, max_size=args.max_size,
                quant_coeff=args.quant_coeff,
            )
            g = build_gaussians_from_blocks(
                bgr, z, K, blocks, valid, cover=args.cover,
                prefilter=args.prefilter, prefilter_size=args.prefilter_size,
            )
            dt = time.perf_counter() - t0
            m = evaluate(g, z, bgr, normal_ref, eval_mask, K)
            m.update(frame=i, method="quadtree", param=tol, build_ms=dt * 1e3)
            rows.append(m)
            _log(m)

    summary = {}
    for method, params in (("uniform", args.baseline_strides), ("quadtree", args.plane_tol)):
        for prm in params:
            sel = [r for r in rows if r["method"] == method and r["param"] == prm]
            summary[f"{method}_{prm}"] = {
                k: float(np.mean([r[k] for r in sel])) for k in METRIC_KEYS
            }

    (out_dir / "summary.json").write_text(json.dumps(summary, indent=2))
    with (out_dir / "frames.csv").open("w", newline="") as f:
        wr = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        wr.writeheader()
        wr.writerows(rows)

    print("\n=== summary (mean over frames) ===")
    print(f"{'config':<18}{'N':>8}{'cover':>8}{'rmse_mm':>9}{'med_mm':>8}"
          f"{'normal':>8}{'psnr':>7}{'ms':>7}")
    for k, v in summary.items():
        print(f"{k:<18}{v['n_gaussians']:>8.0f}{v['coverage']:>8.3f}"
              f"{v['depth_rmse_mm']:>9.2f}{v['depth_med_mm']:>8.2f}"
              f"{v['normal_med_deg']:>8.2f}{v['color_psnr_db']:>7.2f}"
              f"{v['build_ms']:>7.1f}")
    print(f"wrote {out_dir}")


def _log(m: dict) -> None:
    tag = f"{m['method'][:4]}:{m['param']}"
    print(
        f"[f{m['frame']:02d} {tag:<12}] N={m['n_gaussians']:6d} "
        f"cov={m['coverage']:.3f} rmse={m['depth_rmse_mm']:6.2f}mm "
        f"med={m['depth_med_mm']:5.2f}mm normal={m['normal_med_deg']:5.2f}deg "
        f"psnr={m['color_psnr_db']:5.2f} {m['build_ms']:6.1f}ms",
        flush=True,
    )


if __name__ == "__main__":
    main()
