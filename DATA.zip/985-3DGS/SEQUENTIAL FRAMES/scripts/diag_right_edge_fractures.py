"""Root-cause the right-edge vertical fracture holes (rows ~340-390, cols ~600-639).

Loads the final 10-frame model and the frame-0-only model directly from their
npz files, re-renders both into frame 0, defines the GT-valid region from the
undistorted depth, and analyses the exact fracture region per row/column: where
render coverage stops, the nearest disc's projected centre / footprint / birth
frame / S2-vs-curvature class, and whether frame-0 init already had the hole.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

SEQ = Path(__file__).resolve().parent
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SEQ))
sys.path.insert(0, str(SFLOW))

import h_pipeline_final as H            # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402

FINAL = SEQ.parent / "output_f0_ellipse_final" / "model_f0.npz"
F0 = SEQ.parent / "output_f0_0frame" / "model_f0.npz"
Z_MIN, Z_MAX = 0.4, 4.0


def tangent_basis(n):
    n = n.astype(np.float64)
    n = n / np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-12)
    ref = np.tile(np.array([0.0, 0.0, 1.0]), (n.shape[0], 1))
    ref[np.abs(n[:, 2]) > 0.9] = np.array([1.0, 0.0, 0.0])
    t1 = np.cross(ref, n)
    t1 = t1 / np.maximum(np.linalg.norm(t1, axis=1, keepdims=True), 1e-12)
    t2 = np.cross(n, t1)
    return t1, t2


def load_g(path: Path):
    d = np.load(path)
    mu = d["mu"].astype(np.float64)
    normal = d["normal"].astype(np.float64)
    scale = d["scale"].astype(np.float64)
    color = d["color"].astype(np.float64)
    birth = d["birth"].astype(np.int64)
    t1, t2 = tangent_basis(normal)
    g = H.Gaussians(
        mu=mu, normal=normal, scale=scale,
        quat=H._quat_from_frame(t1.astype(np.float32), t2.astype(np.float32), normal.astype(np.float32)),
        color=color, alpha=None,
        pixel=np.zeros((len(mu), 2), np.int32),
        axis1=t1.astype(np.float32), axis2=t2.astype(np.float32))
    return g, birth


def main() -> None:
    pairs = SF.associate(SF.DATA, max_dt=0.02)[: 11]
    sm = SF.load_rgb(pairs[0].rgb_path)
    h, w = sm.shape[:2]
    m1, m2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)
    bgr0, z0, _ = SF.load_pair(pairs, 0, m1, m2)
    valid = (z0 > Z_MIN) & (z0 < Z_MAX)
    print(f"image {w}x{h}, GT-valid px={valid.sum()}")

    gF, birthF = load_g(FINAL)
    g0, birth0 = load_g(F0)
    print(f"10-frame model N={len(gF)}, frame0-only N={len(g0)}")

    for name, g, birth in [("FINAL10", gF, birthF), ("FRAME0", g0, birth0)]:
        depth, index, _ = H.rasterize_discs(g, K, (h, w))
        hole = ~np.isfinite(depth) & valid
        print(f"\n=== {name} ===  valid-hole={hole.sum()} ({100*hole.sum()/valid.sum():.3f}% of GT-valid)")

        # ---- user-specified region: rows 335-389, cols 560-639 ----
        R0, R1 = 335, 390
        C0 = 560
        reg = hole[R0:R1, C0:]
        print(f"region rows[{R0},{R1}) cols[{C0},{w}): holes={reg.sum()}")
        # per-row rightmost hole column and count
        print("row: count | hole columns in region")
        for r in range(R0, R1):
            cs = np.where(reg[r - R0])[0] + C0
            if cs.size:
                print(f"  {r}: {cs.size:3d} | cols {cs.min()}-{cs.max()}  {cs.tolist()[:20]}")
        # per-column counts (col hist) across region
        ch = reg.sum(axis=0)
        nz = np.nonzero(ch)[0] + C0
        print("col histogram (col:count):")
        for c in nz:
            print(f"  {c}:{ch[c-C0]}", end="")
        print()

        # nearest-disc analysis on holes in region
        yy, xx = np.nonzero(reg)
        hy = yy + R0
        hx = xx + C0
        if hy.size:
            fx, fy, cx, cy = (float(K[0,0]), float(K[1,1]), float(K[0,2]), float(K[1,2]))
            zc = np.maximum(g.mu[:, 2], 1e-6)
            uc = (fx * g.mu[:, 0] / zc + cx).astype(np.float64)
            vc = (fy * g.mu[:, 1] / zc + cy).astype(np.float64)
            iso = np.abs(g.scale[:, 0] - g.scale[:, 1]) < 1e-6 * np.maximum(g.scale[:, 0], 1e-9)
            # footprint major projected radius
            r_maj = np.maximum(g.scale[:, 0], g.scale[:, 1])
            r_px = 0.5 * (fx + fy) * r_maj / zc
            CH = 256
            best_d = np.full(hy.size, np.inf)
            best_i = np.full(hy.size, -1, np.int32)
            for s in range(0, hy.size, CH):
                e = min(s + CH, hy.size)
                du = hx[s:e, None] - uc[None, :]
                dv = hy[s:e, None] - vc[None, :]
                dd = du*du + dv*dv
                bi = dd.argmin(axis=1)
                bd = dd[np.arange(e-s), bi]
                best_d[s:e] = bd
                best_i[s:e] = bi
            best_d = np.sqrt(best_d)
            print(f"\n  region holes n={hy.size}")
            print(f"  nearest-disc centre dist px: min={best_d.min():.1f} med={np.median(best_d):.1f} p90={np.percentile(best_d,90):.1f} max={best_d.max():.1f}")
            print(f"  nearest disc birth hist (0..10): {np.bincount(birth[best_i], minlength=11).tolist()}")
            print(f"  nearest disc S2(iso) frac: {iso[best_i].mean():.3f}")
            # does nearest disc footprint reach the hole?
            reach = r_px[best_i] >= best_d
            print(f"  nearest disc major-radius REACHES hole: {reach.mean():.3f}")
            # among unreachable, how far from centre of its footprint
            notreach = ~reach
            if notreach.any():
                gap = best_d[notreach] - r_px[best_i][notreach]
                print(f"  of those NOT reached: gap(px) med={np.median(gap):.1f} p90={np.percentile(gap,90):.1f} max={gap.max():.1f}")
                print(f"  unreached birth hist: {np.bincount(birth[best_i][notreach], minlength=11).tolist()}")
                print(f"  unreached S2 frac: {iso[best_i][notreach].mean():.3f}")
            # distinct nearest discs
            dids = np.unique(best_i)
            print(f"  distinct nearest discs: {dids.size}; their birth hist: {np.bincount(birth[dids], minlength=11).tolist()}")


if __name__ == "__main__":
    main()