"""Diagnose frame-0 holes in the multi-frame final model vs single-frame baseline.

Isolates three hole sources by rendering the FINAL 10-frame model back into
frame 0 (anchored, T = FL9^-1 since GT0 = identity):

  A. renderer: hard ray-disc  vs  EWA cov_scale=1.0  vs  EWA cov_scale=0.33
  B. aging:    final-model frame-0 coverage vs single-frame build_hybrid coverage
               (single-frame has no aging, so any drop is aged-out discs)

The final model was saved by render_absorb_frames.py into
output_absorb_v2/render/model_final.npz (g fields + FL9).
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

SEQ = Path(__file__).resolve().parent
SINGLE = SEQ.parent.parent / "SINGLE FRAME" / "scripts"
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SINGLE))
sys.path.insert(0, str(SFLOW))

import h_pipeline_final as H  # noqa: E402
from exp_surfel_render import render_ewa  # noqa: E402
from tum_io import (  # noqa: E402
    associate, load_depth, load_rgb, remap_depth, remap_rgb, undistort_maps,
)

DATA = Path("/home/sti/Work/986-SceneFlow/rgbd_dataset_freiburg1_desk")
RENDER_DIR = SEQ.parent / "output_absorb_v2" / "render"


def psnr(render, ref, mask):
    if not mask.any():
        return float("nan")
    err = render[mask] - ref[mask]
    return float(-20.0 * np.log10(max(float(np.sqrt(np.mean(err ** 2))), 1e-12)))


def main() -> None:
    npz = np.load(RENDER_DIR / "model_final.npz", allow_pickle=True)
    ax1 = npz["axis1"] if npz["axis1"].shape else None
    ax2 = npz["axis2"] if npz["axis2"].shape else None
    g = H.Gaussians(
        mu=npz["mu"], normal=npz["normal"], scale=npz["scale"],
        quat=npz["quat"], color=npz["color"], alpha=npz["alpha"],
        pixel=npz["pixel"], axis1=ax1, axis2=ax2,
    )
    FL9 = (npz["FL9"], npz["FL9_t"])
    FL9_inv = (FL9[0].T, -FL9[0].T @ FL9[1])

    pairs = associate(DATA)
    fr = pairs[0]
    sample = load_rgb(fr.rgb_path)
    h, w = sample.shape[:2]
    from tum_io import FR1_INTRINSICS
    map1, map2, K = undistort_maps((h, w), FR1_INTRINSICS)
    bgr = remap_rgb(load_rgb(fr.rgb_path), map1, map2)
    z = remap_depth(load_depth(fr.depth_path), map1, map2)
    z[(z < H.GEO_CFG["z_min"]) | (z > H.GEO_CFG["z_max"])] = 0.0
    rgb_ref = bgr[..., ::-1].astype(np.float32) / 255.0
    normal_ref, eval_mask = H.eval_setup(z, K)

    # --- single-frame baseline (no aging) ---
    g_sf, _, _ = H.build_hybrid(bgr, z, K, 0.6)
    d_sf, idx_sf, _ = H.rasterize_discs(g_sf, K, (h, w))
    hit_sf = np.isfinite(d_sf)
    cov_sf_hard = float(hit_sf.mean())
    cov_sf_eval = float((hit_sf & eval_mask).sum() / eval_mask.sum())
    print(f"[single-frame] N={len(g_sf)} hard_cov={cov_sf_hard:.4f} "
          f"eval_cov={cov_sf_eval:.4f}")

    # --- final model -> frame 0 ---
    gt = H.Gaussians(
        mu=g.mu @ FL9_inv[0].T + FL9_inv[1],
        normal=g.normal @ FL9_inv[0].T,
        scale=g.scale, quat=g.quat, color=g.color, alpha=g.alpha,
        pixel=g.pixel,
        axis1=g.axis1 @ FL9_inv[0].T if g.axis1 is not None else None,
        axis2=g.axis2 @ FL9_inv[0].T if g.axis2 is not None else None,
    )
    print(f"\n[final model -> frame0] N={len(g)}")

    # hard ray-disc
    d, idx, _ = H.rasterize_discs(gt, K, (h, w))
    hit = np.isfinite(d)
    render_hard = np.zeros((h, w, 3), np.float32)
    render_hard[hit] = gt.color[idx[hit]]
    print(f"  hard   cov={float(hit.mean()):.4f} "
          f"eval_cov={float((hit & eval_mask).sum() / eval_mask.sum()):.4f} "
          f"PSNR(eval)={psnr(render_hard, rgb_ref, hit & eval_mask):.2f}")

    # EWA cov_scale 1.0 and 0.33
    for cs in (1.0, 0.33):
        col, dp, wt = render_ewa(gt, K, (h, w), mode="normalized", cov_scale=cs)
        hh = wt > 0
        print(f"  ewa cs={cs:<4} cov={float(hh.mean()):.4f} "
              f"eval_cov={float((hh & eval_mask).sum() / eval_mask.sum()):.4f} "
              f"PSNR(eval)={psnr(col, rgb_ref, hh & eval_mask):.2f}")


if __name__ == "__main__":
    main()