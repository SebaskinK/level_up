"""Diff the frame-0 hard ray render before/after moving absorb ahead of the S2 fill.

  PREV : the K6 default as of 2026-09-19 (leftover order = S2 -> absorb -> curvature)
  NEW  : absorb-first (old discs first, then S2, then absorb into this frame's S2)

Panels: PREV render | NEW render | their absolute diff (JET), plus a 2x zoom of the
left band (x < 192) where the mottle lives. The caption reports a mottle proxy
(mean high-frequency energy = mean|I - blur2(I)| over the left band) and the
left-band colour error against the frame-0 image, for GT / PREV / NEW.

Run:  python scripts/cmp_absorb_first_f0.py
"""

from __future__ import annotations

import argparse
from pathlib import Path

import cv2
import numpy as np

SEQ = Path(__file__).resolve().parent
ROOT = SEQ.parent
PREV_DIR = ROOT / "output_f0_80frame_relinkorder"
NEW_DIR = ROOT / "output_f0_80frame_absorb_first"
BAR = 36            # caption strip render_f0_images.py adds under each render
XZ = 192            # left band the mottle shows up in
ZOOM = 2


def strip(p: Path) -> np.ndarray:
    im = cv2.imread(str(p))
    if im is None:
        raise FileNotFoundError(p)
    return im[:-BAR] if im.shape[0] > BAR else im


def band(img: np.ndarray, x0: int = 0, x1: int = XZ) -> np.ndarray:
    return img[:, x0:x1]


def hf_energy(img: np.ndarray, x1: int = XZ, sigma: float = 2.0) -> float:
    """Mean |I - blurred| over the left band: the mottle/high-frequency proxy."""
    b = band(img, 0, x1).astype(np.float32)
    bl = cv2.GaussianBlur(b, (0, 0), sigma)
    return float(np.abs(b - bl).mean())


def col_err(img: np.ndarray, gt: np.ndarray, x1: int = XZ) -> float:
    a = band(img.astype(np.float32), 0, x1) / 255.0
    g = band(gt.astype(np.float32), 0, x1) / 255.0
    return float(np.linalg.norm(a - g, axis=2).mean())


def err_hf(img: np.ndarray, gt: np.ndarray, x1: int = XZ) -> float:
    """Mottle proxy: how HIGH-FREQUENCY the error field is. A smooth colour drift
    gives a smooth error (low value); speckle/mottle gives a noisy error."""
    e = band(np.linalg.norm(img.astype(np.float32) / 255.0
                            - gt.astype(np.float32) / 255.0, axis=2), 0, x1)
    return float(np.abs(e - cv2.GaussianBlur(e, (0, 0), 2.0)).mean())


def title_band(w: int, colour, text: str, h: int = 26) -> np.ndarray:
    b = np.full((h, w, 3), 20, np.uint8)
    cv2.rectangle(b, (6, 5), (20, h - 6), colour, -1)
    cv2.putText(b, text, (28, h - 8), cv2.FONT_HERSHEY_SIMPLEX, 0.46,
                (235, 235, 235), 1, cv2.LINE_AA)
    return b


def caption_bar(img: np.ndarray, lines: list[tuple[str | None, str]],
                size: int = 18) -> np.ndarray:
    PAL = {"green": (60, 200, 60), "yellow": (0, 200, 255), "blue": (60, 60, 255),
           "magenta": (200, 0, 200), "orange": (0, 140, 255), "gray": (110, 110, 110)}
    sw, pad, txt_x = 14, 8, 34
    h_bar = size * len(lines) + 14
    bar = np.full((h_bar, img.shape[1], 3), 20, np.uint8)
    for i, (swatch, text) in enumerate(lines):
        y = 16 + size * i
        if swatch is not None:
            cv2.rectangle(bar, (pad, y - 12), (pad + sw, y), PAL[swatch], -1)
        cv2.putText(bar, text, (txt_x if swatch else pad, y),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.42, (230, 230, 230), 1, cv2.LINE_AA)
    return np.vstack([img, bar])


def main() -> None:
    global PREV_DIR, NEW_DIR
    ap = argparse.ArgumentParser()
    ap.add_argument("--prev", default=PREV_DIR.name)
    ap.add_argument("--new", default=NEW_DIR.name)
    ap.add_argument("--prev-lbl", default="PREV: S2 -> absorb  (K6 default)")
    ap.add_argument("--new-lbl", default="NEW: absorb -> S2 -> absorb")
    ap.add_argument("--note", default="NEW: leftover order absorb(old, footprint) -> S2 "
                                     "-> absorb(this frame's S2). Kills the duplicate "
                                     "overdraw where an old disc ALREADY rasterises the "
                                     "pixel, without creating holes.")
    args = ap.parse_args()
    PREV_DIR = ROOT / args.prev
    NEW_DIR = ROOT / args.new

    prev = strip(PREV_DIR / "f0_hard.png")
    new = strip(NEW_DIR / "f0_hard.png")
    gt = cv2.imread(str(NEW_DIR / "f0_gt.png"))

    d = np.abs(prev.astype(np.int16) - new.astype(np.int16)).max(axis=2).astype(np.uint8)
    heat = cv2.applyColorMap(d, cv2.COLORMAP_JET)
    heat[d < 8] = (18, 18, 18)

    h, w = prev.shape[:2]
    sep = np.full((h, 3, 3), 255, np.uint8)
    top = np.vstack([
        np.hstack([title_band(w, (0, 200, 255), args.prev_lbl),
                   title_band(3, (20, 20, 20), ""),
                   title_band(w, (60, 200, 60), args.new_lbl),
                   title_band(3, (20, 20, 20), ""),
                   title_band(w, (60, 60, 255), "|PREV - NEW| (JET, <8 hidden)")]),
        np.hstack([prev, sep, new, sep, heat]),
    ])
    zp = cv2.resize(band(prev), None, fx=ZOOM, fy=ZOOM, interpolation=cv2.INTER_NEAREST)
    zn = cv2.resize(band(new), None, fx=ZOOM, fy=ZOOM, interpolation=cv2.INTER_NEAREST)
    zh = cv2.resize(band(heat), None, fx=ZOOM, fy=ZOOM, interpolation=cv2.INTER_NEAREST)
    zh[cv2.resize(band(d), None, fx=ZOOM, fy=ZOOM, interpolation=cv2.INTER_NEAREST) < 8] = (18, 18, 18)
    zw = zp.shape[1]
    vsep = np.full((zp.shape[0], 3, 3), 255, np.uint8)
    zoombar = np.full((26, zp.shape[1] * 3 + 6, 3), 20, np.uint8)
    cv2.putText(zoombar, f"ZOOM x{ZOOM} on left band x<{XZ}: PREV | NEW | diff",
                (8, 18), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (235, 235, 235), 1, cv2.LINE_AA)
    bottom = np.vstack([zoombar, np.hstack([zp, vsep, zn, vsep, zh])])

    # pad the two rows to the same width before stacking
    if top.shape[1] < bottom.shape[1]:
        pad = bottom.shape[1] - top.shape[1]
        top = np.hstack([top, np.full((top.shape[0], pad, 3), 18, np.uint8)])
    elif bottom.shape[1] < top.shape[1]:
        pad = top.shape[1] - bottom.shape[1]
        bottom = np.hstack([bottom, np.full((bottom.shape[0], pad, 3), 18, np.uint8)])

    body = np.vstack([top, bottom])
    dp, dn = int((d > 10).sum()), int((d > 30).sum())
    hp, hn, hg = hf_energy(prev), hf_energy(new), hf_energy(gt)
    cp, cn = col_err(prev, gt), col_err(new, gt)
    ep, en = err_hf(prev, gt), err_hf(new, gt)
    holes_p = 1.0 - float((np.load(PREV_DIR / "f0_depth_hard.npy") > 0).mean())
    holes_n = 1.0 - float((np.load(NEW_DIR / "f0_depth_hard.npy") > 0).mean())
    cap = [
        (None, f"frame-0 HARD RAY, 80-frame model | left band x<{XZ}:  "
               f"MOTTLE proxy (high-freq energy of the error field) "
               f"PREV {ep:.4f} -> NEW {en:.4f}   "
               f"| mean colour err vs f0 image PREV {cp:.4f} -> NEW {cn:.4f}   "
               f"| holes PREV {100*holes_p:.2f}% -> NEW {100*holes_n:.2f}%"),
        (None, f"PREV vs NEW pixel diff: >10 = {dp} px, >30 = {dn} px "
               f"({100*dp/(h*w):.2f}% / {100*dn/(h*w):.2f}% of the frame).  "
               f"GT high-freq energy for reference: {hg:.2f} (PREV {hp:.2f}, NEW {hn:.2f})."),
        ("green", args.note),
    ]
    out = caption_bar(body, cap)
    dst = NEW_DIR / "cmp_absorb_first_f0.png"
    cv2.imwrite(str(dst), out)
    print(f"saved -> {dst}  {out.shape}")
    print(f"mottle_hf PREV={ep:.4f} NEW={en:.4f} | colerr PREV={cp:.4f} NEW={cn:.4f} "
          f"| holes PREV={holes_p:.4f} NEW={holes_n:.4f}")
    print(f"diff>10={dp} diff>30={dn}")

    three = np.vstack([
        title_band(w, (0, 200, 255), "GT (frame-0 image)"),
        gt,
        title_band(w, (0, 200, 255), args.prev_lbl),
        prev,
        title_band(w, (60, 200, 60), args.new_lbl),
        new,
    ])
    dst2 = NEW_DIR / "f0_hard_prev_vs_new_f0.png"
    cv2.imwrite(str(dst2), caption_bar(three, cap[1:2] + [("green", cap[2][1])]))
    print(f"saved -> {dst2}")

    four = [("f0_ellipse.png", "ELLIPSE"), ("f0_hard.png", "HARD RAY"),
            ("f0_ewa.png", "EWA"), ("f0_depth_hard.png", "BACKPROJ DEPTH")]
    ims = [caption_bar(strip((NEW_DIR / fn)), [("green", f"{lbl}  |  {args.new_lbl}  |  "
                                                f"81-frame model -> frame-0")])
           for fn, lbl in four]
    dst3 = NEW_DIR / "f0_four_panel.png"
    cv2.imwrite(str(dst3), np.vstack([np.hstack(ims[:2]), np.hstack(ims[2:])]))
    print(f"saved -> {dst3}")


if __name__ == "__main__":
    main()