"""Compare newly-born discs (birth>0) against their nearest old disc (birth==0).

Answers "which attributes differ a lot between a stacked new disc and the old
disc it should have re-linked to": 3D distance, signed depth offset, point-to-plane
residual (the depth gate), normal angle, and colour distance. All in frame-0
camera coordinates from model_f0.npz, so nothing depends on the fusion run.

Usage:
    python diag_new_vs_old_attrs.py <output_dir> [--left-u 80]
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
from scipy.spatial import cKDTree

K_SIGMA = 3.0
FX, FY, CX, CY = 517.306408, 516.469215, 318.643040, 255.313989


def depth_sigma(z: np.ndarray, sigma_ref: float = 0.0031, z_ref: float = 0.75):
    return sigma_ref * (np.maximum(z, 0.3) / z_ref) ** 1.33


def pct(a, p):
    return np.percentile(a, p) if a.size else float("nan")


def main() -> None:
    out = Path(sys.argv[1])
    left_u = float(sys.argv[sys.argv.index("--left-u") + 1]) if "--left-u" in sys.argv else 80.0

    d = np.load(out / "model_f0.npz")
    mu = d["mu"].astype(np.float64)
    normal = d["normal"].astype(np.float64)
    color = d["color"].astype(np.float64)
    birth = d["birth"].astype(np.int32)

    n = normal / np.maximum(np.linalg.norm(normal, axis=1, keepdims=True), 1e-12)
    zc = mu[:, 2]
    u = FX * mu[:, 0] / np.maximum(zc, 1e-6) + CX
    v = FY * mu[:, 1] / np.maximum(zc, 1e-6) + CY

    old = birth == 0
    new = birth > 0
    print(f"N={len(mu)}  old(birth0)={int(old.sum())}  new={int(new.sum())}")
    print(f"new birth hist (10-frame bins): "
          f"{np.bincount(np.clip(birth[new] // 10, 0, 9), minlength=10).tolist()}")

    # left-edge new discs (projected centre is left of `left_u`)
    left_new = new & (u < left_u)
    print(f"left-edge new (u<{left_u:g}): n={int(left_new.sum())}  "
          f"birth hist={np.bincount(np.clip(birth[left_new] // 10, 0, 9), minlength=10).tolist()}")

    tree = cKDTree(mu[old])
    old_idx = np.flatnonzero(old)
    d3, j = tree.query(mu[left_new], k=1)
    mu_o = mu[old][j]
    n_o = n[old][j]
    c_o = color[old][j]
    mu_n = mu[left_new]
    n_n = n[left_new]
    c_n = color[left_new]

    dz = mu_n[:, 2] - mu_o[:, 2]                     # signed depth (camera z)
    plane = np.abs(np.einsum("ij,ij->i", mu_n - mu_o, n_o))   # point-to-plane residual
    dot = np.abs(np.einsum("ij,ij->i", n_n, n_o))
    dot = np.clip(dot, 0.0, 1.0)
    ang = np.degrees(np.arccos(dot))                 # normal angle
    dcol = np.linalg.norm(c_n - c_o, axis=1)         # RGB distance in [0,1]

    # gate budget at the observed (old) depth
    gate = K_SIGMA * depth_sigma(mu_o[:, 2])
    plane_pass = plane < gate

    def rep(tag, a):
        print(f"  {tag:22s} med={np.median(a):.5f}  p50={pct(a,50):.5f} "
              f"p75={pct(a,75):.5f} p90={pct(a,90):.5f} max={a.max():.5f}")

    print("\nleft-edge new disc vs NEAREST old disc (birth0), n=%d:" % int(left_new.sum()))
    rep("3D dist |mu_n-mu_o| (m)", d3)
    rep("signed depth dz (m)", dz)
    rep("point-plane residual (m)", plane)
    rep("normal angle (deg)", ang)
    rep("colour dist ||c_n-c_o||", dcol)

    print(f"\npoint-plane gate budget K*sigma(z): median={np.median(gate):.5f} m")
    print(f"new discs that WOULD pass point-plane gate vs nearest old: "
          f"{int(plane_pass.sum())}/{int(left_new.sum())} ({100*plane_pass.mean():.1f}%)")

    # colour gate budget: use the fixed texture floor as the reference scale
    from h_pipeline_final import TEX_VAR_THR  # noqa: E402
    col_floor = np.sqrt(TEX_VAR_THR)
    print(f"colour gate floor sqrt(TEX_VAR_THR)={col_floor:.5f}; "
          f"dcol < floor: {int((dcol < col_floor).sum())}/{int(left_new.sum())} "
          f"({100*(dcol < col_floor).mean():.1f}%)")

    # how many new discs are essentially ON an old surface (stacking) vs genuinely new
    # "on surface" = plane residual within one gate budget AND normal within ~30deg
    on_surface = plane_pass & (ang < 30.0)
    print(f"'stacking' (plane passes AND normal<30deg): "
          f"{int(on_surface.sum())}/{int(left_new.sum())} ({100*on_surface.mean():.1f}%)")

    # Cleaner split: OVERLAP (3D distance to nearest old < 5 cm) vs ISOLATED.
    ov = d3 < 0.05
    print(f"\nOVERLAP (3D dist to nearest old < 5cm): {int(ov.sum())}/{int(left_new.sum())} "
          f"({100*ov.mean():.1f}%)  -- these are the true revisit/stacking candidates")
    for tag, a in [("  3D dist (m)", d3[ov]), ("  point-plane (m)", plane[ov]),
                   ("  normal angle (deg)", ang[ov]), ("  colour dist", dcol[ov])]:
        if a.size:
            print(f"    {tag:18s} med={np.median(a):.5f} p75={pct(a,75):.5f} p90={pct(a,90):.5f}")
    if ov.any():
        print(f"    of OVERLAP: plane passes={int(plane_pass[ov].sum())}/{int(ov.sum())} "
              f"({100*plane_pass[ov].mean():.1f}%),  "
              f"normal<30deg={int((ang[ov] < 30).sum())}/{int(ov.sum())} "
              f"({100*(ang[ov] < 30).mean():.1f}%),  "
              f"colour<floor={int((dcol[ov] < col_floor).sum())}/{int(ov.sum())} "
              f"({100*(dcol[ov] < col_floor).mean():.1f}%)")


if __name__ == "__main__":
    main()