"""Backproject frame-0 build_hybrid disc ellipse boundaries onto frame 0.

Draws every disc of the hybrid model: curvature discs (anisotropic, principal
axes) in RED, S2 stride-2 discs (isotropic circles) in GREEN, on a dimmed RGB
background. Uses the FULL model returned by build_hybrid (g.axis1/g.axis2 carry
the in-plane axes for both families).
"""

from __future__ import annotations

import sys
from pathlib import Path

import cv2
import numpy as np

SEQ = Path(__file__).resolve().parent
sys.path.insert(0, str(SEQ))

import h_pipeline_final as H  # noqa: E402

DATA = Path("/home/sti/Work/986-SceneFlow/rgbd_dataset_freiburg1_desk")
OUT = SEQ.parent / "output_f0_ellipse_all"
OUT.mkdir(parents=True, exist_ok=True)

N_PTS = 48
TH = np.linspace(0.0, 2.0 * np.pi, N_PTS, endpoint=False)


def main() -> None:
    pairs = H.associate(DATA)
    fr = pairs[0]
    sample = H.load_rgb(fr.rgb_path)
    h, w = sample.shape[:2]
    map1, map2, K = H.undistort_maps((h, w), H.FR1_INTRINSICS)
    bgr = H.remap_rgb(H.load_rgb(fr.rgb_path), map1, map2)
    z = H.remap_depth(H.load_depth(fr.depth_path), map1, map2)
    z[(z < H.GEO_CFG["z_min"]) | (z > H.GEO_CFG["z_max"])] = 0.0

    g, keep_geo, tex_mask = H.build_hybrid(bgr, z, K, 0.6)

    # Classify source pixel -> disc family via the texture mask.
    py = g.pixel[:, 1]
    px = g.pixel[:, 0]
    is_s2 = tex_mask[py, px]
    n_curv = int((~is_s2).sum())
    n_s2 = int(is_s2.sum())
    print(f"N={len(g)} curv={n_curv} s2={n_s2}")

    fx, fy, cx, cy = (float(K[0, 0]), float(K[1, 1]), float(K[0, 2]), float(K[1, 2]))

    mu = g.mu.astype(np.float64)
    r1 = g.scale[:, 0].astype(np.float64)
    r2 = g.scale[:, 1].astype(np.float64)
    if g.axis1 is not None and g.axis2 is not None:
        a1 = g.axis1.astype(np.float64)
        a2 = g.axis2.astype(np.float64)
    else:
        from render_f0_ellipse import tangent_basis  # noqa: E402  (fallback)
        a1, a2 = tangent_basis(g.normal)

    cs = np.cos(TH)[:, None]
    sn = np.sin(TH)[:, None]
    p = (mu[None, :, :]
         + (r1 * cs)[:, :, None] * a1[None, :, :]
         + (r2 * sn)[:, :, None] * a2[None, :, :])          # (N_PTS, N, 3)
    zc = np.maximum(p[..., 2], 1e-6)
    u = np.rint(fx * p[..., 0] / zc + cx).astype(np.int32)   # (N_PTS, N)
    v = np.rint(fy * p[..., 1] / zc + cy).astype(np.int32)

    vis = (bgr.astype(np.float32) * 0.55).astype(np.uint8).copy()
    pts = np.stack([u, v], axis=-1).transpose(1, 0, 2)       # (N, N_PTS, 2)
    pts = np.ascontiguousarray(pts)
    for i in range(len(g)):
        cv2.polylines(vis, [pts[i]], True, (0, 0, 255) if not is_s2[i] else (0, 200, 0),
                      1, cv2.LINE_8)

    bar = np.full((44, w, 3), 25, np.uint8)
    cv2.putText(
        bar,
        f"frame0 build_hybrid disc ellipses: N={len(g)}  curv(red)={n_curv}  s2(green)={n_s2}",
        (8, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (225, 225, 225), 1, cv2.LINE_AA,
    )
    out_img = np.vstack([vis, bar])
    out_path = OUT / "frame0_ellipse_all.png"
    cv2.imwrite(str(out_path), out_img)
    print(f"saved -> {out_path}")


if __name__ == "__main__":
    main()