"""Check whether the curvature discs that front frame-0's LEFT region were really
born on non-textured pixels, or are textured pixels misclassified as curvature.

The user's observation: frame-0's left side is texture-RICH, so it "should not"
produce any curvature discs -- yet curvature discs exist there even after
TEX_VAR_THR was pushed down to 4e-4. We test two hypotheses directly:

  * were the seed pixels actually textured (var >= TEX_VAR_THR) at the BIRTH
    frame, i.e. misclassified? 
  * is their 9x9 texture window diluted by void (FOV black border), which is the
    known leak: pixels near the FOV edge get their variance contaminated by
    black, dropping it below threshold -> classified non-textured -> curvature.

Uses the same 80-frame fusion; records per-disc (source, birth, seed pixel),
rasterizes the final model onto frame 0, then for the LEFT-fronting curvature
discs reports their birth-frame texture variance + void-adjacency.
"""

from __future__ import annotations

import time
from pathlib import Path

import cv2
import numpy as np

import h_pipeline_final as H
import sequential_fusion_flowonly as SF


def pm_compose(a, b):
    Ra, ta = a
    Rb, tb = b
    return Rb @ Ra, Rb @ ta + tb


def pm_inv(a):
    R, t = a
    return R.T, -R.T @ t


def concat(lst):
    return np.concatenate(lst, axis=0)


def main() -> None:
    OUT = SF.SEQ.parent / "output_curv_left_texcheck"
    OUT.mkdir(parents=True, exist_ok=True)

    NPAIR = 81
    AGE_MAX = 1000000
    W_MIN = 0.0

    pairs = SF.associate(SF.DATA, max_dt=0.02)[:NPAIR]
    sample = SF.load_rgb(pairs[0].rgb_path)
    h, w = sample.shape[:2]
    map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)

    print("building frame-0 model ...", flush=True)
    bgr0, z0, _ = SF.load_pair(pairs, 0, map1, map2)
    g0, _, _, owner0 = H.build_hybrid_with_owner(bgr0, z0, K, SF.TEX_Q)
    n_init = len(g0)
    print(f"n_init={n_init}  TEX_VAR_THR={H.TEX_VAR_THR:g}", flush=True)

    src_l = [np.full(n_init, -1, dtype=np.int8)]
    bir_l = [np.zeros(n_init, dtype=np.int32)]
    px_l = [np.asarray(g0.pixel).astype(np.int32)]

    model = SF.Model(
        g=g0,
        w=np.ones(n_init, dtype=np.float32),
        age=np.zeros(n_init, dtype=np.int32),
        owner=owner0,
        birth=np.zeros(n_init, dtype=np.int32),
    )
    FL = [None] * NPAIR
    FL[0] = (np.eye(3), np.zeros(3))
    prev_FL = FL[0]
    prev_sf, prev_dt = None, 1.0
    bgr_a, z_a = bgr0, z0

    t0 = time.perf_counter()
    for i in range(NPAIR - 1):
        bgr_b, z_b, _ = SF.load_pair(pairs, i + 1, map1, map2)
        dt = pairs[i + 1].t_rgb - pairs[i].t_rgb
        sf = SF.compute_scene_flow(bgr_a, bgr_b, z_a, z_b, K,
                                   prev=prev_sf, dt=dt, prev_dt=prev_dt)
        R_10, t_10 = SF.se3_exp(sf.xi)
        FL[i + 1] = pm_compose(prev_FL, (R_10, t_10))

        n_before = len(model.g)
        rec = SF.fuse_frame(model, sf, z_a, z_b, bgr_b, K,
                            age_max=AGE_MAX, w_min=W_MIN, frame_idx=i,
                            R_10=R_10, t_10=t_10)
        if rec["n_new"]:
            sl = slice(n_before, len(model.g))
            src_l.append(np.concatenate([
                np.zeros(rec["n_s2"], dtype=np.int8),
                np.ones(rec["n_curv"], dtype=np.int8),
            ]))
            bir_l.append(np.full(rec["n_new"], i, dtype=np.int32))
            px_l.append(np.asarray(model.g.pixel[sl]).astype(np.int32))
        if (i + 1) % 20 == 0:
            print(f"[{i+1:03d}] N={len(model.g)} cum={time.perf_counter()-t0:.1f}s", flush=True)
        bgr_a, z_a = bgr_b, z_b
        prev_sf, prev_dt = sf, dt
        prev_FL = FL[i + 1]

    g = model.g
    print(f"final N={len(g)}  -> frame 0 ...", flush=True)
    g0f = SF.transform_to_next(g, *pm_inv(FL[NPAIR - 1]))

    source = concat(src_l)
    birth = concat(bir_l)
    pixel = concat(px_l)
    assert len(source) == len(birth) == len(pixel) == len(g)

    print("rasterizing 80-frame model onto frame 0 ...", flush=True)
    depth80, index80, _ = H.rasterize_discs(g0f, K, (h, w))
    hit = np.isfinite(depth80)
    np.save(OUT / "index80.npy", index80.astype(np.int64))

    # cache texture variance + valid mask per birth RGB frame (frame i+1)
    tex_cache = {}
    valid_cache = {}
    def get_tex(i):
        if i not in tex_cache:
            bgr, z, _ = SF.load_pair(pairs, i + 1, map1, map2)
            rgb = bgr[..., ::-1].astype(np.float32) / 255.0
            tex_cache[i] = H.texture_variance(rgb, win=9)
            valid_cache[i] = (np.isfinite(z) & (z > 0)).astype(np.uint8)
        return tex_cache[i], valid_cache[i]

    for L in (64, 128, 200, 320):
        left = np.zeros((h, w), bool)
        left[:, :L] = True
        sel = left & hit
        idx = index80[sel]
        curv = source[idx] == 1
        cidx = np.unique(idx[curv])          # left-fronting curvature disc global indices

        var_at_birth = np.zeros(len(cidx), dtype=np.float64)
        seed_in_void = np.zeros(len(cidx), dtype=bool)
        win_has_void = np.zeros(len(cidx), dtype=bool)
        bfr = birth[cidx]
        for k, gi in enumerate(cidx):
            u, v = int(pixel[gi, 0]), int(pixel[gi, 1])
            var_map, valid = get_tex(bfr[k])
            var_at_birth[k] = var_map[v, u]
            r0, r1 = max(0, v - 4), min(h, v + 5)
            c0, c1 = max(0, u - 4), min(w, u + 5)
            wnd = valid[r0:r1, c0:c1]
            win_has_void[k] = wnd.sum() < wnd.size
            seed_in_void[k] = valid[v, u] == 0

        textured = var_at_birth >= H.TEX_VAR_THR
        loose = var_at_birth >= 1e-4
        print("=" * 72)
        print(f"left x<{L}: pixels fronted by curvature = {int(curv.sum())}px, "
              f"unique curvature discs = {len(cidx)}")
        print(f"  seed NOT in void (valid depth)      : {int((~seed_in_void).sum())}/{len(cidx)}")
        print(f"  seed 9x9 window contains void        : {int(win_has_void.sum())}/{len(cidx)}")
        print(f"  var@birth >= TEX_VAR_THR (textured)  : {int(textured.sum())}/{len(cidx)}")
        print(f"  var@birth >= 1e-4 (loose)            : {int(loose.sum())}/{len(cidx)}")
        print(f"  var@birth median = {float(np.median(var_at_birth)):.2e}  "
              f"mean = {float(var_at_birth.mean()):.2e}")
        # textured & void-window overlap
        both = textured & win_has_void
        print(f"  textured AND window-has-void         : {int(both.sum())}/{len(cidx)}")
        if len(cidx):
            q = np.percentile(var_at_birth, [10, 25, 50, 75, 90])
            print(f"  var@birth percentile [10,25,50,75,90] = {np.array2string(q, precision=4)}")
            # birth histogram of textured discs
            if textured.any():
                hh, ee = np.histogram(bfr[textured], bins=np.arange(0, 81, 10))
                print("  birth hist of TEXTURED left-curv discs:")
                for kk in range(len(hh)):
                    if hh[kk]:
                        print(f"    {int(ee[kk]):3d}-{int(ee[kk+1]-1):3d}: {hh[kk]}")
    print("done", flush=True)


if __name__ == "__main__":
    main()