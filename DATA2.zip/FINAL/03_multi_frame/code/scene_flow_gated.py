"""Adopted flow variant: the same two geometric channels on BOTH correspondence routes.

Additive and flow-only: the finalized 986 scripts (`scene_flow.py`,
`expand_rigid_inliers.py`, `variational_flow.py`) are imported read-only as a library
and are never modified. Everything below lives in this file.

What the finalized pipeline does
--------------------------------
The seed set (photometric DIS route, ~80% of the correspondences) is gated only by
the 1.5 px forward-backward round trip plus the depth range -- no geometric test at
all. The expansion route has three: point-plane < 3 sigma(z), along-depth < 12
sigma(z), plus an existence pre-filter on the normal.

The adopted changes
-------------------
3. **Smoothed normals.** The finalized expansion derives its normal from raw 1-pixel
   central differences on disparity-quantized TUM depth (dz ~ 0.0029 z^2), a
   staircase that wrecks the normal. This file uses the pipeline's own
   `compute_scene_geometry` normals (Gaussian-prefiltered, hole-aware).
   Cost: none (expansion coverage 15.029% -> 15.065%).

   **Along-depth aligned to 3 sigma.** The finalized bound is 4 x 3 = 12 sigma(z),
   4x looser than the point-plane bound and measuring the *same* quantity on a
   camera-facing surface, so it never binds there. Aligned to 3 sigma(z) the three
   geometric bounds form one isotropic 3-sigma displacement box. Cost: 0.08pp of
   expansion coverage; benefit: the expansion route's occlusion violations -74%.
   (`HISTORICAL_AXIS_MULT = 4.0` is the finalized value.)

2. **Normal-agreement gate on both routes.** The angle between the frame-n source
   normal (carried by the camera rotation) and the frame-(n+1) destination normal
   must be below a curvature-dependent tolerance. A tangential slide on a flat patch
   changes neither the normal nor the sagitta, so the finalized gates are blind to
   it exactly where it matters (the cup's side): the angle is the sensitive channel.
   Falling out of this work: the threshold must be parameterised by the *physical*
   slide it tolerates.

1. **Along-depth (visibility) channel on the seed route.** Same criterion as the
   expansion's, with the seed's consumed photometric endpoint as the destination.
   This is the channel that catches occlusion-spanning matches, and the seed route
   is where they live: it removes ~75% of the remaining occlusion violations.

Thresholds
----------
    theta(kc)  =  max(flat_end, normal_floor(kc) + 57.2958 * kc * slide_tol)

`normal_floor(kc)` is the measured single-frame floor of the cross-frame angle
(median over seed pixels, per curvature band, from `diag_normal_floor.py`); it is a
population median, so it is ADDED, not used as a max -- a threshold *at* the floor
would reject half the population by construction. The geometric term follows from
Rodrigues: an arc slide ds on a surface of curvature kc turns the normal by
kc*ds radians (z and f cancel), so the tolerance is expressed as a physical length,
which does not hold for a "scale x floor" rule (that one implies 19 mm of slide on
flat geometry and 0.3 mm on a cup).

Usage (statistics only; nothing is written into the model):

    python scene_flow_gated.py --stats --frames 81 --out output_flow_gated
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
import time
from dataclasses import replace
from pathlib import Path

import numpy as np

SEQ = Path(__file__).resolve().parent
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
for _p in (SEQ, SFLOW):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

import h_pipeline_final as H  # noqa: E402
import scene_flow as SC  # noqa: E402
from expand_rigid_inliers import expand_rigid_inliers  # noqa: E402
from rigid_motion import depth_sigma  # noqa: E402
from se3 import apply_point_motion, se3_exp  # noqa: E402

# --- adopted thresholds -----------------------------------------------------
K_SIGMA = 3.0                      # point-plane and along-depth bound, in sigma(z)
AXIS_MULT = 1.0                    # along-depth = AXIS_MULT * K_SIGMA sigma(z)
HISTORICAL_AXIS_MULT = 4.0         # the finalized value (12 sigma); not used
SLIDE_TOL_MM = 10.0                # ~3 sigma(z) at 0.8 m: the tangential slide the
                                   # angle gate tolerates, same box as the depth gates
NOISE_FLOOR_DEG = 16.0             # flat end: 2x the CANDIDATE population's
                                   # flat-band median angle (~7 deg)
DEG_PER_KC_M = 57.29577951308232   # (180/pi); angle_deg = this * kc * slide_m
SEED_GATE_ENABLED = True
SEED_DEPTH_GATE_ENABLED = True     # the along-depth channel on the seed route

# Measured single-frame floor of the cross-frame normal angle (median, deg, over
# seed pixels), per band of kc = max(|k1|,|k2|) in 1/m, from diag_normal_floor.py:
#   kc ~ 0.25 -> 4.84   1.0 -> 4.10   4.5 -> 5.09   22.4 -> 7.22   158 -> 11.57
NORMAL_FLOOR_ANCHORS = ((0.25, 4.84), (1.0, 4.10), (4.5, 5.09), (22.4, 7.22),
                        (158.0, 11.57))
KC_BANDS = ((0.0, 0.5), (0.5, 2.0), (2.0, 10.0), (10.0, 50.0), (50.0, 1e9))


def _grid(h: int, w: int) -> tuple[np.ndarray, np.ndarray]:
    return np.meshgrid(np.arange(w, dtype=np.float32),
                       np.arange(h, dtype=np.float32))


def scene_geometry(z: np.ndarray, K: np.ndarray):
    """The pipeline's shared per-pixel geometry (smoothed normal + curvature)."""
    return H.compute_scene_geometry(
        z, K, H.GEO_CFG["eps"], H.GEO_CFG["gauss_sigma"], H.GEO_CFG["disc_rel"],
    )


def kc_of(geo) -> np.ndarray:
    """max(|k1|,|k2|) of a CurvatureGeometry. Where the curvature fit is invalid the
    loosest (high-curvature) end of the table is used, so an undefined patch is never
    over-rejected."""
    kc = np.maximum(np.abs(geo.k1), np.abs(geo.k2)).astype(np.float32)
    return np.where(geo.c_ok, kc, NORMAL_FLOOR_ANCHORS[-1][0])


def normal_floor_deg(kc: np.ndarray) -> np.ndarray:
    """Interpolated single-frame floor of the cross-frame normal angle, in degrees."""
    xp = np.log10(np.array([a for a, _ in NORMAL_FLOOR_ANCHORS], dtype=np.float64))
    fp = np.array([f for _, f in NORMAL_FLOOR_ANCHORS], dtype=np.float64)
    kk = np.maximum(np.asarray(kc, dtype=np.float64), 1e-3)
    return np.interp(np.log10(kk), xp, fp).astype(np.float32)


def angle_threshold_deg(kc: np.ndarray, slide_tol_m: float,
                        flat_end_deg: float = NOISE_FLOOR_DEG) -> np.ndarray:
    """max(flat end, floor(kc) + geometric slide tolerance), in degrees."""
    geo = DEG_PER_KC_M * np.maximum(np.asarray(kc, dtype=np.float32), 0.0) * float(slide_tol_m)
    return np.maximum(normal_floor_deg(kc) + geo, np.float32(flat_end_deg))


def angle_threshold_map(kc0: np.ndarray | None, h: int, w: int,
                        slide_tol_m: float, flat_end_deg: float) -> np.ndarray:
    if kc0 is None:
        return np.full((h, w), np.float32(flat_end_deg))
    return angle_threshold_deg(kc0, slide_tol_m, flat_end_deg)


def gate_seeds(sf: SC.SceneFlow, z0: np.ndarray, z1: np.ndarray, K: np.ndarray,
               n0: np.ndarray, n_ok0: np.ndarray,
               n1: np.ndarray, n_ok1: np.ndarray, *,
               kc0: np.ndarray | None = None,
               slide_tol_m: float = SLIDE_TOL_MM * 1e-3,
               flat_end_deg: float = NOISE_FLOOR_DEG,
               k_sigma: float = K_SIGMA, axis_mult: float = AXIS_MULT,
               use_depth: bool = SEED_DEPTH_GATE_ENABLED,
               collect: bool = False):
    """The expansion's two geometric channels, applied to the seed set.

    The seed's destination is the CONSUMED photometric endpoint (not the rigid
    projection), so the tests ask "did the photometric match land on a differently
    oriented patch" (normal-agreement channel) and "did it land on a surface at a
    different depth" (along-depth / visibility channel).

    A rejected seed is not deleted from the world: it simply leaves `valid`, so the
    expansion (whose candidates are `~valid`) may re-add the pixel with the rigid
    model's correspondence. The gates therefore act as a switch from the photometric
    match to the rigid one. Pixels whose normals cannot be measured are kept by the
    angle channel; the depth channel needs no normal.
    """
    h, w = z0.shape
    info = {"n_seed_in": int(sf.valid.sum()), "n_seed_out": int(sf.valid.sum()),
            "n_seed_rejected": 0, "n_seed_rejected_angle": 0,
            "n_seed_rejected_depth": 0, "n_seed_rejected_both": 0,
            "n_seed_untested": 0, "depth_channel": bool(use_depth)}
    if sf.xi is None or not sf.valid.any():
        return sf, info

    thr = np.deg2rad(angle_threshold_map(kc0, h, w, slide_tol_m, flat_end_deg))
    R, t = se3_exp(sf.xi)
    n0r = np.einsum("ij,hwj->hwi", R, n0)
    ys, xs = np.where(sf.valid)
    x1 = np.clip(np.rint(xs + sf.u[ys, xs]).astype(np.int32), 0, w - 1)
    y1 = np.clip(np.rint(ys + sf.v[ys, xs]).astype(np.int32), 0, h - 1)

    testable = n_ok0[ys, xs] & n_ok1[y1, x1]
    cosv = np.abs(np.sum(n0r[ys, xs] * n1[y1, x1], axis=-1))
    ang = np.arccos(np.clip(cosv, -1.0, 1.0))
    ang_bad = testable & (ang >= thr[ys, xs])

    dep_bad = np.zeros_like(ang_bad)
    if use_depth:
        X1_model = apply_point_motion(sf.X0, R, t)
        zq = z1[y1, x1]
        sigma = depth_sigma(z0)
        dep_bad = (zq <= 0) | (np.abs(zq - X1_model[ys, xs, 2])
                               > axis_mult * k_sigma * sigma[ys, xs])

    bad = ang_bad | dep_bad
    valid = np.zeros((h, w), dtype=bool)
    valid[ys[~bad], xs[~bad]] = True
    info["n_seed_untested"] = int((~testable).sum())
    info["n_seed_rejected"] = int(bad.sum())
    info["n_seed_rejected_angle"] = int(ang_bad.sum())
    info["n_seed_rejected_depth"] = int(dep_bad.sum())
    info["n_seed_rejected_both"] = int((ang_bad & dep_bad).sum())
    info["n_seed_out"] = int(valid.sum())
    if collect and bad.any():
        st = max(1, int(bad.sum()) // 100_000)
        info["seed_rejected_kc"] = (kc0[ys[bad], xs[bad]][::st].astype(np.float32)
                                    if kc0 is not None else np.zeros(0, np.float32))
    return replace(sf, valid=valid), info


def expand_gated(sf: SC.SceneFlow, z0: np.ndarray, z1: np.ndarray, K: np.ndarray,
                 n0: np.ndarray, n_ok0: np.ndarray,
                 n1: np.ndarray, n_ok1: np.ndarray, *,
                 kc0: np.ndarray | None = None,
                 slide_tol_m: float = SLIDE_TOL_MM * 1e-3,
                 flat_end_deg: float = NOISE_FLOOR_DEG,
                 k_sigma: float = K_SIGMA, axis_mult: float = AXIS_MULT,
                 rounds: int = 2, subsample: int = 4,
                 z_min: float = 0.4, z_max: float = 4.0,
                 collect: bool = False):
    """The finalized expansion loop plus the normal-agreement channel, on the
    supplied (smoothed) normals. Point-plane and along-depth are the finalized
    criteria with the along-depth bound aligned to the same 3 sigma box."""
    h, w = z0.shape
    fx, fy, cx, cy = (float(K[0, 0]), float(K[1, 1]), float(K[0, 2]), float(K[1, 2]))
    xs, ys = _grid(h, w)
    u = sf.u.copy()
    v = sf.v.copy()
    X1 = sf.X1.copy()
    seed = sf.valid.copy()
    expanded = np.zeros((h, w), dtype=bool)
    rej = {k: 0 for k in ("inb", "z1_range", "n_ok_src", "n_ok_dst", "finite",
                          "zero_motion", "p2plane", "p2pz", "angle")}
    info = {"n_added": 0, "n_cand": 0, **rej}
    xi = sf.xi
    if xi is None:
        return _copy_with(sf, u, v, X1, seed, expanded, info), info

    thr = np.deg2rad(angle_threshold_map(kc0, h, w, slide_tol_m, flat_end_deg))
    z0_ok = (z0 > z_min) & (z0 < z_max)
    sigma = depth_sigma(z0)
    ang_pool: list[np.ndarray] = []
    kc_pool: list[np.ndarray] = []
    theta_pool: list[np.ndarray] = []

    for _ in range(rounds):
        R, t = se3_exp(xi)
        model = SC.flow_from_twist(sf.X0, z0, K, xi, z_min=z_min)
        X1_model = apply_point_motion(sf.X0, R, t)
        x1 = xs + model[..., 0]
        y1 = ys + model[..., 1]
        inb = (x1 >= 0) & (x1 <= w - 1) & (y1 >= 0) & (y1 <= h - 1)
        x1i = np.clip(np.rint(x1).astype(np.int32), 0, w - 1)
        y1i = np.clip(np.rint(y1).astype(np.int32), 0, h - 1)
        z1w = z1[y1i, x1i]
        z1_ok = (z1w > z_min) & (z1w < z_max)
        fin = np.isfinite(model).all(axis=-1)
        nzm = (np.abs(model[..., 0]) + np.abs(model[..., 1])) > 0
        cand = z0_ok & ~seed & ~expanded
        info["n_cand"] += int(cand.sum())

        cur = cand & inb
        rej["inb"] += int((cand & ~inb).sum())
        rej["z1_range"] += int((cur & ~z1_ok).sum())
        cur = cur & z1_ok
        rej["n_ok_src"] += int((cur & ~n_ok0).sum())
        cur = cur & n_ok0
        rej["finite"] += int((cur & ~fin).sum())
        cur = cur & fin
        rej["zero_motion"] += int((cur & ~nzm).sum())
        cur = cur & nzm
        nd = n_ok1[y1i, x1i]
        rej["n_ok_dst"] += int((cur & ~nd).sum())
        pre = cur & nd
        if not pre.any():
            break

        X1_obs = np.stack([(x1 - cx) * z1w / fx, (y1 - cy) * z1w / fy, z1w], axis=-1)
        p2plane = np.abs(np.sum((X1_obs - X1_model) * n0, axis=-1))
        p2pz = np.abs(X1_obs[..., 2] - X1_model[..., 2])
        g1 = p2plane < (k_sigma * sigma)
        g2 = p2pz < (axis_mult * k_sigma * sigma)
        rej["p2plane"] += int((pre & ~g1).sum())
        rej["p2pz"] += int((pre & g1 & ~g2).sum())
        pre2 = pre & g1 & g2
        if not pre2.any():
            break

        # the frame-n normal must be carried by the camera rotation before it can be
        # compared with the frame-(n+1) one
        n0r = np.einsum("ij,hwj->hwi", R, n0)
        cosv = np.abs(np.sum(n0r * n1[y1i, x1i], axis=-1))
        angv = np.arccos(np.clip(cosv, -1.0, 1.0))
        rej["angle"] += int((pre2 & ~(angv < thr)).sum())
        if collect:
            st = max(1, int(pre2.sum()) // 100_000)
            ang_pool.append(angv[pre2][::st].astype(np.float32))
            kc_pool.append((kc0 if kc0 is not None
                            else np.zeros((h, w), np.float32))[pre2][::st].astype(np.float32))
            theta_pool.append(thr[pre2][::st].astype(np.float32))

        gate = pre2 & (angv < thr)
        if not gate.any():
            break
        expanded |= gate
        u[gate] = model[..., 0][gate]
        v[gate] = model[..., 1][gate]
        X1[gate] = X1_obs[gate]

        yy, xx = np.where(seed | expanded)
        if xx.size < 32:
            break
        ks = (xx % subsample == 0) & (yy % subsample == 0)
        xi_new = SC.estimate_twist(sf.X0[yy[ks], xx[ks]], X1[yy[ks], xx[ks]])
        if xi_new is None:
            break
        xi = xi_new

    info.update(rej)
    info["n_added"] = int(expanded.sum())
    info["angles"] = (np.concatenate(ang_pool) if ang_pool else np.zeros(0, np.float32))
    info["kc_at_source"] = (np.concatenate(kc_pool) if kc_pool
                            else np.zeros(0, np.float32))
    info["theta_deg"] = (np.rad2deg(np.concatenate(theta_pool)) if theta_pool
                         else np.zeros(0, np.float32))
    return _copy_with(sf, u, v, X1, seed | expanded, expanded, info), info


def _copy_with(sf: SC.SceneFlow, u, v, X1, valid, expanded, info) -> SC.SceneFlow:
    stats = dict(sf.stats)
    stats["gated_frame"] = {k: v for k, v in info.items()
                            if k not in ("angles", "kc_at_source", "theta_deg")}
    return SC.SceneFlow(
        u=u.astype(np.float32), v=v.astype(np.float32),
        vz=np.where(valid, X1[..., 2] - sf.X0[..., 2], 0.0).astype(np.float32),
        X0=sf.X0, X1=X1, valid=valid, gray0=sf.gray0, gray1=sf.gray1, xi=sf.xi,
        pred_u=sf.pred_u, pred_v=sf.pred_v, res_u=sf.res_u, res_v=sf.res_v,
        bw_u=sf.bw_u, bw_v=sf.bw_v, expanded=expanded, stats=stats,
    )


def compute_scene_flow_gated(bgr0, bgr1, z0, z1, K, *, prev=None, dt=1.0, prev_dt=1.0,
                             slide_tol_mm: float = SLIDE_TOL_MM,
                             flat_end_deg: float = NOISE_FLOOR_DEG,
                             k_sigma: float = K_SIGMA, axis_mult: float = AXIS_MULT,
                             rounds: int = 2, subsample: int = 4, expand: bool = True,
                             seed_gate: bool = SEED_GATE_ENABLED,
                             seed_depth_gate: bool = SEED_DEPTH_GATE_ENABLED,
                             z_min: float = 0.4, z_max: float = 4.0,
                             n0=None, n_ok0=None, n1=None, n_ok1=None, kc0=None,
                             collect: bool = False):
    """Drop-in for `scene_flow.compute_scene_flow` with the adopted changes.

    Pass `n0/n_ok0`, `n1/n_ok1` and `kc0` when the caller has already built the
    per-frame geometry (they are reused across frames), otherwise they are computed.
    """
    sf = SC.compute_scene_flow(bgr0, bgr1, z0, z1, K, prev=prev, dt=dt,
                               prev_dt=prev_dt, expand_inliers=False,
                               motion_constraint=True, project_mode=False)
    if n0 is None:
        g0 = scene_geometry(z0, K)
        n0, n_ok0 = g0.normal, g0.n_ok
        kc0 = kc_of(g0)
    if n1 is None:
        g1 = scene_geometry(z1, K)
        n1, n_ok1 = g1.normal, g1.n_ok
    slide_tol_m = slide_tol_mm * 1e-3

    info_sgate = None
    if seed_gate:
        sf, info_sgate = gate_seeds(
            sf, z0, z1, K, n0, n_ok0, n1, n_ok1, kc0=kc0, slide_tol_m=slide_tol_m,
            flat_end_deg=flat_end_deg, k_sigma=k_sigma, axis_mult=axis_mult,
            use_depth=seed_depth_gate, collect=collect)
    if not expand:
        return sf, {"seed_gate": info_sgate, "expand": None}
    sf, info_exp = expand_gated(
        sf, z0, z1, K, n0, n_ok0, n1, n_ok1, kc0=kc0, slide_tol_m=slide_tol_m,
        flat_end_deg=flat_end_deg, k_sigma=k_sigma, axis_mult=axis_mult,
        rounds=rounds, subsample=subsample, z_min=z_min, z_max=z_max, collect=collect)
    return sf, {"seed_gate": info_sgate, "expand": info_exp}


# ---------------------------------------------------------------------------
# statistics driver (flow only; nothing touches the model)
# ---------------------------------------------------------------------------

def run_stats(frames: int, out: Path, args) -> None:
    import sequential_fusion_flowonly as SF  # heavy; only the driver needs it

    pairs = SF.associate(SF.DATA, max_dt=0.02)[:frames]
    sample = SF.load_rgb(pairs[0].rgb_path)
    h, w = sample.shape[:2]
    map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)

    rej_keys = ("inb", "z1_range", "n_ok_src", "n_ok_dst", "finite",
                "zero_motion", "p2plane", "p2pz", "angle")
    tot = dict(orig_added=0, gated_added=0, cand=0, frame_px=0,
               seed_gate_in=0, seed_gate_rejected=0, seed_gate_angle=0,
               seed_gate_depth=0, seed_gate_both=0, seed_gate_untested=0,
               seed_only_px=0, valid_px=0)
    rej_tot = {k: 0 for k in rej_keys}
    ang_pool: list[np.ndarray] = []
    kc_pool: list[np.ndarray] = []
    theta_pool: list[np.ndarray] = []
    seed_rej_kc: list[np.ndarray] = []
    rows: list[dict] = []

    def frame_geo(z):
        g = scene_geometry(z, K)
        return g.normal, g.n_ok, kc_of(g)

    bgr_a, z_a, _ = SF.load_pair(pairs, 0, map1, map2)
    n0, n_ok0, kc0 = frame_geo(z_a)
    prev_sf, prev_dt = None, 1.0
    t0 = time.perf_counter()

    for i in range(len(pairs) - 1):
        bgr_b, z_b, _ = SF.load_pair(pairs, i + 1, map1, map2)
        dt = pairs[i + 1].t_rgb - pairs[i].t_rgb
        n1, n_ok1, kc1 = frame_geo(z_b)

        base = SC.compute_scene_flow(bgr_a, bgr_b, z_a, z_b, K,
                                     prev=prev_sf, dt=dt, prev_dt=prev_dt,
                                     expand_inliers=False, compute_stats=False)
        # A: the finalized gates, the finalized seed set (baseline check)
        exA = expand_rigid_inliers(base, z_a, z_b, K)

        # adopted: the two channels on the seed set and on the expansion
        sf_seed, info_sgate = gate_seeds(
            base, z_a, z_b, K, n0, n_ok0, n1, n_ok1, kc0=kc0,
            slide_tol_m=args.slide_tol_mm * 1e-3, flat_end_deg=args.flat_end_deg,
            k_sigma=args.k_sigma, axis_mult=args.axis_mult,
            use_depth=args.seed_depth_gate, collect=True)
        sf_gated, info_exp = expand_gated(
            sf_seed, z_a, z_b, K, n0, n_ok0, n1, n_ok1, kc0=kc0,
            slide_tol_m=args.slide_tol_mm * 1e-3, flat_end_deg=args.flat_end_deg,
            k_sigma=args.k_sigma, axis_mult=args.axis_mult,
            z_min=SF.Z_MIN, z_max=SF.Z_MAX, collect=True)

        tot["cand"] += info_exp["n_cand"]
        tot["orig_added"] += int(exA.n_added)
        tot["gated_added"] += info_exp["n_added"]
        tot["frame_px"] += z_a.size
        tot["seed_only_px"] += int(base.valid.sum())
        tot["valid_px"] += int(sf_gated.valid.sum())
        tot["seed_gate_in"] += info_sgate["n_seed_in"]
        tot["seed_gate_rejected"] += info_sgate["n_seed_rejected"]
        tot["seed_gate_angle"] += info_sgate["n_seed_rejected_angle"]
        tot["seed_gate_depth"] += info_sgate["n_seed_rejected_depth"]
        tot["seed_gate_both"] += info_sgate["n_seed_rejected_both"]
        tot["seed_gate_untested"] += info_sgate["n_seed_untested"]
        for k in rej_keys:
            rej_tot[k] += int(info_exp[k])
        if info_exp["angles"].size:
            ang_pool.append(info_exp["angles"])
            kc_pool.append(info_exp["kc_at_source"])
            theta_pool.append(info_exp["theta_deg"])
        if info_sgate.get("seed_rejected_kc") is not None:
            if info_sgate["seed_rejected_kc"].size:
                seed_rej_kc.append(info_sgate["seed_rejected_kc"])

        rows.append({"i": i, "cand": info_exp["n_cand"],
                     "orig_added": int(exA.n_added),
                     "gated_added": info_exp["n_added"],
                     "seed_rejected": info_sgate["n_seed_rejected"]})
        if (i + 1) % 20 == 0:
            print(f"[{i+1:03d}] seed_rej={info_sgate['n_seed_rejected']} "
                  f"added A/C={exA.n_added}/{info_exp['n_added']} "
                  f"({time.perf_counter()-t0:.1f}s)", flush=True)

        prev_sf, prev_dt = base, dt
        bgr_a, z_a = bgr_b, z_b
        n0, n_ok0, kc0 = n1, n_ok1, kc1

    ang = np.concatenate(ang_pool) if ang_pool else np.zeros(0, np.float32)
    kc = np.concatenate(kc_pool) if kc_pool else np.zeros(0, np.float32)
    thr = np.concatenate(theta_pool) if theta_pool else np.zeros(0, np.float32)
    ang_deg = np.rad2deg(ang) if ang.size else ang
    by_band = None
    if kc.size == ang_deg.size and kc.size:
        by_band = {}
        for lo, hi in KC_BANDS:
            m = (kc >= lo) & (kc < hi)
            if not m.any():
                continue
            by_band[f"{lo:g}-{hi:g}"] = {
                "n": int(m.sum()),
                "theta_deg": float(np.median(thr[m])),
                "angle_p50_deg": float(np.median(ang_deg[m])),
                "angle_p90_deg": float(np.percentile(ang_deg[m], 90)),
                "reject_frac": float((ang_deg[m] >= thr[m]).mean()),
            }
    nf = max(len(rows), 1)
    fp = max(tot["frame_px"], 1)
    agg = dict(
        n_frames=len(rows),
        slide_tol_mm=args.slide_tol_mm,
        flat_end_deg=args.flat_end_deg,
        k_sigma=args.k_sigma,
        axis_mult=args.axis_mult,
        seed_gate=True,
        seed_depth_gate=bool(args.seed_depth_gate),
        seed_gate_stats={
            "in_px": tot["seed_gate_in"],
            "rejected_px": tot["seed_gate_rejected"],
            "rejected_frac": tot["seed_gate_rejected"] / max(tot["seed_gate_in"], 1),
            "by_angle_px": tot["seed_gate_angle"],
            "by_depth_px": tot["seed_gate_depth"],
            "by_both_px": tot["seed_gate_both"],
            "untested_px": tot["seed_gate_untested"],
            "rejected_by_kc_band": (
                {f"{lo:g}-{hi:g}": float(((np.concatenate(seed_rej_kc) >= lo)
                                          & (np.concatenate(seed_rej_kc) < hi)).mean())
                 for lo, hi in KC_BANDS} if seed_rej_kc else None),
        },
        # coverage_A must equal 0.15028715006510418 (the finalized
        # frac_added_of_frame) -- the check that the baseline behaviour is untouched
        coverage_A_finalized=tot["orig_added"] / fp,
        coverage_C_adopted=tot["gated_added"] / fp,
        per_frame_added_A=tot["orig_added"] / nf,
        per_frame_added_C=tot["gated_added"] / nf,
        cand_px=tot["cand"],
        expansion_reject_frac_of_cand={k: v / max(tot["cand"], 1)
                                      for k, v in rej_tot.items()},
        expansion_reject_totals=rej_tot,
        seed_only_valid_px=tot["seed_only_px"],
        seed_plus_expansion_valid_px=tot["valid_px"],
        angle_margin_deg={f"p{q}": float(np.percentile(ang_deg, q))
                          for q in (50, 75, 90, 95, 99)} if ang_deg.size else None,
        angle_by_curvature_band=by_band,
    )
    out.mkdir(parents=True, exist_ok=True)
    (out / "flow_gated.json").write_text(json.dumps(agg, indent=2))
    with (out / "flow_gated_per_frame.csv").open("w", newline="") as f:
        wri = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        wri.writeheader()
        wri.writerows(rows)
    print(json.dumps(agg, indent=2))
    print(f"wrote {out}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--stats", action="store_true")
    ap.add_argument("--frames", type=int, default=81)
    ap.add_argument("--out", default="output_flow_gated")
    ap.add_argument("--slide-tol-mm", type=float, default=SLIDE_TOL_MM)
    ap.add_argument("--flat-end-deg", type=float, default=NOISE_FLOOR_DEG)
    ap.add_argument("--k-sigma", type=float, default=K_SIGMA)
    ap.add_argument("--axis-mult", type=float, default=AXIS_MULT,
                    help="along-depth bound = axis_mult * k_sigma * sigma(z); "
                         "the finalized value was 4.0 (12 sigma)")
    ap.add_argument("--no-seed-depth-gate", action="store_false",
                    dest="seed_depth_gate", default=SEED_DEPTH_GATE_ENABLED)
    args = ap.parse_args()
    if args.stats:
        run_stats(args.frames, SEQ.parent / args.out, args)
    else:
        ap.print_help()


if __name__ == "__main__":
    main()