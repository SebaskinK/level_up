"""Plot pose errors and scene-flow residual stats."""

from __future__ import annotations

import argparse
import csv
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def _col(rows, key):
    return np.array([float(r[key] or "nan") for r in rows])


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--csv", default=str(Path(__file__).resolve().parent.parent / "output" / "frame_errors.csv"))
    p.add_argument("--out", default=str(Path(__file__).resolve().parent.parent / "output" / "errors.png"))
    args = p.parse_args()

    rows = list(csv.DictReader(Path(args.csv).open()))
    i = np.array([int(r["i"]) for r in rows])
    terr = _col(rows, "trans_err") * 100.0
    rerr = _col(rows, "rot_err_deg")
    tgt = _col(rows, "trans_gt") * 100.0
    test = _col(rows, "trans_est") * 100.0
    valid = _col(rows, "valid_frac")
    flow = _col(rows, "flow_mag_mean") if "flow_mag_mean" in rows[0] else None
    res = _col(rows, "res_mag_mean") if "res_mag_mean" in rows[0] else None
    rigid = _col(rows, "rigid_delta_mean") if "rigid_delta_mean" in rows[0] else None

    n = 4 if res is not None else 3
    fig, axes = plt.subplots(n, 1, figsize=(10, 2.4 * n), sharex=True)
    axes[0].plot(i, test, label="|t| est")
    axes[0].plot(i, tgt, label="|t| gt", alpha=0.8)
    axes[0].set_ylabel("translation (cm)")
    axes[0].legend()
    axes[0].grid(True, alpha=0.3)

    axes[1].plot(i, terr, label="trans err (cm)")
    axes[1].plot(i, rerr, label="rot err (deg)")
    axes[1].set_ylabel("pose error")
    axes[1].legend()
    axes[1].grid(True, alpha=0.3)

    axes[2].plot(i, valid, color="tab:green", label="valid frac")
    axes[2].set_ylabel("valid pixel frac")
    axes[2].grid(True, alpha=0.3)

    if res is not None:
        axes[3].plot(i, flow, label="|flow|")
        axes[3].plot(i, res, label="|residual DIS|")
        axes[3].plot(i, rigid, label="|flow - rigid|")
        axes[3].set_ylabel("pixels")
        axes[3].legend()
        axes[3].grid(True, alpha=0.3)
        axes[3].set_xlabel("frame pair index")
    else:
        axes[2].set_xlabel("frame pair index")

    fig.tight_layout()
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(args.out, dpi=140)
    print(f"wrote {args.out}")


if __name__ == "__main__":
    main()
