"""Render each frame's NEWBORN discs back-projected onto their own birth frame.

Runs the same 80-frame fusion (aging off, absorption on, black-edge fill on,
TEX_VAR_THR from h_pipeline_final), and as it goes records every new disc's
geometry at birth (in the birth-frame camera coords) + source (S2 / curvature).

Then, for every transition i=0..79, it rasterizes just the discs born at i onto
the RGB frame i+1 (the first frame where they appear) and overlays their
footprint: S2 discs = red, curvature discs = blue, with the disc centres marked.

Outputs:
  output_newborn_tex4e4/frame_{i:03d}.png   one image per birth frame
  output_newborn_tex4e4/montage.png         8x10 grid for quick scanning
"""

from __future__ import annotations

import time
from pathlib import Path

import cv2
import numpy as np

import h_pipeline_final as H
import sequential_fusion_flowonly as SF


def pm_compose(a, b):
    Ra, ta = a
    Rb, tb = b
    return Rb @ Ra, Rb @ ta + tb


def concat(lst):
    return np.concatenate(lst, axis=0)


def build_sub(sel, mu, normal, scale, color, pixel, axis1, axis2):
    return H.Gaussians(
        mu=mu[sel].astype(np.float32),
        normal=normal[sel].astype(np.float32),
        scale=scale[sel].astype(np.float32),
        quat=H._quat_from_frame(axis1[sel].astype(np.float32),
                                axis2[sel].astype(np.float32),
                                normal[sel].astype(np.float32)),
        color=color[sel].astype(np.float32),
        alpha=np.full(len(sel), H.OPAQUE_ALPHA, dtype=np.float32),
        pixel=pixel[sel].astype(np.int32),
        axis1=axis1[sel].astype(np.float32),
        axis2=axis2[sel].astype(np.float32),
    )


def main() -> None:
    SEQ = SF.SEQ
    OUT = SEQ.parent / "output_newborn_tex4e4"
    OUT.mkdir(parents=True, exist_ok=True)

    NPAIR = 81
    AGE_MAX = 1000000
    W_MIN = 0.0
    CELL_W = 300  # montage cell width

    pairs = SF.associate(SF.DATA, max_dt=0.02)[:NPAIR]
    sample = SF.load_rgb(pairs[0].rgb_path)
    h, w = sample.shape[:2]
    map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)

    print("building frame-0 model ...", flush=True)
    bgr0, z0, _ = SF.load_pair(pairs, 0, map1, map2)
    g0, _, _, owner0 = H.build_hybrid_with_owner(bgr0, z0, K, SF.TEX_Q)
    n_init = len(g0)
    print(f"n_init={n_init}  TEX_VAR_THR={H.TEX_VAR_THR:g}", flush=True)

    mu_l = [np.asarray(g0.mu)]
    sc_l = [np.asarray(g0.scale)]
    co_l = [np.asarray(g0.color)]
    nm_l = [np.asarray(g0.normal)]
    px_l = [np.asarray(g0.pixel)]
    a1_l = [np.asarray(g0.axis1)]
    a2_l = [np.asarray(g0.axis2)]
    src_l = [np.full(n_init, -1, dtype=np.int8)]   # -1 original
    bir_l = [np.zeros(n_init, dtype=np.int32)]      # 0 = frame 0

    model = SF.Model(
        g=g0,
        w=np.ones(n_init, dtype=np.float32),
        age=np.zeros(n_init, dtype=np.int32),
        owner=owner0,
        birth=np.zeros(n_init, dtype=np.int32),
    )
    prev_sf, prev_dt = None, 1.0
    bgr_a, z_a = bgr0, z0

    t0 = time.perf_counter()
    for i in range(NPAIR - 1):
        bgr_b, z_b, _ = SF.load_pair(pairs, i + 1, map1, map2)
        dt = pairs[i + 1].t_rgb - pairs[i].t_rgb
        sf = SF.compute_scene_flow(bgr_a, bgr_b, z_a, z_b, K,
                                   prev=prev_sf, dt=dt, prev_dt=prev_dt)
        R_10, t_10 = SF.se3_exp(sf.xi)

        n_before = len(model.g)
        rec = SF.fuse_frame(model, sf, z_a, z_b, bgr_b, K,
                            age_max=AGE_MAX, w_min=W_MIN, frame_idx=i,
                            R_10=R_10, t_10=t_10)
        n_after = len(model.g)
        n_s2 = rec["n_s2"]
        n_curv = rec["n_curv"]
        n_new = rec["n_new"]
        assert n_new == n_s2 + n_curv == n_after - n_before

        if n_new:
            sl = slice(n_before, n_after)
            ng = model.g
            mu_l.append(np.asarray(ng.mu[sl]))
            sc_l.append(np.asarray(ng.scale[sl]))
            co_l.append(np.asarray(ng.color[sl]))
            nm_l.append(np.asarray(ng.normal[sl]))
            px_l.append(np.asarray(ng.pixel[sl]))
            a1_l.append(np.asarray(ng.axis1[sl]))
            a2_l.append(np.asarray(ng.axis2[sl]))
            src_l.append(np.concatenate([
                np.zeros(n_s2, dtype=np.int8),
                np.ones(n_curv, dtype=np.int8),
            ]))
            bir_l.append(np.full(n_new, i, dtype=np.int32))

        if (i + 1) % 10 == 0:
            print(f"[{i+1:03d}] N={len(model.g)} cum={time.perf_counter()-t0:.1f}s",
                  flush=True)
        bgr_a, z_a = bgr_b, z_b
        prev_sf, prev_dt = sf, dt

    print(f"final N={len(model.g)}  recording ...", flush=True)

    mu = concat(mu_l); scale = concat(sc_l); color = concat(co_l)
    normal = concat(nm_l); pixel = concat(px_l)
    axis1 = concat(a1_l); axis2 = concat(a2_l)
    source = concat(src_l); birth = concat(bir_l)
    assert len(mu) == len(source) == len(birth) == len(model.g)

    np.savez(OUT / "records.npz",
             mu=mu.astype(np.float32), scale=scale.astype(np.float32),
             color=color.astype(np.float32), normal=normal.astype(np.float32),
             pixel=pixel.astype(np.int32),
             axis1=axis1.astype(np.float32), axis2=axis2.astype(np.float32),
             source=source.astype(np.int8), birth=birth.astype(np.int32),
             n_init=np.int32(n_init))

    # per birth frame: rasterize newborns onto RGB frame i+1
    cells = []
    for i in range(NPAIR - 1):
        sel = birth == i
        n_sel = int(sel.sum())
        bgr_bf, _, _ = SF.load_pair(pairs, i + 1, map1, map2)
        vis = bgr_bf.copy()
        if n_sel:
            sub = build_sub(sel, mu, normal, scale, color, pixel, axis1, axis2)
            _, idx_sub, _ = H.rasterize_discs(sub, K, (h, w))
            cov = idx_sub >= 0
            # S2 footprint = red, curvature footprint = blue (front-most disc decides)
            overlay = np.zeros_like(bgr_bf)
            overlay[cov] = (0, 0, 255)   # BGR red (S2)
            front = idx_sub[cov]
            curv_front = (source[sel][front] == 1)
            if curv_front.any():
                ys, xs = np.where(cov)
                overlay[ys[curv_front], xs[curv_front]] = (255, 0, 0)  # BGR blue
            vis = cv2.addWeighted(bgr_bf, 0.5, overlay, 0.5, 0)
            for (u, v) in pixel[sel]:
                cv2.circle(vis, (int(u), int(v)), 1, (0, 255, 255), -1, lineType=cv2.LINE_AA)
        cap = f"frame {i+1:02d}  new={n_sel}  (S2={int((source[sel]==0).sum())} curv={int((source[sel]==1).sum())})"
        vis = _caption(vis, cap)
        cv2.imwrite(str(OUT / f"frame_{i:03d}.png"), vis)
        cells.append(vis)

    # montage 8 cols
    scale_f = CELL_W / w
    th = int(round(vis.shape[0] * scale_f))
    cells_r = [cv2.resize(c, (CELL_W, th), interpolation=cv2.INTER_AREA) for c in cells]
    ncol = 8
    nrow = (len(cells_r) + ncol - 1) // ncol
    pad = 4
    rows = []
    for r in range(nrow):
        row_chunk = cells_r[r * ncol:(r + 1) * ncol]
        while len(row_chunk) < ncol:
            row_chunk.append(np.full_like(cells_r[0]))
        row_img = np.hstack([
            np.pad(c, ((0, 0), (pad // 2, pad // 2), (0, 0)), constant_values=40)
            for c in row_chunk
        ])
        rows.append(row_img)
    montage = np.vstack([
        np.pad(ro, ((pad // 2, pad // 2), (0, 0), (0, 0)), constant_values=40)
        for ro in rows
    ])
    cv2.imwrite(str(OUT / "montage.png"), montage)
    print(f"wrote {OUT / 'montage.png'}  ({nrow}x{ncol} grid)", flush=True)
    print("done", flush=True)


def _caption(img, text, h_bar=30):
    w = img.shape[1]
    bar = np.full((h_bar, w, 3), 20, np.uint8)
    cv2.putText(bar, text, (8, h_bar - 9), cv2.FONT_HERSHEY_SIMPLEX,
                0.42, (230, 230, 230), 1, cv2.LINE_AA)
    return np.vstack([img, bar])


if __name__ == "__main__":
    main()