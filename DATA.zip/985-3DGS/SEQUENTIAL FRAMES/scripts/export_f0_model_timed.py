"""Run incremental fusion (N transitions) and export the final model in FRAME-0
coordinates as both PLY and npz, with per-frame timing written to files.

Same fusion as the approved pipeline (one-point flow hit + frozen-radius absorb,
aging off). Unlike render_f0_images.py this does NOT do any frame-0 raster/EWA
rendering -- it only exports geometry, so it is cheap enough for 80 frames.

Outputs (all in --out):
  model_f0.ply            final model transformed back to frame-0 camera coords
                          (quat rebuilt from transformed axis1/axis2 so the
                           anisotropic in-plane orientation survives the frame
                           change -- transform_to_next recomputes quat from the
                           normal only, which discards the principal axis)
  model_f0.npz            mu/normal/scale/color/birth in frame-0 coords
  fusion.csv, summary.json
  timings.csv             per-frame scene-flow / fuse wall seconds
  timings_summary.json    totals + means/p50/p95 per stage
"""

from __future__ import annotations

import argparse
import csv
import json
import time
from pathlib import Path

import numpy as np

import h_pipeline_final as H                # noqa: E402  (multi-frame copy)
import sequential_fusion_flowonly as SF     # noqa: E402

AGE_MAX = 1000000   # aging pruning off
W_MIN = 0.0


def pm_compose(a, b):
    Ra, ta = a
    Rb, tb = b
    return Rb @ Ra, Rb @ ta + tb


def pm_inv(a):
    R, t = a
    return R.T, -R.T @ t


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--max-pairs", type=int, default=80)
    ap.add_argument("--out", default=str(SF.SEQ.parent / "output_absorb_frozen_80_export"))
    args = ap.parse_args()
    OUT = Path(args.out)
    OUT.mkdir(parents=True, exist_ok=True)

    pairs = SF.associate(SF.DATA, max_dt=0.02)[: args.max_pairs + 1]
    n_frames = len(pairs)
    sample = SF.load_rgb(pairs[0].rgb_path)
    h, w = sample.shape[:2]
    map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)

    bgr0, z0, _ = SF.load_pair(pairs, 0, map1, map2)
    g0, _, _, owner0 = H.build_hybrid_with_owner(bgr0, z0, K, SF.TEX_Q)
    model = SF.Model(
        g=g0,
        w=np.ones(len(g0), dtype=np.float32),
        age=np.zeros(len(g0), dtype=np.int32),
        owner=owner0,
        birth=np.zeros(len(g0), dtype=np.int32),
    )

    FL = [None] * n_frames
    FL[0] = (np.eye(3), np.zeros(3))
    prev_FL = FL[0]

    t0 = time.perf_counter()
    rows = [{"i": -1, "n": len(g0), "t_sf": 0.0, "t_fuse": 0.0}]
    prev_sf = None
    prev_dt = 1.0
    bgr_a, z_a = bgr0, z0

    for i in range(len(pairs) - 1):        # transitions 0..N-1
        bgr_b, z_b, _ = SF.load_pair(pairs, i + 1, map1, map2)
        dt = pairs[i + 1].t_rgb - pairs[i].t_rgb

        t_sf0 = time.perf_counter()
        sf = SF.compute_scene_flow(
            bgr_a, bgr_b, z_a, z_b, K, prev=prev_sf, dt=dt, prev_dt=prev_dt,
        )
        if sf.xi is None:
            raise RuntimeError("scene flow produced no twist")
        R_10, t_10 = SF.se3_exp(sf.xi)
        t_sf = time.perf_counter() - t_sf0
        FL[i + 1] = pm_compose(prev_FL, (R_10, t_10))

        t_f0 = time.perf_counter()
        rec = SF.fuse_frame(model, sf, z_a, z_b, bgr_b, K,
                            age_max=AGE_MAX, w_min=W_MIN, frame_idx=i,
                            R_10=R_10, t_10=t_10)
        t_fuse = time.perf_counter() - t_f0

        rows.append({"i": i, "n": rec["n"], "t_sf": round(t_sf, 4),
                     "t_fuse": round(t_fuse, 4)})
        print(f"[{i:03d}] N={rec['n']} sf={t_sf:.3f}s fuse={t_fuse:.3f}s "
              f"cum={time.perf_counter() - t0:.1f}s", flush=True)

        bgr_a, z_a = bgr_b, z_b
        prev_sf, prev_dt = sf, dt
        prev_FL = FL[i + 1]

    t_total = time.perf_counter() - t0
    g = model.g                                   # last-frame camera coords
    g0f = SF.transform_to_next(g, *pm_inv(FL[n_frames - 1]))  # back to frame 0
    # transform_to_next rebuilds quat from the normal only; restore the true
    # in-plane anisotropy from the transformed principal axes.
    if g0f.axis1 is not None and g0f.axis2 is not None:
        g0f.quat = H._quat_from_frame(g0f.axis1, g0f.axis2, g0f.normal)

    SF.write_ply(OUT / "model_f0.ply", g0f)
    np.savez(OUT / "model_f0.npz",
             mu=g0f.mu.astype(np.float64),
             normal=g0f.normal.astype(np.float64),
             scale=g0f.scale.astype(np.float64),
             color=g0f.color.astype(np.float64),
             birth=model.birth.astype(np.int32))

    # per-frame timing csv
    with (OUT / "timings.csv").open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["i", "n", "t_sf", "t_fuse"])
        w.writeheader()
        w.writerows(rows[1:])

    fine = rows[1:]
    sf_t = np.array([r["t_sf"] for r in fine])
    fu_t = np.array([r["t_fuse"] for r in fine])
    def stat(a):
        return {"mean": round(float(a.mean()), 4),
                "p50": round(float(np.percentile(a, 50)), 4),
                "p95": round(float(np.percentile(a, 95)), 4),
                "max": round(float(a.max()), 4)}
    summary = {
        "n_transitions": len(fine),
        "n_init": rows[0]["n"],
        "n_final": len(g),
        "t_total_s": round(t_total, 3),
        "t_per_frame_s": round(t_total / len(fine), 4),
        "t_scene_flow": stat(sf_t),
        "t_fuse": stat(fu_t),
    }
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2))
    (OUT / "timings_summary.json").write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2))
    print(f"saved -> {OUT}")


if __name__ == "__main__":
    main()