"""Side-by-side crops of the desk-edge region: GT vs frame0-only vs 10-frame."""
import sys
from pathlib import Path

import cv2
import numpy as np

SEQ = Path(__file__).resolve().parent
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SEQ))
sys.path.insert(0, str(SFLOW))

import h_pipeline_final as H  # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402

OUT = SEQ.parent / "output_f0_10frame"
pairs = SF.associate(SF.DATA, max_dt=0.02)[:1]
h, w = SF.load_rgb(pairs[0].rgb_path).shape[:2]
map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)
bgr0, z0, _ = SF.load_pair(pairs, 0, map1, map2)

g0, _, _, owner0 = H.build_hybrid_with_owner(bgr0, z0, K, SF.TEX_Q)

def render(g):
    depth, index, _ = H.rasterize_discs(g, K, (h, w))
    hit = np.isfinite(depth)
    out = np.zeros((h, w, 3), np.float32)
    out[hit] = g.color[index[hit]]
    return (np.clip(out, 0, 1) * 255).astype(np.uint8)

r0 = render(g0)
hard = cv2.imread(str(OUT / "f0_hard.png"))
gt = bgr0  # BGR

y0, y1, x0, x1 = 330, 400, 380, 640
def crop(im):
    c = im[y0:y1, x0:x1]
    return cv2.resize(c, None, fx=3.0, fy=3.0, interpolation=cv2.INTER_NEAREST)

for name, im in [("gt", gt), ("f0only", r0), ("10frame", hard)]:
    cv2.imwrite(str(OUT / f"crop_{name}.png"), crop(im))

# save a combined strip: [gt | f0only | 10frame]
strip = np.hstack([crop(gt), crop(r0), crop(hard)])
cv2.imwrite(str(OUT / "crop_compare.png"), strip)

print("saved crops ->", OUT)
print("desk-region mean BGR: gt", gt[y0:y1, x0:x1].mean((0,1)).round(1),
      "f0only", r0[y0:y1, x0:x1].mean((0,1)).round(1),
      "10frame", hard[y0:y1, x0:x1].mean((0,1)).round(1))