# absorb merge rewrite — APPROVED (default) snapshot

吸收合并段改写为与 `update_hits_onepoint`（flow-hit 逐点）**同一套代数**，并冻结半径。
经用户确认，以本快照为默认方案。

## 改动（相对 `backup/20260918_013535_absorb_merge/` 的 pre-change 版）
- 新增 `merge_absorbed_points`：吸收路径的批量合并，mu/color/normal 的累积公式与
  `update_hits_onepoint` 逐行一致；normal 更新后重推 `axis1/axis2/quat`。
- **`scale` 完全冻结**：删除了旧版"沿任意轴拉长半径"的漂移来源（原先吸收会扩大半径，
  把 +0.5 盘心拖回角点，并破坏各向同性 S2 定义）。吸收是 9×9 邻域查找（ABSORB_NBR_R=4），
  只把 leftover 像素折进邻近盘、精化其位置/颜色/法向，不动盘覆盖半径。
- 吸收 gate（共面/半径 sagitta/颜色 + 最小切向偏移选盘）不变，只改 gate 通过后的合并段。

## 数字（关老化 `--age-max 1000000 --w-min 0`、开吸收、10 帧，投回第 0 帧）
| 指标 | 原版（S2盘心 N=42235） | 本版（吸收重写 N=42246） |
| --- | --- | --- |
| 最终 N | 42235 | 42246 |
| hard hole | 1.27% | 1.69% |
| EWA hole | 0.56% | 0.68% |
| hard PSNR | 23.55 dB | 23.66 dB |
| EWA PSNR | 26.99 dB | 27.05 dB |

- 帧 0 吸收量 abs=3333 与原版一致（gate 未动），分叉从帧 1 起逐步累积。
- 结论：正确性（吸收与命中同代数、半径冻结）修复后，PSNR 微升、hole 微升、N 微升（+11），
  差异集中在 FOV 边缘增量条带，内部中位深度差 0。
- 产出在 `SEQUENTIAL FRAMES/output_absorb_frozen_render/`（四张图 + model_f0.npz）。

## 复现
```bash
cd "/home/sti/Work/985-3DGS/SEQUENTIAL FRAMES/scripts"
"/home/sti/Work/985-3DGS/SINGLE FRAME/.venv/bin/python" sequential_fusion_flowonly.py \
    --max-pairs 10 --age-max 1000000 --w-min 0 --out ../output_absorb_frozen
"/home/sti/Work/985-3DGS/SINGLE FRAME/.venv/bin/python" render_f0_images.py \
    --frames 11 --out ../output_absorb_frozen_render
```