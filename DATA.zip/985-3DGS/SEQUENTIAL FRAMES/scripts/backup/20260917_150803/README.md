# backup snapshot 2026-09-17 15:08

手动快照（本目录不是 git 仓库，`/home/sti/Work/.git` 实为 Trae 日志目录，不可 `git show` 回溯）。

## 快照内容

- `sequential_fusion_flowonly.py` — 当前（已改）版本：命中分支已换成
  `update_hits_onepoint()`（逐盘单点、半径冻结，去方向漂移）。
- `OPEN_ITEMS.md` — 当前版本文档。
- `sequential_fusion.py` — 旧基线（保留完整「逐像素区域加权」命中代数）。

## 关于被替换掉的旧命中分支（区域加权）

`sequential_fusion_flowonly.py` 里原有的「逐像素区域加权」命中块已在 `fuse_frame()`
内被 `update_hits_onepoint()` 替换掉（原地替换，未另存函数）。那份区域加权代数的
**权威仍存本**在 `scripts/sequential_fusion.py` 第 174–215 行（owner 命中像素 →
按盘累加 `sum_x/sum_c/sum_wp` → 加权平均写 `g.mu` / `g.color`）。flowonly 版本在此
基础上额外多了两条门（颜色门 `COLOR_GATE_K × 9×9 纹理σ`、正常由 3×3 Sobel 查表更新），
这两条的设计记录见 `OPEN_ITEMS.md` §1.1。

> 说明：flowonly 旧命中分支被替换前的逐字节内容未单独留档，本快照以
> `sequential_fusion.py` 的完整区域加权实现 + §1.1 门限说明作为回溯依据。
> 后续每次破坏性改动前，请先在 `backup/<时间戳>/` 快照。