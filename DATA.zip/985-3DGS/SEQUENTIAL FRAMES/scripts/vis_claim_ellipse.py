"""Claim ellipse vs emitted footprint: why tilted discs (low |nz|) can put
centres ~1px apart and still pass the greedy claim.

Greedy claim (coverage_sample_elliptical_fast) claims an ELLIPSE, not a circle:
  * long axis (perpendicular to the tilt direction) = 0.6 * r_proj
  * short axis (along the tilt direction, dir = normalize(nx/fx, ny/fy))
      = 0.6 * r_proj * |nz|

A slanted disc (small |nz|, e.g. the monitor screen) therefore claims a very
flat ellipse in image space, so two centres can be ~1px apart along the tilt
direction and still lie outside each other's claim ellipse. That is the
foreshortening of the disc's ACTUAL image footprint -- not a missing cover.

This draws, zoomed into the left-top (screen) region:
  * RED   = emitted footprint ellipse (full r, what we rasterize)
  * GREEN = claim ellipse (0.6r, flattened by |nz|), the greedy's exclusion zone
  * GREEN dot = disc centre
"""

import sys
from pathlib import Path

import cv2
import numpy as np

SEQ = Path(__file__).resolve().parent
SINGLE = SEQ.parent.parent / "SINGLE FRAME" / "scripts"
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SINGLE))
sys.path.insert(0, str(SFLOW))

import h_pipeline_final as H  # noqa: E402
import incremental_hybrid as INC  # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402
from scene_flow import compute_scene_flow  # noqa: E402
from tum_io import undistort_maps as tu_um, FR1_INTRINSICS as tu_K  # noqa: E402

OUT = SF.SEQ.parent / "output_T_floor3" / "vis"
SCALE = 4
N = 48
TH = np.linspace(0, 2 * np.pi, N, endpoint=False)
X0, Y0, X1, Y1 = 60, 60, 320, 300   # crop window (screen region)


def tangent_basis(n):
    n = n / np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-9)
    ref = np.zeros_like(n, np.float32)
    ref[:, 2] = 1.0
    par = np.abs(n[:, 2]) > 0.9
    ref[par, 2] = 0.0
    ref[par, 0] = 1.0
    e1 = np.cross(ref, n)
    e1 /= np.maximum(np.linalg.norm(e1, axis=1, keepdims=True), 1e-12)
    e2 = np.cross(n, e1)
    return e1, e2


def main() -> None:
    pairs = SF.associate(SF.DATA, max_dt=0.02)[:2]
    h, w = 480, 640
    map1, map2, K = tu_um((h, w), tu_K)

    bgr0, z0, _ = SF.load_pair(pairs, 0, map1, map2)
    g0, _, _ = H.build_hybrid(bgr0, z0, K, SF.TEX_Q)
    model = SF.Model(
        g=g0, w=np.ones(len(g0), np.float32), age=np.zeros(len(g0), np.int32),
        owner=SF.owner_from_raster(g0, K, (h, w)), birth=np.zeros(len(g0), np.int32),
        cnt=np.ones(len(g0), np.float32),
    )
    bgr1, z1, _ = SF.load_pair(pairs, 1, map1, map2)
    dt = pairs[1].t_rgb - pairs[0].t_rgb
    sf = compute_scene_flow(bgr0, bgr1, z0, z1, K, prev=None, dt=dt, prev_dt=1.0)
    ow = SF.warp_owner(model.owner, sf.u, sf.v, sf.valid)
    ow = SF._fill_owner_backward(ow, model.owner, sf)
    leftover = (z1 > SF.Z_MIN) & (z1 < SF.Z_MAX) & (ow < 0)
    g_new = INC.build_hybrid_region(bgr1, z1, K, SF.TEX_Q, leftover)

    rgb = bgr1[..., ::-1].astype(np.float32) / 255.0
    tex = H.texture_mask(rgb, SF.TEX_Q)
    px = g_new.pixel
    is_curv = ~tex[px[:, 1], px[:, 0]]

    fx, fy, cx, cy = K[0, 0], K[1, 1], K[0, 2], K[1, 2]
    fmean = 0.5 * (fx + fy)

    # ---- emitted footprint ellipse (full r) ----
    e1, e2 = tangent_basis(g_new.normal)
    a_emit = g_new.scale[:, 0].astype(np.float64)
    b_emit = g_new.scale[:, 1].astype(np.float64)
    mu = g_new.mu.astype(np.float64)
    nrm = g_new.normal.astype(np.float64)

    def emit_pts(i):
        p = (mu[i][None, :] + (a_emit[i] * np.cos(TH))[:, None] * e1[i][None, :]
             + (b_emit[i] * np.sin(TH))[:, None] * e2[i][None, :])
        z = np.maximum(p[:, 2], 1e-6)
        return np.stack([fx * p[:, 0] / z + cx, fy * p[:, 1] / z + cy], axis=1)

    # ---- claim ellipse (0.6r, flattened by |nz|), dir = normalize(nx/fx, ny/fy)
    diru = nrm[:, 0] / fx
    dirv = nrm[:, 1] / fy
    dn = np.hypot(diru, dirv)
    diru = np.where(dn < 1e-9, 1.0, diru / np.maximum(dn, 1e-9))
    dirv = np.where(dn < 1e-9, 0.0, dirv / np.maximum(dn, 1e-9))
    nz = np.abs(nrm[:, 2])
    proj_r = fmean * a_emit / np.maximum(mu[:, 2], 1e-6)   # full projected long axis
    claim_a = 0.6 * proj_r          # perpendicular to tilt dir
    claim_b = 0.6 * proj_r * nz     # along tilt dir
    pu, pv = -dirv, diru            # perpendicular to dir

    def claim_pts(i):
        cu = fx * mu[i, 0] / max(mu[i, 2], 1e-6) + cx
        cv = fy * mu[i, 1] / max(mu[i, 2], 1e-6) + cy
        x = cu + (claim_a[i] * np.cos(TH)) * pu[i] + (claim_b[i] * np.sin(TH)) * diru[i]
        y = cv + (claim_a[i] * np.cos(TH)) * pv[i] + (claim_b[i] * np.sin(TH)) * dirv[i]
        return np.stack([x, y], axis=1)

    vis = (bgr1.astype(np.float32) * 0.5).astype(np.uint8)
    vis_big = cv2.resize(vis, (w * SCALE, h * SCALE), interpolation=cv2.INTER_NEAREST)

    n_curv_drawn = 0
    for i in range(len(g_new)):
        if not is_curv[i]:
            continue
        # emitted footprint (red)
        epts = np.rint(emit_pts(i) * SCALE).astype(np.int32)
        epts = np.clip(epts, 0, [w * SCALE - 1, h * SCALE - 1])
        cv2.polylines(vis_big, [epts], True, (0, 0, 255), 1, cv2.LINE_AA)
        # claim ellipse (green)
        cpts = np.rint(claim_pts(i) * SCALE).astype(np.int32)
        cpts = np.clip(cpts, 0, [w * SCALE - 1, h * SCALE - 1])
        cv2.polylines(vis_big, [cpts], True, (0, 255, 0), 1, cv2.LINE_AA)
        cu = int(round(fx * mu[i, 0] / max(mu[i, 2], 1e-6) * SCALE))
        cyy = int(round(fy * mu[i, 1] / max(mu[i, 2], 1e-6) * SCALE))
        cv2.circle(vis_big, (cu, cyy), 3, (0, 255, 0), -1, cv2.LINE_AA)
        n_curv_drawn += 1

    # crop window + legend
    crop = vis_big[Y0 * SCALE:Y1 * SCALE, X0 * SCALE:X1 * SCALE]
    bar = np.full((60, crop.shape[1], 3), 25, np.uint8)
    lg = [
        ((0, 0, 255), "emitted footprint (full r)"),
        ((0, 255, 0), "claim ellipse (0.6r, |nz|-flattened): greedy exclusion"),
        ((0, 255, 0), "disc centre (dot)"),
    ]
    y = 8
    for col, name in lg:
        cv2.rectangle(bar, (8, y), (24, y + 14), col, -1)
        cv2.putText(bar, name, (32, y + 12), cv2.FONT_HERSHEY_SIMPLEX, 0.45,
                    (220, 220, 220), 1, cv2.LINE_AA)
        y += 20
    img = np.vstack([crop, bar])
    p = OUT / "claim_ellipse_zoom_screen.png"
    cv2.imwrite(str(p), img)
    print(f"wrote {p}  curv discs drawn={n_curv_drawn}")


if __name__ == "__main__":
    main()