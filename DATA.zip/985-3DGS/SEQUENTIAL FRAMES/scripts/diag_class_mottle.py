"""Which owner class makes frame-0 look mottled ("花")?

For every hard-render pixel, measure how far its colour sits from the local
median of the rendered image (15x15 window) -- a direct proxy for "this pixel
sticks out of its neighbourhood", i.e. visible mottling. Subtract the same
measure taken on the ground-truth frame-0 image, so real image texture is not
charged as dirt. Then attribute the excess to the owner class
(old / old-drifted / later-born on-surface / later-born off-surface).

Run:  python scripts/diag_class_mottle.py
"""

from __future__ import annotations

import sys
from pathlib import Path

import cv2
import numpy as np

SEQ = Path(__file__).resolve().parent
sys.path.insert(0, str(SEQ))

import h_pipeline_final as H          # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402
from diag_left_oldnew_color import tangent_basis  # noqa: E402
from make_owner_vs_hard_montage import caption_bar_legend  # noqa: E402

RUN = SEQ.parent / "output_f0_80frame_A_footprint"
DRIFT_EPS = 0.04
DEPTH_TOL = 0.05
WIN = 15
STICK_T = 0.05            # excess above this = visibly sticking out
PAL = {1: (60, 200, 60), 2: (0, 200, 255), 3: (60, 60, 255), 4: (200, 0, 200)}
NAMES = {1: "old disc, colour unchanged", 2: "old disc, colour drifted >0.04",
         3: "born f1-80, ON f0 surface", 4: "born f1-80, OFF f0 surface"}


def smooth_median(img8: np.ndarray, k: int = WIN) -> np.ndarray:
    return cv2.medianBlur(np.ascontiguousarray(img8), k).astype(np.float32) / 255.0


def main() -> None:
    d = np.load(RUN / "model_f0.npz")
    mu, normal, scale = d["mu"], d["normal"], d["scale"]
    color, birth, birth_color = d["color"], d["birth"], d["birth_color"]
    a1, a2 = tangent_basis(normal)
    g = H.Gaussians(mu=mu, normal=normal, scale=scale, quat=np.zeros((len(mu), 4)),
                    color=color, alpha=np.ones(len(mu)), pixel=np.zeros((len(mu), 2)),
                    axis1=a1, axis2=a2)

    pairs = SF.associate(SF.DATA, max_dt=0.02)[:81]
    sample = SF.load_rgb(pairs[0].rgb_path)
    h, w = sample.shape[:2]
    map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)
    bgr0, z0, _ = SF.load_pair(pairs, 0, map1, map2)
    gt = bgr0[..., ::-1].astype(np.float32) / 255.0
    gt8 = (gt * 255).astype(np.uint8)

    depth, index, _ = H.rasterize_discs(g, K, (h, w))
    hit = index >= 0
    own = index[hit]
    b = birth[own]

    dc = np.linalg.norm(color - birth_color, axis=1)
    dz = np.abs(depth[hit] - z0[hit]) / np.maximum(z0[hit], 1e-6)

    cls = np.zeros((h, w), np.uint8)
    dc_px = np.zeros((h, w), np.float32); dc_px[hit] = dc[own]
    b_px = np.full((h, w), -1, np.int32); b_px[hit] = b
    oldm = hit & (b_px == 0)
    newm = hit & (b_px >= 1)
    cls[oldm & (dc_px <= DRIFT_EPS)] = 1
    cls[oldm & (dc_px > DRIFT_EPS)] = 2
    on_surf = np.zeros((h, w), bool); on_surf[hit] = dz < DEPTH_TOL
    cls[newm & on_surf] = 3
    cls[newm & ~on_surf] = 4

    # hard render colours; holes filled with the GT frame so they create no edges
    render = gt.copy()
    render[hit] = color[own].astype(np.float32)
    r8 = (np.clip(render, 0, 1) * 255).astype(np.uint8)

    stick_r = np.abs(smooth_median(r8) - render).mean(axis=2)
    stick_g = np.abs(smooth_median(gt8) - gt).mean(axis=2)
    excess = stick_r - stick_g                      # > 0 = dirtier than the real image

    print(f"window={WIN}px  hit={int(hit.sum())} ({100 * hit.mean():.2f}%)")
    print(f"image-level stick-out: render={stick_r[hit].mean():.4f}  "
          f"GT={stick_g[hit].mean():.4f}  excess={excess[hit].mean():.4f}")
    print("\nclass                              px     mottle(stick)  excess  "
          "px excess>0.05   share of total excess")
    tot = excess[hit].clip(0).sum()
    for k in (1, 2, 3, 4):
        m = hit & (cls == k)
        if not m.any():
            continue
        e = excess[m]
        print(f"{NAMES[k]:33s} {int(m.sum()):6d}   {stick_r[m].mean():.4f}      "
              f"{e.mean():+.4f}   {100 * float((e > STICK_T).mean()):5.2f}%        "
              f"{100 * float(e.clip(0).sum() / tot):5.1f}%")

    # left band, where the user's complaint lives
    for x0, x1 in [(0, 128), (128, w)]:
        band = np.zeros((h, w), bool); band[:, x0:x1] = True
        print(f"\n  band x[{x0},{x1}) excess by class (mean / px>0.05% / share):")
        band_tot = excess[band & hit].clip(0).sum()
        for k in (1, 2, 3, 4):
            m = band & hit & (cls == k)
            if not m.any():
                continue
            e = excess[m]
            print(f"    {NAMES[k]:33s} n={int(m.sum()):6d}  mean={e.mean():+.4f}  "
                  f"px>0.05={100 * float((e > STICK_T).mean()):5.2f}%  "
                  f"share={100 * float(e.clip(0).sum() / band_tot):5.1f}%")

    # how wrong are the colours themselves (vs the f0 image), by class
    err = np.zeros((h, w), np.float32)
    err[hit] = np.linalg.norm(color[own] - gt[hit], axis=1)
    print("\ncolour error vs f0 image, by class (mean |dRGB|):")
    for k in (1, 2, 3, 4):
        m = hit & (cls == k)
        if m.any():
            print(f"  {NAMES[k]:33s} {err[m].mean():.4f}")

    # ---- visual: render | excess heat | class map ----
    heat = cv2.applyColorMap(np.clip(excess * 255 * 4, 0, 255).astype(np.uint8),
                             cv2.COLORMAP_JET)
    heat[~hit] = (18, 18, 18)
    clsm = (gt * 0.30 * 255).astype(np.uint8).copy()
    for k, c in PAL.items():
        clsm[cls == k] = c
    rvis = (np.clip(render, 0, 1) * 255).astype(np.uint8)[..., ::-1].copy()
    rvis[~hit] = 0
    mon = np.hstack([rvis, heat, clsm])
    legend = [("green", f"{NAMES[1]}"),
              ("yellow", f"{NAMES[2]}"),
              ("blue", f"{NAMES[3]}"),
              ("magenta", f"{NAMES[4]}")]
    cap = [(None, "frame-0, 80-frame model (footprint relink) -- LEFT: hard ray "
                  "render | MID: stick-out heat (|pixel - 15px local median| minus "
                  "the same measured on the GT frame) | RIGHT: owner class")] + legend
    tot_by = {k: excess[hit & (cls == k)].clip(0).sum() / tot for k in (1, 2, 3, 4)}
    cap += [(None, "share of the image's total mottle excess: "
                   + "  ".join(f"{NAMES[k].split(',')[0]}={100 * tot_by[k]:.0f}%"
                               for k in (1, 2, 3, 4)))]
    out = caption_bar_legend(mon, cap)
    out = cv2.resize(out, None, fx=1.4, fy=1.4, interpolation=cv2.INTER_NEAREST)
    dst = RUN / "diag_class_mottle.png"
    cv2.imwrite(str(dst), out)
    print("\nsaved ->", dst)


if __name__ == "__main__":
    main()