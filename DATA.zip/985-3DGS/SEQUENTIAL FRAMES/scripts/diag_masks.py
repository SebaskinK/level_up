"""Check masks at the desk-edge region (frame 0) to find which boundary fires."""
import sys
from pathlib import Path

import numpy as np

SEQ = Path(__file__).resolve().parent
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SEQ))
sys.path.insert(0, str(SFLOW))

import h_pipeline_final as H  # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402

pairs = SF.associate(SF.DATA, max_dt=0.02)[:1]
h, w = SF.load_rgb(pairs[0].rgb_path).shape[:2]
map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)
bgr0, z0, _ = SF.load_pair(pairs, 0, map1, map2)

geo = H.compute_scene_geometry(
    z0, K, H.GEO_CFG["eps"], H.GEO_CFG["gauss_sigma"], H.GEO_CFG["disc_rel"],
)
rgb = bgr0[..., ::-1].astype(np.float32) / 255.0
tex_mask = H.texture_mask(rgb, SF.TEX_Q)

disc = H.depth_discontinuity_mask(z0, H.GEO_CFG["disc_rel"], valid=geo.valid_depth)
jump = H.depth_jump_mask(z0, H.GEO_CFG["disc_rel"], valid=geo.valid_depth)

print("x=560 vertical profile (y, z, valid, tex, disc, jump, r_edge, r_fp):")
for y in range(270, 400, 8):
    z = z0[y, 560]
    print(f"  y={y:3d} z={z:5.2f} valid={bool(geo.valid_depth[y,560])} "
          f"tex={bool(tex_mask[y,560])} disc={bool(disc[y,560])} "
          f"jump={bool(jump[y,560])} r_edge={geo.r_edge[y,560]:.4f} "
          f"r_fp={geo.r_fp[y,560]:.4f}")

band = tex_mask[260:410, 380:640]
print("\ntex_mask frac in desk band:", band.mean())
print("depth_jump frac in desk band:", jump[260:410, 380:640].mean())
print("depth_discontinuity frac in desk band:", disc[260:410, 380:640].mean())
print("valid_depth frac in desk band:", geo.valid_depth[260:410, 380:640].mean())