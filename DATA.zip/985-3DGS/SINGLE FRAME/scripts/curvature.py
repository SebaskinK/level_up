"""Analytic principal curvature from a depth map.

Experiment B hit a wall: an isotropic disc of radius r needs normal accuracy
better than arctan(eps/r), and the measured normal floor (6.8 deg) only supports
~5 mm discs. That bound assumes the disc must stay flat against a surface that
curves equally in all directions.

Sizing by curvature instead removes that assumption. A disc of radius r on a
surface of normal curvature k deviates from its own plane by the sagitta

    sag ~= 0.5 * k * r^2

so bounding sag <= eps gives a per-direction radius limit

    r(k) = sqrt(2 eps / |k|)

which is anisotropic: along a cylinder's axis k -> 0 and the disc may stretch,
around its circumference k is large and the disc must stay thin. A quadtree
block cannot express this -- its discs are isotropic and its boundaries are
axis-aligned.

Curvature is a second-order quantity, so it is more noise-sensitive than the
normal. Everything here is validated against closed-form ground truth on
synthetic surfaces first (see exp_d_curvature.py).
"""

from __future__ import annotations

import cv2
import numpy as np

_QUAD_CACHE: dict[int, dict[str, np.ndarray]] = {}


def quadric_kernels(win: int) -> dict[str, np.ndarray]:
    """Derivative filters from a least-squares quadric fit over a win x win box.

    Fitting z = a u^2 + b uv + c v^2 + d u + e v + f and reading off the
    coefficients gives zuu = 2a, zuv = b, zvv = 2c, zu = d, zv = e. Each
    coefficient is a linear functional of the window, so it is a fixed
    correlation kernel -- one convolution per derivative, no per-pixel solve.

    The point of doing it this way rather than Gaussian-blur-then-Sobel is that
    the support is EXACTLY win x win and stated up front. With a Gaussian the
    support is ~3 sigma and only implicit, which is how the estimate ended up
    describing a different neighbourhood than the disc it was sizing.
    """
    cached = _QUAD_CACHE.get(win)
    if cached is not None:
        return cached
    r = win // 2
    us, vs = np.meshgrid(
        np.arange(-r, r + 1, dtype=np.float64),
        np.arange(-r, r + 1, dtype=np.float64),
    )
    u, v = us.ravel(), vs.ravel()
    A = np.stack([u * u, u * v, v * v, u, v, np.ones_like(u)], axis=1)
    P = np.linalg.pinv(A)

    def k(i: int, scale: float) -> np.ndarray:
        # cv2.filter2D CORRELATES, and P[i].reshape(win, win) is already in
        # correlation layout (row = v + r, col = u + r) -- so no flip. The
        # [::-1, ::-1] that used to be here (with the comment "flip to get a
        # convolution") was the bug: it maps (u, v) -> (-u, -v), which leaves
        # zuu/zvv/zuv alone but negates zu/zv. Fixed 2026-09-16 together with
        # h_pipeline_final.quadric_kernels; see scripts/h_quadric_sign.py.
        # NOTE: experiment numbers in EXPERIMENT_D/E/G predate this fix.
        return (scale * P[i].reshape(win, win)).astype(np.float32)

    out = {
        "zuu": k(0, 2.0), "zuv": k(1, 1.0), "zvv": k(2, 2.0),
        "zu": k(3, 1.0), "zv": k(4, 1.0),
    }
    _QUAD_CACHE[win] = out
    return out


def _derivatives(z: np.ndarray, win: int = 0) -> tuple[np.ndarray, ...]:
    """First and second image-space derivatives of depth.

    win > 0 selects the quadric-fit operator with an explicit win x win support;
    win = 0 keeps the original Gaussian-blur-then-Sobel path, which the
    synthetic comparisons in exp_f still reference.
    """
    if win and win >= 3:
        K = quadric_kernels(win)
        d = {
            name: cv2.filter2D(z, cv2.CV_32F, K[name], borderType=cv2.BORDER_REPLICATE)
            for name in ("zu", "zv", "zuu", "zvv", "zuv")
        }
        return d["zu"], d["zv"], d["zuu"], d["zvv"], d["zuv"]
    zu = cv2.Sobel(z, cv2.CV_32F, 1, 0, ksize=3) / 8.0
    zv = cv2.Sobel(z, cv2.CV_32F, 0, 1, ksize=3) / 8.0
    zuu = cv2.Sobel(z, cv2.CV_32F, 2, 0, ksize=3) / 4.0
    zvv = cv2.Sobel(z, cv2.CV_32F, 0, 2, ksize=3) / 4.0
    zuv = cv2.Sobel(zu, cv2.CV_32F, 0, 1, ksize=3) / 8.0
    return zu, zv, zuu, zvv, zuv


def principal_curvatures(
    z: np.ndarray, K: np.ndarray, win: int = 0
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Principal curvatures and their image-space directions.

    Returns (k1, k2, dir1, valid) with |k1| >= |k2|, in 1/m. Sign follows the
    camera-facing normal, so a convex surface reads negative; only magnitude
    matters for sizing a disc.

    Uses the standard first/second fundamental forms of the parametric surface
    P(u, v) = z(u, v) * K^-1 [u, v, 1]:

        E = Pu.Pu   F = Pu.Pv   G = Pv.Pv
        L = Puu.n   M = Puv.n   N = Pvv.n

    The shape operator is S = I^-1 II, whose eigenvalues are the principal
    curvatures. Working in the image parameterisation rather than an arc-length
    one keeps every term a plain finite difference.
    """
    h, w = z.shape
    fx, fy, cx, cy = K[0, 0], K[1, 1], K[0, 2], K[1, 2]
    us, vs = np.meshgrid(
        np.arange(w, dtype=np.float32), np.arange(h, dtype=np.float32)
    )
    a = (us - cx) / fx
    b = (vs - cy) / fy

    zu, zv, zuu, zvv, zuv = _derivatives(z, win)

    # P = z * [a, b, 1]; a_u = 1/fx, b_v = 1/fy, all other parameter derivs zero.
    Pu = np.stack([zu * a + z / fx, zu * b, zu], axis=-1)
    Pv = np.stack([zv * a, zv * b + z / fy, zv], axis=-1)
    Puu = np.stack([zuu * a + 2.0 * zu / fx, zuu * b, zuu], axis=-1)
    Pvv = np.stack([zvv * a, zvv * b + 2.0 * zv / fy, zvv], axis=-1)
    Puv = np.stack([zuv * a + zv / fx, zuv * b + zu / fy, zuv], axis=-1)

    nvec = np.cross(Pu, Pv)
    nlen = np.linalg.norm(nvec, axis=-1)
    ok = nlen > 1e-12
    n = nvec / np.where(ok, nlen, 1.0)[..., None]
    flip = n[..., 2] > 0
    n[flip] *= -1.0

    E = np.einsum("ijk,ijk->ij", Pu, Pu)
    F = np.einsum("ijk,ijk->ij", Pu, Pv)
    G = np.einsum("ijk,ijk->ij", Pv, Pv)
    L = np.einsum("ijk,ijk->ij", Puu, n)
    M = np.einsum("ijk,ijk->ij", Puv, n)
    N = np.einsum("ijk,ijk->ij", Pvv, n)

    det_I = E * G - F * F
    ok &= np.abs(det_I) > 1e-20
    inv = np.where(ok, 1.0 / np.where(ok, det_I, 1.0), 0.0)

    # S = I^-1 II, written out so no per-pixel 2x2 solve is needed.
    s11 = (G * L - F * M) * inv
    s12 = (G * M - F * N) * inv
    s21 = (E * M - F * L) * inv
    s22 = (E * N - F * M) * inv

    tr = s11 + s22
    det = s11 * s22 - s12 * s21
    disc = np.maximum(0.25 * tr * tr - det, 0.0)
    root = np.sqrt(disc)
    ka = 0.5 * tr + root
    kb = 0.5 * tr - root

    # Order by |k|, not by signed value. What bounds the disc radius is how
    # sharply the surface bends, regardless of which way. With the normal facing
    # the camera a convex surface has negative curvature, so signed ordering
    # would report a cylinder as k1 = 0 and put the flat direction first.
    swap = np.abs(kb) > np.abs(ka)
    k1 = np.where(swap, kb, ka)
    k2 = np.where(swap, ka, kb)

    # Eigenvector of S for k1, in (du, dv). Pick whichever row is better
    # conditioned; at umbilic points any direction is principal.
    d1 = np.stack([s12, k1 - s11], axis=-1)
    d2 = np.stack([k1 - s22, s21], axis=-1)
    use1 = np.linalg.norm(d1, axis=-1) >= np.linalg.norm(d2, axis=-1)
    dirs = np.where(use1[..., None], d1, d2)
    dl = np.linalg.norm(dirs, axis=-1)
    degenerate = dl < 1e-12
    dirs = dirs / np.where(degenerate, 1.0, dl)[..., None]
    dirs[degenerate] = np.array([1.0, 0.0], dtype=np.float32)

    ok &= np.isfinite(k1) & np.isfinite(k2)
    return (
        k1.astype(np.float32),
        k2.astype(np.float32),
        dirs.astype(np.float32),
        ok,
    )


def curvature_radii(
    k1: np.ndarray, k2: np.ndarray, eps: float
) -> tuple[np.ndarray, np.ndarray]:
    """Radii whose sagitta stays within eps: r = sqrt(2 eps / |k|).

    k1 is the larger-magnitude principal curvature, so r1 <= r2 and the disc is
    thin across the sharply curved direction and long along the flat one.
    """
    r1 = np.sqrt(2.0 * eps / np.maximum(np.abs(k1), 1e-9))
    r2 = np.sqrt(2.0 * eps / np.maximum(np.abs(k2), 1e-9))
    return r1.astype(np.float32), r2.astype(np.float32)


def scale_space_curvature(
    z: np.ndarray, K: np.ndarray, win: int = 9,
):
    """Curvature from an already-differentiated-on smoothed depth map.

    The Gaussian smoothing happens in the CALLER (prefilter_depth/masked_gauss),
    not here: the normal and the curvature must read the SAME smoothed surface,
    i.e. one gauss_sigma for both. This function previously blurred again
    internally, which made the curvature effective sigma sqrt(2) larger than the
    normal's -- the normal saw 1x sigma, the curvature 2x sigma -- re-opening
    exactly the normal/curvature scale mismatch that switching to a Gaussian was
    meant to close. Differentiate the caller-supplied smoothed depth instead.

    win sets the derivative stencil to an explicit win x win quadric fit, so the
    neighbourhood the curvature actually saw is stated rather than implied by a
    Gaussian tail. That mismatch was the bug: 3x3 Sobel on sigma=3 blur sees
    ~17 mm at z=1 m, but the radius it produced reached 50 mm, so the disc
    covered ground the curvature never measured. Normals at those centres were
    23 deg off truth versus 6.6 deg at random pixels.

    Known cost of the win x win quadric: a sphere reads high, because a 9 px
    window spans enough arc that third-order terms leak into the second-order
    coefficients (R=1.0 m reads |k| 2.43 vs 1.00). Planes and cylinders are
    unaffected -- their zero-curvature direction stays at 0.001 -- so on a desk
    scene the error is conservative: over-reported curvature only shrinks discs.

    Empirical trade-off (from experiment D):
      * disc radius limit r_max = sqrt(2 eps / k_spur) grows with sigma
      * but a real feature degrades when its pixel radius is below ~8x sigma,
        so sigma=3 preserves ~25 px structures at 2 m (about 100 mm)

    Returns (k1, k2, dir1_3d, valid, dir1_img). dir1_3d is the tangent
    direction (in the camera frame) along which the disc is thinnest; the long
    direction is perpendicular to it and to the normal. dir1_img is the same
    direction as an image-space (du, dv) unit vector, which is what an
    elliptical pixel footprint needs.
    """
    k1, k2, dirs_img, valid = principal_curvatures(z, K, win=win)

    h, w = z.shape
    fx, fy, cx, cy = K[0, 0], K[1, 1], K[0, 2], K[1, 2]
    us, vs = np.meshgrid(
        np.arange(w, dtype=np.float32), np.arange(h, dtype=np.float32)
    )
    zu = cv2.Sobel(z, cv2.CV_32F, 1, 0, ksize=3) / 8.0
    zv = cv2.Sobel(z, cv2.CV_32F, 0, 1, ksize=3) / 8.0
    a = (us - cx) / fx
    b = (vs - cy) / fy
    Pu = np.stack([a * zu + z / fx, b * zu, zu], axis=-1)
    Pv = np.stack([a * zv, b * zv + z / fy, zv], axis=-1)

    # Tangent along the image direction dirs_img = (du, dv).
    du = dirs_img[..., 0]
    dv = dirs_img[..., 1]
    t1 = Pu * du[..., None] + Pv * dv[..., None]
    t1 = t1 / np.maximum(np.linalg.norm(t1, axis=-1, keepdims=True), 1e-12)
    return k1, k2, t1, valid, dirs_img
