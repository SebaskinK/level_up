"""Left-edge newborn discs vs nearest old disc: per-gate funnel with the NEW colour gate.

Answers "which gate the newborn discs got stuck at" for the light_gate run, using
the split colour gate (spatial texture + temporal lighting, in quadrature):

    budget = sqrt( (K * sigma_tex)^2 + min(COLOR_LIGHT_RATE * age, COLOR_LIGHT_MAX)^2 )

The temporal term needs the OLD disc's age at the revisit instant, which is not in
model_f0.npz, so the colour gate is reported at several representative ages
(0 / 1 / 8 / 21+) to show the sensitivity. sigma_tex is the real frame-0 9x9
texture std at the old disc's projected pixel (not just the floor).

Usage:
    python diag_gate_funnel.py <output_dir> [--left-u 80]
"""
from __future__ import annotations

import sys
from pathlib import Path

import cv2
import numpy as np
from scipy.spatial import cKDTree

SEQ = Path(__file__).resolve().parent
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
SINGLE = SEQ.parent.parent / "SINGLE FRAME" / "scripts"
sys.path.insert(0, str(SFLOW))
sys.path.insert(0, str(SINGLE))
sys.path.insert(0, str(SEQ))

import h_pipeline_final as H                        # noqa: E402
import sequential_fusion_flowonly as SF             # noqa: E402

K_SIGMA = SF.K_SIGMA
FX, FY, CX, CY = 517.306408, 516.469215, 318.643040, 255.313989


def depth_sigma(z: np.ndarray, sigma_ref: float = 0.0031, z_ref: float = 0.75):
    return sigma_ref * (np.maximum(z, 0.3) / z_ref) ** 1.33


def pct(a, p):
    return float(np.percentile(a, p)) if a.size else float("nan")


def main() -> None:
    out = Path(sys.argv[1])
    left_u = float(sys.argv[sys.argv.index("--left-u") + 1]) if "--left-u" in sys.argv else 80.0

    d = np.load(out / "model_f0.npz")
    mu = d["mu"].astype(np.float64)
    normal = d["normal"].astype(np.float64)
    color = d["color"].astype(np.float64)
    birth = d["birth"].astype(np.int32)
    scale = d["scale"].astype(np.float64)

    n = normal / np.maximum(np.linalg.norm(normal, axis=1, keepdims=True), 1e-12)
    zc = mu[:, 2]
    u = FX * mu[:, 0] / np.maximum(zc, 1e-6) + CX
    v = FY * mu[:, 1] / np.maximum(zc, 1e-6) + CY

    # frame-0 RGB for the real spatial texture std at each old disc's pixel
    pairs = SF.associate(SF.DATA, max_dt=0.02)
    sample = SF.load_rgb(pairs[0].rgb_path)
    h0, w0 = sample.shape[:2]
    map1, map2, K = SF.undistort_maps((h0, w0), SF.FR1_INTRINSICS)
    bgr0, z0, _ = SF.load_pair(pairs, 0, map1, map2)
    rgb0 = bgr0[..., ::-1].astype(np.float32) / 255.0
    var0 = H.texture_variance(rgb0, win=9)
    sigma0 = np.sqrt(np.maximum(var0, H.TEX_VAR_THR))          # (H, W) real spatial std

    old = birth == 0
    new = birth > 0
    left_new = new & (u < left_u)
    print(f"N={len(mu)}  old(birth0)={int(old.sum())}  new={int(new.sum())}  "
          f"left-edge new (u<{left_u:g})={int(left_new.sum())}")

    # nearest EARLIER-born disc among k neighbours (stacking onto any prior frame,
    # not only frame 0). A disc whose k neighbours are all born at/after it has no
    # older disc to fuse into at birth -> genuinely new territory.
    kk = 24
    lnew_idx = np.flatnonzero(left_new)
    birth_l = birth[left_new]
    tree = cKDTree(mu)
    d3k, jk = tree.query(mu[lnew_idx], k=kk)
    if kk == 1:
        d3k = d3k[:, None]
        jk = jk[:, None]
    d3 = np.full(lnew_idx.shape[0], np.inf)
    j = np.full(lnew_idx.shape[0], -1, dtype=np.int64)
    for kk_i in range(kk):
        nn = jk[:, kk_i]
        is_earlier = birth[nn] < birth_l
        take = is_earlier & (d3k[:, kk_i] < d3)
        d3[take] = d3k[take, kk_i]
        j[take] = nn[take]
    has_older = j >= 0

    mu_o = np.where(has_older[:, None], mu[j], 0.0)
    n_o = np.where(has_older[:, None], n[j], 0.0)
    c_o = np.where(has_older[:, None], color[j], 0.0)
    mu_n = mu[lnew_idx]
    n_n = n[lnew_idx]
    c_n = color[lnew_idx]
    birth_n = birth_l

    # no-older entries (j==-1) carry junk in mu_o/n_o/c_o; exclude from every stat.
    jc = np.where(has_older, j, 0)
    mu_o = mu[jc]
    n_o = n[jc]
    c_o = color[jc]

    plane = np.abs(np.einsum("ij,ij->i", mu_n - mu_o, n_o))
    off = mu_n - mu_o
    off_t = off - np.einsum("ij,ij->i", off, n_o)[:, None] * n_o   # in-plane (tangential) offset
    tan = np.linalg.norm(off_t, axis=1)
    dot = np.clip(np.abs(np.einsum("ij,ij->i", n_n, n_o)), 0.0, 1.0)
    ang = np.degrees(np.arccos(dot))
    dcol = np.linalg.norm(c_n - c_o, axis=1)
    # older disc footprint radius = max principal radius (absorb's tangential-offset
    # budget is the curvature sagitta r_k, but the disc's own radius bounds how far
    # its footprint legally reaches).
    r_o = np.maximum(scale[jc, 0], scale[jc, 1])

    gate_p = K_SIGMA * depth_sigma(mu_o[:, 2])
    plane_pass = plane < gate_p
    norm_pass = ang < 30.0
    # absorb-only gate: tangential offset within the older disc's footprint radius.
    radius_pass = tan <= r_o

    # real spatial std at the older disc's projected pixel (clamped to valid image)
    up = np.clip(np.rint(u[jc]).astype(np.int32), 0, w0 - 1)
    vp = np.clip(np.rint(v[jc]).astype(np.int32), 0, h0 - 1)
    sig_tex = sigma0[vp, up]

    print(f"\nleft-edge NEWBORN disc vs NEAREST EARLIER-BORN disc, per-gate:")
    print(f"  with older nbr (within k={kk}): {int(has_older.sum())}/{int(left_new.sum())} "
          f"({100*has_older.mean():.1f}%)")
    m = has_older
    print(f"  [older-nbr subset] 3D dist   med={np.median(d3[m]):.4f} "
          f"p75={pct(d3[m],75):.4f} p90={pct(d3[m],90):.4f}")
    print(f"  point-plane    med={np.median(plane[m]):.5f}  (budget med={np.median(gate_p[m]):.5f})")
    print(f"  tangent (in-plane) offset med={np.median(tan[m]):.4f} "
          f"(older radius med={np.median(r_o[m]):.4f})")
    print(f"  normal angle   med={np.median(ang[m]):.2f} deg   [NOT a pipeline gate -- diagnostic only]")
    print(f"  colour dist    med={np.median(dcol[m]):.4f} p75={pct(dcol[m],75):.4f} p90={pct(dcol[m],90):.4f}")
    print(f"  texture sigma  med={np.median(sig_tex[m]):.4f} p90={pct(sig_tex[m],90):.4f}")

    ov = has_older & (d3 < 0.05)
    print(f"\nOVERLAP (older nbr & 3D<5cm, true stacking/revisit candidates): "
          f"{int(ov.sum())}/{int(left_new.sum())} ({100*ov.mean():.1f}%)")

    # funnel over the OVERLAP set only
    if ov.any():
        p_ov = plane_pass[ov]
        n_ov = norm_pass[ov]
        r_ov = radius_pass[ov]
        print(f"  of overlap: plane pass    {int(p_ov.sum())}/{int(ov.sum())} ({100*p_ov.mean():.1f}%)")
        print(f"              radius pass   {int(r_ov.sum())}/{int(ov.sum())} ({100*r_ov.mean():.1f}%)  [absorb-only gate]")
        print(f"              normal<30     {int(n_ov.sum())}/{int(ov.sum())} ({100*n_ov.mean():.1f}%)  [not a gate]")
        pr = p_ov & r_ov
        print(f"              plane&radius  {int(pr.sum())}/{int(ov.sum())} ({100*pr.mean():.1f}%)")
        print(f"\n  colour gate (spatial=K*sigma_tex, temporal=min(rate*age,max)) over overlap:")
        k = SF.COLOR_GATE_K
        for age, tag in [(0, "age=0 (spatial only)"),
                         (1, "age=1"),
                         (8, "age=8"),
                         (21, "age=21+ (temporal capped)")]:
            light = np.minimum(SF.COLOR_LIGHT_RATE * age, SF.COLOR_LIGHT_MAX)
            budget = np.sqrt((k * sig_tex[ov]) ** 2 + light ** 2)
            cpass = dcol[ov] <= budget
            print(f"    {tag:26s} budget med={np.median(budget):.4f}  "
                  f"colour pass={int(cpass.sum())}/{int(ov.sum())} ({100*cpass.mean():.1f}%)")
        # -- the two ACTUAL gate stacks the pipeline offers a leftover pixel --
        # (a) relink: plane + colour          (no radius gate)
        # (b) absorb: plane + radius + colour (no normal gate)
        # A pixel only becomes a NEW disc if BOTH reject it. Report both at age21+.
        c21 = dcol[ov] <= np.sqrt((k * sig_tex[ov]) ** 2 + SF.COLOR_LIGHT_MAX ** 2)
        relink_acc = p_ov & c21
        absorb_acc = p_ov & r_ov & c21
        print(f"\n  ACTUAL gates (age21+, capped temporal):")
        print(f"    relink path (plane&colour)      passes {int(relink_acc.sum())}/{int(ov.sum())} "
              f"({100*relink_acc.mean():.1f}%)")
        print(f"    absorb path (plane&radius&col)  passes {int(absorb_acc.sum())}/{int(ov.sum())} "
              f"({100*absorb_acc.mean():.1f}%)")

        res = ~relink_acc & ~absorb_acc
        # classify the reason (order: any plane-only fail, then radius-only, then colour-only)
        fail_p = res & ~p_ov
        fail_r = res & p_ov & ~r_ov
        fail_c = res & p_ov & r_ov
        print(f"\n  residual (neither relink nor absorb could claim it): {int(res.sum())}/{int(ov.sum())} "
              f"({100*res.mean():.1f}%)")
        if res.any():
            print(f"      plane-only fail   = {int(fail_p.sum())} ({100*fail_p.sum()/res.sum():.1f}%)")
            print(f"      radius-only fail  = {int(fail_r.sum())} ({100*fail_r.sum()/res.sum():.1f}%)")
            print(f"      colour-only fail  = {int(fail_c.sum())} ({100*fail_c.sum()/res.sum():.1f}%)")

    # birth histogram of the left-edge newborns (where in the run they appear)
    print(f"\nleft-edge newborn birth hist (10-frame bins): "
          f"{np.bincount(np.clip(birth_n // 10, 0, 9), minlength=10).tolist()}")


if __name__ == "__main__":
    main()