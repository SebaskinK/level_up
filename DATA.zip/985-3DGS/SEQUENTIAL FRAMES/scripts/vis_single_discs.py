"""Single-frame (frame 0) full build: every disc centre + projected footprint.

Same drawing convention as vis_new_discs/vis_claim_ellipse: RED = curvature
discs, BLUE = S2 (texture footprint) discs; a filled dot of the same colour is
the disc centre. 4x nearest upscale so small discs are legible.

The footprint ellipse is the perspective image of the 3D disc boundary (full r,
same as rasterize_discs' hard footprint). Orientation: the single-frame concat
also drops axis1/axis2, so anisotropic orientation is the tangent basis (size
preserved, direction approximate) -- same caveat as the incremental plots.
"""

import sys
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parent
SINGLE = ROOT.parent.parent / "SINGLE FRAME" / "scripts"
sys.path.insert(0, str(SINGLE))

import h_pipeline_final as H  # noqa: E402

OUT = H.ROOT.parent / "output_H_singledisc"
SCALE = 4
N = 48
TH = np.linspace(0, 2 * np.pi, N, endpoint=False)


def tangent_basis(n):
    n = n / np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-9)
    ref = np.zeros_like(n, np.float32)
    ref[:, 2] = 1.0
    par = np.abs(n[:, 2]) > 0.9
    ref[par, 2] = 0.0
    ref[par, 0] = 1.0
    e1 = np.cross(ref, n)
    e1 /= np.maximum(np.linalg.norm(e1, axis=1, keepdims=True), 1e-12)
    e2 = np.cross(n, e1)
    return e1, e2


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    # single-frame path: H's own (full-precision) intrinsics + associate
    d = Path("/home/sti/Work/986-SceneFlow/rgbd_dataset_freiburg1_desk")
    pairs = H.associate(d)
    fr = pairs[0]
    map1, map2, K = H.undistort_maps((480, 640), H.FR1_INTRINSICS)
    bgr = H.remap_rgb(H.load_rgb(fr.rgb_path), map1, map2)
    z = H.remap_depth(H.load_depth(fr.depth_path), map1, map2)
    z[(z < H.GEO_CFG["z_min"]) | (z > H.GEO_CFG["z_max"])] = 0.0

    g, keep_geo, tex = H.build_hybrid(bgr, z, K, 0.6)
    px = g.pixel
    is_tex = tex[px[:, 1], px[:, 0]]          # S2 disc
    is_curv = ~is_tex

    fx, fy, cx, cy = K[0, 0], K[1, 1], K[0, 2], K[1, 2]
    e1, e2 = tangent_basis(g.normal)
    a = g.scale[:, 0].astype(np.float64)
    b = g.scale[:, 1].astype(np.float64)
    mu = g.mu.astype(np.float64)

    vis = (bgr.astype(np.float32) * 0.5).astype(np.uint8)
    vis_big = cv2.resize(vis, (640 * SCALE, 480 * SCALE), interpolation=cv2.INTER_NEAREST)

    def draw(g_, sel, color):
        for i in np.nonzero(sel)[0]:
            p3 = (mu[i][None, :] + (a[i] * np.cos(TH))[:, None] * e1[i][None, :]
                  + (b[i] * np.sin(TH))[:, None] * e2[i][None, :])
            zz = np.maximum(p3[:, 2], 1e-6)
            u = fx * p3[:, 0] / zz + cx
            v = fy * p3[:, 1] / zz + cy
            pts = np.rint(np.stack([u, v], axis=1) * SCALE).astype(np.int32)
            cv2.polylines(vis_big, [pts], True, color, 1, cv2.LINE_AA)
            cu = int(round((fx * mu[i, 0] / max(mu[i, 2], 1e-6) + cx) * SCALE))
            cv_ = int(round((fy * mu[i, 1] / max(mu[i, 2], 1e-6) + cy) * SCALE))
            cv2.circle(vis_big, (cu, cv_), 3, color, -1, cv2.LINE_AA)

    draw(g, is_curv, (0, 0, 255))   # red  = curvature
    draw(g, is_tex, (255, 0, 0))    # blue = S2 (texture)

    bar = np.full((64, 640 * SCALE, 3), 25, np.uint8)
    lg = [
        ((0, 0, 255), f"curvature disc  n={int(is_curv.sum())}"),
        ((255, 0, 0), f"S2 (texture) disc  n={int(is_tex.sum())}"),
    ]
    y = 8
    for col, name in lg:
        cv2.rectangle(bar, (8, y), (24, y + 14), col, -1)
        cv2.putText(bar, name, (32, y + 12), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                    (220, 220, 220), 1, cv2.LINE_AA)
        y += 22
    cv2.putText(bar, f"frame 0 single-frame build, N={len(g)}  (outline = projected "
                     f"footprint, dot = centre, 4x)",
                (8, y + 6), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (220, 220, 220), 1, cv2.LINE_AA)

    img = np.vstack([vis_big, bar])
    p = OUT / "single_frame_discs.png"
    cv2.imwrite(str(p), img)
    print(f"wrote {p}  N={len(g)}  curv={int(is_curv.sum())}  s2={int(is_tex.sum())}")


if __name__ == "__main__":
    main()