"""Crop GT vs hard ray render over rows 370-400, cols 600-640 and compute the
difference, to expose the user's 3 vertical cracks. Saves a 3-panel composite.
"""
from __future__ import annotations
from pathlib import Path

import numpy as np
import cv2

OUT = Path(__file__).resolve().parent.parent / "output_f0_ellipse_final"
R0, R1 = 370, 400
C0, C1 = 600, 640
SCALE = 6


def main():
    gt = cv2.imread(str(OUT / "f0_gt.png"))
    hard = cv2.imread(str(OUT / "f0_hard.png"))

    gt_g = cv2.cvtColor(gt, cv2.COLOR_BGR2GRAY).astype(np.float32)
    hard_g = cv2.cvtColor(hard, cv2.COLOR_BGR2GRAY).astype(np.float32)
    diff_full = np.abs(gt_g - hard_g)
    diff_amp_full = np.clip(diff_full * 3.0, 0, 255).astype(np.uint8)
    diff_bgr = cv2.cvtColor(diff_amp_full, cv2.COLOR_GRAY2BGR)

    def panel(img, title, scale=SCALE):
        crop = img[R0:R1, C0:C1]
        crop = cv2.resize(crop, None, fx=scale, fy=scale, interpolation=cv2.INTER_NEAREST)
        lab = np.full((18, crop.shape[1], 3), 30, np.uint8)
        cv2.putText(lab, title, (4, 12), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1, cv2.LINE_AA)
        return np.vstack([lab, crop])

    comp = np.hstack([panel(gt, "GT RGB rows370-400 cols600-640"),
                      panel(hard, "hard ray render"),
                      panel(diff_bgr, "|GT - hard| x3")])
    out_path = OUT / "crop_gt_hard_diff_370_400.png"
    cv2.imwrite(str(out_path), comp)

    # column-wise diff stats to isolate the vertical bands
    reg = diff_full[R0:R1, C0:C1]
    print("col-by-col (rows 370-399) mean diff / gt_mean / hard_mean:")
    for c in range(C1 - C0):
        col = reg[:, c]
        g = gt_g[R0:R1, C0 + c]
        hh = hard_g[R0:R1, C0 + c]
        print(f"  col {C0+c:3d}: diff={col.mean():6.1f} gt={g.mean():6.1f} hard={hh.mean():6.1f}")

    print("wrote", out_path, comp.shape)


if __name__ == "__main__":
    main()