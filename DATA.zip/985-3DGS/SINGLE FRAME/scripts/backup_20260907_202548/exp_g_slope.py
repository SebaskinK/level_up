"""Experiment G: how does the pipeline model surfaces of varying slope?

Three questions, in the order the user raised them:

  1. Does the primitive explosion still reproduce when foreshortening is
     re-enabled on the CURRENT pipeline? (the recorded number was 11.5k -> 51k,
     4.4x, measured before the 9x9 quadric stencil and the consistency mask)
  2. Where do the holes actually sit -- on real object contours, or in the
     interior of large tilted surfaces?
  3. Does the normal field really carry "large amounts of spurious tilt in flat
     regions"? That claim was made from a single hand-picked rectangle whose
     "truth" later turned out to be a fit across a table edge. It has never been
     re-checked against RANSAC-validated planes.

Plus a controlled synthetic slope sweep, which is the only way to state the
slope behaviour without arguing about what the truth is.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from curvature import curvature_radii, scale_space_curvature  # noqa: E402
from exp_e_curvature_sample import curvature_mask  # noqa: E402
from exp_f_normal_truth import find_planar_blocks, plane_depth, quantize  # noqa: E402
from gaussian_build import (  # noqa: E402
    build_gaussians_curvature,
    depth_discontinuity_mask,
    depth_valid,
    edge_distance_limit,
    normals_from_depth,
    prefilter_depth,
    surfel_radius,
)
from metrics import evaluate, rasterize_discs  # noqa: E402
from rgbd_io import (  # noqa: E402
    FR1_INTRINSICS,
    associate,
    camera_matrix,
    load_depth,
    load_rgb,
    remap_depth,
    remap_rgb,
    undistort_maps,
)

# Production configuration, as documented in EXPERIMENT_E.
CFG = dict(eps=0.001, gauss_sigma=3.0, r_max=0.05, disc_rel=0.02,
           shrink=0.7, overlap=0.6, z_min=0.4, z_max=4.0)


def build(bgr, z, K, foreshorten: bool, aniso_claim: bool = False):
    keep = curvature_mask(
        z, K, CFG["eps"], CFG["gauss_sigma"], CFG["z_min"], CFG["z_max"],
        CFG["disc_rel"], CFG["overlap"], CFG["r_max"], foreshorten=foreshorten,
        aniso_claim=aniso_claim,
    )
    g = build_gaussians_curvature(
        bgr, z, K, eps=CFG["eps"], gauss_sigma=CFG["gauss_sigma"],
        r_max=CFG["r_max"], shrink=CFG["shrink"], normal_mode="disc_inliers",
        z_min=CFG["z_min"], z_max=CFG["z_max"], disc_rel=CFG["disc_rel"],
        mask=keep, prefilter="gauss", prefilter_size=int(CFG["gauss_sigma"]),
    )
    return g, keep


def eval_setup(z, K):
    zd = depth_valid(z)
    z_grad = prefilter_depth(z, "gauss", int(CFG["gauss_sigma"]), valid=zd)
    normal_ref, n_ok = normals_from_depth(z_grad, K)
    eval_mask = (
        n_ok & zd & (z > CFG["z_min"]) & (z < CFG["z_max"])
        & ~depth_discontinuity_mask(z, CFG["disc_rel"], valid=zd)
    )
    return normal_ref, eval_mask


# ---------------------------------------------------------------- part 1
def part1(pairs, K, map1, map2, n_frames: int) -> None:
    print("=" * 100)
    print("1. DOES THE FORESHORTENING EXPLOSION STILL REPRODUCE?  (current pipeline)")
    print("=" * 100)
    print(f"{'frame':>6}{'fore':>7}{'N':>8}{'cover':>8}{'hole':>8}"
          f"{'rmse_mm':>9}{'med_mm':>8}{'n_area':>8}{'r_med_mm':>9}")
    acc = {False: [], True: []}
    for i, fr in enumerate(pairs[:n_frames]):
        bgr = remap_rgb(load_rgb(fr.rgb_path), map1, map2)
        z = remap_depth(load_depth(fr.depth_path), map1, map2)
        normal_ref, eval_mask = eval_setup(z, K)
        for fs in (False, True):
            g, _ = build(bgr, z, K, fs)
            m = evaluate(g, z, bgr, normal_ref, eval_mask, K)
            acc[fs].append(m)
            print(f"{i:>6}{str(fs):>7}{m['n_gaussians']:>8d}"
                  f"{m['coverage']:>8.3f}{m['hole_frac']:>8.3f}"
                  f"{m['depth_rmse_mm']:>9.2f}{m['depth_med_mm']:>8.2f}"
                  f"{m['normal_area_med_deg']:>8.2f}{m['radius_med_mm']:>9.2f}",
                  flush=True)
    print("-" * 100)
    for fs in (False, True):
        r = acc[fs]
        if not r:
            continue
        f = lambda k: float(np.mean([x[k] for x in r]))  # noqa: E731
        print(f"{'MEAN':>6}{str(fs):>7}{f('n_gaussians'):>8.0f}"
              f"{f('coverage'):>8.3f}{f('hole_frac'):>8.3f}"
              f"{f('depth_rmse_mm'):>9.2f}{f('depth_med_mm'):>8.2f}"
              f"{f('normal_area_med_deg'):>8.2f}{f('radius_med_mm'):>9.2f}")
    a, b = acc[False], acc[True]
    if a and b:
        ra = float(np.mean([x["n_gaussians"] for x in b])) / max(
            float(np.mean([x["n_gaussians"] for x in a])), 1.0)
        print(f"\n  primitive ratio ON/OFF = {ra:.2f}x "
              f"(recorded earlier: 4.4x, 11549 -> 50991)")


# ---------------------------------------------------------------- part 2
def part2(bgr, z, K, out_dir: Path) -> None:
    print()
    print("=" * 100)
    print("2. WHERE ARE THE HOLES?   (frame 0, foreshorten OFF)")
    print("=" * 100)
    normal_ref, eval_mask = eval_setup(z, K)
    g, _ = build(bgr, z, K, False)
    depth, index, _ = rasterize_discs(g, K, z.shape)
    hit = np.isfinite(depth) & eval_mask
    hole = eval_mask & ~hit

    edge = depth_discontinuity_mask(z, CFG["disc_rel"], valid=depth_valid(z))
    dist_edge = cv2.distanceTransform((~edge).astype(np.uint8), cv2.DIST_L2, 3)

    print(f"  eval px {eval_mask.sum():7d}   hit {hit.sum():7d}   "
          f"hole {hole.sum():7d}  ({100.0*hole.sum()/max(eval_mask.sum(),1):.1f}%)")
    print()
    print("  distance to the nearest depth discontinuity (px):")
    for name, m in (("covered", hit), ("hole", hole)):
        d = dist_edge[m]
        print(f"    {name:<8} med {np.median(d):5.1f}  p10 {np.percentile(d,10):5.1f}"
              f"  p90 {np.percentile(d,90):5.1f}   frac<=2px {100*(d<=2).mean():5.1f}%"
              f"   frac<=4px {100*(d<=4).mean():5.1f}%")

    num, lab, stats, _ = cv2.connectedComponentsWithStats(
        hole.astype(np.uint8), connectivity=8)
    areas = stats[1:, cv2.CC_STAT_AREA]
    if areas.size:
        bins = [(1, 2), (3, 8), (9, 32), (33, 128), (129, 10**9)]
        print()
        print(f"  hole components: {areas.size}  total px {areas.sum()}")
        for lo, hi in bins:
            sel = (areas >= lo) & (areas <= hi)
            tag = f"{lo}-{hi}" if hi < 10**8 else f">={lo}"
            print(f"    size {tag:<8} n={sel.sum():5d} ({100*sel.mean():5.1f}% of comps)"
                  f"  px={areas[sel].sum():6d} ({100*areas[sel].sum()/areas.sum():5.1f}% of hole px)")

    # Slope of the reference normal field where holes sit vs where they do not.
    tilt = np.degrees(np.arccos(np.clip(np.abs(normal_ref[..., 2]), 0, 1)))
    print()
    print("  reference-normal tilt from the optical axis (deg):")
    for name, m in (("covered", hit), ("hole", hole)):
        t = tilt[m]
        print(f"    {name:<8} med {np.median(t):5.1f}  p90 {np.percentile(t,90):5.1f}"
              f"   frac>45deg {100*(t>45).mean():5.1f}%   frac>60deg {100*(t>60).mean():5.1f}%")
    print()
    print("  hole rate stratified by reference tilt:")
    print(f"    {'tilt bin':<12}{'eval px':>9}{'hole px':>9}{'hole %':>8}"
          f"{'med dist2edge':>15}")
    for lo, hi in ((0, 15), (15, 30), (30, 45), (45, 60), (60, 75), (75, 90)):
        m = eval_mask & (tilt >= lo) & (tilt < hi)
        if m.sum() < 50:
            continue
        hm = hole & m
        d = dist_edge[m]
        print(f"    {f'{lo}-{hi}':<12}{m.sum():>9d}{hm.sum():>9d}"
              f"{100.0*hm.sum()/m.sum():>8.1f}{np.median(d):>15.1f}")

    vis = bgr.copy()
    vis[hole] = (0, 0, 255)
    vis[edge & eval_mask] = (0, 255, 255)
    out = out_dir / "holes_vs_edges.png"
    cv2.imwrite(str(out), vis)
    print(f"\n  wrote {out}  (red = hole, yellow = depth discontinuity)")


# ---------------------------------------------------------------- part 3
def part3(z, K) -> None:
    print()
    print("=" * 100)
    print("3. IS THERE SPURIOUS TILT IN GENUINELY FLAT REGIONS?  (RANSAC-validated planes)")
    print("=" * 100)
    blocks = find_planar_blocks(z, K, size=48, stride=24, min_inlier=0.85)
    print(f"  validated single-plane blocks: {len(blocks)}")
    if not blocks:
        print("  none -- cannot answer")
        return

    z_s = prefilter_depth(z, "gauss", int(CFG["gauss_sigma"]), valid=depth_valid(z))
    normal, n_ok = normals_from_depth(z_s, K)

    rows = []
    for box, nv, inl, res, zc in blocks:
        sub_ok = n_ok[box]
        if sub_ok.sum() < 200:
            continue
        nn = normal[box][sub_ok]
        cos = np.clip(np.abs(nn @ nv.astype(np.float32)), 0, 1)
        ang = np.degrees(np.arccos(cos))
        nz = np.abs(nn[:, 2])
        rows.append(dict(
            tilt=float(np.degrees(np.arccos(min(abs(nv[2]), 1.0)))),
            nz_true=float(abs(nv[2])), nz_med=float(np.median(nz)),
            nz_p10=float(np.percentile(nz, 10)),
            err_med=float(np.median(ang)), err_p90=float(np.percentile(ang, 90)),
            f20=float((ang > 20).mean()), f45=float((ang > 45).mean()),
            z=zc, res_mm=res * 1000.0,
        ))
    if not rows:
        print("  no usable blocks")
        return

    print()
    print("  per-block, grouped by the block's TRUE tilt:")
    print(f"    {'tilt bin':<10}{'blocks':>7}{'|nz|true':>10}{'|nz|med':>9}"
          f"{'bias':>8}{'|nz|p10':>9}{'errmed':>8}{'errp90':>8}"
          f"{'>20deg':>8}{'>45deg':>8}")
    for lo, hi in ((0, 15), (15, 30), (30, 45), (45, 60), (60, 90)):
        sel = [r for r in rows if lo <= r["tilt"] < hi]
        if not sel:
            continue
        f = lambda k: float(np.mean([r[k] for r in sel]))  # noqa: E731
        print(f"    {f'{lo}-{hi}':<10}{len(sel):>7d}{f('nz_true'):>10.3f}"
              f"{f('nz_med'):>9.3f}{f('nz_med')-f('nz_true'):>+8.3f}"
              f"{f('nz_p10'):>9.3f}{f('err_med'):>8.2f}{f('err_p90'):>8.2f}"
              f"{100*f('f20'):>7.1f}%{100*f('f45'):>7.1f}%")

    f = lambda k: float(np.mean([r[k] for r in rows]))  # noqa: E731
    print()
    print(f"  ALL blocks: err med {f('err_med'):.2f} deg, p90 {f('err_p90'):.2f} deg, "
          f"{100*f('f20'):.1f}% of pixels >20 deg, {100*f('f45'):.1f}% >45 deg")
    print(f"  |n_z| bias (median est - truth) = {f('nz_med')-f('nz_true'):+.3f}, "
          f"mean plane residual {f('res_mm'):.2f} mm")
    print()
    print("  The earlier claim came from ONE hand-picked rectangle whose least-squares")
    print("  'truth' |n_z| = 0.466 straddled a table edge; RANSAC on the same region")
    print("  gives 0.727. Numbers above use only blocks whose residual stays under the")
    print("  local quantization step, so the truth cannot be a two-surface compromise.")


# ---------------------------------------------------------------- part 4
def part4(K, tilts, z_centre: float, quant: float) -> None:
    print()
    print("=" * 100
          )
    print(f"4. SYNTHETIC SLOPE SWEEP THROUGH THE FULL PIPELINE  "
          f"(z={z_centre:g} m, TUM quantization {quant:g})")
    print("=" * 100)
    H, W = 480, 640
    rng = np.random.default_rng(0)
    tex = rng.integers(0, 255, (H, W, 3), dtype=np.uint8)
    tex = cv2.GaussianBlur(tex, (0, 0), 2)
    m_in = np.zeros((H, W), bool)
    m_in[60:-60, 60:-60] = True

    print(f"{'tilt':>6}{'fore':>7}{'N':>7}{'cover':>8}{'hole':>8}"
          f"{'rmse_mm':>9}{'med_mm':>8}{'p95_mm':>8}"
          f"{'nerr_med':>9}{'nerr_p90':>9}{'r_med_mm':>9}")
    for t in tilts:
        z, n_true = plane_depth(K, t, z_centre)
        zq = quantize(z, quant)
        for fs, aniso in ((False, False), (True, False), (False, True)):
            g, _ = build(tex, zq, K, fs, aniso_claim=aniso)
            if len(g) == 0:
                print(f"{t:>5.0f}d{str(fs):>7}{'0':>7}  (nothing built)")
                continue
            depth, index, _ = rasterize_discs(g, K, zq.shape)
            hit = np.isfinite(depth) & m_in
            cov = hit.sum() / m_in.sum()
            # Truth is the ANALYTIC plane, not the quantized reading.
            err = depth[hit] - z[hit]
            cos = np.clip(np.abs(g.normal @ n_true.astype(np.float32)), 0, 1)
            ang = np.degrees(np.arccos(cos))
            tag = str(fs) + ("A" if aniso else "")
            print(f"{t:>5.0f}d{tag:>7}{len(g):>7d}{cov:>8.3f}{1-cov:>8.3f}"
                  f"{1000*np.sqrt(np.mean(err**2)):>9.2f}"
                  f"{1000*np.median(np.abs(err)):>8.2f}"
                  f"{1000*np.percentile(np.abs(err),95):>8.2f}"
                  f"{np.median(ang):>9.2f}{np.percentile(ang,90):>9.2f}"
                  f"{1000*np.median(g.scale[:,0]):>9.2f}", flush=True)


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--data", default=str(
        ROOT.parent.parent / "986-SceneFlow" / "rgbd_dataset_freiburg1_desk"))
    p.add_argument("--out", default=str(ROOT.parent / "output_G"))
    p.add_argument("--frames", type=int, default=3)
    p.add_argument("--tilts", type=float, nargs="+",
                   default=[0, 15, 30, 45, 60, 75])
    p.add_argument("--syn-z", type=float, default=1.5)
    p.add_argument("--quant", type=float, default=0.00291)
    p.add_argument("--parts", default="1234")
    args = p.parse_args()

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    K = camera_matrix(FR1_INTRINSICS)

    pairs = associate(Path(args.data))
    sample = load_rgb(pairs[0].rgb_path)
    map1, map2, Ku = undistort_maps(sample.shape[:2], FR1_INTRINSICS)

    if "1" in args.parts:
        part1(pairs, Ku, map1, map2, args.frames)
    if "2" in args.parts or "3" in args.parts:
        bgr = remap_rgb(load_rgb(pairs[0].rgb_path), map1, map2)
        z = remap_depth(load_depth(pairs[0].depth_path), map1, map2)
        if "2" in args.parts:
            part2(bgr, z, Ku, out_dir)
        if "3" in args.parts:
            part3(z, Ku)
    if "4" in args.parts:
        part4(K, args.tilts, args.syn_z, args.quant)


if __name__ == "__main__":
    main()
