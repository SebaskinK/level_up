"""Clean culprit analysis of the desk-edge white-over-gray using ONLY the
frame-0-consistent model_f0.npz (mu/normal/scale/color/birth). Reconstructs the
tangent frame from the normal (same frame `_quat_from_normal` uses), so the only
approximation is in-plane rotation for anisotropic discs."""
import os
import sys
from pathlib import Path

import numpy as np

SEQ = Path(__file__).resolve().parent
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SEQ))
sys.path.insert(0, str(SFLOW))

import h_pipeline_final as H  # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402

OUT = Path(os.environ.get("MODEL_DIR", str(SEQ.parent / "output_f0_10frame")))
d = np.load(OUT / "model_f0.npz")
mu = d["mu"].astype(np.float32)
normal = d["normal"].astype(np.float32)
scale = d["scale"].astype(np.float32)
color = d["color"].astype(np.float32)
birth = d["birth"].astype(np.int32)

t1, t2 = H._tangent_basis(normal.astype(np.float32))
g = H.Gaussians(mu=mu, normal=normal, scale=scale,
                quat=H._quat_from_normal(normal.astype(np.float32)),
                color=color, alpha=np.ones(len(mu), np.float32),
                pixel=np.zeros((len(mu), 2), np.int32),
                axis1=t1.astype(np.float32), axis2=t2.astype(np.float32))

pairs = SF.associate(SF.DATA, max_dt=0.02)[:1]
h, w = SF.load_rgb(pairs[0].rgb_path).shape[:2]
map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)
bgr0, z0, _ = SF.load_pair(pairs, 0, map1, map2)
gt = bgr0[..., ::-1].astype(np.float32) / 255.0

depth, index, _ = H.rasterize_discs(g, K, (h, w))
render = np.zeros((h, w, 3), np.float32)
hit = np.isfinite(depth)
render[hit] = color[index[hit]]

hw = render.min(axis=2) > 0.68
gs = (gt.mean(axis=2) > 0.15) & (gt.mean(axis=2) < 0.6)
mask = hw & gs & hit
print("white-over-gray pixels total:", int(mask.sum()))

# desk-edge region only
y0, y1, x0, x1 = 366, 400, 400, 640
sub = mask[y0:y1, x0:x1]
print("white-over-gray in desk-edge region:", int(sub.sum()))
culp = np.unique(index[y0:y1, x0:x1][sub])
print("culprit discs in desk-edge:", len(culp))
for b in range(0, 11):
    sel = culp[birth[culp] == b]
    if sel.size:
        print(f"  birth={b}: {sel.size} discs  mean r=({scale[sel,0].mean():.4f},{scale[sel,1].mean():.4f}) "
              f"mean col=({color[sel,0].mean():.2f},{color[sel,1].mean():.2f},{color[sel,2].mean():.2f}) "
              f"mean nz={normal[sel,2].mean():.2f}")

# for each culprit disc report source pixel + GT color at source
print("\nculprit discs detail (idx, birth, r, col, source(u,v), gt@source, mu.z):")
fx, fy, cx, cy = (float(K[0,0]), float(K[1,1]), float(K[0,2]), float(K[1,2]))
us = np.clip((fx * mu[:,0] / np.maximum(mu[:,2],1e-6) + cx).astype(int), 0, w-1)
vs = np.clip((fy * mu[:,1] / np.maximum(mu[:,2],1e-6) + cy).astype(int), 0, h-1)
order = np.argsort(-scale[culp,0])
for o in order[:25]:
    i = culp[o]
    gts = gt[vs[i], us[i]]
    print(f"  idx{i:5d} b={birth[i]} r=({scale[i,0]:.4f},{scale[i,1]:.4f}) "
          f"col=({color[i,0]:.2f},{color[i,1]:.2f},{color[i,2]:.2f}) "
          f"src=({us[i]},{vs[i]}) gt@src=({gts[0]:.2f},{gts[1]:.2f},{gts[2]:.2f}) "
          f"z={mu[i,2]:.2f} nz={normal[i,2]:.2f}")