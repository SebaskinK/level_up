"""Decisive aging A/B: no-prune vs prune, frame-0 coverage.

Runs the 10-frame fusion twice -- age_max=8 (current) vs age_max=10**6 (no
prune) -- and renders each final model back into frame 0 with EWA@0.33 (the
single-frame-tuned render). Flow, poses, and anchor FL9 are identical in both
runs; only the age prune differs. If coverage recovers under no-prune, aging is
the hole source; if not, the loss is disc drift/shrink under frozen radii.

Prints, for each run: N(final), frame-8 prune count, and EWA@0.33 eval-region
coverage on frame 0.
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

SEQ = Path(__file__).resolve().parent
SINGLE = SEQ.parent.parent / "SINGLE FRAME" / "scripts"
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SINGLE))
sys.path.insert(0, str(SFLOW))

import h_pipeline_final as H  # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402
from exp_surfel_render import render_ewa  # noqa: E402


def run_fusion(age_max: int):
    """Returns (final_g, FL9, prune_bytes_at_each_frame)."""
    pairs = SF.associate(SF.DATA, max_dt=0.02)[:11]
    sample = SF.load_rgb(pairs[0].rgb_path)
    h, w = sample.shape[:2]
    map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)

    bgr0, z0, _ = SF.load_pair(pairs, 0, map1, map2)
    g0, _, _ = H.build_hybrid(bgr0, z0, K, SF.TEX_Q)
    model = SF.Model(
        g=g0, w=np.ones(len(g0), dtype=np.float32),
        age=np.zeros(len(g0), dtype=np.int32),
        owner=SF.owner_from_raster(g0, K, (h, w)),
        birth=np.zeros(len(g0), dtype=np.int32),
        cnt=np.ones(len(g0), dtype=np.float32),
    )
    F = (np.eye(3), np.zeros(3))  # accumulated flow point motion frame0->k
    prunes = []
    prev_sf = None
    prev_dt = 1.0
    bgr_a, z_a = bgr0, z0
    for i in range(len(pairs) - 1):
        bgr_b, z_b, _ = SF.load_pair(pairs, i + 1, map1, map2)
        dt = pairs[i + 1].t_rgb - pairs[i].t_rgb
        sf = SF.compute_scene_flow(bgr_a, bgr_b, z_a, z_b, K,
                                   prev=prev_sf, dt=dt, prev_dt=prev_dt)
        R_10, t_10 = SF.se3_exp(sf.xi)
        rec = SF.fuse_frame(model, sf, z_a, z_b, bgr_b, K,
                            age_max=age_max, w_min=2.0, frame_idx=i,
                            R_10=R_10, t_10=t_10)
        prunes.append(rec["n_dead"])
        F = (F[0] @ R_10, F[0] @ t_10 + F[1])
        bgr_a, z_a = bgr_b, z_b
        prev_sf, prev_dt = sf, dt
    return model.g, F, prunes


def place_frame0(g: H.Gaussians, F):
    R, t = F
    Ri = R.T
    ti = -R.T @ t
    return H.Gaussians(
        mu=g.mu @ Ri.T + ti,
        normal=g.normal @ Ri.T,
        scale=g.scale, quat=g.quat, color=g.color, alpha=g.alpha,
        pixel=g.pixel,
        axis1=g.axis1 @ Ri.T if g.axis1 is not None else None,
        axis2=g.axis2 @ Ri.T if g.axis2 is not None else None,
    )


def main() -> None:
    pairs = SF.associate(SF.DATA, max_dt=0.02)[:11]
    sample = SF.load_rgb(pairs[0].rgb_path)
    h, w = sample.shape[:2]
    map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)
    bgr, z, _ = SF.load_pair(pairs, 0, map1, map2)
    _, eval_mask = H.eval_setup(z, K)
    n_eval = int(eval_mask.sum())

    g_sf, _, _ = H.build_hybrid(bgr, z, K, 0.6)
    _, __, wt_sf = render_ewa(g_sf, K, (h, w), mode="normalized", cov_scale=0.33)
    cov_sf = float(((wt_sf > 0) & eval_mask).sum() / n_eval)
    print(f"single-frame (reference)    N={len(g_sf)}  "
          f"EWA@0.33 eval_cov={cov_sf:.4f}")

    for age_max in (8, 10**6):
        g, F9, prunes = run_fusion(age_max)
        g0 = place_frame0(g, F9)
        _, __, wt = render_ewa(g0, K, (h, w), mode="normalized", cov_scale=0.33)
        cov = float(((wt > 0) & eval_mask).sum() / n_eval)
        print(f"age_max={age_max:<6}  N={len(g)}  "
              f"pruned={sum(prunes)}  EWA@0.33 eval_cov={cov:.4f}")


if __name__ == "__main__":
    main()