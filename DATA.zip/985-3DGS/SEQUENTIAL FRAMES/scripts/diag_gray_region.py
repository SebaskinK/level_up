"""Diagnose white-over-gray desk region: which discs cover it, their color/radius."""
import sys
from pathlib import Path

import numpy as np

SEQ = Path(__file__).resolve().parent
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SEQ))
sys.path.insert(0, str(SFLOW))

import h_pipeline_final as H  # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402

OUT = SEQ.parent / "output_f0_10frame"

d = np.load(OUT / "model_f0.npz")
mu = d["mu"].astype(np.float64)
normal = d["normal"].astype(np.float64)
scale = d["scale"].astype(np.float64)

raw = (OUT / "model.ply").read_bytes()
hdr_end = raw.index(b"end_header\n") + len(b"end_header\n")
arr = np.frombuffer(raw[hdr_end:], dtype=np.float32).reshape(-1, 17)
col = arr[:, 6:9].astype(np.float64)

pairs = SF.associate(SF.DATA, max_dt=0.02)[:1]
sample = SF.load_rgb(pairs[0].rgb_path)
h, w = sample.shape[:2]
map1, map2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)
fx, fy, cx, cy = (float(K[0, 0]), float(K[1, 1]), float(K[0, 2]), float(K[1, 2]))

u = fx * mu[:, 0] / np.maximum(mu[:, 2], 1e-6) + cx
v = fy * mu[:, 1] / np.maximum(mu[:, 2], 1e-6) + cy
ui = np.clip(u.astype(int), 0, w - 1)
vi = np.clip(v.astype(int), 0, h - 1)
r1 = scale[:, 0]
r2 = scale[:, 1]

gray = (vi >= 280) & (vi < 400) & (ui >= 400) & (ui < 640)
print("centers in gray region:", gray.sum())
for i in np.where(gray)[0]:
    print(f"  idx{i} mu=({mu[i,0]:.3f},{mu[i,1]:.3f},{mu[i,2]:.3f}) "
          f"col=({col[i,0]:.2f},{col[i,1]:.2f},{col[i,2]:.2f}) "
          f"r1={r1[i]:.4f} r2={r2[i]:.4f} nz={normal[i,2]:.2f}")

# discs that actually own pixels in the gray region (via rasterize) with white color
g = H.Gaussians(
    mu=mu.astype(np.float32), normal=normal.astype(np.float32),
    scale=scale.astype(np.float32),
    quat=H._quat_from_normal(normal.astype(np.float32)),
    color=col.astype(np.float32), alpha=np.ones(len(mu), np.float32),
    pixel=0, axis1=None, axis2=None,
)
depth, index, _ = H.rasterize_discs(
    g, K, (h, w), axis1=None, axis2=None, quat=g.quat)
idx = index[280:400, 400:640]
hit = idx >= 0
owners, counts = np.unique(idx[hit], return_counts=True)
print("discs owning gray-region pixels (idx, npix, color, r1, r2):")
for o, c in sorted(zip(owners, counts), key=lambda t: -t[1])[:20]:
    print(f"  idx{o} npix={c} col=({col[o,0]:.2f},{col[o,1]:.2f},{col[o,2]:.2f}) "
          f"r1={r1[o]:.4f} r2={r2[o]:.4f} mu=({mu[o,0]:.3f},{mu[o,1]:.3f},{mu[o,2]:.3f})")