"""E1 anisotropic claim on real data: 3 frames, OFF vs ON vs aniso, + hole panels.

Run:
  MPLCONFIGDIR=/tmp/mpl .venv/bin/python scripts/exp_g_aniso_real.py --frames 3 --out output_G_refactor
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from exp_e_curvature_sample import curvature_mask  # noqa: E402
from gaussian_build import (  # noqa: E402
    build_gaussians_curvature,
    depth_discontinuity_mask,
    depth_valid,
    normals_from_depth,
    prefilter_depth,
)
from metrics import evaluate, rasterize_discs  # noqa: E402
from rgbd_io import (  # noqa: E402
    FR1_INTRINSICS,
    associate,
    camera_matrix,
    load_depth,
    load_rgb,
    remap_depth,
    remap_rgb,
    undistort_maps,
)

CFG = dict(eps=0.001, gauss_sigma=3.0, r_max=0.05, disc_rel=0.02,
           shrink=0.7, overlap=0.6, z_min=0.4, z_max=4.0)


def build(bgr, z, K, foreshorten: bool, aniso_claim: bool):
    keep = curvature_mask(
        z, K, CFG["eps"], CFG["gauss_sigma"], CFG["z_min"], CFG["z_max"],
        CFG["disc_rel"], CFG["overlap"], CFG["r_max"], foreshorten=foreshorten,
        aniso_claim=aniso_claim,
    )
    g = build_gaussians_curvature(
        bgr, z, K, eps=CFG["eps"], gauss_sigma=CFG["gauss_sigma"],
        r_max=CFG["r_max"], shrink=CFG["shrink"], normal_mode="disc_inliers",
        z_min=CFG["z_min"], z_max=CFG["z_max"], disc_rel=CFG["disc_rel"],
        mask=keep, prefilter="gauss", prefilter_size=int(CFG["gauss_sigma"]),
    )
    return g, keep


def eval_setup(z, K):
    zd = depth_valid(z)
    z_grad = prefilter_depth(z, "gauss", int(CFG["gauss_sigma"]), valid=zd)
    normal_ref, n_ok = normals_from_depth(z_grad, K)
    eval_mask = (
        n_ok & zd & (z > CFG["z_min"]) & (z < CFG["z_max"])
        & ~depth_discontinuity_mask(z, CFG["disc_rel"], valid=zd)
    )
    return normal_ref, eval_mask


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--data", default=str(
        ROOT.parent.parent / "986-SceneFlow" / "rgbd_dataset_freiburg1_desk"))
    p.add_argument("--out", default=str(ROOT.parent / "output_G_refactor"))
    p.add_argument("--frames", type=int, default=3)
    args = p.parse_args()

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    K = camera_matrix(FR1_INTRINSICS)

    pairs = associate(Path(args.data))
    sample = load_rgb(pairs[0].rgb_path)
    map1, map2, Ku = undistort_maps(sample.shape[:2], FR1_INTRINSICS)

    cfgs = (
        ("OFF", dict(foreshorten=False, aniso_claim=False)),
        ("ON", dict(foreshorten=True, aniso_claim=False)),
        ("ANISO", dict(foreshorten=False, aniso_claim=True)),
    )

    print(f"{'frame':>6}{'cfg':>8}{'N':>8}{'cover':>8}{'hole':>8}"
          f"{'rmse_mm':>9}{'med_mm':>8}{'n_area':>8}{'r_med_mm':>9}")
    acc = {name: [] for name, _ in cfgs}
    for i, fr in enumerate(pairs[:args.frames]):
        bgr = remap_rgb(load_rgb(fr.rgb_path), map1, map2)
        z = remap_depth(load_depth(fr.depth_path), map1, map2)
        normal_ref, eval_mask = eval_setup(z, K)
        for name, kw in cfgs:
            g, _ = build(bgr, z, K, **kw)
            m = evaluate(g, z, bgr, normal_ref, eval_mask, K)
            acc[name].append(m)
            print(f"{i:>6}{name:>8}{m['n_gaussians']:>8d}"
                  f"{m['coverage']:>8.3f}{m['hole_frac']:>8.3f}"
                  f"{m['depth_rmse_mm']:>9.2f}{m['depth_med_mm']:>8.2f}"
                  f"{m['normal_area_med_deg']:>8.2f}{m['radius_med_mm']:>9.2f}",
                  flush=True)

            # Hole overlay panel for the first frame only.
            if i == 0:
                depth, _, _ = rasterize_discs(g, K, z.shape)
                hit = np.isfinite(depth) & eval_mask
                hole = eval_mask & ~hit
                vis = bgr.copy()
                vis[hole] = (0, 0, 255)
                edge = depth_discontinuity_mask(z, CFG["disc_rel"], valid=depth_valid(z))
                vis[edge & eval_mask] = (0, 255, 255)
                out = out_dir / f"hole_aniso_f0_{name}.png"
                cv2.imwrite(str(out), vis)
    print("-" * 100)
    for name, _ in cfgs:
        r = acc[name]
        if not r:
            continue
        f = lambda k: float(np.mean([x[k] for x in r]))  # noqa: E731
        print(f"{'MEAN':>6}{name:>8}{f('n_gaussians'):>8.0f}"
              f"{f('coverage'):>8.3f}{f('hole_frac'):>8.3f}"
              f"{f('depth_rmse_mm'):>9.2f}{f('depth_med_mm'):>8.2f}"
              f"{f('normal_area_med_deg'):>8.2f}{f('radius_med_mm'):>9.2f}")
    a = np.mean([x["n_gaussians"] for x in acc["OFF"]])
    for name in ("ON", "ANISO"):
        b = np.mean([x["n_gaussians"] for x in acc[name]])
        print(f"  ratio {name}/OFF = {b/a:.2f}x")
    print(f"\nwrote hole panels to {out_dir}")


if __name__ == "__main__":
    main()
