"""Where does the frame-to-frame rotation error come from?"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import cv2
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from eval_ate import load_trajectory  # noqa: E402
from tum_io import interpolate_pose, load_groundtruth, quat_xyzw_to_R  # noqa: E402


def rotvec(R: np.ndarray) -> np.ndarray:
    rv, _ = cv2.Rodrigues(R)
    return np.degrees(rv.ravel())


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--traj", required=True)
    p.add_argument("--gt", default=str(ROOT.parent / "rgbd_dataset_freiburg1_desk" / "groundtruth.txt"))
    p.add_argument("--csv", default=None, help="frame_errors.csv for valid_frac correlation")
    args = p.parse_args()

    est_ts, _, est_q = load_trajectory(Path(args.traj))
    gt_ts, gt_t, gt_q = load_groundtruth(Path(args.gt))

    est_R, gt_R, stamps = [], [], []
    for i, t in enumerate(est_ts):
        pose = interpolate_pose(t, gt_ts, gt_t, gt_q)
        if pose is None:
            continue
        est_R.append(quat_xyzw_to_R(est_q[i]))
        gt_R.append(pose[0])
        stamps.append(t)
    stamps = np.array(stamps)

    err_vec, gt_vec, est_vec, dts = [], [], [], []
    for i in range(len(est_R) - 1):
        dR_est = est_R[i].T @ est_R[i + 1]
        dR_gt = gt_R[i].T @ gt_R[i + 1]
        err_vec.append(rotvec(dR_est.T @ dR_gt))
        gt_vec.append(rotvec(dR_gt))
        est_vec.append(rotvec(dR_est))
        dts.append(stamps[i + 1] - stamps[i])
    err_vec = np.array(err_vec)
    gt_vec = np.array(gt_vec)
    est_vec = np.array(est_vec)
    dts = np.array(dts)

    gt_mag = np.linalg.norm(gt_vec, axis=1)
    est_mag = np.linalg.norm(est_vec, axis=1)
    err_mag = np.linalg.norm(err_vec, axis=1)
    ang_vel = gt_mag / dts

    print(f"frames: {len(err_mag)}")
    print("\n=== is the error biased or random? (deg, camera axes) ===")
    print(f"  mean err vector : {np.round(err_vec.mean(axis=0), 4)}")
    print(f"  std  err vector : {np.round(err_vec.std(axis=0), 4)}")
    print(f"  |mean| / |std|  : {np.linalg.norm(err_vec.mean(axis=0)) / np.linalg.norm(err_vec.std(axis=0)):.3f}")
    print(f"  err magnitude   : mean {err_mag.mean():.3f}  median {np.median(err_mag):.3f}")

    print("\n=== under- or over-rotation? ===")
    ratio = est_mag / np.maximum(gt_mag, 1e-6)
    print(f"  |est| / |gt| : mean {ratio.mean():.4f}  median {np.median(ratio):.4f}")
    print(f"  signed mag err (est-gt): mean {np.mean(est_mag - gt_mag):+.4f} deg")

    print("\n=== per-axis (x=pitch-ish, y=yaw-ish, z=roll-ish in camera frame) ===")
    for k, name in enumerate("xyz"):
        m = err_vec[:, k]
        print(f"  {name}: mean {m.mean():+.4f}  std {m.std():.4f}  rms {np.sqrt((m**2).mean()):.4f}")
    print(f"  gt rotation axis mean (normalized): {np.round((gt_vec / np.maximum(gt_mag[:, None], 1e-9)).mean(axis=0), 3)}")

    print("\n=== error vs GT angular velocity ===")
    edges = [0, 30, 50, 70, 90, 1e9]
    print("  ang_vel(deg/s)   n   err_mean  err_rms  ratio")
    for lo, hi in zip(edges[:-1], edges[1:]):
        m = (ang_vel >= lo) & (ang_vel < hi)
        if m.sum() == 0:
            continue
        label = f"{lo:.0f}-{hi:.0f}" if hi < 1e8 else f">{lo:.0f}"
        print(
            f"  {label:>12s} {m.sum():4d}   {err_mag[m].mean():.3f}    "
            f"{np.sqrt((err_mag[m]**2).mean()):.3f}   {ratio[m].mean():.3f}"
        )

    print("\n=== correlations with |err| ===")
    print(f"  ang_vel   : {np.corrcoef(err_mag, ang_vel)[0, 1]:+.3f}")
    print(f"  gt_mag    : {np.corrcoef(err_mag, gt_mag)[0, 1]:+.3f}")
    print(f"  dt        : {np.corrcoef(err_mag, dts)[0, 1]:+.3f}")

    if args.csv:
        import csv as _csv

        rows = list(_csv.DictReader(Path(args.csv).open()))
        n = min(len(rows), len(err_mag))
        for key in ["valid_frac", "res_mag_mean", "rigid_delta_mean", "photo_mean"]:
            v = np.array([float(r[key] or "nan") for r in rows[:n]])
            m = np.isfinite(v)
            print(f"  {key:9s} : {np.corrcoef(err_mag[:n][m], v[m])[0, 1]:+.3f}")

    print("\n=== cumulative drift: does error add up coherently? ===")
    cum = np.cumsum(err_vec, axis=0)
    rand_walk = np.sqrt(np.arange(1, len(err_vec) + 1)) * err_mag.std()
    print(f"  |sum of err vectors| : {np.linalg.norm(cum[-1]):.2f} deg")
    print(f"  random-walk expected : {rand_walk[-1]:.2f} deg")
    print(f"  sum |err|            : {err_mag.sum():.2f} deg")

    fig, axes = plt.subplots(3, 1, figsize=(10, 8), sharex=True)
    idx = np.arange(len(err_mag))
    axes[0].plot(idx, ang_vel, color="tab:gray")
    axes[0].set_ylabel("GT ang vel (deg/s)")
    axes[0].grid(True, alpha=0.3)

    axes[1].plot(idx, err_mag, color="tab:red")
    axes[1].set_ylabel("|rot err| (deg)")
    axes[1].grid(True, alpha=0.3)

    for k, name in enumerate("xyz"):
        axes[2].plot(idx, np.cumsum(err_vec[:, k]), label=f"cum err {name}")
    axes[2].set_ylabel("cumulative (deg)")
    axes[2].set_xlabel("frame pair index")
    axes[2].legend()
    axes[2].grid(True, alpha=0.3)

    fig.tight_layout()
    out = Path(args.traj).parent / "rot_error.png"
    fig.savefig(out, dpi=140)
    print(f"\nwrote {out}")


if __name__ == "__main__":
    main()
