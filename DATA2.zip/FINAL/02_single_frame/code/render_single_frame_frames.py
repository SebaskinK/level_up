"""Generate the single-frame line's FINAL results for EVERY frame of the sequence.

For each frame it runs the frozen single-file pipeline `h_pipeline_final.py`
**independently** (no cross-frame state at all: each frame is built from its own
RGB-D pair) plus the delivered EWA renderer, and writes the same 4-panel set as
frame 0 plus per-frame metrics.

Panel order (matches the multi-frame results):
    ellipse | hard ray
    EWA     | back-projected depth
Outputs per frame k: `f{k:02d}_{ellipse,hard,ewa,depth_hard}.png`,
`frame_{k:02d}_quad.png`; plus one `metrics.json` holding every frame's numbers
and a summary block (mean/median).

Run:
  python render_single_frame_frames.py [--dataset DIR] [--out DIR] [--frames all|0,1,2]
"""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import cv2
import numpy as np

import h_pipeline_final as H
from exp_surfel_render import render_ewa

DEFAULT_DATA = Path("/home/sti/Work/986-SceneFlow/rgbd_dataset_freiburg1_desk")
TEX_Q = 0.6                      # 定稿 texture quantile
TITLE_H = 30
TH = np.linspace(0.0, 2.0 * np.pi, 32, endpoint=False)


def bar(lines, w, h=TITLE_H):
    b = np.full((h * len(lines), w, 3), 30, np.uint8)
    for i, t in enumerate(lines):
        cv2.putText(b, t, (10, h * i + h - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                    (235, 235, 235), 1, cv2.LINE_AA)
    return b


def save_depth(path: Path, depth: np.ndarray, title: str) -> np.ndarray:
    hit = np.isfinite(depth)
    d = np.where(hit, depth, np.nan)
    lo, hi = np.nanpercentile(d, [1, 99]) if hit.any() else (0.0, 1.0)
    n = np.clip((d - lo) / max(hi - lo, 1e-9), 0, 1)
    img = cv2.applyColorMap((n * 255).astype(np.uint8), cv2.COLORMAP_TURBO)
    img[~hit] = 0
    out = np.vstack([bar([title], img.shape[1]), img])
    cv2.imwrite(str(path), out)
    return out


def tangent_basis(n: np.ndarray):
    """Same Gram-Schmidt the builder's normal->quaternion convention uses."""
    n = n.astype(np.float64)
    n = n / np.maximum(np.linalg.norm(n, axis=1, keepdims=True), 1e-12)
    ref = np.tile(np.array([0.0, 0.0, 1.0]), (n.shape[0], 1))
    ref[np.abs(n[:, 2]) > 0.9] = np.array([1.0, 0.0, 0.0])
    t1 = np.cross(ref, n)
    t1 /= np.maximum(np.linalg.norm(t1, axis=1, keepdims=True), 1e-12)
    return t1, np.cross(n, t1)


def run_frame(k: int, fr, map1, map2, K, out_dir: Path, data_name: str, quiet=False):
    bgr = H.remap_rgb(H.load_rgb(fr.rgb_path), map1, map2)
    z = H.remap_depth(H.load_depth(fr.depth_path), map1, map2).astype(np.float64)
    h, w = z.shape
    fx, fy, cx, cy = (float(K[0, 0]), float(K[1, 1]), float(K[0, 2]), float(K[1, 2]))

    g, keep_geo, tex_mask = H.build_hybrid(bgr, z, K, TEX_Q)
    geo = H.compute_scene_geometry(z, K, H.GEO_CFG["eps"], H.GEO_CFG["gauss_sigma"],
                                   H.GEO_CFG["disc_rel"])
    metrics = H.evaluate(g, z, bgr, geo.normal, geo.valid_depth, K)

    cap = (f"SINGLE FRAME (final config)  |  frame {k}  t={fr.t_rgb:.3f}  |  "
           f"{data_name}  |  TEX_Q={TEX_Q}  |  N={len(g.mu)}")
    # (1) ellipse
    mu = g.mu.astype(np.float64)
    a1, a2 = tangent_basis(g.normal)
    r1 = g.scale[:, 0].astype(np.float64)[:, None]
    r2 = g.scale[:, 1].astype(np.float64)[:, None]
    p = (mu[:, None, :]
         + (r1 * np.cos(TH)[None, :])[..., None] * a1[:, None, :]
         + (r2 * np.sin(TH)[None, :])[..., None] * a2[:, None, :])
    zc = np.maximum(p[..., 2], 1e-6)
    u = np.clip((fx * p[..., 0] / zc + cx).astype(np.int32), 0, w - 1)
    v = np.clip((fy * p[..., 1] / zc + cy).astype(np.int32), 0, h - 1)
    epts = np.ascontiguousarray(np.stack([u, v], -1))
    vis = (bgr.astype(np.float32) * 0.5).astype(np.uint8).copy()
    for i in range(len(mu)):
        cv2.polylines(vis, [epts[i]], True, (0, 0, 255), 1, cv2.LINE_8)
    ell = np.vstack([bar([cap.replace("SINGLE FRAME (final config)", "ELLIPSE")], w), vis])
    cv2.imwrite(str(out_dir / f"f{k:02d}_ellipse.png"), ell)

    # (2) hard ray + (4) depth
    depth, index, _ = H.rasterize_discs(g, K, (h, w))
    hit = np.isfinite(depth)
    hard = np.zeros((h, w, 3), np.float32)
    hard[hit] = g.color[index[hit]]
    hard_bgr = (np.clip(hard, 0, 1) * 255).astype(np.uint8)[..., ::-1].copy()
    hard_bgr[~hit] = 0
    hard_p = np.vstack([bar([cap.replace("SINGLE FRAME (final config)", "HARD RAY")], w),
                        hard_bgr])
    cv2.imwrite(str(out_dir / f"f{k:02d}_hard.png"), hard_p)
    dep_p = save_depth(out_dir / f"f{k:02d}_depth_hard.png", depth,
                       cap.replace("SINGLE FRAME (final config)", "BACKPROJ DEPTH"))

    # (3) EWA
    color, _, weight = render_ewa(g, K, (h, w), mode="normalized", cov_scale=0.33)
    hit_e = weight > 0
    ewa = (np.clip(color, 0, 1) * 255).astype(np.uint8)[..., ::-1].copy()
    ewa[~hit_e] = 0
    ewa_p = np.vstack([bar([cap.replace("SINGLE FRAME (final config)", "EWA")], w), ewa])
    cv2.imwrite(str(out_dir / f"f{k:02d}_ewa.png"), ewa_p)

    quad = np.vstack([np.hstack([ell, hard_p]), np.hstack([ewa_p, dep_p])])
    head = bar([cap, f"N={len(g.mu)}   coverage={metrics['coverage']:.4f}   "
                     f"hole={metrics['hole_frac']:.4f}   "
                     f"depth RMSE={metrics['depth_rmse_mm']:.2f} mm   "
                     f"PSNR={metrics['color_psnr_db']:.2f} dB"], quad.shape[1])
    cv2.imwrite(str(out_dir / f"frame_{k:02d}_quad.png"), np.vstack([head, quad]))
    if not quiet:
        print(f"[{k:02d}] N={len(g.mu)} cov={metrics['coverage']:.4f} "
              f"hole={metrics['hole_frac']:.4f} rmse={metrics['depth_rmse_mm']:.2f}mm "
              f"psnr={metrics['color_psnr_db']:.2f}dB", flush=True)
    return {"frame": k, "t": fr.t_rgb, "n_gaussians": len(g.mu),
            "keep_geo": int(keep_geo.sum()), "tex_px": int(tex_mask.sum()),
            **{kk: float(v) for kk, v in metrics.items()}}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", default=str(DEFAULT_DATA))
    ap.add_argument("--out", default=str(Path(__file__).resolve().parent.parent / "results"))
    ap.add_argument("--frames", default="all", help="'all' or a comma list")
    ap.add_argument("--max-frames", type=int, default=81,
                    help="'--frames all' means the first N associated pairs; the "
                         "multi-frame line uses 81 (frames 0..80)")
    a = ap.parse_args()
    data = Path(a.dataset)
    out_dir = Path(a.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    pairs = H.associate(data, 0.02)
    if a.frames == "all":
        ks = list(range(min(a.max_frames, len(pairs))))
    else:
        ks = [int(x) for x in a.frames.split(",") if x.strip()]
    map1, map2, K = H.undistort_maps((480, 640), H.FR1_INTRINSICS)
    print(f"[single-frame] dataset={data.name}  frames={len(ks)}/{len(pairs)}  "
          f"out={out_dir}", flush=True)

    t0 = time.time()
    rows = [run_frame(k, pairs[k], map1, map2, K, out_dir, data.name) for k in ks]
    keys = ["coverage", "hole_frac", "depth_rmse_mm", "depth_med_mm", "depth_p95_mm",
            "normal_med_deg", "color_psnr_db", "n_gaussians"]
    summary = {kk: {"mean": float(np.mean([r[kk] for r in rows])),
                    "median": float(np.median([r[kk] for r in rows])),
                    "min": float(np.min([r[kk] for r in rows])),
                    "max": float(np.max([r[kk] for r in rows]))}
               for kk in keys}
    (out_dir / "metrics.json").write_text(json.dumps({
        "dataset": str(data), "tex_q": TEX_Q, "n_frames": len(rows),
        "frames": rows, "summary": summary,
    }, indent=2))
    print(f"\n[saved] {out_dir}   ({time.time() - t0:.1f} s)")
    print("summary (mean / min / max):")
    for kk in keys:
        s = summary[kk]
        print(f"  {kk:<16} {s['mean']:.4f} / {s['min']:.4f} / {s['max']:.4f}")


if __name__ == "__main__":
    main()