"""Why the top-left screen region differs so much between relink orders.

Zooms the A/B ray-disc renders and owner classification to the screen crop and
prints the disc-level bookkeeping there (birth frame, radius, colour drift,
w_col) so the pattern difference is explained by numbers, not by eye.

Run:
  python scripts/diag_screen_region_ab.py
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import cv2
import numpy as np

SEQ = Path(__file__).resolve().parent
sys.path.insert(0, str(SEQ))

import h_pipeline_final as H          # noqa: E402
import sequential_fusion_flowonly as SF  # noqa: E402

A = SEQ.parent / "output_f0_80frame_olddraw"
B = SEQ.parent / "output_f0_80frame_flowfirst"
BAR = 36
DRIFT_EPS = 0.04
DEPTH_TOL = 0.05
REGION = (10, 120, 0, 220)          # y0,y1,x0,x1 -- the screen
PAL = {1: (60, 200, 60), 2: (0, 200, 255), 3: (60, 60, 255), 4: (200, 0, 200)}


def tangent_basis(n):
    ref = np.zeros_like(n)
    ref[:, 2] = 1.0
    ref[np.abs(n[:, 2]) > 0.9] = np.array([1.0, 0.0, 0.0])
    a1 = np.cross(n, ref)
    a1 /= np.maximum(np.linalg.norm(a1, axis=1, keepdims=True), 1e-9)
    a2 = np.cross(n, a1)
    a2 /= np.maximum(np.linalg.norm(a2, axis=1, keepdims=True), 1e-9)
    return a1, a2


def load(run: Path, K, hw, z0, gt):
    d = np.load(run / "model_f0.npz")
    mu, normal, scale = d["mu"], d["normal"], d["scale"]
    color, birth, birth_color = d["color"], d["birth"], d["birth_color"]
    w_col = d["w_col"]
    a1, a2 = tangent_basis(normal)
    g = H.Gaussians(mu=mu, normal=normal, scale=scale, quat=np.zeros((len(mu), 4)),
                    color=color, alpha=np.ones(len(mu)), pixel=np.zeros((len(mu), 2)),
                    axis1=a1, axis2=a2)
    depth, index, _ = H.rasterize_discs(g, K, hw)
    hit = index >= 0
    return d, g, depth, index, hit


def main():
    pairs = SF.associate(SF.DATA, max_dt=0.02)[:81]
    sample = SF.load_rgb(pairs[0].rgb_path)
    hw = sample.shape[:2]
    map1, map2, K = SF.undistort_maps(hw, SF.FR1_INTRINSICS)
    bgr0, z0, _ = SF.load_pair(pairs, 0, map1, map2)
    gt = bgr0[..., ::-1].astype(np.float32) / 255.0

    y0, y1, x0, x1 = REGION
    reg = np.zeros(hw, bool)
    reg[y0:y1, x0:x1] = True
    print(f"region = rows {y0}:{y1} cols {x0}:{x1}  ({int(reg.sum())} px)")
    print(f"GT in region: mean RGB={gt[reg].mean(0).round(3)}  "
          f"luma={float((gt[reg] @ [0.299, 0.587, 0.114]).mean()):.3f}  "
          f"spatial std(luma)={float((gt[reg] @ [0.299, 0.587, 0.114]).std()):.3f}")

    out = {}
    for tag, run in (("A relink-first", A), ("B flow-first", B)):
        d, g, depth, index, hit = load(run, K, hw, z0, gt)
        color, birth, bcol, wc = d["color"], d["birth"], d["birth_color"], d["w_col"]
        r = np.maximum(d["scale"][:, 0], d["scale"][:, 1])
        hitr = hit & reg
        own = index[hitr]
        dc = np.linalg.norm(color - bcol, axis=1)
        err = np.linalg.norm(color[own] - gt[hitr], axis=1)
        east = np.abs(g.axis1[own, 2])
        uni = np.unique(own)
        b = birth[uni]
        print(f"\n== {tag} ==  region hit = {100 * hitr.sum() / reg.sum():.1f}% of region")
        print(f"  pixel-level: |col-GT| mean={err.mean():.3f} p90={np.percentile(err, 90):.3f}"
              f"   |col-birth| mean={dc[own].mean():.3f} p90={np.percentile(dc[own], 90):.3f}")
        print(f"  discs owning region px: {uni.size}   radius median={np.median(r[uni]) * 1000:.2f}mm"
              f" p90={np.percentile(r[uni], 90) * 1000:.2f}mm"
              f"   |n_z| of tangent frame median={np.median(east):.3f}")
        for f, nm in ((0, "born f0"), (1, "born f1-10"), (11, "born f11-40"),
                      (41, "born f41-80")):
            lo = {"born f0": (0, 0), "born f1-10": (1, 10),
                  "born f11-40": (11, 40), "born f41-80": (41, 80)}[nm]
            m = (b >= lo[0]) & (b <= lo[1])
            if m.any():
                print(f"    {nm:12s}: {int(m.sum()):5d} discs  "
                      f"r_med={np.median(r[uni][m]) * 1000:5.2f}mm  "
                      f"drift|dc| med={np.median(dc[uni][m]):.3f}  "
                      f"w_col med={np.median(wc[uni][m]):6.1f}  "
                      f"px={int(np.isin(own, uni[m]).sum()):6d}")
        split = np.zeros(hw, np.uint8)
        dcp = dc[own]
        hm = np.zeros(hw, bool)
        hm[y0:y1, x0:x1] = True
        oldm = hit & hm & (birth[index] == 0) if False else None
        # owner-class split inside the region (same rule as cmp_relink_order_yellow)
        cls = np.zeros(hw, np.uint8)
        bp = np.full(hw, -1, np.int32)
        bp[hit] = birth[index[hit]]
        dz = np.where(hit, np.abs(depth - z0) / np.maximum(z0, 1e-6), np.inf)
        on = dz < DEPTH_TOL
        cls[(hit & (bp == 0) & (dc[index] <= DRIFT_EPS))] = 1
        cls[(hit & (bp == 0) & (dc[index] > DRIFT_EPS))] = 2
        cls[(hit & (bp >= 1) & on)] = 3
        cls[(hit & (bp >= 1) & ~on)] = 4
        tot = int((cls[reg] > 0).sum())
        for k, nm in {1: "GREEN old-unchanged", 2: "YELLOW old-drifted",
                      3: "BLUE new-on-surf", 4: "MAGENTA new-off-surf"}.items():
            m = (cls == k) & reg
            print(f"    px {nm:22s}: {int(m.sum()):6d} ({100 * m.sum() / max(tot, 1):5.1f}%)")
        out[tag] = dict(err=float(err.mean()), n_disc=int(uni.size),
                        r_med=float(np.median(r[uni])), drift=float(dc[own].mean()))

    Path(A.parent / "scripts" / "diag_screen_region_ab_stats.json").write_text(
        json.dumps(out, indent=2))


if __name__ == "__main__":
    main()