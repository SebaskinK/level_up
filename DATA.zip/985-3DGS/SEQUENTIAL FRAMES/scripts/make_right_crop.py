"""Produce annotated right-edge crops of the frame-0 renders so the user can
pinpoint the 3 vertical cracks. Stacks GT / hard / depth / ewa, marks the
frame-0 GT-valid boundary (red dots), and draws a 10px grid with coordinates.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import cv2

SEQ = Path(__file__).resolve().parent
SFLOW = Path("/home/sti/Work/986-SceneFlow/scripts")
sys.path.insert(0, str(SEQ))
sys.path.insert(0, str(SFLOW))

import sequential_fusion_flowonly as SF  # noqa: E402

OUT = SEQ.parent / "output_f0_ellipse_final"
R0, R1 = 300, 440
C0, C1 = 470, 640
SCALE = 3


def annotate(crop, valid):
    out = crop.copy()
    for rr in range(crop.shape[0]):
        r = R0 + rr
        c = np.where(valid[r][C0:C1])[0]
        if c.size:
            gmax = c.max()
            cv2.circle(out, (gmax, rr), 0, (0, 0, 255), -1)
    return out


def grid(img):
    out = img.copy()
    hh, ww = out.shape[:2]
    for x in range(0, ww, 10 * SCALE):
        cv2.line(out, (x, 0), (x, hh), (0, 255, 0), 1)
    for y in range(0, hh, 10 * SCALE):
        cv2.line(out, (0, y), (ww, y), (0, 255, 0), 1)
    for x in range(0, ww, 10 * SCALE):
        col = C0 + x // SCALE
        if col % 10 == 0:
            cv2.putText(out, str(col), (x + 1, 12), cv2.FONT_HERSHEY_SIMPLEX, 0.3, (0, 255, 255), 1, cv2.LINE_AA)
    for y in range(0, hh, 10 * SCALE):
        row = R0 + y // SCALE
        if row % 10 == 0:
            cv2.putText(out, str(row), (2, y + 10), cv2.FONT_HERSHEY_SIMPLEX, 0.3, (0, 255, 255), 1, cv2.LINE_AA)
    return out


def main():
    pairs = SF.associate(SF.DATA, max_dt=0.02)[:11]
    sm = SF.load_rgb(pairs[0].rgb_path)
    h, w = sm.shape[:2]
    m1, m2, K = SF.undistort_maps((h, w), SF.FR1_INTRINSICS)
    bgr0, z0, _ = SF.load_pair(pairs, 0, m1, m2)
    valid = (z0 > 0.4) & (z0 < 4.0)

    titles = {
        "f0_gt": "GT frame0 (red dots = right edge of valid depth)",
        "f0_hard": "hard ray render",
        "f0_depth_hard": "backprojection depth (turbo)",
        "f0_ewa": "EWA render",
    }
    panels = []
    for name in titles:
        img = cv2.imread(str(OUT / f"{name}.png"))
        crop = img[R0:R1, C0:C1]
        crop = annotate(crop, valid)
        crop = cv2.resize(crop, None, fx=SCALE, fy=SCALE, interpolation=cv2.INTER_NEAREST)
        crop = grid(crop)
        label = np.full((18, crop.shape[1], 3), 30, np.uint8)
        cv2.putText(label, titles[name], (4, 12), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1, cv2.LINE_AA)
        panels.append(np.vstack([label, crop]))

    comp = np.vstack(panels)
    out_path = OUT / "crop_right_edge_annotated.png"
    cv2.imwrite(str(out_path), comp)
    print("wrote", out_path, comp.shape)


if __name__ == "__main__":
    main()